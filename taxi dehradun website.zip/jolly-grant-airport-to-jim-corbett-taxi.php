﻿<?php
$__route_slug = 'jolly-grant-airport-to-jim-corbett-taxi';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/route-head.php';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/route-template.php';
require_once __DIR__ . '/includes/footer.php';