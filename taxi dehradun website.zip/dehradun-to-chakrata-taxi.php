<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Chakrata Taxi | Tiger Falls Drops';
$page_description = 'Dehradun to Chakrata taxi: 90 km hill drive to Tiger Falls, Kalsi & Kanasar. Sedan ₹2,800, Ertiga ₹3,800, Crysta ₹4,800.';
$page_url         = $domain . "/dehradun-to-chakrata-taxi";

$__faqs = [
["How far is Chakrata from Dehradun by taxi?", "Chakrata is about 90 km from Dehradun via Vikasnagar and Kalsi route, taking around 3 to 3.5 hours of scenic hill drive."],
["What is the one-way taxi fare from Dehradun to Chakrata?", "One-way sedan taxi fare from Dehradun to Chakrata starts at ₹2,800 for a Dzire, ₹3,800 for an Ertiga (SUV), and ₹4,800 for an Innova Crysta."],
["Can I visit Tiger Falls and Kanasar on a same-day trip from Dehradun?", "Yes. You can book an 8-hour or full-day package covering Tiger Falls, Chilmiri Neck, and Kanasar pine meadows."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Chakrata Taxi Service','serviceType'=>'Outstation hill taxi transfer','description'=>'One-way and round-trip taxi from Dehradun to Chakrata over 90 km with verified hill drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Chakrata']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'2800','description'=>'One way sedan taxi fare from Dehradun to Chakrata starts from 2,800 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Chakrata Town','~90 km','2,800','3,800','4,800','/dehradun-to-chakrata-taxi'],
['Dehradun → Tiger Falls Base','~105 km','3,200','4,200','5,200','/dehradun-to-chakrata-taxi'],
['Dehradun → Kanasar Pine Forest','~115 km','3,500','4,500','5,500','/dehradun-to-chakrata-taxi'],
];

$__sights = [
['Tiger Falls','fa-water','One of the highest direct waterfalls in Uttarakhand, accessible via a short trek.'],
['Chilmiri Neck','fa-mountain','Panoramic sunset viewpoint overlooking the Himalayan peaks.'],
['Kanasar Meadows','fa-tree','Dense ancient deodar pine forests and camping spots.'],
['Kalsi Ashokan Rock Edict','fa-landmark','Historic 3rd century BCE Ashokan rock inscription on the way to Chakrata.'],
];

$__related = [
['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],['Dehradun → Dhanaulti','/dehradun-to-dhanaulti-taxi','fa-tree'],
['Dehradun → Shimla','/dehradun-to-shimla-taxi','fa-mountain'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],
];
?>
<main id="main">
<style>
.ck{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--pine:#0f766e;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eaf4f1 0%,#ffffff 440px)}
.ck *{box-sizing:border-box}
.ck .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ck .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.ck .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.ck .rv.in{opacity:1;transform:none}
.ck .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.ck .crumb a{color:var(--slate);text-decoration:none}.ck .crumb a:hover{color:var(--pine)}.ck .crumb i{font-size:.6rem;color:var(--mute)}.ck .crumb .cur{color:var(--ink);font-weight:600}
.ck .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.ck .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.ck .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.ck .hero h1 em{font-style:normal;color:var(--pine)}
.ck .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.ck .lead strong{color:var(--ink)}
.ck .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.ck .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.ck .m i{color:var(--pine)}.ck .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.ck .m span{font-size:.8rem;color:var(--slate)}
.ck .herocta{display:flex;gap:12px;flex-wrap:wrap}
.ck .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.ck .btn-p{background:var(--pine);color:#fff;box-shadow:0 16px 34px -14px rgba(15,118,110,.55)}.ck .btn-p:hover{transform:translateY(-2px)}
.ck .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.ck .btn-g:hover{transform:translateY(-2px)}
.ck .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.ck .btn-o:hover{border-color:var(--pine);color:var(--pine)}
.ck .card{position:sticky;top:88px;background:linear-gradient(160deg,#06231f,#0f766e);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(6,35,31,.6);overflow:hidden}
.ck .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#bdf3ea;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.ck .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.ck .fares{display:grid;gap:8px;margin:14px 0 0}
.ck .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.ck .fr .v{font-weight:700;font-size:.9rem}.ck .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.ck .card .cta{display:grid;gap:10px;margin-top:16px}
.ck .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.ck .card .cta .w{background:#fff;color:var(--pine)}.ck .card .cta .g{background:#25d366;color:#04260f}
.ck .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--pine);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ck .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);margin-bottom:8px}
.ck .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ck .qa strong{color:var(--ink)}
.ck .sec{padding:48px 0}
.ck .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.ck .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.ck .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.ck .sh p{color:var(--slate);margin:0}
.ck .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.ck .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.ck .sico{flex:none;width:44px;height:44px;border-radius:12px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:1rem}
.ck .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.ck .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.ck .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ck .tscroll{overflow-x:auto}
.ck table{width:100%;border-collapse:collapse;min-width:560px}
.ck th,.ck td{padding:15px 18px;text-align:left;font-size:.92rem}
.ck thead th{background:var(--soft);color:var(--pine);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.ck tbody tr{border-top:1px solid var(--line)}
.ck .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.ck .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.ck .rchip i{color:var(--pine)}.ck .rchip:hover{border-color:var(--pine);color:var(--pine);transform:translateY(-2px)}
.ck .fbox{max-width:820px;margin:0 auto}
.ck .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.ck .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ck .ft{flex:none;width:26px;height:26px;border-radius:8px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.ck .fi.open .ft{transform:rotate(45deg)}
.ck .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ck .fi.open .fb{max-height:380px;padding:0 20px 18px}
.ck .soft{background:linear-gradient(180deg,#eaf4f1,#f6fbfa)}
.ck .cta{padding:0 0 70px}
.ck .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0f766e,transparent 55%),linear-gradient(120deg,#06231f,#0f766e);color:#fff;text-align:center;padding:50px 24px}
.ck .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ck .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ck .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ck .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.ck .cta .w{background:#fff;color:var(--pine)}.ck .cta .g{background:#25d366;color:#04260f}.ck .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.ck .hero{grid-template-columns:1fr;gap:24px}.ck .card{position:static}}
</style>

<div class="ck">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Chakrata Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-mountain"></i> Tiger Falls · 90 km</span>
<h1 class="disp">Dehradun to Chakrata <em>taxi service</em> — Tiger Falls Drops</h1>
<p class="lead"><strong>Dehradun to Chakrata taxi fare starts from ₹2,800 for a sedan.</strong> Anaya Cab Service offers scenic hill transfers to Tiger Falls, Chilmiri Neck, and Kanasar meadows with verified hill drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>90 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>3–3.5 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-mountain"></i> <b>~2,118 m</b> <span>altitude</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹2,800+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Chakrata cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chakrata taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Chakrata fare">
<span class="tag"><i class="fa-solid fa-mountain"></i> Hill fare</span>
<h3 class="disp">Dehradun → Chakrata</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹2,800</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹3,800</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹4,800</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chakrata taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> operates daily <strong>Dehradun to Chakrata taxi service</strong> (~90 km, 3.5 hours drive via Kalsi) with fixed fares starting at <strong>₹2,800 for Sedan</strong> (Dzire), <strong>₹3,800 for SUV</strong> (Ertiga), and <strong>₹4,800 for Innova Crysta</strong>. Direct drops to Tiger Falls, Chilmiri Neck, and Kanasar pine meadows.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Chakrata taxi fares by destination</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Chakrata taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Chakrata</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Chakrata taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Chakrata or Tiger Falls? Book your cab now</h2>
<p>Fixed fare, verified hill driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Chakrata cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chakrata taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ck .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ck .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

