<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

/* Rate Manager wiring — admin se change hote hi page update */
$apt_ddn = anaya_rate('airport_to_dehradun');
if ($apt_ddn <= 0) { $apt_ddn = 800; }
$apt_rish = anaya_rate('airport_to_rishikesh');
if ($apt_rish <= 0) { $apt_rish = 1500; }
$apt_har = anaya_rate('airport_to_haridwar');
if ($apt_har <= 0) { $apt_har = 1800; }
$apt_mus = anaya_rate('airport_to_mussoorie');
if ($apt_mus <= 0) { $apt_mus = 1500; }

$apt_ddn_suv = (int)round($apt_ddn * 1.3 / 50) * 50;
$apt_ddn_crys = (int)round($apt_ddn * 1.5 / 50) * 50;
$apt_rish_suv = (int)round($apt_rish * 1.3 / 50) * 50;
$apt_rish_crys = (int)round($apt_rish * 1.5 / 50) * 50;
$apt_har_suv = (int)round($apt_har * 1.3 / 50) * 50;
$apt_har_crys = (int)round($apt_har * 1.5 / 50) * 50;
$apt_mus_suv = (int)round($apt_mus * 1.3 / 50) * 50;
$apt_mus_crys = (int)round($apt_mus * 1.5 / 50) * 50;

$f_apt_ddn = number_format($apt_ddn);
$f_apt_rish = number_format($apt_rish);
$f_apt_har = number_format($apt_har);
$f_apt_mus = number_format($apt_mus);

$page_title = "Dehradun Airport Taxi | Jolly Grant Cab from ₹" | Anaya Cab";
$page_url         = $domain . "/dehradun-airport-taxi-service";

$__faqs = [
["How much is a taxi from Jolly Grant Airport to Dehradun city?", "A taxi from Jolly Grant Airport to Dehradun city (Rajpur Road, Paltan Bazaar, ISBT, Railway Station) starts at Rs " . $f_apt_ddn . " for a sedan. The journey is approximately 25 km and takes 35 to 45 minutes depending on traffic."],
["Can I book a taxi from Dehradun Airport to Rishikesh?", "Yes, we offer direct fixed-fare taxis from Jolly Grant Airport to Rishikesh starting at Rs " . $f_apt_rish . " for a sedan. The drive takes approximately 35 to 45 minutes via NH7, and we track your flight so the driver is waiting when you land."],
["Is there a prepaid taxi counter at Jolly Grant Airport?", "Yes, Jolly Grant Airport has a prepaid taxi counter inside the terminal near the arrivals gate. However, pre-booking with Anaya Cab Service gives you a confirmed vehicle, flight-tracked pickup, and often a lower fare than the prepaid counter rates."],
["Do you track my flight for airport pickups?", "Yes. When you book an airport pickup, we ask for your flight number and track it in real time. If your flight is early or delayed, the driver adjusts automatically — no waiting charges for reasonable delays."],
["How far is Jolly Grant Airport from Haridwar?", "Jolly Grant Airport is approximately 35 km from Haridwar, taking 50 to 60 minutes by taxi. Our fixed fare from the airport to Haridwar starts at Rs " . $f_apt_har . " for a sedan, with no hidden charges for tolls or parking."],
["Is taxi available at Dehradun Airport at night?", "Yes, Anaya Cab Service operates 24 hours, 7 days a week at Jolly Grant Airport. Whether your flight lands at 5 AM or 11 PM, a verified driver will be waiting at the arrivals gate with a name board."],
["What is the fare from Dehradun Airport to Mussoorie?", "A taxi from Jolly Grant Airport to Mussoorie starts at Rs " . $f_apt_mus . " for a sedan. The journey is approximately 55 km and takes 1.5 to 2 hours via the hill road, and we provide experienced hill drivers for the climb."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Jolly Grant Airport Taxi Service','serviceType'=>'Airport transfer','description'=>'24x7 taxi pickup and drop service at Jolly Grant Airport (DED) Dehradun for transfers to Dehradun city, Rishikesh, Haridwar, Mussoorie and other Uttarakhand destinations with flight tracking and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>['Dehradun','Rishikesh','Haridwar','Mussoorie','Jolly Grant Airport'],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>(string)$apt_ddn,'description'=>'Airport to Dehradun city taxi fare starts from ' . $f_apt_ddn . ' rupees for a sedan.']],
['@type'=>'CivicStructure','name'=>'Jolly Grant Airport','alternateName'=>['Dehradun Airport','DED'],'description'=>'Domestic airport serving Dehradun, Rishikesh, Haridwar and Mussoorie in Uttarakhand, India.','geo'=>['@type'=>'GeoCoordinates','latitude'=>30.1897,'longitude'=>78.1803],'address'=>['@type'=>'PostalAddress','addressLocality'=>'Dehradun','addressRegion'=>'Uttarakhand','addressCountry'=>'IN']],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun City','~25 km','35–45 min',$f_apt_ddn,number_format($apt_ddn_suv),number_format($apt_ddn_crys)],
['Rishikesh','~35 km','35–45 min',$f_apt_rish,number_format($apt_rish_suv),number_format($apt_rish_crys)],
['Haridwar','~35 km','50–60 min',$f_apt_har,number_format($apt_har_suv),number_format($apt_har_crys)],
['Mussoorie','~55 km','1.5–2 hr',$f_apt_mus,number_format($apt_mus_suv),number_format($apt_mus_crys)],
];
$__drops = [
    ['Airport to Mussoorie', 'fa-mountain-sun', 'Direct hill drop to Mall Road, Library & Picture Palace. <a href="/jolly-grant-airport-to-mussoorie-taxi" style="color:#0057ff;font-weight:700;text-decoration:none;">View Mussoorie Transfer →</a>'],
    ['Airport to Rishikesh', 'fa-water', 'Direct ashram & river resort drops in Tapovan & Ram Jhula. <a href="/jolly-grant-airport-to-rishikesh-taxi" style="color:#0057ff;font-weight:700;text-decoration:none;">View Rishikesh Transfer →</a>'],
    ['Airport to Haridwar', 'fa-om', 'Direct spiritual transfers to Har Ki Pauri and railway station. <a href="/jolly-grant-airport-to-haridwar-taxi" style="color:#0057ff;font-weight:700;text-decoration:none;">View Haridwar Transfer →</a>'],
    ['Dehradun City Center', 'fa-city', 'Rajpur Road, Paltan Bazaar, Clock Tower, ISBT, Railway Station.'],
    ['Hotels & Resorts', 'fa-hotel', 'Any hotel, resort, or homestay in Uttarakhand.'],
    ['Railway Stations', 'fa-train', 'Dehradun, Haridwar, Rishikesh railway station drops.'],
];
$__process = [
['fa-plane-arrival','Land & collect baggage','Driver tracks your flight in real time and waits at arrivals.'],
['fa-user-check','Meet & greet','Driver holds a name board at the arrivals gate with your name.'],
['fa-suitcase-rolling','Luggage assistance','Driver helps with bags and loads them into the vehicle.'],
['fa-car-side','Direct drop','Non-stop drive to your hotel, home, or next destination.'],
];
?>
<main id="main">
<style>
.ap{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--navy:#0a2540;--cyan:#00c2ff;--cyan-700:#0099cc;--cyan-tint:#e0f7ff;--soft:#f0f9ff;--green:#16a34a;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#e0f2fe 0%,#ffffff 440px)}
.ap *{box-sizing:border-box}
.ap::before{content:"";position:absolute;top:-200px;left:-120px;width:580px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,194,255,.10),transparent 70%);pointer-events:none}
.ap .ap-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.ap .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ap .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.ap .rv.in{opacity:1;transform:none}
.ap .ap-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.ap .ap-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.ap .ap-crumb a:hover{color:var(--cyan)}
.ap .ap-crumb i{font-size:.6rem;color:var(--mute)}.ap .ap-crumb .cur{color:var(--ink);font-weight:600}
.ap .ap-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.ap .ap-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan-700);background:var(--cyan-tint);padding:7px 13px;border-radius:999px}
.ap .ap-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.ap .ap-hero h1 em{font-style:normal;color:var(--cyan-700)}
.ap .ap-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.ap .ap-lead strong{color:var(--ink)}
.ap .ap-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.ap .ap-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.ap .ap-m i{color:var(--cyan)}.ap .ap-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.ap .ap-m span{font-size:.8rem;color:var(--slate)}
.ap .ap-herocta{display:flex;gap:12px;flex-wrap:wrap}
.ap .ap-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.ap .ap-btn-p{background:var(--navy);color:#fff;box-shadow:0 16px 34px -14px rgba(10,37,64,.55)}.ap .ap-btn-p:hover{transform:translateY(-2px);filter:brightness(1.15)}
.ap .ap-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.ap .ap-btn-g:hover{transform:translateY(-2px)}
.ap .ap-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.ap .ap-btn-o:hover{border-color:var(--cyan);color:var(--cyan-700)}
.ap .ap-card{position:sticky;top:88px;background:linear-gradient(160deg,var(--navy),#0e4a7a);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,.5);overflow:hidden}
.ap .ap-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.ap .ap-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px;position:relative}
.ap .ap-fares{display:grid;gap:8px;margin:14px 0 0;position:relative}
.ap .ap-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.ap .ap-fr .v{font-weight:700;font-size:.9rem}
.ap .ap-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.ap .ap-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.ap .ap-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.ap .ap-card .cta .w{background:#fff;color:var(--navy)}.ap .ap-card .cta .g{background:#25d366;color:#04260f}
.ap .ap-card .cta a:hover{transform:translateY(-2px)}
.ap .ap-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.ap .ap-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--cyan);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ap .ap-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan-700);margin-bottom:8px}
.ap .ap-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ap .ap-qa strong{color:var(--ink)}
.ap .ap-sec{padding:48px 0}
.ap .ap-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.ap .ap-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan-700);background:var(--cyan-tint);padding:7px 13px;border-radius:999px}
.ap .ap-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.ap .ap-sh p{color:var(--slate);margin:0}
.ap .ap-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ap .ap-tscroll{overflow-x:auto}
.ap table{width:100%;border-collapse:collapse;min-width:640px}
.ap th,.ap td{padding:15px 18px;text-align:left;font-size:.92rem}
.ap thead th{background:var(--soft);color:var(--cyan-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.ap tbody tr{border-top:1px solid var(--line);transition:background .2s}.ap tbody tr:hover{background:var(--soft)}
.ap td .pr{font-family:'Sora','Poppins',sans-serif;font-weight:700;color:var(--ink)}
.ap .ap-pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.ap .ap-pitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.ap .ap-pitem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.ap .ap-pico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--cyan-tint);color:var(--cyan-700);display:grid;place-items:center;font-size:1rem}
.ap .ap-pitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.ap .ap-pitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.ap .ap-dgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
.ap .ap-ditem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.ap .ap-ditem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.ap .ap-dico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--cyan-tint);color:var(--cyan-700);display:grid;place-items:center;font-size:1rem}
.ap .ap-ditem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.ap .ap-ditem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.ap .ap-prepaid{background:linear-gradient(135deg,#0a2540,#0e4a7a);border-radius:var(--radius);padding:32px;color:#fff;box-shadow:0 24px 50px -28px rgba(10,37,64,.4)}
.ap .ap-prepaid h3{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 12px;color:#fff}
.ap .ap-prepaid p{color:rgba(255,255,255,.88);line-height:1.7;margin:0 0 16px;font-size:.95rem}
.ap .ap-prepaid ul{list-style:none;padding:0;margin:0}
.ap .ap-prepaid li{padding-left:28px;position:relative;color:rgba(255,255,255,.9);line-height:1.6;margin-bottom:10px;font-size:.9rem}
.ap .ap-prepaid li::before{content:"\f00c";font-family:"Font Awesome 6 Free";font-weight:900;position:absolute;left:0;top:0;color:#c9f7dd;font-size:.85rem}
.ap .ap-fbox{max-width:820px;margin:0 auto}
.ap .ap-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.ap .ap-fi:hover{border-color:#bfe6e0}
.ap .ap-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ap .ap-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--cyan-tint);color:var(--cyan-700);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.ap .ap-fi.open .ap-ft{transform:rotate(45deg)}
.ap .ap-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ap .ap-fi.open .ap-fb{max-height:380px;padding:0 20px 18px}
.ap .ap-soft{background:linear-gradient(180deg,#e0f2fe,#f0f9ff)}
.ap .ap-cta{padding:0 0 70px}
.ap .ap-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#00c2ff,transparent 55%),linear-gradient(120deg,#0a2540,#0e4a7a);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.ap .ap-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ap .ap-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ap .ap-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ap .ap-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.ap .ap-cta .w{background:#fff;color:var(--navy)}.ap .ap-cta .g{background:#25d366;color:#04260f}.ap .ap-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.ap .ap-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.ap .ap-hero{grid-template-columns:1fr;gap:24px}.ap .ap-card{position:static}}
@media(prefers-reduced-motion:reduce){.ap *{transition:none!important;animation:none!important}.ap .rv{opacity:1!important;transform:none!important}}
</style>
<div class="ap">
<div class="ap-in">
<nav class="ap-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Airport Taxi</span></nav>
<section class="ap-hero">
<div class="rv">
<span class="ap-eyebrow"><i class="fa-solid fa-plane-departure"></i> Jolly Grant Airport</span>
<h1 class="disp">Dehradun Airport Taxi Service <em>(Jolly Grant 24x7 Pickup &amp; Drop)</em></h1>
<p class="ap-lead"><strong>Dehradun airport taxi fare starts from ₹<?php echo $f_apt_ddn; ?> for a sedan to Dehradun city.</strong> Anaya Cab Service operates round-the-clock airport transfers connecting Jolly Grant Airport (DED) to Dehradun, Rishikesh, Haridwar, and Mussoorie with real-time flight tracking, confirmed vehicles, and verified drivers.</p>
<div class="ap-metrics">
<span class="ap-m"><i class="fa-solid fa-road"></i> <b>25 km</b> <span>to Dehradun city</span></span>
<span class="ap-m"><i class="fa-regular fa-clock"></i> <b>35–45 min</b> <span>drive time</span></span>
<span class="ap-m"><i class="fa-solid fa-satellite-dish"></i> <b>Flight track</b> <span>included</span></span>
<span class="ap-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹<?php echo $f_apt_ddn; ?>+</b> <span>fixed fare</span></span>
</div>
<div class="ap-herocta">
<a class="ap-btn ap-btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book airport cab</a>
<a class="ap-btn ap-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a Jolly Grant Airport taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="ap-btn ap-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="ap-card rv" aria-label="Airport taxi fare">
<span class="tag"><i class="fa-solid fa-plane"></i> Airport fare</span>
<h3 class="disp">Jolly Grant → Your destination</h3>
<div class="ap-fares">
<div class="ap-fr"><span class="v">Dehradun City</span><span class="p">₹<?php echo $f_apt_ddn; ?></span></div>
<div class="ap-fr"><span class="v">Rishikesh</span><span class="p">₹<?php echo $f_apt_rish; ?></span></div>
<div class="ap-fr"><span class="v">Haridwar</span><span class="p">₹<?php echo $f_apt_har; ?></span></div>
<div class="ap-fr"><span class="v">Mussoorie</span><span class="p">₹<?php echo $f_apt_mus; ?></span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a Jolly Grant Airport taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">Sedan fare · SUV &amp; Crysta available · 24×7</p>
</aside>
</section>
<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="ap-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Jolly Grant Airport Taxi Fares &amp; Timing</div>
<p itemprop="text"><strong>Jolly Grant Airport (DED) is located 25 km from Dehradun city center (35–45 minutes drive).</strong> Taxi fare starts from <strong>₹<?php echo $f_apt_ddn; ?> to Dehradun City</strong>, <strong>₹<?php echo $f_apt_rish; ?> to Rishikesh</strong> (35 km), <strong>₹<?php echo $f_apt_har; ?> to Haridwar</strong> (35 km), and <strong>₹<?php echo $f_apt_mus; ?> to Mussoorie</strong> (55 km) for a Sedan. Anaya Cab Service provides 24x7 flight-tracked meet-and-greet pickup with zero surge and no waiting charges for reasonable flight delays.</p>
</div>
</div>
<!-- FARE TABLE -->
<section class="ap-sec rv"><div class="ap-in">
<div class="ap-sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Jolly Grant Airport taxi fares by destination</h2></div>
<div class="ap-twrap"><div class="ap-tscroll">
<table aria-label="Jolly Grant Airport taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Time</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td><?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td class="pr">₹<?php echo $f[5]; ?></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</div></section>
<!-- PROCESS -->
<section class="ap-sec ap-soft rv"><div class="ap-in">
<div class="ap-sh"><span class="ey"><i class="fa-solid fa-list-check"></i> How it works</span><h2 class="disp">Your airport pickup in 4 steps</h2></div>
<div class="ap-pgrid">
<?php foreach ($__process as $p): ?>
<div class="ap-pitem rv"><span class="ap-pico"><i class="fa-solid <?php echo $p[0]; ?>"></i></span><div><h3><?php echo $p[1]; ?></h3><p><?php echo $p[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- PREPAID GUIDE -->
<section class="ap-sec rv"><div class="ap-in">
<div class="ap-sh"><span class="ey"><i class="fa-solid fa-receipt"></i> Prepaid counter guide</span><h2 class="disp">Prepaid taxi vs pre-booked cab</h2></div>
<div class="ap-prepaid rv">
<h3>Prepaid Taxi Counter at Jolly Grant Airport</h3>
<p>Jolly Grant Airport has a prepaid taxi counter inside the terminal near the arrivals gate. You pay a fixed fare upfront and get a slip with the driver details. However, pre-booking with Anaya Cab Service often gives you a better deal and more convenience.</p>
<ul>
<li><strong>Pre-booking advantage:</strong> Confirmed vehicle with flight tracking — no waiting in line at the counter.</li>
<li><strong>Lower fares:</strong> Our fixed fares are often ₹200–500 less than prepaid counter rates for the same destination.</li>
<li><strong>Meet &amp; greet:</strong> Driver waits at arrivals with a name board — no searching for your cab outside.</li>
<li><strong>Flight tracking:</strong> We monitor your flight in real time; no waiting charges for reasonable delays.</li>
<li><strong>Vehicle choice:</strong> Pick from Sedan, SUV, or Innova Crysta — prepaid counter assigns random vehicles.</li>
<li><strong>WhatsApp support:</strong> 24×7 customer support for any changes or issues during your journey.</li>
</ul>
</div>
</div></section>
<!-- DROPS -->
<section class="ap-sec ap-soft rv"><div class="ap-in">
<div class="ap-sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers from the airport</h2></div>
<div class="ap-dgrid">
<?php foreach ($__drops as $d): ?>
<div class="ap-ditem rv"><span class="ap-dico"><i class="fa-solid <?php echo $d[1]; ?>"></i></span><div><h3><?php echo $d[0]; ?></h3><p><?php echo $d[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- FAQ -->
<section class="ap-sec rv" id="faq"><div class="ap-in">
<div class="ap-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Jolly Grant Airport taxi — FAQs</h2></div>
<div class="ap-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="ap-fi<?php echo $i===0?' open':''; ?>"><div class="ap-fh"><?php echo htmlspecialchars($f[0]); ?><span class="ap-ft"><i class="fa-solid fa-plus"></i></span></div><div class="ap-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- CTA -->
<section class="ap-cta rv"><div class="ap-in">
<div class="ap-ctain">
<h2 class="disp">Landing at Jolly Grant Airport?</h2>
<p>Book a fixed-fare taxi with flight tracking and meet-and-greet — confirmed before you land.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book airport cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a Jolly Grant Airport taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ap .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ap .ap-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>