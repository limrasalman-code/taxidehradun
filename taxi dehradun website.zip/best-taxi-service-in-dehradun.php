<?php
require_once __DIR__ . '/includes/config.php';

// Safe check for rates.php to avoid fatal error if file is missing
if (file_exists(__DIR__ . '/includes/rates.php')) {
    require_once __DIR__ . '/includes/rates.php';
}

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title       = "Best Taxi Service in Dehradun | Anaya Cab";
// FIX: Syntax error corrected here. Added $phone variable and closed string properly.
$page_description = "Looking for the best taxi service in Dehradun? 4.9 Star rated Anaya Cab offers verified drivers, clean AC cabs, and transparent fixed pricing. Call " . $phone . ".";
$page_url         = $domain . "/best-taxi-service-in-dehradun";

$__faqs = [
    ["Why is Anaya Cab considered the best taxi service in Dehradun?", "With a 4.9-star rating across 22+ verified Google reviews, 100% verified local chauffeurs, 5-minute doorstep pickup, and strict zero-surge pricing, Anaya Cab is trusted by thousands of travelers."],
    ["What types of cabs are available for booking?", "We maintain an extensive fleet including hatchbacks (WagonR, Glanza), sedans (Dzire, Etios), SUVs (Ertiga), luxury MPVs (Innova Crysta), and Tempo Travellers (12–17 seater)."],
    ["Are taxi services available 24/7 across Dehradun?", "Yes. We operate round-the-clock for local city transfers, late-night Jolly Grant Airport pickups, railway station drops, and outstation mountain tours."],
    ["Do I need to make an advance payment?", "No advance payment is needed for regular local rides or airport transfers. You pay directly after completing your trip."]
];

$__faq_entities = [];
foreach ($__faqs as $f) {
    $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
    [
        '@type'=>'Service',
        '@id'=>$page_url.'#service',
        'name'=>'Best Taxi Service in Dehradun',
        'serviceType'=>'Taxi Service',
        'description'=>'Award-winning 24x7 cab service in Dehradun with top-rated mountain drivers, sanitized AC vehicles, and upfront billing.',
        'provider'=>[
            '@type'=>'TaxiService',
            'name'=>'Anaya Cab Service',
            'telephone'=>$phone_tel,
            'url'=>$domain.'/'
        ],
        'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'900','description'=>'Local packages starting at ₹900.']
    ],
    ['@type'=>'BreadcrumbList','itemListElement'=>[
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>$domain.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Services','item'=>$domain.'/services'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Best Taxi Service','item'=>$page_url]
    ]],
    ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities]
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>
<main id="main">
<style>
.best-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef6ff 0%,#ffffff 460px);padding-bottom:60px}
.best-pg *{box-sizing:border-box}
.best-in{max-width:1200px;margin:0 auto;padding:0 24px}
.best-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:0.82rem;color:var(--slate);padding:24px 0 0}
.best-crumb a{color:var(--slate);text-decoration:none;transition:color 0.2s}.best-crumb a:hover{color:var(--blue)}
.best-crumb i{font-size:0.6rem;color:#94a3b8}.best-crumb .cur{color:var(--ink);font-weight:700}
.best-hero{display:grid;grid-template-columns:1.24fr 0.86fr;gap:36px;align-items:start;padding:20px 0 10px}
.best-badge{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 14px;border-radius:999px}
.best-hero h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2rem,4.4vw,3.1rem);font-weight:800;letter-spacing:-0.035em;line-height:1.06;margin:14px 0 12px;color:#07142f}
.best-hero h1 em{font-style:normal;color:var(--blue)}
/* Big Featured Hero Image Layout (Screenshot 2 Match) */
.best-hero-img-wrap{position:relative;width:100%;height:320px;border-radius:22px;overflow:hidden;margin:16px 0 20px;box-shadow:0 18px 42px -16px rgba(9,32,84,0.22);background:#07142f}
.best-hero-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease}
.best-hero-img-wrap:hover .best-hero-img{transform:scale(1.03)}
.best-lead-bold{font-weight:700;color:#07142f;font-size:1.06rem;line-height:1.55;margin:0 0 10px}
.best-lead{color:var(--slate);font-size:1rem;line-height:1.66;margin:0 0 18px;max-width:58ch}
.best-ai-box{background:#ffffff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:14px;padding:18px 20px;margin:0 0 24px;box-shadow:0 4px 16px rgba(0,87,255,0.05)}
.best-ai-box h3{font-size:0.88rem;font-weight:800;color:var(--blue);margin:0 0 6px;display:flex;align-items:center;gap:6px}
.best-ai-box p{margin:0;font-size:0.92rem;line-height:1.55;color:#334155}
.best-actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.best-btn-p{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.best-btn-w{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
.best-btn-s{display:inline-flex;align-items:center;gap:8px;padding:13px 20px;border-radius:14px;background:#fff;border:1px solid var(--line);color:#07142f;font-weight:700;text-decoration:none}
/* Right Column Luxury Fare Card (Screenshot 2 Match) */
.best-fare-card{position:sticky;top:88px;background:linear-gradient(160deg,#0a2540,#0e4a7a);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,0.5);overflow:hidden}
.best-fare-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,0.12);padding:6px 12px;border-radius:999px}
.best-fare-card h3{font-family:'Sora',sans-serif;font-size:1.25rem;font-weight:800;margin:14px 0 14px}
.best-fares-list{display:grid;gap:8px;margin:14px 0 0}
.best-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);border-radius:12px;padding:11px 14px}
.best-fr .v{font-weight:700;font-size:0.9rem}
.best-fr .p{font-family:'Sora',sans-serif;font-weight:800;color:#00c2ff}
.best-fare-card .cta{display:grid;gap:10px;margin-top:16px}
.best-fare-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform 0.2s}
.best-fare-card .cta .w{background:#fff;color:#0a2540}
.best-fare-card .cta .g{background:#25d366;color:#04260f}
.best-fare-card .cta a:hover{transform:translateY(-2px)}
.best-fare-card .note{font-size:0.76rem;color:rgba(255,255,255,0.66);text-align:center;margin:12px 0 0}
.best-sec{padding:48px 0;border-top:1px solid var(--line)}
.best-sec h2{font-family:'Sora',sans-serif;font-size:clamp(1.7rem,3.4vw,2.3rem);font-weight:800;color:#07142f;margin:0 0 16px;letter-spacing:-0.03em}
.best-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:24px}
.best-box{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 4px 16px rgba(11,18,32,0.04)}
.best-box h4{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#07142f;margin:0 0 8px}
.best-box p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
.best-faq-item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 22px;margin-bottom:12px}
.best-faq-item h4{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#07142f;margin:0 0 8px}
.best-faq-item p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
@media (max-width:960px){.best-hero{grid-template-columns:1fr;gap:24px}.best-hero-img-wrap{height:230px;border-radius:16px}.best-fare-card{position:static}.best-in{padding:0 16px}}
</style>
<div class="best-pg">
<div class="best-in">
<nav class="best-crumb" aria-label="Breadcrumb">
<a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>
<a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i>
<span class="cur">Best Taxi Service</span>
</nav>
<div class="best-hero">
<div>
<span class="best-badge"><i class="fa-solid fa-star"></i> 4.9★ RATED · 24×7 CAB SERVICE</span>
<h1>Best Taxi Service in <em>Dehradun</em></h1>
<div class="best-hero-img-wrap">
<img 
src="/assets/images/services/local-taxi-in-dehradun.webp" 
alt="Best Taxi Service in Dehradun - Anaya Cab" 
width="680" 
height="360" 
loading="eager" 
decoding="async" 
class="best-hero-img"
>
</div>
<p class="best-lead-bold">Top-rated 24x7 cab booking in Dehradun starting at ₹900 for city packages and ₹800 to Jolly Grant Airport.</p>
<p class="best-lead">Looking for the best taxi service in Dehradun? Anaya Cab Service delivers immaculate AC cars, courteous mountain-expert drivers, guaranteed on-time pickups, and 100% upfront pricing with zero hidden charges.</p>
<div class="best-ai-box">
<h3><i class="fa-solid fa-bolt"></i> Quick Direct Answer</h3>
<p>Anaya Cab Service is recognized as the best taxi service in Dehradun with a 4.9★ rating (22 Google reviews). We provide local hourly rentals from ₹900, flat airport drops from ₹800, and outstation trips with verified drivers.</p>
</div>
<div class="best-actions">
<a class="best-btn-p" href="/#booking"><i class="fa-solid fa-car-side"></i> Book Taxi Now</a>
<a class="best-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need the best taxi service in Dehradun'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="best-btn-s" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<!-- Right Column Luxury Fare Card (Screenshot 2 Match) -->
<aside class="best-fare-card" aria-label="Popular Dehradun taxi rates">
<span class="tag"><i class="fa-solid fa-bolt"></i> Guaranteed Rates</span>
<h3>Dehradun → Top Routes</h3>
<div class="best-fares-list">
<div class="best-fr"><span class="v">Jolly Grant Airport Drop</span><span class="p">₹800</span></div>
<div class="best-fr"><span class="v">Local Sightseeing (8h/80k)</span><span class="p">₹1,600</span></div>
<div class="best-fr"><span class="v">Mussoorie Hill Station</span><span class="p">₹1,050</span></div>
<div class="best-fr"><span class="v">Rishikesh / Haridwar</span><span class="p">₹1,150</span></div>
<div class="best-fr"><span class="v">Delhi NCR Expressway</span><span class="p">₹3,500</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need to book a taxi'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">Sedan fare · SUV &amp; Crysta available · 24×7</p>
</aside>
</div>
<section class="best-sec">
<h2>Why Anaya Cab is the #1 Rated Taxi Service</h2>
<div class="best-grid">
<div class="best-box">
<h4><i class="fa-solid fa-award" style="color:var(--blue);margin-right:8px;"></i> 4.9★ Real Customer Rating</h4>
<p>Backed by genuine traveler reviews for exceptional cleanliness, punctual pickup, and polite drivers.</p>
</div>
<div class="best-box">
<h4><i class="fa-solid fa-clock" style="color:#16a34a;margin-right:8px;"></i> 5-Minute Rapid Doorstep Pickup</h4>
<p>Cabs positioned across all Dehradun sectors ensuring the fastest response times.</p>
</div>
<div class="best-box">
<h4><i class="fa-solid fa-file-invoice-dollar" style="color:#f59e0b;margin-right:8px;"></i> 100% Upfront Pricing</h4>
<p>Transparent rates with no surge pricing, no hidden extras, and automated digital receipts.</p>
</div>
</div>
</section>
<section class="best-sec">
<h2>Frequently Asked Questions</h2>
<?php foreach ($__faqs as $faq): ?>
<div class="best-faq-item">
<h4><?php echo htmlspecialchars($faq[0]); ?></h4>
<p><?php echo htmlspecialchars($faq[1]); ?></p>
</div>
<?php endforeach; ?>
</section>
</div>
</div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>