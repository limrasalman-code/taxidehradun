<?php
/**
 * Anaya Cab Service — Homepage
 * Production / SEO / AEO / GEO / Booking optimized
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/fleet-config.php';

/*
|--------------------------------------------------------------------------
| Safe configuration values
|--------------------------------------------------------------------------
*/
$domain    = defined('SITE_DOMAIN') ? rtrim((string)SITE_DOMAIN, '/') : '';
$phone     = defined('BUSINESS_PHONE') ? (string)BUSINESS_PHONE : '';
$phoneTel  = defined('BUSINESS_PHONE_TEL') ? (string)BUSINESS_PHONE_TEL : '';
$whatsapp  = defined('BUSINESS_WHATSAPP') ? (string)BUSINESS_WHATSAPP : '';
$email     = defined('BUSINESS_EMAIL') ? (string)BUSINESS_EMAIL : '';
$address   = defined('BUSINESS_FULL_ADDRESS')
    ? (string)BUSINESS_FULL_ADDRESS
    : 'Dehradun, Uttarakhand, India';

$businessName = defined('SITE_NAME')
    ? (string)SITE_NAME
    : 'Anaya Cab Service';

$latitude = defined('BUSINESS_LATITUDE')
    ? (string)BUSINESS_LATITUDE
    : '30.291308';

$longitude = defined('BUSINESS_LONGITUDE')
    ? (string)BUSINESS_LONGITUDE
    : '77.996000';

$googleProfile = defined('GOOGLE_BUSINESS_PROFILE_URL')
    ? (string)GOOGLE_BUSINESS_PROFILE_URL
    : '';

$googleMaps = defined('GOOGLE_BUSINESS_MAPS_URL')
    ? (string)GOOGLE_BUSINESS_MAPS_URL
    : '';

/*
|--------------------------------------------------------------------------
| Homepage SEO
|--------------------------------------------------------------------------
*/
$page_title = 'Taxi Service in Dehradun | 24x7 Cab Booking | Anaya Cab';

$page_description = 'Book 24x7 taxi in Dehradun – airport cabs ₹800, local rides ₹12/km, Delhi & Char Dham trips. Verified drivers, fixed fares. Call now.';

$page_url = $domain . '/';

/*
|--------------------------------------------------------------------------
| Conversational Voice-Search FAQs (AEO Optimized)
|--------------------------------------------------------------------------
*/
$__faqs = [
    [
        'What is the best cab service in Dehradun?',
        'Anaya Cab Service (+91 80776 11583) is rated 4.9★ on Google, providing 24x7 airport taxi, local city cabs, outstation cabs, Char Dham Yatra tours, and luxury tempo traveller rentals with police-verified drivers and transparent fixed fares.'
    ],
    [
        'How much is a taxi from Dehradun to Delhi?',
        'One-way taxi fare from Dehradun to Delhi is ₹3,500 for a Sedan (Dzire) covering 213 km in 2.5 to 3 hours via the new expressway. Ertiga SUV is ₹4,550 and Innova Crysta is ₹5,250. Round-trip sedan package starts at ₹5,000.'
    ],
    [
        'What is the taxi fare from Dehradun to Mussoorie?',
        'One-way taxi fare from Dehradun to Mussoorie is ₹1,050 for a Sedan (Dzire) and ₹1,450 for an Ertiga SUV. Full-day sightseeing packages to Kempty Falls, Dhanaulti, and George Everest start from ₹2,200.'
    ],
    [
        'Do you provide Jolly Grant Airport taxi service?',
        'Yes. Anaya Cab Service provides 24x7 flight-tracked pickup and drop service between Dehradun and Jolly Grant Airport from ₹800 to ₹1,200 with meet-and-greet arrivals and zero waiting penalties on delayed flights.'
    ],
    [
        'Are your drivers experienced on Uttarakhand hill routes?',
        'Yes. All Anaya Cab chauffeurs possess minimum 5+ years of verified mountain driving experience across Mussoorie, Nainital, Chopta, and the high-altitude Char Dham circuit.'
    ],
    [
        'Which areas in Dehradun do you cover for local pickups?',
        'We provide 5 to 15-minute doorstep pickup across all Dehradun localities including Rajpur Road, Jakhan, Hathibarkala, Dalanwala, Karanpur, Race Course, Dharampur, Patel Nagar, Clement Town, ISBT, GMS Road, Ballupur, Prem Nagar, Vasant Vihar, Kaulagarh, Indra Nagar, Sahastradhara, and Bajawala.'
    ],
    [
        'What is the starting taxi fare in Dehradun for local rentals?',
        'Local hourly packages start at ₹900 for 4 hours / 40 km (Hatchback), ₹1,100 (Sedan), ₹1,350 (Ertiga), and ₹1,600 (Innova Crysta). Extra km rates start from ₹11/km.'
    ],
    [
        'How do I book a cab with Anaya Cab Service?',
        'You can book online through https://www.taxidehradun.com/, call our 24x7 desk at +91 80776 11583, or message us on WhatsApp for instant 60-second confirmation.'
    ]
];

$__faq_entities = [];
foreach ($__faqs as $faq) {
    $__faq_entities[] = [
        '@type' => 'Question',
        'name' => $faq[0],
        'acceptedAnswer' => [
            '@type' => 'Answer',
            'text' => $faq[1]
        ]
    ];
}

/*
|--------------------------------------------------------------------------
| JSON-LD Master Graph Schema
|--------------------------------------------------------------------------
*/
$schema_graph = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => [
                'LocalBusiness',
                'TaxiService'
            ],
            '@id' => $domain . '/#taxi-service',
            'name' => $businessName,
            'url' => $domain . '/',
            'telephone' => $phoneTel,
            'email' => $email,
            'description' => $page_description,
            'priceRange' => '₹₹',
            'currenciesAccepted' => 'INR',
            'image' => [
                $domain . '/assets/images/logo-source-original.png'
            ],
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => 'Shimla Bypass Road, Near St. Jude\'s School, Shanti Vihar Colony, Sewla Kalan Majra',
                'addressLocality' => 'Dehradun',
                'addressRegion' => 'Uttarakhand',
                'postalCode' => '248001',
                'addressCountry' => 'IN'
            ],
            'geo' => [
                '@type' => 'GeoCoordinates',
                'latitude' => (float)$latitude,
                'longitude' => (float)$longitude
            ],
            'openingHoursSpecification' => [
                '@type' => 'OpeningHoursSpecification',
                'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                'opens' => '00:00',
                'closes' => '23:59'
            ],
            'areaServed' => [
                ['@type' => 'City', 'name' => 'Dehradun'],
                ['@type' => 'AdministrativeArea', 'name' => 'Uttarakhand'],
                ['@type' => 'City', 'name' => 'Haridwar'],
                ['@type' => 'City', 'name' => 'Rishikesh'],
                ['@type' => 'City', 'name' => 'Mussoorie'],
                ['@type' => 'City', 'name' => 'Delhi']
            ],
            
            'contactPoint' => [
                '@type' => 'ContactPoint',
                'telephone' => $phoneTel,
                'contactType' => 'customer service',
                'availableLanguage' => ['English', 'Hindi']
            ],
            'sameAs' => array_values(
                array_filter([
                    defined('SOCIAL_FACEBOOK') ? SOCIAL_FACEBOOK : '',
                    defined('SOCIAL_INSTAGRAM') ? SOCIAL_INSTAGRAM : '',
                    defined('SOCIAL_LINKEDIN') ? SOCIAL_LINKEDIN : '',
                    $googleProfile
                ])
            )
        ],
        [
            '@type' => 'WebSite',
            '@id' => $domain . '/#website',
            'url' => $domain . '/',
            'name' => $businessName,
            'publisher' => ['@id' => $domain . '/#taxi-service'],
            'inLanguage' => 'en-IN'
        ],
        [
            '@type' => 'WebPage',
            '@id' => $domain . '/#webpage',
            'url' => $domain . '/',
            'name' => $page_title,
            'description' => $page_description,
            'isPartOf' => ['@id' => $domain . '/#website'],
            'about' => ['@id' => $domain . '/#taxi-service'],
            'inLanguage' => 'en-IN'
        ],
        [
            '@type' => 'FAQPage',
            '@id' => $domain . '/#faq',
            'mainEntity' => $__faq_entities
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $domain . '/#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => $domain . '/'
                ]
            ]
        ]
    ]
];

$page_schema =
    '<script type="application/ld+json">' .
    json_encode(
        $schema_graph,
        JSON_UNESCAPED_SLASHES |
        JSON_UNESCAPED_UNICODE |
        JSON_HEX_TAG |
        JSON_HEX_AMP |
        JSON_HEX_APOS |
        JSON_HEX_QUOT
    ) .
    '</script>';

require_once __DIR__ . '/includes/header.php';

/*
|--------------------------------------------------------------------------
| Fleet visual metadata
|--------------------------------------------------------------------------
*/
$fleet_meta = [
    'dzire' => [
        'Sedan',
        '#0057ff',
        'fa-car'
    ],

    'zest' => [
        'Hatchback',
        '#12b76a',
        'fa-car'
    ],

    'ertiga' => [
        'MPV',
        '#7c3aed',
        'fa-car-rear'
    ],

    'innova' => [
        'MPV',
        '#f79009',
        'fa-van-shuttle'
    ],

    'innova-crysta' => [
        'Premium MPV',
        '#0891b2',
        'fa-van-shuttle'
    ],

    'tempo' => [
        'Traveller',
        '#0891b2',
        'fa-bus-simple'
    ],

    'urbania' => [
        'Luxury Van',
        '#e11d48',
        'fa-bus-simple'
    ]
];

/*
|--------------------------------------------------------------------------
| Services
|--------------------------------------------------------------------------
*/
$services_premium = [

    [
        'eyebrow' => 'City rides',
        'ico' => 'fa-shield-halved',
        'word1' => 'Local',
        'word2' => 'Taxi',
        'desc' => 'Hourly and point-to-point taxi rides across Dehradun for markets, stations, hospitals, offices and local travel.',
        'url' => '/local-taxi-in-dehradun',
        'ac' => '#0057ff',
        'tint' => '#eef4ff',
        'glyph' => 'fa-taxi',
        'img' => '/assets/images/services/local-taxi-in-dehradun.webp'
    ],

    [
        'eyebrow' => 'Airport travel',
        'ico' => 'fa-plane-departure',
        'word1' => 'Airport',
        'word2' => 'Transfer',
        'desc' => 'Reliable taxi pickup and drop service between Dehradun and Jolly Grant Airport.',
        'url' => '/dehradun-airport-taxi-service',
        'ac' => '#0891b2',
        'tint' => '#e6f7fb',
        'glyph' => 'fa-plane-departure',
        'img' => '/assets/images/services/dehradun-airport-taxi-service.webp'
    ],

    [
        'eyebrow' => 'Beyond the city',
        'ico' => 'fa-mountain-sun',
        'word1' => 'Outstation',
        'word2' => 'Taxi',
        'desc' => 'One-way and round-trip taxi service from Dehradun to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital and more.',
        'url' => '/outstation-taxi-from-dehradun',
        'ac' => '#16a34a',
        'tint' => '#e9f8ef',
        'glyph' => 'fa-mountain-sun',
        'img' => '/assets/images/services/outstation-taxi-from-dehradun.webp'
    ],

    [
        'eyebrow' => 'Divine journey',
        'ico' => 'fa-om',
        'word1' => 'Char Dham',
        'word2' => 'Yatra',
        'desc' => 'Taxi and tempo traveller options for Char Dham Yatra with experienced Uttarakhand hill-route drivers.',
        'url' => '/char-dham-yatra-taxi',
        'ac' => '#ea7317',
        'tint' => '#fff2e6',
        'glyph' => 'fa-om',
        'img' => '/assets/images/routes/char-dham-yatra-taxi.webp'
    ]
];

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
*/
$route_links = [
    [
        'Haridwar',
        55,
        '/dehradun-to-haridwar-taxi'
    ],
    [
        'Rishikesh',
        45,
        '/dehradun-to-rishikesh-taxi'
    ],
    [
        'Mussoorie',
        35,
        '/dehradun-to-mussoorie-taxi'
    ],
    [
        'Delhi',
        250,
        '/dehradun-to-delhi-taxi'
    ],
    [
        'Nainital',
        280,
        '/dehradun-to-nainital-taxi'
    ],
    [
        'Char Dham',
        null,
        '/char-dham-yatra-taxi'
    ]
];

/*
|--------------------------------------------------------------------------
| Fare rows
|--------------------------------------------------------------------------
*/
$fare_rows = [
    [
        'Dehradun → Jolly Grant Airport',
        'jolly grant airport',
        '/dehradun-airport-taxi-service'
    ],
    [
        'Dehradun → Haridwar',
        'haridwar',
        '/dehradun-to-haridwar-taxi'
    ],
    [
        'Dehradun → Rishikesh',
        'rishikesh',
        '/dehradun-to-rishikesh-taxi'
    ],
    [
        'Dehradun → Mussoorie',
        'mussoorie',
        '/dehradun-to-mussoorie-taxi'
    ],
    [
        'Dehradun → Delhi',
        'delhi',
        '/dehradun-to-delhi-taxi'
    ],
    [
        'Dehradun → Nainital',
        'nainital',
        '/dehradun-to-nainital-taxi'
    ]
];

/*
|--------------------------------------------------------------------------
| Blog
|--------------------------------------------------------------------------
*/
$latest_blogs = [
    [
        'slug' => 'best-time-to-visit-mussoorie',
        'title' => 'Best Time to Visit Mussoorie',
        'excerpt' => 'Season-by-season guide for weather, sightseeing and the best time to plan your Mussoorie trip.',
        'tag' => 'Travel Guide',
        'icon' => 'fa-mountain-sun',
        'time' => '6 min'
    ],

    [
        'slug' => 'dehradun-to-mussoorie-distance-taxi',
        'title' => 'Dehradun to Mussoorie Distance',
        'excerpt' => 'Route distance, approximate travel time, taxi options and useful tips for the hill drive.',
        'tag' => 'Route Guide',
        'icon' => 'fa-route',
        'time' => '5 min'
    ],

    [
        'slug' => 'char-dham-yatra-planning-guide',
        'title' => 'Char Dham Yatra Planning Guide',
        'excerpt' => 'A practical first-timer guide to planning your Char Dham Yatra from Uttarakhand.',
        'tag' => 'Yatra Guide',
        'icon' => 'fa-om',
        'time' => '8 min'
    ]
];

$reviews_google = [
    [
        'name' => 'Archit Rawat',
        'badge' => 'Google Verified Customer',
        'text' => 'great cab, best drivers with respect',
        'rating' => 5,
        'date' => '3 weeks ago'
    ],
    [
        'name' => 'prateek pant',
        'badge' => 'Google Verified Customer',
        'text' => 'best cab in dehradun, on time',
        'rating' => 5,
        'date' => '1 month ago'
    ],
    [
        'name' => 'Deepak Rawat',
        'badge' => 'Google Verified Customer',
        'text' => 'Best cab service in Dehradun! Timely, clean cars, and polite drivers. Highly recommended for airport transfers and outstation trips',
        'rating' => 5,
        'date' => '1 month ago'
    ],
    [
        'name' => 'Mansi Tyagi',
        'badge' => 'Google Verified Customer',
        'text' => 'Had a great experience with Anaya cab service. Driver was on time and very helpful. Highly recommended.',
        'rating' => 5,
        'date' => '2 months ago'
    ]
];

$waDefaultText = rawurlencode(
    'Hi Anaya Cab, I want to book a taxi.'
);

$waVerifyText = rawurlencode(
    'Hi Anaya Cab, I want to verify and book a taxi.'
);

$mapQuery = rawurlencode(
    'Anaya Cab Service, Dehradun, Uttarakhand'
);
?>

<main id="main-content">

<?php
if (file_exists(__DIR__ . '/includes/slider.php')) {
    require __DIR__ . '/includes/slider.php';
} elseif (file_exists(__DIR__ . '/slider.php')) {
    require __DIR__ . '/slider.php';
}
?>
<?php 
// Google Preferred Source Button (Homepage Placement)
if (function_exists('gps_render_button')) { gps_render_button('home'); } 
?>
<div id="hm">

<style>
@property --angle{
    syntax:'<angle>';
    initial-value:0deg;
    inherits:false
}

#hm-scroll-progress{
    position:fixed;
    top:0;
    left:0;
    height:3px;
    background:linear-gradient(90deg,#0057ff,#00c2ff);
    z-index:9999;
    width:0;
    transition:width .1s linear;
    box-shadow:0 0 10px rgba(0,87,255,.6)
}

#hm{
    --blue:#0057ff;
    --cyan:#00c2ff;
    --ink:#0a0f1e;
    --slate:#5b6577;
    --mute:#94a3b8;
    --line:#e7edf6;
    --cloud:#f4f7fb;
    --r:22px;
    --rs:14px;
    font-family:'Plus Jakarta Sans',system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    color:var(--ink);
    overflow-x:hidden
}

#hm *,
#hm *::before,
#hm *::after{
    box-sizing:border-box
}

#hm .disp{
    font-family:'Sora','Poppins',sans-serif;
    letter-spacing:-.04em;
    line-height:1.06
}

#hm .wrap{
    max-width:1220px;
    margin:0 auto;
    padding:0 24px
}

#hm .rv{
    opacity:0;
    transform:translateY(40px)
}

#hm .rv.in{
    opacity:1;
    transform:none;
    transition:
        opacity .9s cubic-bezier(.16,1,.3,1),
        transform .9s cubic-bezier(.16,1,.3,1)
}

#hm .eyebrow{
    display:inline-flex;
    align-items:center;
    gap:9px;
    font-size:.68rem;
    font-weight:800;
    letter-spacing:.16em;
    text-transform:uppercase;
    color:var(--blue);
    background:rgba(0,87,255,.08);
    padding:8px 16px;
    border-radius:999px
}

#hm .sec{
    padding:84px 0
}

#hm .sec-head{
    margin-bottom:42px;
    max-width:720px
}

#hm .sec-head.center{
    margin-inline:auto;
    text-align:center
}

#hm .sec-head h2{
    font-family:'Sora','Poppins',sans-serif;
    font-size:clamp(1.9rem,4.2vw,2.9rem);
    font-weight:800;
    letter-spacing:-.04em;
    margin:16px 0 12px
}

#hm .sec-head p{
    color:var(--slate);
    font-size:1.06rem;
    line-height:1.7
}

#hm .sec-head p a{
    color:var(--blue);
    font-weight:700;
    text-decoration:none
}

#hm .soft{
    background:linear-gradient(180deg,#eef4fc,#f7faff)
}

#hm .hbtn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700;
    font-size:.94rem;
    padding:14px 26px;
    border-radius:14px;
    border:1px solid transparent;
    cursor:pointer;
    transition:all .3s cubic-bezier(.16,1,.3,1);
    text-decoration:none;
    position:relative;
    overflow:hidden
}

#hm .hbtn-p{
    background:linear-gradient(135deg,#0057ff,#00c2ff);
    color:#fff;
    box-shadow:0 16px 40px -14px rgba(0,120,255,.55)
}

#hm .hbtn-p:hover{
    transform:translateY(-3px);
    box-shadow:0 24px 54px -16px rgba(0,120,255,.7)
}

#hm .hbtn-o{
    background:#fff;
    color:var(--ink);
    border-color:var(--line)
}

#hm .hbtn-o:hover{
    border-color:var(--blue);
    color:var(--blue);
    transform:translateY(-2px)
}

#hm .hbtn-wa{
    background:linear-gradient(135deg,#25d366,#128c7e);
    color:#fff;
    box-shadow:0 14px 34px -10px rgba(37,211,102,.5)
}

#hm .hbtn-wa:hover{
    transform:translateY(-2px)
}

/* BOOKING */

#hm .bk-sec{
    padding:56px 0 64px;
    background:
        radial-gradient(
            90% 70% at 50% 0%,
            rgba(0,87,255,.07),
            transparent 70%
        ),
        #fff;
    scroll-margin-top:86px
}

#hm .bk-card{
    position:relative;
    border-radius:26px;
    background:#fff;
    border:1px solid var(--line);
    box-shadow:0 30px 80px -30px rgba(9,32,84,.28);
    display:grid;
    grid-template-columns:.85fr 1.15fr
}

#hm .bk-card::before{
    content:"";
    position:absolute;
    inset:-2px;
    border-radius:28px;
    padding:2px;
    background:
        conic-gradient(
            from var(--angle),
            transparent 0deg,
            rgba(0,87,255,0) 60deg,
            #0057ff 110deg,
            #00c2ff 160deg,
            rgba(0,194,255,0) 220deg,
            transparent 360deg
        );
    -webkit-mask:
        linear-gradient(#fff 0 0) content-box,
        linear-gradient(#fff 0 0);
    -webkit-mask-composite:xor;
    mask-composite:exclude;
    animation:hm-orbit 5s linear infinite;
    pointer-events:none;
    z-index:2
}

@keyframes hm-orbit{
    to{
        --angle:360deg
    }
}

#hm .bk-aside{
    background:
        radial-gradient(
            120% 100% at 100% 0%,
            #1e4bff,
            transparent 60%
        ),
        linear-gradient(160deg,#03102e,#0057ff);
    color:#fff;
    padding:34px 32px;
    border-radius:26px 0 0 26px;
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:14px
}

#hm .bk-aside .live{
    align-self:flex-start;
    display:inline-flex;
    align-items:center;
    gap:8px;
    font-size:.7rem;
    font-weight:800;
    color:#c9f7dd;
    background:rgba(255,255,255,.14);
    padding:6px 13px;
    border-radius:999px;
    letter-spacing:.06em
}

#hm .bk-aside .live::before{
    content:"";
    width:7px;
    height:7px;
    border-radius:50%;
    background:#34e39b;
    animation:hm-pulse 1.8s infinite
}

@keyframes hm-pulse{
    70%{
        box-shadow:0 0 0 8px rgba(52,227,155,0)
    }

    100%{
        box-shadow:0 0 0 0 rgba(52,227,155,0)
    }
}

#hm .bk-aside h2{
    font-family:'Sora','Poppins',sans-serif;
    font-weight:800;
    font-size:1.55rem;
    letter-spacing:-.02em;
    line-height:1.15
}

#hm .bk-aside p{
    color:rgba(255,255,255,.8);
    font-size:.92rem;
    line-height:1.65
}

#hm .bk-aside ul{
    list-style:none;
    display:flex;
    flex-direction:column;
    gap:10px;
    padding:0
}

#hm .bk-aside li{
    display:flex;
    gap:10px;
    color:rgba(255,255,255,.92);
    font-size:.88rem
}

#hm .bk-aside li i{
    color:#8fd0ff;
    margin-top:3px
}

#hm .bk-form{
    padding:26px 28px 24px
}

#hm .bk-mhead{
    display:none;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    margin-bottom:14px
}

#hm .bk-mhead h2{
    font-family:'Sora','Poppins',sans-serif;
    font-size:1.15rem;
    font-weight:800
}

#hm .bk-mhead .live{
    display:inline-flex;
    align-items:center;
    gap:7px;
    font-size:.66rem;
    font-weight:800;
    color:#16a34a;
    background:#dcfce7;
    padding:5px 11px;
    border-radius:999px
}

#hm .bk-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px 12px
}

#hm .fld.full{
    grid-column:1/-1
}

#hm .fld label{
    display:block;
    font-size:.62rem;
    font-weight:800;
    color:var(--slate);
    margin-bottom:5px;
    letter-spacing:.08em;
    text-transform:uppercase
}

#hm .iw{
    position:relative;
    display:flex;
    align-items:center
}

#hm .iw i{
    position:absolute;
    left:13px;
    color:var(--mute);
    font-size:.82rem;
    pointer-events:none;
    z-index:1
}

#hm .iw input,
#hm .iw select{
    width:100%;
    height:46px;
    padding:0 12px 0 38px;
    border:1.5px solid var(--line);
    border-radius:12px;
    font:inherit;
    font-size:.9rem;
    background:var(--cloud);
    transition:border .2s,box-shadow .2s,background .2s;
    color:var(--ink)
}

#hm .iw input:focus,
#hm .iw select:focus{
    outline:none;
    border-color:var(--blue);
    background:#fff;
    box-shadow:0 0 0 4px rgba(0,87,255,.1)
}

#hm .fare-chip{
    grid-column:1/-1;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    background:rgba(0,87,255,.06);
    border:1.5px dashed #b9d0ff;
    border-radius:12px;
    padding:10px 14px
}

#hm .fare-chip[hidden]{
    display:none
}

#hm .fare-chip .l{
    font-size:.74rem;
    font-weight:800;
    color:#0039ad;
    display:flex;
    align-items:center;
    gap:7px
}

#hm .fare-chip .v{
    font-family:'Sora','Poppins',sans-serif;
    font-weight:800;
    font-size:1.1rem;
    color:var(--blue)
}

#hm .fare-chip .v.neutral{
    font-size:.85rem;
    font-weight:700;
    color:var(--slate)
}

#hm .book-btn{
    grid-column:1/-1;
    width:100%;
    font-size:.98rem;
    padding:15px
}

#hm .book-note{
    grid-column:1/-1;
    text-align:center;
    font-size:.72rem;
    color:var(--slate)
}

/* STATS */

#hm .stats-strip{
    padding:26px 0
}

#hm .strip-card{
    position:relative;
    background:rgba(255,255,255,.92);
    backdrop-filter:blur(16px);
    border:1px solid #e3ebf6;
    border-radius:22px;
    box-shadow:0 20px 50px rgba(10,22,51,.08);
    display:grid;
    grid-template-columns:repeat(4,1fr);
    overflow:hidden
}

#hm .strip-item{
    position:relative;
    padding:18px 12px;
    text-align:center;
    border-right:1px solid #eef2f8;
    transition:background .25s,transform .3s
}

#hm .strip-item:last-child{
    border-right:0
}

#hm .strip-item:hover{
    background:rgba(0,87,255,.05);
    transform:translateY(-3px)
}

#hm .strip-item i{
    display:inline-grid;
    place-items:center;
    width:40px;
    height:40px;
    border-radius:999px;
    background:rgba(0,87,255,.1);
    color:var(--blue);
    font-size:1rem;
    margin-bottom:8px
}

#hm .strip-item strong{
    display:block;
    font-family:'Sora','Poppins',sans-serif;
    font-size:1.05rem;
    color:#07142f
}

#hm .strip-item span{
    display:block;
    color:#5b6b8c;
    font-size:.8rem;
    margin-top:4px
}

/* COMMON */

#hm .split{
    display:grid;
    grid-template-columns:1.05fr .95fr;
    gap:52px;
    align-items:center
}

#hm .panel{
    background:#fff;
    border:1px solid var(--line);
    border-radius:var(--r);
    padding:32px;
    box-shadow:0 14px 40px -18px rgba(9,32,84,.18)
}

#hm .list-check{
    list-style:none;
    margin:20px 0 0;
    padding:0;
    display:flex;
    flex-direction:column;
    gap:13px
}

#hm .list-check li{
    display:flex;
    gap:12px;
    color:var(--slate);
    font-size:.95rem;
    line-height:1.6
}

#hm .list-check i{
    color:var(--blue);
    margin-top:4px;
    flex:none
}

/* FLEET */

#hm .fleet-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:24px
}

#hm .fcard{
    position:relative;
    border-radius:24px;
    background:#fff;
    border:1px solid var(--line);
    overflow:hidden;
    transition:box-shadow .5s,transform .25s;
    box-shadow:
        0 2px 6px rgba(11,18,32,.05),
        0 22px 54px -22px rgba(9,32,84,.18)
}

#hm .fcard:hover{
    transform:translateY(-6px);
    box-shadow:
        0 2px 6px rgba(11,18,32,.06),
        0 44px 90px -28px rgba(9,32,84,.34)
}

#hm .fcard::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    right:0;
    height:4px;
    background:var(--ac);
    z-index:5;
    transform:scaleX(0);
    transform-origin:left;
    transition:transform .5s
}

#hm .fcard:hover::before{
    transform:scaleX(1)
}

#hm .fstage{
    position:relative;
    aspect-ratio:16/9;
    display:grid;
    place-items:center;
    background:#f7faff;
    overflow:hidden;
    padding:10px
}

#hm .fstage img{
    width:100%;
    height:100%;
    object-fit:contain;
    transition:transform .6s cubic-bezier(.16,1,.3,1)
}

#hm .fcard:hover .fstage img{
    transform:scale(1.06) translateY(-4px)
}

#hm .fglyph{
    font-size:4.4rem;
    color:#64748b
}

#hm .fbadge{
    position:absolute;
    top:14px;
    left:14px;
    z-index:6;
    display:inline-flex;
    align-items:center;
    gap:7px;
    font-size:.62rem;
    font-weight:800;
    color:#fff;
    background:var(--ac);
    padding:7px 13px;
    border-radius:999px;
    letter-spacing:.05em;
    text-transform:uppercase
}

#hm .fbody{
    padding:22px 24px 24px
}

#hm .fbody h3{
    font-family:'Sora','Poppins',sans-serif;
    font-size:1.25rem;
    font-weight:800;
    margin-bottom:4px
}

#hm .fdesc{
    color:var(--slate);
    font-size:.84rem;
    margin-bottom:14px;
    line-height:1.6;
    display:block
}

#hm .fspecs{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    margin-bottom:16px
}

#hm .fspecs span{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:var(--cloud);
    border:1px solid var(--line);
    border-radius:999px;
    padding:7px 12px;
    font-size:.76rem;
    font-weight:700
}

#hm .fspecs i{
    color:var(--ac);
    font-size:.68rem
}

#hm .ffoot{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    padding-top:14px;
    border-top:1px solid var(--line)
}

#hm .fprice{
    font-family:'Sora','Poppins',sans-serif;
    font-weight:800;
    font-size:1.5rem
}

#hm .fprice small{
    font-weight:600;
    font-size:.78rem;
    color:var(--slate)
}

#hm .fprice em{
    display:block;
    font-style:normal;
    font-size:.58rem;
    color:var(--mute);
    font-weight:800;
    letter-spacing:.1em;
    text-transform:uppercase
}

#hm .fbook{
    display:inline-flex;
    align-items:center;
    gap:8px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700;
    font-size:.84rem;
    color:#fff;
    background:var(--ac);
    border:none;
    cursor:pointer;
    padding:12px 20px;
    border-radius:13px;
    transition:all .3s
}

#hm .fbook:hover{
    gap:12px;
    filter:brightness(1.1);
    transform:translateY(-2px)
}

#hm .fcard.featured{
    grid-column:span 3;
    display:grid;
    grid-template-columns:1.1fr .9fr
}

#hm .fcard.featured .fstage{
    aspect-ratio:auto;
    min-height:340px
}

#hm .fcard.featured .fbody{
    display:flex;
    flex-direction:column;
    justify-content:center;
    padding:40px 46px
}

#hm .fcard.featured .fbody h3{
    font-size:1.7rem
}

#hm .feat-tag{
    display:inline-flex;
    align-items:center;
    gap:8px;
    font-size:.66rem;
    font-weight:800;
    color:var(--ac);
    background:#effaff;
    border:1px solid #c9eef5;
    padding:7px 14px;
    border-radius:999px;
    margin-bottom:12px;
    letter-spacing:.05em;
    text-transform:uppercase;
    align-self:flex-start
}

/* SERVICES */

#hm .sv-list{
    display:flex;
    flex-direction:column;
    gap:22px
}

#hm .sv-row{
    display:grid;
    grid-template-columns:1fr 1fr;
    background:#fff;
    border:1px solid var(--line);
    border-radius:26px;
    overflow:hidden;
    transition:transform .5s,box-shadow .5s;
    box-shadow:0 2px 6px rgba(11,18,32,.04),0 18px 44px -20px rgba(9,32,84,.14);
    text-decoration:none
}

#hm .sv-row:hover{
    transform:translateY(-6px);
    box-shadow:0 36px 70px -26px rgba(9,32,84,.24)
}

#hm .sv-row.rev .sv-copy{
    order:2
}

#hm .sv-copy{
    padding:36px 40px;
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:12px
}

#hm .sv-eyebrow{
    display:inline-flex;
    align-items:center;
    gap:8px;
    align-self:flex-start;
    font-size:.62rem;
    font-weight:800;
    letter-spacing:.12em;
    text-transform:uppercase;
    color:var(--ac);
    background:var(--tint);
    padding:7px 14px;
    border-radius:999px
}

#hm .sv-copy h3{
    font-family:'Sora','Poppins',sans-serif;
    font-size:clamp(1.6rem,3vw,2.1rem);
    font-weight:800;
    letter-spacing:-.03em;
    line-height:1.05
}

#hm .sv-copy h3 span{
    color:var(--ac)
}

#hm .sv-copy p{
    color:var(--slate);
    font-size:.95rem;
    max-width:46ch;
    line-height:1.65
}

#hm .sv-link{
    display:inline-flex;
    align-items:center;
    gap:9px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700;
    font-size:.88rem;
    color:var(--ac);
    margin-top:6px
}

#hm .sv-media{
    position:relative;
    aspect-ratio:16/9;
    align-self:center;
    width:100%;
    background:linear-gradient(160deg,var(--tint),#fff 80%);
    display:grid;
    place-items:center;
    padding:16px;
    overflow:hidden
}

#hm .sv-media img{
    width:100%;
    height:100%;
    object-fit:contain;
    border-radius:16px;
    transition:transform .6s
}

#hm .sv-row:hover .sv-media img{
    transform:scale(1.03)
}

#hm .sv-glyph{
    font-size:4.6rem;
    color:#94a3b8
}

/* WHY */

#hm .why-wrap{
    display:grid;
    grid-template-columns:.9fr 1.1fr;
    gap:52px;
    align-items:start
}

#hm .why-list{
    display:grid;
    grid-template-columns:1fr 1fr;
    background:#fff;
    border:1px solid var(--line);
    border-radius:var(--r);
    overflow:hidden;
    box-shadow:0 14px 40px -18px rgba(9,32,84,.16)
}

#hm .why-item{
    padding:26px;
    display:flex;
    gap:15px;
    border-right:1px solid var(--line);
    border-bottom:1px solid var(--line)
}

#hm .why-item:nth-child(2n){
    border-right:0
}

#hm .why-item:nth-last-child(-n+2){
    border-bottom:0
}

#hm .why-icon{
    flex:none;
    width:48px;
    height:48px;
    border-radius:13px;
    display:grid;
    place-items:center;
    background:rgba(0,87,255,.08);
    color:var(--blue);
    font-size:1.1rem
}

#hm .why-item h3{
    font-family:'Sora','Poppins',sans-serif;
    font-size:1rem;
    font-weight:700;
    margin-bottom:4px
}

#hm .why-item p{
    color:var(--slate);
    font-size:.86rem;
    line-height:1.6
}

/* CHIPS */

#hm .chips{
    display:flex;
    flex-wrap:wrap;
    gap:13px
}

#hm .chip{
    display:inline-flex;
    align-items:center;
    gap:9px;
    background:#fff;
    border:1.5px solid var(--line);
    border-radius:999px;
    padding:12px 20px;
    font-weight:700;
    font-size:.9rem;
    text-decoration:none;
    color:var(--ink);
    transition:all .3s
}

#hm .chip:hover{
    border-color:var(--blue);
    color:var(--blue);
    transform:translateY(-3px);
    box-shadow:0 14px 30px -12px rgba(0,87,255,.35)
}

#hm .chip small{
    color:var(--mute);
    font-weight:600;
    font-size:.76rem
}

/* TABLE */

#hm .tbl-wrap{
    background:#fff;
    border:1px solid var(--line);
    border-radius:var(--r);
    overflow:auto;
    box-shadow:0 12px 34px -16px rgba(9,32,84,.14)
}

#hm table{
    width:100%;
    border-collapse:collapse;
    min-width:620px
}

#hm th,
#hm td{
    padding:17px 22px;
    text-align:left;
    font-size:.93rem
}

#hm thead th{
    background:var(--cloud);
    color:#0039ad;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700;
    font-size:.76rem;
    text-transform:uppercase
}

#hm tbody tr{
    border-top:1px solid var(--line)
}

#hm td .fare{
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700
}

#hm td a{
    color:var(--blue);
    font-weight:700;
    text-decoration:none
}

/* BLOG */

#hm .blog-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:24px
}

#hm .blog-card{
    position:relative;
    background:#fff;
    border:1px solid var(--line);
    border-radius:22px;
    overflow:hidden;
    text-decoration:none;
    color:var(--ink);
    transition:all .5s cubic-bezier(.16,1,.3,1);
    display:flex;
    flex-direction:column
}

#hm .blog-card:hover{
    transform:translateY(-9px);
    box-shadow:0 36px 70px -26px rgba(9,32,84,.3)
}

#hm .blog-img{
    position:relative;
    aspect-ratio:16/9;
    overflow:hidden;
    background:linear-gradient(135deg,rgba(0,87,255,.08),#e4edfc);
    display:grid;
    place-items:center;
    padding:10px
}

#hm .blog-img img{
    width:100%;
    height:100%;
    object-fit:contain;
    border-radius:12px;
    transition:transform .7s
}

#hm .blog-card:hover .blog-img img{
    transform:scale(1.04)
}

#hm .blog-tag{
    position:absolute;
    top:14px;
    left:14px;
    z-index:2;
    display:inline-flex;
    align-items:center;
    gap:6px;
    font-size:.6rem;
    font-weight:800;
    color:#fff;
    background:var(--blue);
    padding:6px 12px;
    border-radius:999px;
    text-transform:uppercase
}

#hm .blog-body{
    padding:22px 24px 24px;
    display:flex;
    flex-direction:column;
    flex:1
}

#hm .blog-body h3{
    font-family:'Sora','Poppins',sans-serif;
    font-size:1.08rem;
    font-weight:700;
    margin-bottom:9px;
    line-height:1.35
}

#hm .blog-body p{
    color:var(--slate);
    font-size:.87rem;
    line-height:1.65;
    margin-bottom:15px;
    flex:1
}

#hm .blog-meta{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding-top:15px;
    border-top:1px solid var(--line)
}

#hm .blog-meta .read{
    display:inline-flex;
    align-items:center;
    gap:7px;
    font-size:.77rem;
    font-weight:700;
    color:var(--blue)
}

#hm .blog-meta .btime{
    font-size:.72rem;
    color:var(--mute);
    font-weight:600;
    display:inline-flex;
    align-items:center;
    gap:6px
}

/* FAQ */

#hm .faqbox{
    max-width:860px;
    margin:0 auto
}

#hm .faq-i{
    background:#fff;
    border:1px solid var(--line);
    border-radius:var(--rs);
    margin-bottom:13px;
    overflow:hidden
}

#hm .faq-h{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    padding:18px 22px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:600;
    font-size:1rem;
    cursor:pointer
}

#hm .faq-t{
    flex:none;
    width:28px;
    height:28px;
    border-radius:9px;
    background:rgba(0,87,255,.08);
    color:var(--blue);
    display:grid;
    place-items:center;
    transition:transform .35s
}

#hm .faq-i.open .faq-t{
    transform:rotate(45deg)
}

#hm .faq-b{
    max-height:0;
    overflow:hidden;
    color:var(--slate);
    font-size:.93rem;
    line-height:1.7;
    padding:0 22px;
    transition:max-height .4s,padding .4s
}

#hm .faq-i.open .faq-b{
    max-height:380px;
    padding:0 22px 20px
}

/* CTA */

#hm .cta{
    position:relative;
    overflow:hidden;
    border-radius:30px;
    margin:0 24px;
    background:
        radial-gradient(
            120% 140% at 85% 0%,
            #00c2ff,
            transparent 55%
        ),
        linear-gradient(120deg,#03102e,#0057ff);
    color:#fff;
    text-align:center;
    padding:70px 28px
}

#hm .cta h2{
    font-family:'Sora','Poppins',sans-serif;
    font-weight:800;
    font-size:clamp(1.8rem,4.4vw,2.6rem);
    letter-spacing:-.04em
}

#hm .cta p{
    color:rgba(255,255,255,.82);
    margin:14px 0 28px;
    font-size:1.08rem
}

#hm .cta-actions{
    display:flex;
    gap:14px;
    justify-content:center;
    flex-wrap:wrap
}

/* RESPONSIVE */

@media(max-width:1024px){

    #hm .fleet-grid{
        grid-template-columns:repeat(2,1fr)
    }

    #hm .fcard.featured{
        grid-column:span 2
    }
}

@media(max-width:960px){

    #hm .bk-card{
        grid-template-columns:1fr
    }

    #hm .bk-aside{
        display:none
    }

    #hm .bk-mhead{
        display:flex
    }

    #hm .split,
    #hm .why-wrap{
        grid-template-columns:1fr;
        gap:30px
    }

    #hm .sv-row{
        grid-template-columns:1fr
    }

    #hm .sv-row.rev .sv-copy{
        order:0
    }

    #hm .sv-media{
        order:-1
    }

    #hm .sv-copy{
        padding:26px
    }

    #hm .blog-grid{
        grid-template-columns:1fr 1fr
    }
}

@media(max-width:860px){

    #hm .fleet-grid{
        grid-template-columns:1fr
    }

    #hm .fcard.featured{
        grid-column:span 1;
        grid-template-columns:1fr
    }

    #hm .fcard.featured .fstage{
        min-height:240px
    }

    #hm .why-list{
        grid-template-columns:1fr
    }

    #hm .why-item{
        border-right:0!important
    }

    #hm .why-item:nth-last-child(-n+2){
        border-bottom:1px solid var(--line)
    }

    #hm .why-item:last-child{
        border-bottom:0
    }
}

@media(max-width:640px){

    #hm .wrap{
        padding:0 16px
    }

    #hm .bk-form{
        padding:18px 16px 16px
    }

    #hm .bk-grid{
        grid-template-columns:1fr;
        gap:10px
    }

    #hm .fld.full,
    #hm .fare-chip,
    #hm .book-btn,
    #hm .book-note{
        grid-column:1
    }

    #hm .strip-card{
        grid-template-columns:repeat(2,1fr)
    }

    #hm .strip-item:nth-child(2){
        border-right:0
    }

    #hm .strip-item:nth-child(-n+2){
        border-bottom:1px solid #eef2f8
    }

    #hm .blog-grid{
        grid-template-columns:1fr
    }

    #hm .sec{
        padding:64px 0
    }

    #hm .cta{
        margin:0 8px;
        padding:54px 20px
    }

    #hm .ffoot{
        align-items:flex-end
    }
}

@media(prefers-reduced-motion:reduce){

    #hm *,
    #hm *::before,
    #hm *::after{
        animation:none!important;
        transition:none!important
    }

    #hm .rv{
        opacity:1!important;
        transform:none!important
    }
}
</style>

<div id="hm-scroll-progress" aria-hidden="true"></div>

<!-- =========================================================
     BOOKING
========================================================= -->

<section class="bk-sec" id="booking">

<div class="wrap">

<div class="bk-card rv">

<div class="bk-aside">

<span class="live">
Live booking desk
</span>

<h2 class="disp">
Book your cab in 30 seconds
</h2>

<p>
Fill in your trip details and send your booking request directly to Anaya Cab Service.
</p>

<ul>

<li>
<i class="fa-solid fa-circle-check"></i>
Transparent fares
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
Experienced drivers
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
24×7 booking support
</li>

</ul>

</div>

<div class="bk-form">

<div class="bk-mhead">

<h2 class="disp">
Book your cab
</h2>

<span class="live">
● Live
</span>

</div>

<form
    id="bookingForm"
    class="bk-grid"
    autocomplete="off"
    novalidate
>

<input
    type="text"
    name="website"
    tabindex="-1"
    autocomplete="off"
    aria-hidden="true"
    style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0;pointer-events:none"
>

<div class="fld">

<label for="custName">
Name
</label>

<div class="iw">

<i class="fa-solid fa-user"></i>

<input
    type="text"
    name="customer_name"
    id="custName"
    placeholder="Full name"
    maxlength="100"
    autocomplete="name"
>

</div>

</div>

<div class="fld">

<label for="custPhone">
Phone
</label>

<div class="iw">

<i class="fa-solid fa-phone"></i>

<input
    type="tel"
    name="phone"
    id="custPhone"
    placeholder="10-digit mobile"
    inputmode="numeric"
    autocomplete="tel"
    maxlength="15"
    required
>

</div>

</div>

<div class="fld">

<label for="pickup">
Pickup
</label>

<div class="iw">

<i class="fa-solid fa-circle-dot"></i>

<input
    type="text"
    name="pickup"
    id="pickup"
    placeholder="e.g. Dehradun"
    list="places"
    maxlength="255"
    autocomplete="off"
    required
>

</div>

</div>

<div class="fld">

<label for="drop">
Drop
</label>

<div class="iw">

<i class="fa-solid fa-location-dot"></i>

<input
    type="text"
    name="drop"
    id="drop"
    placeholder="e.g. Haridwar"
    list="places"
    maxlength="255"
    autocomplete="off"
    required
>

</div>

</div>

<datalist id="places">

<option value="Dehradun">
<option value="Jolly Grant Airport">
<option value="Haridwar">
<option value="Rishikesh">
<option value="Mussoorie">
<option value="Delhi">
<option value="Nainital">
<option value="Chandigarh">

</datalist>

<div class="fld">

<label for="tripDate">
Date
</label>

<div class="iw">

<i class="fa-regular fa-calendar"></i>

<input
    type="date"
    name="date"
    id="tripDate"
    required
>

</div>

</div>

<div class="fld">

<label for="tripTime">
Time
</label>

<div class="iw">

<i class="fa-regular fa-clock"></i>

<input
    type="time"
    name="time"
    id="tripTime"
    required
>

</div>

</div>

<div class="fld full">

<label for="vehicle">
Vehicle
</label>

<div class="iw">

<i class="fa-solid fa-car-side"></i>

<select
    name="vehicle"
    id="vehicle"
    required
>

<option value="" disabled selected>
Choose vehicle
</option>

<?php
if (isset($FLEET) && is_array($FLEET)):

    foreach ($FLEET as $key => $vehicle):
?>

<option
    value="<?php echo htmlspecialchars((string)$key, ENT_QUOTES, 'UTF-8'); ?>"
>
<?php
echo htmlspecialchars(
    (string)$vehicle['name'],
    ENT_QUOTES,
    'UTF-8'
);
?>
 — ₹<?php echo (int)$vehicle['rate']; ?>/km
</option>

<?php
    endforeach;

endif;
?>

</select>

</div>

</div>

<div
    class="fare-chip"
    id="fareChip"
    hidden
>

<span class="l">

<i class="fa-solid fa-indian-rupee-sign"></i>

Approx. fare

</span>

<span
    class="v neutral"
    id="fareValue"
>
Fare on request
</span>

</div>

<button
    type="submit"
    class="hbtn hbtn-p book-btn"
    id="bookBtn"
>

<span class="btn-text">
Book now
</span>

<i class="fa-solid fa-arrow-right btn-arrow"></i>

<span
    class="btn-spinner"
    hidden
>
<i class="fa-solid fa-circle-notch fa-spin"></i>
</span>

</button>

<p class="book-note">
Booking request will open WhatsApp for confirmation.
</p>

</form>

</div>

</div>

</div>

</section>

<!-- =========================================================
     TRUST
========================================================= -->

<section class="stats-strip">

<div class="wrap">

<div class="strip-card rv">

<div class="strip-item">

<i class="fa-solid fa-id-badge"></i>

<strong>
<?php echo defined('STAT_DRIVERS') ? htmlspecialchars(STAT_DRIVERS) : '50+'; ?>
</strong>

<span>
Experienced drivers
</span>

</div>

<div class="strip-item">

<i class="fa-solid fa-city"></i>

<strong>
<?php echo defined('STAT_CITIES') ? htmlspecialchars(STAT_CITIES) : '25+'; ?>
</strong>

<span>
Cities covered
</span>

</div>

<div class="strip-item">

<i class="fa-solid fa-shield-halved"></i>

<strong>
100%
</strong>

<span>
Safety-focused rides
</span>

</div>

<div class="strip-item">

<i class="fa-solid fa-headset"></i>

<strong>
24×7
</strong>

<span>
Booking support
</span>

</div>

</div>

</div>

</section>

<!-- =========================================================
     ABOUT
========================================================= -->

<section
    class="sec soft"
    id="about-service"
>

<div class="wrap split">

<div class="rv">

<span class="eyebrow">

<i class="fa-solid fa-circle-info"></i>

About our service

</span>

<h2 class="disp">
Dehradun's Reliable Taxi Service
</h2>

<div class="bp-qa aiBox" style="margin:20px 0 22px;background:#fff;border:1px solid var(--line,#e3eaf8);border-left:4px solid var(--blue,#0057ff);border-radius:16px;padding:18px 22px;box-shadow:0 10px 30px rgba(10,22,51,.05)">
<div style="display:inline-flex;align-items:center;gap:8px;font-size:.7rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue,#0057ff);margin-bottom:8px">
<i class="fa-solid fa-bolt"></i> Quick Summary &amp; Booking Rates (2026)
</div>
<p style="margin:0;color:#33415c;line-height:1.65;font-size:.96rem">
<strong>Anaya Cab Service</strong> is Dehradun's trusted 24×7 taxi service offering local city rides (from ₹12/km), Jolly Grant Airport pickups (₹800 fixed), outstation transfers to Mussoorie (₹1,050), Rishikesh (₹1,150), Haridwar (₹1,350), Delhi Expressway drops (₹3,500), and complete Char Dham Yatra packages with verified hill drivers.
</p>
</div>

<p
    style="color:var(--slate);line-height:1.75;margin:18px 0 16px"
>

Anaya Cab Service is a Dehradun-based taxi service providing
<a
    href="/local-taxi-in-dehradun"
    style="color:var(--blue);font-weight:700"
>
local taxi
</a>,
<a
    href="/dehradun-airport-taxi-service"
    style="color:var(--blue);font-weight:700"
>
Jolly Grant Airport transfers
</a>,
<a
    href="/outstation-taxi-from-dehradun"
    style="color:var(--blue);font-weight:700"
>
outstation taxi
</a>
and
<a
    href="/char-dham-yatra-taxi"
    style="color:var(--blue);font-weight:700"
>
Char Dham Yatra taxi
</a>
services.

</p>

<ul class="list-check">

<li>
<i class="fa-solid fa-circle-check"></i>
Transparent fares confirmed before booking
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
Cars, Innovas and group travel vehicles
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
Experienced drivers for Uttarakhand routes
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
24×7 call and WhatsApp booking support
</li>

</ul>

<div
    style="display:flex;gap:14px;flex-wrap:wrap;margin-top:24px"
>

<a
    class="hbtn hbtn-p"
    href="/services"
>
View all services
</a>

<a
    class="hbtn hbtn-o"
    href="/pricing"
>
See fares →
</a>

</div>

</div>

<div class="panel rv" itemscope itemtype="https://schema.org/Answer">

<span
    class="eyebrow"
    style="margin-bottom:14px"
>

<i class="fa-solid fa-bolt"></i>

Direct Answer · Dehradun Cab Service Overview

</span>

<h3
    class="disp"
    style="font-weight:800;margin:8px 0;font-size:1.3rem"
>
Dehradun Taxi Service &amp; Cab Booking
</h3>

<p
    style="color:var(--slate);font-size:.95rem;line-height:1.7"
    itemprop="text"
>

<strong style="color:var(--ink)">
Anaya Cab Service
</strong>
is Dehradun's premier 24x7 taxi provider offering local city cabs (from ₹12/km or ₹900 for 4hr/40km), Jolly Grant Airport transfers (₹800 fixed fare), one-way outstation cabs to Delhi (₹3,500), Mussoorie (₹1,200), Haridwar (₹1,350), Rishikesh (₹1,000), and custom 10–12 day Char Dham Yatra packages with verified hill-expert drivers.

</p>

<p
    style="color:var(--slate);font-size:.8rem;margin-top:16px;margin-bottom:10px"
>

<strong style="color:var(--ink)">
24x7 Doorstep Pickup Areas:
</strong>

</p>

<div
    class="chips"
    aria-label="Areas covered in Dehradun"
>

<span class="chip">Rajpur Road</span>
<span class="chip">Clement Town</span>
<span class="chip">ISBT Dehradun</span>
<span class="chip">Railway Station</span>
<span class="chip">Paltan Bazaar</span>
<span class="chip">Sahastradhara Road</span>
<span class="chip">Shimla Bypass</span>
<span class="chip">Sewla Kalan</span>
<span class="chip">Jolly Grant Airport</span>

</div>

</div>

</div>

</section>

<!-- =========================================================
     FLEET
========================================================= -->

<section
    class="sec"
    id="fleet"
>

<div class="wrap">

<div class="sec-head rv">

<span class="eyebrow">

<i class="fa-solid fa-car"></i>

Our fleet

</span>

<h2 class="disp">
Choose the car that fits your journey
</h2>

<p>
Comfortable vehicles for individual travellers, families and groups.
<a href="/fleet">
See full fleet →
</a>
</p>

</div>

<div class="fleet-grid">

<?php

$featured_key = 'innova-crysta';

$fv =
    isset($FLEET[$featured_key])
        ? $FLEET[$featured_key]
        : null;

$fm =
    $fleet_meta[$featured_key]
        ?? ['Premium MPV', '#0891b2', 'fa-van-shuttle'];

if ($fv):

?>

<article
    class="fcard featured rv"
    style="--ac:<?php echo htmlspecialchars($fm[1], ENT_QUOTES, 'UTF-8'); ?>"
>

<div class="fstage">

<span class="fbadge">

<i class="fa-solid <?php echo htmlspecialchars($fm[2], ENT_QUOTES, 'UTF-8'); ?>"></i>

<?php echo htmlspecialchars($fm[0], ENT_QUOTES, 'UTF-8'); ?>

</span>

<img
    src="/assets/images/fleet/<?php echo rawurlencode($featured_key); ?>.webp"
    alt="<?php echo htmlspecialchars($fv['name'], ENT_QUOTES, 'UTF-8'); ?> taxi in Dehradun"
    width="1200"
    height="675"
    loading="lazy"
    decoding="async"
    onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
>

<i
    class="fa-solid <?php echo htmlspecialchars($fm[2], ENT_QUOTES, 'UTF-8'); ?> fglyph"
    style="display:none"
></i>

</div>

<div class="fbody">

<span class="feat-tag">

<i class="fa-solid fa-crown"></i>

Most requested

</span>

<h3>
<?php echo htmlspecialchars($fv['name'], ENT_QUOTES, 'UTF-8'); ?>
</h3>

<span class="fdesc">
<?php
echo htmlspecialchars(
    (string)($fv['desc'] ?? 'Premium comfort for family and long-distance travel.'),
    ENT_QUOTES,
    'UTF-8'
);
?>
</span>

<div class="fspecs">

<span>
<i class="fa-solid fa-user-group"></i>
<?php echo (int)$fv['pax']; ?> Pax
</span>

<span>
<i class="fa-solid fa-suitcase-rolling"></i>
<?php echo (int)$fv['bags']; ?> Bags
</span>

<span>
<i class="fa-solid fa-snowflake"></i>
AC
</span>

<span>
<i class="fa-solid fa-mountain-sun"></i>
Hill ready
</span>

</div>

<div class="ffoot">

<div class="fprice">

<em>
Base fare
</em>

₹<?php echo number_format((int)$fv['rate']); ?>

<small>
/km
</small>

</div>

<button
    class="fbook fleet-book"
    data-vehicle="<?php echo htmlspecialchars($featured_key, ENT_QUOTES, 'UTF-8'); ?>"
    type="button"
>

Book now

<i class="fa-solid fa-arrow-right"></i>

</button>

</div>

</div>

</article>

<?php endif; ?>

<?php

if (isset($FLEET) && is_array($FLEET)):

foreach ($FLEET as $key => $vehicle):

if ($key === $featured_key) {
    continue;
}

$m =
    $fleet_meta[$key]
        ?? ['Taxi', '#0057ff', 'fa-car'];

?>

<article
    class="fcard rv"
    style="--ac:<?php echo htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8'); ?>"
>

<div class="fstage">

<span class="fbadge">

<i class="fa-solid <?php echo htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8'); ?>"></i>

<?php echo htmlspecialchars($m[0], ENT_QUOTES, 'UTF-8'); ?>

</span>

<img
    src="/assets/images/fleet/<?php echo rawurlencode((string)$key); ?>.webp"
    alt="<?php echo htmlspecialchars($vehicle['name'], ENT_QUOTES, 'UTF-8'); ?> taxi in Dehradun"
    width="1200"
    height="675"
    loading="lazy"
    decoding="async"
    onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
>

<i
    class="fa-solid <?php echo htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8'); ?> fglyph"
    style="display:none"
></i>

</div>

<div class="fbody">

<h3>
<?php echo htmlspecialchars($vehicle['name'], ENT_QUOTES, 'UTF-8'); ?>
</h3>

<span class="fdesc">
<?php
echo htmlspecialchars(
    (string)($vehicle['desc'] ?? 'Comfortable AC taxi for local and outstation travel.'),
    ENT_QUOTES,
    'UTF-8'
);
?>
</span>

<div class="fspecs">

<span>
<i class="fa-solid fa-user-group"></i>
<?php echo (int)$vehicle['pax']; ?> Pax
</span>

<span>
<i class="fa-solid fa-suitcase-rolling"></i>
<?php echo (int)$vehicle['bags']; ?> Bags
</span>

<span>
<i class="fa-solid fa-snowflake"></i>
AC
</span>

</div>

<div class="ffoot">

<div class="fprice">

<em>
Base fare
</em>

₹<?php echo number_format((int)$vehicle['rate']); ?>

<small>
/km
</small>

</div>

<button
    class="fbook fleet-book"
    data-vehicle="<?php echo htmlspecialchars((string)$key, ENT_QUOTES, 'UTF-8'); ?>"
    type="button"
>

Book

<i class="fa-solid fa-arrow-right"></i>

</button>

</div>

</div>

</article>

<?php

endforeach;

endif;

?>

</div>

</div>

</section>

<!-- =========================================================
     SERVICES
========================================================= -->

<section
    class="sec soft"
    id="services"
>

<div class="wrap">

<div class="sec-head rv">

<span class="eyebrow">

<i class="fa-solid fa-route"></i>

Services

</span>

<h2 class="disp">
Taxi services for every journey
</h2>

<p>
From city rides to airport transfers, outstation trips and Char Dham Yatra.
<a href="/services">
Explore all →
</a>
</p>

</div>

<div class="sv-list">

<?php

$si = 0;

foreach ($services_premium as $service):

    $rev = ($si % 2 === 1);

    $si++;

?>

<a
    class="sv-row rv<?php echo $rev ? ' rev' : ''; ?>"
    href="<?php echo htmlspecialchars($service['url'], ENT_QUOTES, 'UTF-8'); ?>"
    style="--ac:<?php echo htmlspecialchars($service['ac'], ENT_QUOTES, 'UTF-8'); ?>;--tint:<?php echo htmlspecialchars($service['tint'], ENT_QUOTES, 'UTF-8'); ?>"
>

<div class="sv-copy">

<span class="sv-eyebrow">

<i class="fa-solid <?php echo htmlspecialchars($service['ico'], ENT_QUOTES, 'UTF-8'); ?>"></i>

<?php echo htmlspecialchars($service['eyebrow'], ENT_QUOTES, 'UTF-8'); ?>

</span>

<h3 class="disp">

<?php echo htmlspecialchars($service['word1'], ENT_QUOTES, 'UTF-8'); ?>

<span>

<?php echo htmlspecialchars($service['word2'], ENT_QUOTES, 'UTF-8'); ?>

</span>

</h3>

<p>
<?php echo htmlspecialchars($service['desc'], ENT_QUOTES, 'UTF-8'); ?>
</p>

<span class="sv-link">

View details

<i class="fa-solid fa-arrow-right"></i>

</span>

</div>

<div class="sv-media">

<img
    src="<?php echo htmlspecialchars($service['img'], ENT_QUOTES, 'UTF-8'); ?>"
    alt="<?php echo htmlspecialchars($service['word1'] . ' ' . $service['word2'] . ' from Dehradun', ENT_QUOTES, 'UTF-8'); ?>"
    width="1200"
    height="675"
    loading="lazy"
    decoding="async"
    onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
>

<div
    class="sv-glyph"
    style="display:none"
>
<i class="fa-solid <?php echo htmlspecialchars($service['glyph'], ENT_QUOTES, 'UTF-8'); ?>"></i>
</div>

</div>

</a>

<?php endforeach; ?>

</div>

</div>

</section>

<!-- =========================================================
     WHY US
========================================================= -->

<section
    class="sec"
    id="why-us"
>

<div class="wrap why-wrap">

<div
    class="sec-head rv"
    style="margin-bottom:0"
>

<span class="eyebrow">

<i class="fa-solid fa-medal"></i>

Why Anaya

</span>

<h2 class="disp">
A dependable taxi partner in Dehradun
</h2>

<p>
Clear communication, practical fares and experienced drivers for every journey.
</p>

</div>

<div class="why-list rv">

<?php

$why = [

    [
        'fa-id-badge',
        'Experienced drivers',
        'Drivers familiar with Dehradun and Uttarakhand routes.'
    ],

    [
        'fa-location-crosshairs',
        'Trip coordination',
        'Pickup and drop details are confirmed before the journey.'
    ],

    [
        'fa-tags',
        'Transparent pricing',
        'Route and vehicle pricing is discussed before booking.'
    ],

    [
        'fa-headset',
        '24×7 support',
        'Call or WhatsApp us whenever you need booking assistance.'
    ],

    [
        'fa-spray-can-sparkles',
        'Clean vehicles',
        'Vehicles are maintained and prepared for customer trips.'
    ],

    [
        'fa-bolt',
        'Quick booking',
        'Send your trip details through the online form or WhatsApp.'
    ]

];

foreach ($why as $item):

?>

<div class="why-item">

<span class="why-icon">

<i class="fa-solid <?php echo htmlspecialchars($item[0], ENT_QUOTES, 'UTF-8'); ?>"></i>

</span>

<div>

<h3>
<?php echo htmlspecialchars($item[1], ENT_QUOTES, 'UTF-8'); ?>
</h3>

<p>
<?php echo htmlspecialchars($item[2], ENT_QUOTES, 'UTF-8'); ?>
</p>

</div>

</div>

<?php endforeach; ?>

</div>

</div>

</section>

<!-- =========================================================
     GOOGLE TRUST
========================================================= -->

<section
    class="sec soft"
    id="google-trust"
>

<div class="wrap split">

<div class="rv">

<span class="eyebrow">

<i class="fa-brands fa-google"></i>

Google Business Profile

</span>

<h2 class="disp">
Find Anaya Cab Service on Google
</h2>

<p
    style="color:var(--slate);line-height:1.75"
>

Use our Google listing to verify business information, location,
phone details and customer reviews.

</p>

<ul class="list-check">

<li>
<i class="fa-solid fa-circle-check"></i>
Business name and contact information
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
Google Maps location and directions
</li>

<li>
<i class="fa-solid fa-circle-check"></i>
Customer reviews and business information
</li>

</ul>

<div
    style="display:flex;gap:14px;flex-wrap:wrap;margin-top:24px"
>

<a
    class="hbtn hbtn-p"
    href="<?php echo htmlspecialchars($googleProfile ?: $googleMaps, ENT_QUOTES, 'UTF-8'); ?>"
    target="_blank"
    rel="noopener noreferrer"
>

<i class="fa-brands fa-google"></i>

Open Google Listing

</a>

<a
    class="hbtn hbtn-o"
    href="/reviews"
>
Customer reviews →
</a>

</div>

</div>

<div class="panel rv">

<h3
    class="disp"
    style="font-weight:800;margin-bottom:8px;font-size:1.2rem"
>
Quick booking
</h3>

<p
    style="color:var(--slate);font-size:.9rem;margin-bottom:18px"
>
Call or WhatsApp Anaya Cab Service for direct booking assistance.
</p>

<div style="display:grid;gap:12px">

<a
    class="hbtn hbtn-p"
    href="tel:<?php echo htmlspecialchars($phoneTel, ENT_QUOTES, 'UTF-8'); ?>"
>

<i class="fa-solid fa-phone"></i>

Call <?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>

</a>

<a
    class="hbtn hbtn-wa"
    href="https://wa.me/<?php echo htmlspecialchars($whatsapp, ENT_QUOTES, 'UTF-8'); ?>?text=<?php echo $waVerifyText; ?>"
    target="_blank"
    rel="noopener noreferrer"
>

<i class="fa-brands fa-whatsapp"></i>

WhatsApp booking

</a>

<a
    class="hbtn hbtn-o"
    href="<?php echo htmlspecialchars($googleMaps ?: $googleProfile, ENT_QUOTES, 'UTF-8'); ?>"
    target="_blank"
    rel="noopener noreferrer"
>

<i class="fa-solid fa-map-location-dot"></i>

Google Maps

</a>

</div>

</div>

</div>

</section>

<!-- =========================================================
     ROUTES
========================================================= -->

<section
    class="sec"
    id="routes"
>

<div class="wrap">

<div class="sec-head rv">

<span class="eyebrow">

<i class="fa-solid fa-map"></i>

Popular routes

</span>

<h2 class="disp">
Popular taxi routes from Dehradun
</h2>

<p>
Book one-way or round-trip taxi service for popular Uttarakhand and North India routes.
</p>

</div>

<div
    class="chips"
    aria-label="Popular taxi routes from Dehradun"
>

<?php foreach ($route_links as $route): ?>

<a
    class="chip route-chip"
    href="<?php echo htmlspecialchars($route[2], ENT_QUOTES, 'UTF-8'); ?>"
>

Dehradun → <?php echo htmlspecialchars($route[0], ENT_QUOTES, 'UTF-8'); ?>

<?php if (!empty($route[1])): ?>

<small>
<?php echo (int)$route[1]; ?> km
</small>

<?php endif; ?>

</a>

<?php endforeach; ?>

</div>

</div>

</section>

<!-- =========================================================
     FARES
========================================================= -->

<section
    class="sec soft"
    id="fares"
>

<div class="wrap">

<div class="sec-head center rv">

<span class="eyebrow">

<i class="fa-solid fa-indian-rupee-sign"></i>

Fares

</span>

<h2 class="disp">
One-way taxi fares from Dehradun
</h2>

<p>
Published starting fares for selected routes. Final fare is confirmed before booking.
<a href="/pricing">
View complete pricing →
</a>
</p>

</div>

<div class="tbl-wrap rv">

<table aria-label="One-way taxi fares from Dehradun">

<thead>

<tr>

<th>
Route
</th>

<th>
Distance
</th>

<th>
Starting fare
</th>

<th>
Details
</th>

</tr>

</thead>

<tbody>

<?php

if (isset($ROUTES) && is_array($ROUTES)):

foreach ($fare_rows as $row):

    if (!isset($ROUTES[$row[1]])) {
        continue;
    }

    $routeFare = $ROUTES[$row[1]];

?>

<tr>

<td>
<strong>
<?php echo htmlspecialchars($row[0], ENT_QUOTES, 'UTF-8'); ?>
</strong>
</td>

<td>
<?php echo (int)$routeFare['km']; ?> km
</td>

<td class="fare">
₹<?php echo number_format((int)$routeFare['base']); ?>
</td>

<td>
<a href="<?php echo htmlspecialchars($row[2], ENT_QUOTES, 'UTF-8'); ?>">
Details →
</a>
</td>

</tr>

<?php

endforeach;

endif;

?>

</tbody>

</table>

</div>

<p
    style="text-align:center;margin-top:16px;font-size:.82rem;color:var(--slate)"
>
Toll, parking, state tax and hill charges may apply where applicable.
Final fare is confirmed at booking.
</p>

</div>

</section>

<!-- =========================================================
     BLOG
========================================================= -->

<section
    class="sec"
    id="latest-blog"
>

<div class="wrap">

<div class="sec-head rv">

<span class="eyebrow">

<i class="fa-solid fa-newspaper"></i>

From our blog

</span>

<h2 class="disp">
Dehradun travel guides & taxi tips
</h2>

<p>
Helpful route guides, Uttarakhand travel information and taxi planning tips.
<a href="/blog">
View all posts →
</a>
</p>

</div>

<div class="blog-grid">

<?php foreach ($latest_blogs as $blog): ?>

<a
    class="blog-card rv"
    href="/blog/<?php echo rawurlencode($blog['slug']); ?>"
>

<div class="blog-img">

<span class="blog-tag">

<i class="fa-solid <?php echo htmlspecialchars($blog['icon'], ENT_QUOTES, 'UTF-8'); ?>"></i>

<?php echo htmlspecialchars($blog['tag'], ENT_QUOTES, 'UTF-8'); ?>

</span>

<img
    src="/assets/images/blog/<?php echo rawurlencode($blog['slug']); ?>.webp"
    alt="<?php echo htmlspecialchars($blog['title'], ENT_QUOTES, 'UTF-8'); ?>"
    width="1200"
    height="675"
    loading="lazy"
    decoding="async"
    onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
>

<div
    class="blog-glyph"
    style="display:none"
>
<i class="fa-solid <?php echo htmlspecialchars($blog['icon'], ENT_QUOTES, 'UTF-8'); ?>"></i>
</div>

</div>

<div class="blog-body">

<h3>
<?php echo htmlspecialchars($blog['title'], ENT_QUOTES, 'UTF-8'); ?>
</h3>

<p>
<?php echo htmlspecialchars($blog['excerpt'], ENT_QUOTES, 'UTF-8'); ?>
</p>

<div class="blog-meta">

<span class="read">

Read guide

<i class="fa-solid fa-arrow-right"></i>

</span>

<span class="btime">

<i class="fa-regular fa-clock"></i>

<?php echo htmlspecialchars($blog['time'], ENT_QUOTES, 'UTF-8'); ?>

</span>

</div>

</div>

</a>

<?php endforeach; ?>

</div>

<div
    style="text-align:center;margin-top:32px"
>

<a
    class="hbtn hbtn-o"
    href="/blog"
>
View all blog posts →
</a>

</div>

</div>

</section>

<!-- =========================================================
     VERIFIED GOOGLE REVIEWS
========================================================= -->

<section class="sec" id="reviews-home">
<div class="wrap">
<div class="sec-head center rv">
<span class="eyebrow" style="color:#d97706;background:rgba(245,158,11,0.12)">
<i class="fa-solid fa-star"></i> Verified Google Reviews
</span>
<h2 class="disp">Rated 4.9★ by Travelers in Dehradun</h2>
<p>Real feedback from authentic passengers on our Google Business Profile.</p>
</div>

<div class="rv" style="min-height:120px;padding:10px 0;">
<!-- Trustindex Google Reviews Widget -->
<script defer async src='https://cdn.trustindex.io/loader.js?c40b2f079d02660789462470352'></script>
</div>

<div style="text-align:center;margin-top:32px" class="rv">
<a class="hbtn hbtn-o" href="<?php echo htmlspecialchars($googleProfile ?: 'https://maps.google.com/?cid=12642595085186256999', ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer">
  <i class="fa-brands fa-google" style="color:#ea4335"></i> View Google Profile (22+ Reviews) →
</a>
</div>

</div>
</section>

<!-- =========================================================
     FAQ
========================================================= -->

<section
    class="sec soft"
    id="faq-home"
>

<div class="wrap">

<div class="sec-head center rv">

<span class="eyebrow">

<i class="fa-regular fa-circle-question"></i>

FAQ

</span>

<h2 class="disp">
Frequently asked questions
</h2>

</div>

<div class="faqbox">

<?php foreach ($__faqs as $index => $faq): ?>

<div
    class="faq-i<?php echo $index === 0 ? ' open' : ''; ?>"
>

<button
    type="button"
    class="faq-h"
    aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>"
>

<span>
<?php echo htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8'); ?>
</span>

<span class="faq-t">
<i class="fa-solid fa-plus"></i>
</span>

</button>

<div class="faq-b">

<p style="padding-top:4px">

<?php echo htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8'); ?>

</p>

</div>

</div>

<?php endforeach; ?>

<p
    style="text-align:center;margin-top:22px"
>

<a
    class="hbtn hbtn-o"
    href="/faq"
>
See all FAQs →
</a>

</p>

</div>

</div>

</section>

<!-- =========================================================
     CONTACT
========================================================= -->

<section
    class="sec"
    id="reach-us"
>

<div class="wrap split">

<div class="rv">

<span class="eyebrow">

<i class="fa-solid fa-location-dot"></i>

Reach us

</span>

<h2 class="disp">
Anaya Cab Service, Dehradun
</h2>

<p
    style="color:var(--slate);margin:18px 0 8px"
>

<strong style="color:var(--ink)">
Address:
</strong>

<?php echo htmlspecialchars($address, ENT_QUOTES, 'UTF-8'); ?>

</p>

<p
    style="color:var(--slate);margin-bottom:8px"
>

<strong style="color:var(--ink)">
Phone:
</strong>

<a
    href="tel:<?php echo htmlspecialchars($phoneTel, ENT_QUOTES, 'UTF-8'); ?>"
    style="color:var(--blue);font-weight:700"
>
<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>
</a>

</p>

<p style="color:var(--slate)">

<strong style="color:var(--ink)">
Email:
</strong>

<a
    href="mailto:<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
    style="color:var(--blue);font-weight:700"
>
<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>
</a>

</p>

<div
    style="display:flex;gap:14px;flex-wrap:wrap;margin-top:24px"
>

<a
    class="hbtn hbtn-p"
    href="tel:<?php echo htmlspecialchars($phoneTel, ENT_QUOTES, 'UTF-8'); ?>"
>

<i class="fa-solid fa-phone"></i>

Call now

</a>

<a
    class="hbtn hbtn-o"
    href="/contact"
>
Contact page →
</a>

</div>

</div>

<div
    class="panel rv"
    style="padding:12px"
>

<iframe
    src="https://maps.google.com/maps?q=<?php echo $mapQuery; ?>&z=16&output=embed"
    width="100%"
    height="340"
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"
    title="Anaya Cab Service location in Dehradun"
    style="border:0;border-radius:18px;width:100%"
></iframe>

<div style="margin-top:14px">

<a
    class="hbtn hbtn-p"
    style="width:100%"
    href="<?php echo htmlspecialchars($googleMaps ?: $googleProfile, ENT_QUOTES, 'UTF-8'); ?>"
    target="_blank"
    rel="noopener noreferrer"
>

<i class="fa-solid fa-map-location-dot"></i>

Open in Google Maps

</a>

</div>

</div>

</div>

</section>

<!-- =========================================================
     CTA
========================================================= -->

<section
    class="sec"
    style="padding-top:0"
>

<div class="cta rv">

<h2 class="disp">
Need a cab right now?
</h2>

<p>
Call or WhatsApp Anaya Cab Service for quick booking assistance.
</p>

<div class="cta-actions">

<a
    class="hbtn hbtn-o"
    style="background:#fff"
    href="tel:<?php echo htmlspecialchars($phoneTel, ENT_QUOTES, 'UTF-8'); ?>"
>

<i class="fa-solid fa-phone"></i>

Call now

</a>

<a
    class="hbtn hbtn-wa"
    href="https://wa.me/<?php echo htmlspecialchars($whatsapp, ENT_QUOTES, 'UTF-8'); ?>?text=<?php echo $waDefaultText; ?>"
    target="_blank"
    rel="noopener noreferrer"
>

<i class="fa-brands fa-whatsapp"></i>

WhatsApp

</a>

</div>

</div>

</section>

</div>

</main>

<script>
/*
|--------------------------------------------------------------------------
| Public frontend data
|--------------------------------------------------------------------------
*/
window.ANAYA = <?php
echo json_encode(
    [
        'routes' => isset($ROUTES) && is_array($ROUTES) ? $ROUTES : [],
        'fleet' => isset($FLEET) && is_array($FLEET) ? $FLEET : [],
        'whatsapp' => $whatsapp,
        'bookingEndpoint' => '/api/booking.php'
    ],
    JSON_UNESCAPED_SLASHES |
    JSON_UNESCAPED_UNICODE |
    JSON_HEX_TAG |
    JSON_HEX_AMP |
    JSON_HEX_APOS |
    JSON_HEX_QUOT
);
?>;
</script>

<script>
(function(){

'use strict';

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function qs(selector, parent){
    return (parent || document).querySelector(selector);
}

function qsa(selector, parent){
    return Array.prototype.slice.call(
        (parent || document).querySelectorAll(selector)
    );
}

/*
|--------------------------------------------------------------------------
| Scroll progress
|--------------------------------------------------------------------------
*/

(function(){

    var bar = document.getElementById('hm-scroll-progress');

    if(!bar){
        return;
    }

    function update(){

        var doc = document.documentElement;

        var scrollTop =
            window.pageYOffset ||
            doc.scrollTop ||
            0;

        var scrollHeight =
            doc.scrollHeight -
            window.innerHeight;

        var percentage =
            scrollHeight > 0
                ? (scrollTop / scrollHeight) * 100
                : 0;

        bar.style.width =
            Math.max(0, Math.min(100, percentage)) + '%';
    }

    window.addEventListener(
        'scroll',
        update,
        {passive:true}
    );

    window.addEventListener(
        'resize',
        update,
        {passive:true}
    );

    update();

})();

/*
|--------------------------------------------------------------------------
| Reveal animation
|--------------------------------------------------------------------------
*/

(function(){

    var elements =
        qsa('#hm .rv');

    if(!elements.length){
        return;
    }

    if(
        !('IntersectionObserver' in window) ||
        window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ){

        elements.forEach(function(el){
            el.classList.add('in');
        });

        return;
    }

    var observer =
        new IntersectionObserver(
            function(entries){

                entries.forEach(function(entry){

                    if(!entry.isIntersecting){
                        return;
                    }

                    entry.target.classList.add('in');

                    observer.unobserve(
                        entry.target
                    );

                });

            },
            {
                threshold:.08,
                rootMargin:'0px 0px -6% 0px'
            }
        );

    elements.forEach(function(el){
        observer.observe(el);
    });

})();

/*
|--------------------------------------------------------------------------
| FAQ
|--------------------------------------------------------------------------
*/

(function(){

    qsa('#hm .faq-h').forEach(function(button){

        button.addEventListener(
            'click',
            function(){

                var item =
                    button.closest('.faq-i');

                if(!item){
                    return;
                }

                var isOpen =
                    item.classList.contains('open');

                qsa('#hm .faq-i').forEach(function(other){

                    other.classList.remove('open');

                    var otherButton =
                        qs('.faq-h', other);

                    if(otherButton){
                        otherButton.setAttribute(
                            'aria-expanded',
                            'false'
                        );
                    }

                });

                if(!isOpen){

                    item.classList.add('open');

                    button.setAttribute(
                        'aria-expanded',
                        'true'
                    );

                }

            }
        );

    });

})();

/*
|--------------------------------------------------------------------------
| Fleet booking buttons
|--------------------------------------------------------------------------
*/

(function(){

    qsa('#hm .fleet-book').forEach(function(button){

        button.addEventListener(
            'click',
            function(){

                var vehicle =
                    button.getAttribute('data-vehicle');

                var select =
                    document.getElementById('vehicle');

                var booking =
                    document.getElementById('booking');

                if(select && vehicle){

                    select.value = vehicle;

                    select.dispatchEvent(
                        new Event('change')
                    );

                }

                if(booking){

                    booking.scrollIntoView({
                        behavior:'smooth',
                        block:'center'
                    });

                    setTimeout(function(){

                        var phone =
                            document.getElementById('custPhone');

                        if(phone){
                            phone.focus({
                                preventScroll:true
                            });
                        }

                    },700);

                }

            }
        );

    });

})();

/*
|--------------------------------------------------------------------------
| Booking
|--------------------------------------------------------------------------
*/

(function(){

    var form =
        document.getElementById('bookingForm');

    if(!form){
        return;
    }

    var dateInput =
        document.getElementById('tripDate');

    var timeInput =
        document.getElementById('tripTime');

    var phoneInput =
        document.getElementById('custPhone');

    var dropInput =
        document.getElementById('drop');

    var pickupInput =
        document.getElementById('pickup');

    var vehicleSelect =
        document.getElementById('vehicle');

    var fareChip =
        document.getElementById('fareChip');

    var fareValue =
        document.getElementById('fareValue');

    var bookButton =
        document.getElementById('bookBtn');

    var today =
        new Date();

    var yyyy =
        today.getFullYear();

    var mm =
        String(today.getMonth() + 1).padStart(2,'0');

    var dd =
        String(today.getDate()).padStart(2,'0');

    var todayString =
        yyyy + '-' + mm + '-' + dd;

    if(dateInput){

        dateInput.min =
            todayString;

    }

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    var toast =
        document.createElement('div');

    toast.setAttribute(
        'role',
        'status'
    );

    toast.style.cssText =
        'position:fixed;' +
        'left:50%;' +
        'bottom:30px;' +
        'transform:translate(-50%,20px);' +
        'z-index:99999;' +
        'background:#0a0f1e;' +
        'color:#fff;' +
        'padding:14px 22px;' +
        'border-radius:16px;' +
        'font-family:Sora,Poppins,sans-serif;' +
        'font-weight:700;' +
        'font-size:.9rem;' +
        'box-shadow:0 20px 50px -14px rgba(0,0,0,.5);' +
        'opacity:0;' +
        'pointer-events:none;' +
        'transition:opacity .3s,transform .3s;' +
        'max-width:90vw;' +
        'text-align:center;';

    document.body.appendChild(toast);

    var toastTimer = null;

    function showToast(message, success){

        toast.textContent =
            message;

        toast.style.background =
            success === false
                ? '#b42318'
                : '#0a0f1e';

        toast.style.opacity =
            '1';

        toast.style.transform =
            'translate(-50%,0)';

        clearTimeout(toastTimer);

        toastTimer =
            setTimeout(function(){

                toast.style.opacity =
                    '0';

                toast.style.transform =
                    'translate(-50%,20px)';

            },4000);

    }

    /*
    |--------------------------------------------------------------------------
    | Value helper
    |--------------------------------------------------------------------------
    */

    function value(id){

        var element =
            document.getElementById(id);

        return element
            ? String(element.value || '').trim()
            : '';

    }

    /*
    |--------------------------------------------------------------------------
    | Phone validation
    |--------------------------------------------------------------------------
    */

    function cleanPhone(phone){

        var digits =
            phone.replace(/\D/g,'');

        if(
            digits.length > 10 &&
            digits.indexOf('91') === 0
        ){

            digits =
                digits.slice(-10);

        }

        return digits;

    }

    function validPhone(phone){

        var digits =
            cleanPhone(phone);

        return /^[6-9]\d{9}$/.test(
            digits
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Fare calculation
    |--------------------------------------------------------------------------
    */

    function normaliseText(text){

        return String(text || '')
            .toLowerCase()
            .replace(/[^\p{L}\p{N}\s-]/gu,' ')
            .replace(/\s+/g,' ')
            .trim();

    }

    function findRoute(drop){

        var normalized =
            normaliseText(drop);

        var routes =
            window.ANAYA &&
            window.ANAYA.routes
                ? window.ANAYA.routes
                : {};

        if(!normalized){
            return null;
        }

        var best = null;

        Object.keys(routes).forEach(function(key){

            var normalizedKey =
                normaliseText(key);

            if(
                normalized === normalizedKey ||
                normalized.indexOf(normalizedKey) !== -1 ||
                normalizedKey.indexOf(normalized) !== -1
            ){

                if(
                    !best ||
                    normalizedKey.length > best.key.length
                ){

                    best = {
                        key:key,
                        route:routes[key]
                    };

                }

            }

        });

        return best;

    }

    function calculateFare(){

        var drop =
            value('drop');

        var vehicle =
            vehicleSelect
                ? vehicleSelect.value
                : '';

        if(
            !drop ||
            !vehicle
        ){

            if(fareChip){
                fareChip.hidden = true;
            }

            if(fareValue){

                fareValue.textContent =
                    'Fare on request';

                fareValue.classList.add(
                    'neutral'
                );

            }

            return;

        }

        var routes =
            window.ANAYA.routes || {};

        var fleet =
            window.ANAYA.fleet || {};

        var routeMatch =
            findRoute(drop);

        var fare = 0;

        if(
            routeMatch &&
            routeMatch.route &&
            Number(routeMatch.route.base) > 0
        ){

            /*
             * Published route fare is sedan base fare.
             * For larger vehicles use fleet multiplier.
             */

            var base =
                Number(
                    routeMatch.route.base
                );

            var selectedVehicle =
                fleet[vehicle];

            if(
                selectedVehicle &&
                Number(selectedVehicle.mult) > 0
            ){

                fare =
                    Math.round(
                        base *
                        Number(selectedVehicle.mult)
                    );

            }else{

                fare =
                    base;

            }

        }

        if(fare > 0){

            if(fareChip){
                fareChip.hidden = false;
            }

            if(fareValue){

                fareValue.textContent =
                    '₹' +
                    fare.toLocaleString(
                        'en-IN'
                    );

                fareValue.classList.remove(
                    'neutral'
                );

            }

        }else{

            if(fareChip){
                fareChip.hidden = false;
            }

            if(fareValue){

                fareValue.textContent =
                    'Fare on request';

                fareValue.classList.add(
                    'neutral'
                );

            }

        }

    }

    if(dropInput){

        dropInput.addEventListener(
            'input',
            calculateFare
        );

        dropInput.addEventListener(
            'change',
            calculateFare
        );

    }

    if(vehicleSelect){

        vehicleSelect.addEventListener(
            'change',
            calculateFare
        );

    }

    /*
    |--------------------------------------------------------------------------
    | WhatsApp message
    |--------------------------------------------------------------------------
    */

    function buildWhatsAppUrl(){

        var name =
            value('custName');

        var phone =
            value('custPhone');

        var pickup =
            value('pickup');

        var drop =
            value('drop');

        var date =
            value('tripDate');

        var time =
            value('tripTime');

        var vehicleName = '';

        if(
            vehicleSelect &&
            vehicleSelect.selectedIndex >= 0 &&
            vehicleSelect.value
        ){

            vehicleName =
                vehicleSelect.options[
                    vehicleSelect.selectedIndex
                ].text;

        }

        var fare =
            fareValue
                ? fareValue.textContent.trim()
                : '';

        var lines = [
            'Hi Anaya Cab, mujhe cab book karni hai:',
            name ? 'Name: ' + name : '',
            phone ? 'Phone: ' + phone : '',
            pickup ? 'Pickup: ' + pickup : '',
            drop ? 'Drop: ' + drop : '',
            date ? 'Date: ' + date : '',
            time ? 'Time: ' + time : '',
            vehicleName ? 'Vehicle: ' + vehicleName : '',
            fare && fare !== 'Fare on request'
                ? 'Approx fare: ' + fare
                : ''
        ].filter(Boolean);

        var message =
            encodeURIComponent(
                lines.join('\n')
            );

        return (
            'https://wa.me/' +
            encodeURIComponent(
                window.ANAYA.whatsapp
            ) +
            '?text=' +
            message
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Initial fare
    |--------------------------------------------------------------------------
    */

    calculateFare();

    /*
    |--------------------------------------------------------------------------
    | Submit
    |--------------------------------------------------------------------------
    */

    form.addEventListener(
        'submit',
        async function(event){

            event.preventDefault();
            event.stopPropagation();

            if(!form.checkValidity()){

                form.reportValidity();

                return;

            }

            var phone =
                value('custPhone');

            if(!validPhone(phone)){

                showToast(
                    'Please enter a valid 10-digit mobile number.',
                    false
                );

                if(phoneInput){
                    phoneInput.focus();
                }

                return;

            }

            var pickup =
                value('pickup');

            var drop =
                value('drop');

            if(!pickup || !drop){

                showToast(
                    'Please enter pickup and drop location.',
                    false
                );

                return;

            }

            var date =
                value('tripDate');

            if(
                date &&
                date < todayString
            ){

                showToast(
                    'Please select today or a future date.',
                    false
                );

                return;

            }

            var whatsappUrl =
                buildWhatsAppUrl();

            var btnText =
                qs('.btn-text',bookButton);

            var spinner =
                qs('.btn-spinner',bookButton);

            if(bookButton){
                bookButton.disabled = true;
            }

            if(btnText){
                btnText.textContent =
                    'Sending…';
            }

            if(spinner){
                spinner.hidden = false;
            }

            /*
             * Open WhatsApp immediately while still inside the user gesture.
             * This avoids popup blockers on mobile browsers.
             */

            try{

                window.open(
                    whatsappUrl,
                    '_blank',
                    'noopener,noreferrer'
                );

            }catch(error){

                window.location.href =
                    whatsappUrl;

            }

            /*
             * Save booking to MySQL.
             */

            try{

                var formData =
                    new FormData(form);

                formData.set(
                    'fare',
                    fareValue
                        ? fareValue.textContent.replace(/[^\d]/g,'')
                        : ''
                );

                var response =
                    await fetch(
                        window.ANAYA.bookingEndpoint,
                        {
                            method:'POST',
                            body:formData,
                            headers:{
                                'X-Requested-With':
                                    'XMLHttpRequest',
                                'Accept':
                                    'application/json'
                            },
                            credentials:'same-origin'
                        }
                    );

                var data = null;

                try{

                    data =
                        await response.json();

                }catch(jsonError){

                    data = {
                        ok:false
                    };

                }

                if(
                    response.ok &&
                    data &&
                    data.ok &&
                    !data.spam
                ){

                    showToast(
                        'Booking request received ✓ WhatsApp pe confirmation complete kar dein.',
                        true
                    );

                }else if(
                    data &&
                    data.ok &&
                    data.spam
                ){

                    /*
                     * Honeypot response.
                     */

                }else{

                    showToast(
                        'WhatsApp request bhej di gayi hai. Hum booking confirm karenge.',
                        false
                    );

                }

            }catch(error){

                showToast(
                    'WhatsApp request bhej di gayi hai. Booking confirmation ke liye contact karein.',
                    false
                );

            }finally{

                setTimeout(function(){

                    if(bookButton){
                        bookButton.disabled = false;
                    }

                    if(btnText){
                        btnText.textContent =
                            'Book now';
                    }

                    if(spinner){
                        spinner.hidden = true;
                    }

                },2500);

            }

        }
    );

})();

})();
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>