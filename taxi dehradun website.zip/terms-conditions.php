<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$email       = defined('BUSINESS_EMAIL') ? BUSINESS_EMAIL : 'anayacabservice.in@gmail.com';

$page_title       = "Terms & Conditions | Anaya Cab Service Dehradun";
$page_description = "Terms and conditions for Anaya Cab Service Dehradun — booking rules, transparent fares, payments, passenger guidelines and cancellation policy.";
$page_url         = $domain . "/terms-conditions";

$__faqs = [
  ['How is my taxi booking confirmed with Anaya Cab Service?', 'Your booking is confirmed once we send the driver name, vehicle number, pickup time and fixed fare via WhatsApp or SMS. For most local, airport and outstation trips, zero advance payment is required.'],
  ['Are toll taxes, parking and state taxes included in the quoted fare?', 'Quoted fares include vehicle hire, fuel and driver allowance. Toll taxes, state border permits, FASTag charges and attraction parking are charged at actuals with transparent receipts.'],
  ['Can I reschedule or change my pickup time?', 'Yes, pickup timings can be modified at no extra charge by notifying us at least 2 hours before local/airport trips or 6 hours before outstation trips via call or WhatsApp.'],
  ['What payment methods do you accept?', 'We accept Cash, UPI (Google Pay, PhonePe, Paytm, BHIM), Net Banking and major Debit/Credit Cards upon completion of your trip.']
];

$__faq_entities = [];
foreach ($__faqs as $f) {
  $__faq_entities[] = [
    '@type' => 'Question',
    'name' => $f[0],
    'acceptedAnswer' => [
      '@type' => 'Answer',
      'text' => $f[1]
    ]
  ];
}

$page_schema = '<script type="application/ld+json">'
. json_encode([
  '@context' => 'https://schema.org',
  '@graph' => [
    [
      '@type' => 'WebPage',
      '@id' => $page_url . '#webpage',
      'url' => $page_url,
      'name' => $page_title,
      'description' => $page_description,
      'isPartOf' => ['@id' => $domain . '/#website']
    ],
    [
      '@type' => 'FAQPage',
      '@id' => $page_url . '#faq',
      'mainEntity' => $__faq_entities
    ]
  ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>
<main>
<style>
.lp{--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f6f9ff;--radius:18px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef3fb,#ffffff 240px)}
.lp *{box-sizing:border-box}
.lp .lp-in{max-width:1120px;margin:0 auto;padding:0 22px}
.lp .lp-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:18px 0 0;font-size:.82rem;color:var(--slate)}
.lp .lp-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}
.lp .lp-crumb a:hover{color:var(--blue)}
.lp .lp-crumb i{font-size:.62rem;color:#94a3b8}
.lp .lp-crumb .cur{color:var(--ink);font-weight:600}
.lp .lp-head{padding:26px 0 8px;max-width:760px}
.lp .lp-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.lp .lp-head h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.8rem,4vw,2.6rem);font-weight:800;letter-spacing:-.03em;line-height:1.08;margin:14px 0 10px}
.lp .lp-head p{color:var(--slate);font-size:1.02rem;line-height:1.6;margin:0}
.lp .lp-meta{display:flex;flex-wrap:wrap;gap:16px;margin-top:14px;font-size:.8rem;color:var(--slate)}
.lp .lp-meta span{display:inline-flex;align-items:center;gap:7px}
.lp .lp-meta i{color:var(--blue)}
.lp .lp-layout{display:grid;grid-template-columns:248px 1fr;gap:40px;padding:30px 0 60px;align-items:start}
.lp .lp-toc{position:sticky;top:88px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:18px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 12px 30px -16px rgba(9,32,84,.18)}
.lp .lp-toc h2{font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#94a3b8;margin:0 0 12px}
.lp .lp-toc a{display:block;padding:7px 10px;border-radius:10px;color:var(--slate);font-size:.86rem;font-weight:500;text-decoration:none;border-left:2px solid transparent;transition:.2s}
.lp .lp-toc a:hover{background:var(--soft);color:var(--blue);border-left-color:var(--blue)}
.lp .lp-body{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:36px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 12px 30px -16px rgba(9,32,84,.18)}
.lp .lp-body section{margin-bottom:34px;scroll-margin-top:92px}
.lp .lp-body section:last-child{margin-bottom:0}
.lp .lp-body h2{font-family:'Sora','Poppins',sans-serif;font-size:1.24rem;font-weight:700;letter-spacing:-.02em;margin:0 0 12px;color:var(--ink);display:flex;align-items:center;gap:10px}
.lp .lp-body h2 span.num{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:8px;background:var(--blue-tint);color:var(--blue);font-size:.82rem;font-weight:800}
.lp .lp-body p{color:#334155;line-height:1.75;font-size:.95rem;margin:0 0 14px}
.lp .lp-body p:last-child{margin-bottom:0}
.lp .lp-body ul{margin:0 0 14px 20px;padding:0;color:#334155;line-height:1.75;font-size:.95rem}
.lp .lp-body li{margin-bottom:6px}
.lp .lp-highlight{background:linear-gradient(135deg,#f8faff,#eaf1ff);border:1px solid #d4e3fc;border-left:4px solid var(--blue);border-radius:12px;padding:16px 18px;margin:18px 0}
.lp .lp-faq{margin-top:24px}
.lp .lp-faq details{background:var(--soft);border:1px solid var(--line);border-radius:12px;padding:14px 18px;margin-bottom:10px;transition:.2s}
.lp .lp-faq details[open]{background:#fff;border-color:var(--blue)}
.lp .lp-faq summary{font-weight:700;color:var(--ink);cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px}
.lp .lp-faq summary::-webkit-details-marker{display:none}
.lp .lp-faq summary::after{content:'+';font-size:1.2rem;color:var(--blue);font-weight:700;transition:transform .2s}
.lp .lp-faq details[open] summary::after{content:'–'}
.lp .lp-faq p{margin-top:10px;font-size:.92rem;color:var(--slate)}
@media(max-width:860px){
.lp .lp-layout{grid-template-columns:1fr;gap:20px}
.lp .lp-toc{display:none}
.lp .lp-body{padding:22px 18px}
}
</style>

<div class="lp">
<div class="lp-in">

<nav class="lp-crumb" aria-label="Breadcrumb">
<a href="/">Home</a>
<i class="fa-solid fa-chevron-right"></i>
<span class="cur">Terms &amp; Conditions</span>
</nav>

<header class="lp-head">
<span class="lp-eyebrow"><i class="fa-solid fa-shield-halved"></i> Agreement</span>
<h1>Terms &amp; Conditions</h1>
<p>Transparent guidelines for booking, fares, payments and travel with Anaya Cab Service in Dehradun and Uttarakhand.</p>
<div class="lp-meta">
<span><i class="fa-regular fa-calendar-check"></i> Last Updated: <?php echo date('F Y'); ?></span>
<span><i class="fa-solid fa-location-dot"></i> Dehradun, Uttarakhand</span>
</div>
</header>

<div class="lp-layout">

<aside class="lp-toc" aria-label="Table of Contents">
<h2>On this page</h2>
<a href="#sec-overview">1. Overview</a>
<a href="#sec-booking">2. Booking &amp; Confirmation</a>
<a href="#sec-fares">3. Fares &amp; Tolls</a>
<a href="#sec-passenger">4. Passenger Guidelines</a>
<a href="#sec-cancellation">5. Cancellation Policy</a>
<a href="#sec-faq">6. Common FAQs</a>
</aside>

<article class="lp-body">

<section id="sec-overview">
<h2><span class="num">1</span> Overview &amp; Acceptance</h2>
<p>These Terms &amp; Conditions govern all taxi reservations made with <strong>Anaya Cab Service</strong> (taxidehradun.com) via website form, WhatsApp or phone. By confirming a booking with us, you agree to these transparent terms.</p>
<div class="lp-highlight">
<strong>Quick Summary:</strong> Anaya Cab Service provides fixed-fare local cabs, Jolly Grant Airport pickups, hill station transfers and Char Dham Yatra tours with verified drivers and zero hidden surcharges.
</div>
</section>

<section id="sec-booking">
<h2><span class="num">2</span> Booking &amp; Confirmation</h2>
<p>Bookings are accepted 24 hours a day, 7 days a week. When you book, our dispatch team provides driver details, vehicle registration number, and pickup time. Most local and airport bookings require <strong>no upfront advance</strong>.</p>
<ul>
<li>Provide accurate pickup location, flight/train details, passenger count and luggage volume.</li>
<li>Child seats or specific route requests must be informed at the time of booking.</li>
<li>Driver tracking and real-time status updates are provided via WhatsApp.</li>
</ul>
</section>

<section id="sec-fares">
<h2><span class="num">3</span> Fares, Tolls &amp; Payments</h2>
<p>Our pricing model is 100% transparent with zero surge pricing:</p>
<ul>
<li><strong>Included:</strong> Vehicle rental, fuel, driver allowance and complimentary waiting time for airport flights.</li>
<li><strong>At Actuals:</strong> National highway tolls, state border entry taxes, FASTag charges and commercial parking fees (supported by official receipts).</li>
<li><strong>Payment Methods:</strong> Cash, UPI (Google Pay, PhonePe, Paytm), and Net Banking after trip completion.</li>
</ul>
</section>

<section id="sec-passenger">
<h2><span class="num">4</span> Passenger Guidelines &amp; Safety</h2>
<p>To ensure comfortable and safe mountain journeys across Uttarakhand:</p>
<ul>
<li>All passengers must follow state seatbelt guidelines.</li>
<li>Carrying hazardous materials or illicit items is strictly prohibited.</li>
<li>Hill driving regulations in Uttarakhand enforce speed limits and night driving restrictions in high-altitude zones for safety.</li>
</ul>
</section>

<section id="sec-cancellation">
<h2><span class="num">5</span> Cancellation &amp; Rescheduling</h2>
<p>We provide a flexible, customer-first cancellation policy. You can cancel or reschedule local/airport pickups free of charge up to 2 hours prior to pickup. For multi-day or Char Dham Yatra tours, please refer to our dedicated <a href="/cancellation-policy" style="color:var(--blue);font-weight:600">Cancellation &amp; Refund Policy</a>.</p>
</section>

<section id="sec-faq">
<h2><span class="num">6</span> Frequently Asked Questions</h2>
<div class="lp-faq">
<?php foreach ($__faqs as $faq): ?>
<details>
<summary><?php echo htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8'); ?></summary>
<p><?php echo htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8'); ?></p>
</details>
<?php endforeach; ?>
</div>
</section>

</article>

</div>

</div>
</div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>