<?php
/**
 * Agent cron runner. Optional.
 * URL: /api/agent-cron.php?token=YOUR_TOKEN
 */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/agent-functions.php';
$pdo = agent_db();
agent_tables_install($pdo);
$token = agent_get_setting('agent_cron_token', '');
if ($token === '') {
    $token = bin2hex(random_bytes(16));
    agent_set_setting('agent_cron_token', $token);
}
if (!hash_equals($token, (string)($_GET['token'] ?? ''))) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Forbidden','hint'=>'Set/copy token from AI Agents settings table.']);
    exit;
}
$stmt = $pdo->query("SELECT id FROM agent_tasks WHERE status='pending' ORDER BY priority ASC, id ASC LIMIT 3");
$ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
$out = [];
foreach ($ids as $id) $out[$id] = agent_execute_task((int)$id);
echo json_encode(['ok'=>true,'ran'=>count($ids),'results'=>$out], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
