<?php
/**
 * Anaya Cab Service — Canonical Booking API
 *
 * SINGLE SOURCE OF TRUTH
 * Endpoint:
 *   /api/booking.php
 *
 * /booking -> /booking.php -> /api/booking.php
 *
 * Responsibilities:
 * - Validate booking request
 * - Honeypot protection
 * - Rate limiting
 * - Strict phone/date/time validation
 * - Vehicle validation against FLEET
 * - Never converts missing fare into 0
 * - Creates/repairs bookings table
 * - Prepared INSERT
 * - JSON-only response
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

/*
|--------------------------------------------------------------------------
| JSON RESPONSE
|--------------------------------------------------------------------------
*/
function booking_json(
    bool $ok,
    string $message = '',
    array $extra = [],
    int $status = 200
): never {
    http_response_code($status);

    echo json_encode(
        array_merge(
            [
                'ok'      => $ok,
                'message' => $message,
            ],
            $extra
        ),
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

/*
|--------------------------------------------------------------------------
| POST ONLY
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    booking_json(
        false,
        'Method not allowed.',
        [],
        405
    );
}

/*
|--------------------------------------------------------------------------
| REQUEST SIZE
|--------------------------------------------------------------------------
*/
$contentLength = isset($_SERVER['CONTENT_LENGTH'])
    ? (int)$_SERVER['CONTENT_LENGTH']
    : 0;

if ($contentLength > 65536) {
    booking_json(
        false,
        'Request too large.',
        [],
        413
    );
}

/*
|--------------------------------------------------------------------------
| LOAD CONFIG
|--------------------------------------------------------------------------
*/
$configCandidates = [
    __DIR__ . '/../includes/config.php',
    __DIR__ . '/../../includes/config.php',
];

$fleetCandidates = [
    __DIR__ . '/../includes/fleet-config.php',
    __DIR__ . '/../../includes/fleet-config.php',
];

$configFile = null;
$fleetFile  = null;

foreach ($configCandidates as $file) {
    if (is_file($file)) {
        $configFile = $file;
        break;
    }
}

foreach ($fleetCandidates as $file) {
    if (is_file($file)) {
        $fleetFile = $file;
        break;
    }
}

if (!$configFile) {
    booking_json(
        false,
        'Booking configuration unavailable.',
        [],
        500
    );
}

try {
    require_once $configFile;

    if ($fleetFile) {
        require_once $fleetFile;
    }
} catch (Throwable $e) {
    error_log(
        'Anaya Booking Config Error: ' .
        $e->getMessage()
    );

    booking_json(
        false,
        'Booking service temporarily unavailable.',
        [],
        500
    );
}

/*
|--------------------------------------------------------------------------
| HONEYPOT
|--------------------------------------------------------------------------
|
| Bot-filled hidden field:
| return fake success but NEVER save.
|--------------------------------------------------------------------------
*/
$honeypot = trim(
    (string)($_POST['website'] ?? '')
);

if ($honeypot !== '') {
    booking_json(
        true,
        'Request received.',
        [
            'spam' => true,
        ]
    );
}

/*
|--------------------------------------------------------------------------
| BASIC RATE LIMIT
|--------------------------------------------------------------------------
*/
$ip = trim(
    (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown')
);

if ($ip === '') {
    $ip = 'unknown';
}

$rateDir = sys_get_temp_dir()
    . DIRECTORY_SEPARATOR
    . 'anaya_booking_rate';

if (!is_dir($rateDir)) {
    @mkdir($rateDir, 0700, true);
}

$rateKey = hash(
    'sha256',
    $ip
);

$rateFile = $rateDir
    . DIRECTORY_SEPARATOR
    . $rateKey
    . '.json';

$now = time();

/*
 * 8 requests / 5 minutes / IP
 */
$windowSeconds = 300;
$maxRequests   = 8;

$requestTimes = [];

if (is_file($rateFile)) {
    $raw = @file_get_contents($rateFile);

    if ($raw !== false) {
        $decoded = json_decode(
            $raw,
            true
        );

        if (is_array($decoded)) {
            foreach ($decoded as $timestamp) {
                if (is_numeric($timestamp)) {
                    $requestTimes[] = (int)$timestamp;
                }
            }
        }
    }
}

$requestTimes = array_values(
    array_filter(
        $requestTimes,
        static function (int $timestamp) use (
            $now,
            $windowSeconds
        ): bool {
            return $timestamp > (
                $now - $windowSeconds
            );
        }
    )
);

if (count($requestTimes) >= $maxRequests) {
    booking_json(
        false,
        'Too many requests. Please try again after a few minutes.',
        [],
        429
    );
}

$requestTimes[] = $now;

@file_put_contents(
    $rateFile,
    json_encode($requestTimes),
    LOCK_EX
);

/*
|--------------------------------------------------------------------------
| CLEAN INPUT
|--------------------------------------------------------------------------
*/
$clean = static function (
    string $key,
    int $max = 120
): string {
    $value = $_POST[$key] ?? '';

    if (is_array($value)) {
        return '';
    }

    $value = trim((string)$value);

    $value = strip_tags($value);

    $value = preg_replace(
        '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',
        '',
        $value
    ) ?? '';

    if (function_exists('mb_substr')) {
        return mb_substr(
            $value,
            0,
            $max
        );
    }

    return substr(
        $value,
        0,
        $max
    );
};

/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/
$name = $clean(
    'customer_name',
    100
);

$phone = $clean(
    'phone',
    30
);

$pickup = $clean(
    'pickup',
    255
);

$drop = $clean(
    'drop',
    255
);

$date = $clean(
    'date',
    10
);

$time = $clean(
    'time',
    5
);

$vehicle = $clean(
    'vehicle',
    60
);

$fareRaw = $clean(
    'fare',
    40
);

/*
|--------------------------------------------------------------------------
| REQUIRED FIELD VALIDATION
|--------------------------------------------------------------------------
*/
if (
    $pickup === '' ||
    $drop === '' ||
    $date === '' ||
    $time === '' ||
    $phone === ''
) {
    booking_json(
        false,
        'Please enter all required booking details.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| PHONE VALIDATION
|--------------------------------------------------------------------------
*/
$phoneDigits = preg_replace(
    '/\D+/',
    '',
    $phone
);

$phoneDigits = is_string($phoneDigits)
    ? $phoneDigits
    : '';

/*
 * Accept:
 * 8077611583
 * 918077611583
 * +918077611583
 */
if (
    strlen($phoneDigits) > 10 &&
    substr($phoneDigits, 0, 2) === '91'
) {
    $phoneDigits = substr(
        $phoneDigits,
        -10
    );
}

if (
    strlen($phoneDigits) !== 10 ||
    preg_match(
        '/^[6-9][0-9]{9}$/',
        $phoneDigits
    ) !== 1
) {
    booking_json(
        false,
        'Please enter a valid Indian mobile number.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| DATE VALIDATION
|--------------------------------------------------------------------------
*/
if (
    preg_match(
        '/^\d{4}-\d{2}-\d{2}$/',
        $date
    ) !== 1
) {
    booking_json(
        false,
        'Invalid travel date.',
        [],
        422
    );
}

[$year, $month, $day] = array_map(
    'intval',
    explode('-', $date)
);

if (!checkdate(
    $month,
    $day,
    $year
)) {
    booking_json(
        false,
        'Invalid travel date.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| TIME VALIDATION
|--------------------------------------------------------------------------
*/
if (
    preg_match(
        '/^\d{2}:\d{2}$/',
        $time
    ) !== 1
) {
    booking_json(
        false,
        'Invalid travel time.',
        [],
        422
    );
}

[$hour, $minute] = array_map(
    'intval',
    explode(':', $time)
);

if (
    $hour < 0 ||
    $hour > 23 ||
    $minute < 0 ||
    $minute > 59
) {
    booking_json(
        false,
        'Invalid travel time.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| DATE CANNOT BE IN PAST
|--------------------------------------------------------------------------
*/
try {
    $timezone = new DateTimeZone(
        'Asia/Kolkata'
    );

    $today = new DateTimeImmutable(
        'today',
        $timezone
    );

    $tripDate = new DateTimeImmutable(
        $date,
        $timezone
    );

    if ($tripDate < $today) {
        booking_json(
            false,
            'Please select today or a future date.',
            [],
            422
        );
    }
} catch (Throwable $e) {
    booking_json(
        false,
        'Invalid travel date.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| VEHICLE VALIDATION
|--------------------------------------------------------------------------
|
| Vehicle key must exist in FLEET.
| Unknown vehicle is NOT silently accepted.
|--------------------------------------------------------------------------
*/
if (
    !isset($FLEET) ||
    !is_array($FLEET) ||
    !$FLEET
) {
    booking_json(
        false,
        'Fleet configuration unavailable.',
        [],
        500
    );
}

if (
    $vehicle === '' ||
    !array_key_exists(
        $vehicle,
        $FLEET
    )
) {
    booking_json(
        false,
        'Please select a valid vehicle.',
        [],
        422
    );
}

$vehicleData = $FLEET[$vehicle];

$vehicleName = trim(
    (string)(
        $vehicleData['name']
        ?? ''
    )
);

if ($vehicleName === '') {
    booking_json(
        false,
        'Selected vehicle is not configured correctly.',
        [],
        422
    );
}

/*
|--------------------------------------------------------------------------
| FARE HANDLING
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Frontend fare is NOT trusted as a pricing authority.
|
| Missing / blank / invalid fare => NULL.
|
| NEVER:
|   missing fare => 0
|
| This prevents the debugger from interpreting a missing fare
| as an actual zero fare.
|--------------------------------------------------------------------------
*/
$fareNumeric = null;

$fareClean = trim(
    preg_replace(
        '/[^\d.]/',
        '',
        $fareRaw
    ) ?? ''
);

if ($fareClean !== '') {

    /*
     * Only one decimal point.
     */
    if (
        substr_count(
            $fareClean,
            '.'
        ) <= 1 &&
        is_numeric($fareClean)
    ) {
        $fareFloat = (float)$fareClean;

        /*
         * Valid booking fare range.
         *
         * 0 is NOT stored as a legitimate quote.
         * If frontend sends 0, treat it as missing.
         */
        if (
            $fareFloat > 0 &&
            $fareFloat <= 1000000
        ) {
            $fareNumeric = (string)(
                round($fareFloat, 2)
            );
        }
    }
}

/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/
if (!function_exists('db')) {
    booking_json(
        false,
        'Database configuration unavailable.',
        [],
        500
    );
}

try {
    $pdo = db();
} catch (Throwable $e) {
    error_log(
        'Anaya Booking DB Init Error: ' .
        $e->getMessage()
    );

    booking_json(
        false,
        'Booking service temporarily unavailable.',
        [],
        503
    );
}

if (!$pdo instanceof PDO) {
    booking_json(
        false,
        'Booking service temporarily unavailable.',
        [],
        503
    );
}

/*
|--------------------------------------------------------------------------
| DATABASE TABLE
|--------------------------------------------------------------------------
*/
try {

    $pdo->exec(
        "
        CREATE TABLE IF NOT EXISTS `bookings` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `customer_name` VARCHAR(120) DEFAULT NULL,
            `phone` VARCHAR(30) DEFAULT NULL,
            `pickup` VARCHAR(255) NOT NULL,
            `drop_location` VARCHAR(255) NOT NULL,
            `trip_date` DATE NOT NULL,
            `trip_time` TIME NOT NULL,
            `vehicle` VARCHAR(80) DEFAULT NULL,
            `fare_estimate` VARCHAR(40) DEFAULT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'new',
            `source` VARCHAR(30) NOT NULL DEFAULT 'website',
            `notes` TEXT DEFAULT NULL,
            `ip` VARCHAR(64) DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT NULL
                ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_status` (`status`),
            KEY `idx_trip_date` (`trip_date`),
            KEY `idx_phone` (`phone`),
            KEY `idx_created_at` (`created_at`)
        )
        ENGINE=InnoDB
        DEFAULT CHARSET=utf8mb4
        COLLATE=utf8mb4_unicode_ci
        "
    );

} catch (Throwable $e) {

    error_log(
        'Anaya Booking Table Error: ' .
        $e->getMessage()
    );
}

/*
|--------------------------------------------------------------------------
| COMPATIBILITY COLUMNS
|--------------------------------------------------------------------------
*/
$columnDefinitions = [

    'customer_name' =>
        "VARCHAR(120) DEFAULT NULL",

    'phone' =>
        "VARCHAR(30) DEFAULT NULL",

    'status' =>
        "VARCHAR(20) NOT NULL DEFAULT 'new'",

    'source' =>
        "VARCHAR(30) NOT NULL DEFAULT 'website'",

    'notes' =>
        "TEXT DEFAULT NULL",

    'updated_at' =>
        "TIMESTAMP NULL DEFAULT NULL
         ON UPDATE CURRENT_TIMESTAMP",
];

foreach (
    $columnDefinitions as $column => $definition
) {
    try {

        $stmt = $pdo->prepare(
            "SHOW COLUMNS FROM `bookings`
             LIKE ?"
        );

        $stmt->execute([
            $column
        ]);

        $exists = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        if (!$exists) {

            $pdo->exec(
                "ALTER TABLE `bookings`
                 ADD COLUMN `$column`
                 $definition"
            );
        }

    } catch (Throwable $e) {

        /*
         * Existing schema may already have the column
         * with an incompatible definition.
         *
         * Do not kill booking endpoint here.
         */
        error_log(
            'Anaya Booking Column [' .
            $column .
            ']: ' .
            $e->getMessage()
        );
    }
}

/*
|--------------------------------------------------------------------------
| SAVE BOOKING
|--------------------------------------------------------------------------
*/
try {

    $stmt = $pdo->prepare(
        "
        INSERT INTO `bookings`
        (
            `customer_name`,
            `phone`,
            `pickup`,
            `drop_location`,
            `trip_date`,
            `trip_time`,
            `vehicle`,
            `fare_estimate`,
            `status`,
            `source`,
            `ip`,
            `created_at`
        )
        VALUES
        (
            :customer_name,
            :phone,
            :pickup,
            :drop_location,
            :trip_date,
            :trip_time,
            :vehicle,
            :fare_estimate,
            :status,
            :source,
            :ip,
            NOW()
        )
        "
    );

    $stmt->execute([
        ':customer_name' =>
            $name !== ''
                ? $name
                : null,

        ':phone' =>
            $phoneDigits,

        ':pickup' =>
            $pickup,

        ':drop_location' =>
            $drop,

        ':trip_date' =>
            $date,

        ':trip_time' =>
            $time,

        ':vehicle' =>
            $vehicleName,

        ':fare_estimate' =>
            $fareNumeric,

        ':status' =>
            'new',

        ':source' =>
            'website',

        ':ip' =>
            substr(
                $ip,
                0,
                64
            ),
    ]);

    $bookingId = (int)$pdo->lastInsertId();

    /*
     * IMPORTANT:
     * Return the stored fare state so frontend/debugger
     * can distinguish NULL from real 0.
     */
    booking_json(
        true,
        'Booking received successfully.',
        [
            'id' => $bookingId,
            'spam' => false,
            'fare_saved' => (
                $fareNumeric !== null
            ),
            'fare' => $fareNumeric,
            'vehicle' => $vehicleName,
        ]
    );

} catch (Throwable $e) {

    error_log(
        'Anaya Booking Save Error: ' .
        $e->getMessage()
    );

    booking_json(
        false,
        'Booking could not be saved right now.',
        [],
        500
    );
}