﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = "Jolly Grant Airport to Rishikesh Taxi | Anaya Cab";
$page_description = "Book Jolly Grant Airport to Rishikesh taxi. Flat ₹1,200 for Sedan, flight tracking, meet and greet at arrivals, Tapovan & ashram drops. Call " . $phone .";
$page_url         = $domain . "/jolly-grant-airport-to-rishikesh-taxi";

$__faqs = [
    ["What is the taxi fare from Jolly Grant Airport to Rishikesh?", "Taxi fare from Jolly Grant Airport (DED) to Rishikesh starts at flat ₹1,200 for an AC Sedan (Dzire/Etios) and ₹1,600 for a 6-seater SUV (Ertiga), with all airport parking and tolls included."],
    ["How far is Rishikesh from Jolly Grant Airport and how long does it take?", "The distance is only 21 km via Dehradun-Rishikesh Highway, taking about 30 to 40 minutes depending on local traffic."],
    ["Do you provide drops to Tapovan, Laxman Jhula and river rafting camps?", "Yes, we provide direct door-to-door drops to all hotels, yoga ashrams, and adventure camps in Tapovan, Ram Jhula, Laxman Jhula, and Shivpuri."],
    ["Will the driver wait if my flight is delayed?", "Yes, we track your flight number in real time and your chauffeur will be waiting at the arrival terminal with zero waiting penalty."]
];

$__faq_entities = [];
foreach ($__faqs as $f) {
    $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
    [
        '@type'=>'Service',
        '@id'=>$page_url.'#service',
        'name'=>'Jolly Grant Airport to Rishikesh Taxi Service',
        'serviceType'=>'Airport Transfer Taxi',
        'description'=>'Fast and reliable direct transfer from Jolly Grant Airport to Rishikesh ashrams, yoga retreats, Tapovan, and river rafting camps. Fixed flat fares from ₹1,200 with flight delay tracking.',
        'provider'=>[
            '@type'=>'TaxiService',
            'name'=>'Anaya Cab Service',
            'telephone'=>$phone_tel,
            'url'=>$domain.'/'
        ],
        'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'1200','description'=>'Flat ₹1200 for Jolly Grant Airport to Rishikesh transfer.']
    ],
    [
        '@type'=>'Trip',
        '@id'=>$page_url.'#trip',
        'name'=>'Jolly Grant Airport to Rishikesh Taxi Transfer',
        'origin'=>['@type'=>'Airport','name'=>'Jolly Grant Airport Dehradun','iataCode'=>'DED'],
        'destination'=>['@type'=>'Place','name'=>'Rishikesh Uttarakhand'],
        'distance'=>'21 km'
    ],
    ['@type'=>'BreadcrumbList','itemListElement'=>[
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>$domain.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Airport Taxi','item'=>$domain.'/dehradun-airport-taxi-service'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Airport to Rishikesh','item'=>$page_url]
    ]],
    ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities]
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
.ap-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef6ff 0%,#ffffff 460px);padding-bottom:60px}
.ap-pg *{box-sizing:border-box}
.ap-in{max-width:1200px;margin:0 auto;padding:0 24px}
.ap-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:0.82rem;color:var(--slate);padding:24px 0 0}
.ap-crumb a{color:var(--slate);text-decoration:none;transition:color 0.2s}.ap-crumb a:hover{color:var(--blue)}
.ap-crumb i{font-size:0.6rem;color:#94a3b8}.ap-crumb .cur{color:var(--ink);font-weight:700}
.ap-hero{display:grid;grid-template-columns:1.24fr 0.86fr;gap:36px;align-items:start;padding:20px 0 10px}
.ap-badge{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 14px;border-radius:999px}
.ap-hero h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2rem,4.4vw,3.1rem);font-weight:800;letter-spacing:-0.035em;line-height:1.06;margin:14px 0 12px;color:#07142f}
.ap-hero h1 em{font-style:normal;color:var(--blue)}

/* Big Featured Hero Image Layout (Screenshot 2 Match) */
.ap-hero-img-wrap{position:relative;width:100%;height:320px;border-radius:22px;overflow:hidden;margin:16px 0 20px;box-shadow:0 18px 42px -16px rgba(9,32,84,0.22);background:#07142f}
.ap-hero-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease}
.ap-hero-img-wrap:hover .ap-hero-img{transform:scale(1.03)}




.ap-lead-bold{font-weight:700;color:#07142f;font-size:1.06rem;line-height:1.55;margin:0 0 10px}
.ap-lead{color:var(--slate);font-size:1rem;line-height:1.66;margin:0 0 18px;max-width:58ch}
.ap-ai-box{background:#ffffff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:14px;padding:18px 20px;margin:0 0 24px;box-shadow:0 4px 16px rgba(0,87,255,0.05)}
.ap-ai-box h3{font-size:0.88rem;font-weight:800;color:var(--blue);margin:0 0 6px;display:flex;align-items:center;gap:6px}
.ap-ai-box p{margin:0;font-size:0.92rem;line-height:1.55;color:#334155}
.ap-actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.ap-btn-p{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.ap-btn-w{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
.ap-btn-s{display:inline-flex;align-items:center;gap:8px;padding:13px 20px;border-radius:14px;background:#fff;border:1px solid var(--line);color:#07142f;font-weight:700;text-decoration:none}

/* Right Column Luxury Fare Card (Screenshot 2 Match) */
.ap-fare-card{position:sticky;top:88px;background:linear-gradient(160deg,#0a2540,#0e4a7a);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,0.5);overflow:hidden}
.ap-fare-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,0.12);padding:6px 12px;border-radius:999px}
.ap-fare-card h3{font-family:'Sora',sans-serif;font-size:1.25rem;font-weight:800;margin:14px 0 14px}
.ap-fares-list{display:grid;gap:8px;margin:14px 0 0}
.ap-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);border-radius:12px;padding:11px 14px}
.ap-fr .v{font-weight:700;font-size:0.9rem}
.ap-fr .p{font-family:'Sora',sans-serif;font-weight:800;color:#00c2ff}
.ap-fare-card .cta{display:grid;gap:10px;margin-top:16px}
.ap-fare-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform 0.2s}
.ap-fare-card .cta .w{background:#fff;color:#0a2540}
.ap-fare-card .cta .g{background:#25d366;color:#04260f}
.ap-fare-card .cta a:hover{transform:translateY(-2px)}
.ap-fare-card .note{font-size:0.76rem;color:rgba(255,255,255,0.66);text-align:center;margin:12px 0 0}

.ap-sec{padding:48px 0;border-top:1px solid var(--line)}
.ap-sec h2{font-family:'Sora',sans-serif;font-size:clamp(1.7rem,3.4vw,2.3rem);font-weight:800;color:#07142f;margin:0 0 16px;letter-spacing:-0.03em}
.ap-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:24px}
.ap-box{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 4px 16px rgba(11,18,32,0.04)}
.ap-box h4{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#07142f;margin:0 0 8px}
.ap-box p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
.ap-faq-item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 22px;margin-bottom:12px}
.ap-faq-item h4{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#07142f;margin:0 0 8px}
.ap-faq-item p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
@media (max-width:960px){.ap-hero{grid-template-columns:1fr;gap:24px}.ap-hero-img-wrap{height:230px;border-radius:16px}.ap-fare-card{position:static}.ap-in{padding:0 16px}}
</style>

<div class="ap-pg">
    <div class="ap-in">
        <nav class="ap-crumb" aria-label="Breadcrumb">
            <a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>
            <a href="/dehradun-airport-taxi-service">Airport Taxi</a><i class="fa-solid fa-chevron-right"></i>
            <span class="cur">Airport to Rishikesh Taxi</span>
        </nav>

        <div class="ap-hero">
            <div>
                <span class="ap-badge"><i class="fa-solid fa-plane-departure"></i> Airport Transfer · Flat ₹1,200</span>
                <h1>Jolly Grant Airport to <em>Rishikesh</em> Taxi</h1>

                <div class="ap-hero-img-wrap">
                    <img 
                        src="/assets/images/routes/dehradun-to-rishikesh-taxi.webp" 
                        alt="Jolly Grant Airport to Rishikesh Taxi Service - Anaya Cab" 
                        width="680" 
                        height="360" 
                        loading="eager" 
                        decoding="async" 
                        class="ap-hero-img"
                    >
                </div>

                <p class="ap-lead-bold">Direct airport transfer from Jolly Grant (DED) to Rishikesh ashrams & Tapovan starting at flat ₹1,200 with flight delay tracking.</p>
                <p class="ap-lead">Fast and reliable direct transfer from Jolly Grant Airport to Rishikesh ashrams, yoga retreats, Tapovan, and river rafting camps. Fixed flat fares from ₹1,200 with flight delay tracking and professional local chauffeurs.</p>

                <div class="ap-ai-box">
                    <h3><i class="fa-solid fa-bolt"></i> Quick Direct Answer</h3>
                    <p>Taxi from Jolly Grant Airport (DED) to Rishikesh costs flat ₹1,200 for Sedan and ₹1,600 for 6-Seater SUV. Distance is only 21 km taking approximately 30 to 40 minutes via the direct highway.</p>
                </div>

                <div class="ap-actions">
                    <a class="ap-btn-p" href="/#booking"><i class="fa-solid fa-plane-arrival"></i> Book Airport Pickup</a>
                    <a class="ap-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need airport taxi to Rishikesh'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                    <a class="ap-btn-s" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
                </div>
            </div>

            <!-- Right Column Luxury Fare Card (Screenshot 2 Match) -->
            <aside class="ap-fare-card" aria-label="Airport to Rishikesh rates">
                <span class="tag"><i class="fa-solid fa-plane"></i> Airport Fare</span>
                <h3>Jolly Grant → Rishikesh</h3>
                <div class="ap-fares-list">
                    <div class="ap-fr"><span class="v">Sedan (Dzire/Etios)</span><span class="p">Flat ₹1,200</span></div>
                    <div class="ap-fr"><span class="v">Ertiga (6-Seater SUV)</span><span class="p">₹1,600</span></div>
                    <div class="ap-fr"><span class="v">Innova Crysta (Luxury)</span><span class="p">₹2,400</span></div>
                    <div class="ap-fr"><span class="v">Tempo Traveller (12-17)</span><span class="p">₹3,500</span></div>
                </div>
                <div class="cta">
                    <a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
                    <a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book airport taxi to Rishikesh'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
                </div>
                <p class="note">Sedan fare · SUV &amp; Crysta available · 24×7</p>
            </aside>
        </div>

        <section class="ap-sec">
            <h2>Why Choose Anaya Cab for Jolly Grant to Rishikesh Transfers?</h2>
            <div class="ap-grid">
                <div class="ap-box">
                    <h4><i class="fa-solid fa-plane" style="color:var(--blue);margin-right:8px;"></i> Flight Delay Tracking</h4>
                    <p>We monitor live flights. Your cab will be ready even if your arrival is delayed with zero waiting penalty.</p>
                </div>
                <div class="ap-box">
                    <h4><i class="fa-solid fa-handshake" style="color:#16a34a;margin-right:8px;"></i> Direct Tapovan & Ashram Drop</h4>
                    <p>Chauffeurs deliver you straight to your resort or yoga retreat without luggage change hassles.</p>
                </div>
                <div class="ap-box">
                    <h4><i class="fa-solid fa-receipt" style="color:#f59e0b;margin-right:8px;"></i> 100% Upfront Fixed Fare</h4>
                    <p>No extra toll charges, parking surprises, or luggage surcharges upon arrival.</p>
                </div>
            </div>
        </section>

        <section class="ap-sec">
            <h2>Frequently Asked Questions (Airport to Rishikesh)</h2>
            <?php foreach ($__faqs as $faq): ?>
            <div class="ap-faq-item">
                <h4><?php echo htmlspecialchars($faq[0]); ?></h4>
                <p><?php echo htmlspecialchars($faq[1]); ?></p>
            </div>
            <?php endforeach; ?>
        </section>
    </div>
</div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
