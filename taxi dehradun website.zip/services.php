<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$page_title = "Taxi Services in Dehradun | Local & Outstation - Anaya Cab";
$page_description = 'All Dehradun taxi services in one place – local cabs, Jolly Grant airport transfers, outstation routes, tempo travellers & Char Dham packages. Fixed fares.';
$page_url         = $domain . "/services";
$__faqs = [
["What taxi services does Anaya Cab Service offer in Dehradun?", "Anaya Cab Service offers local Dehradun taxi, Jolly Grant Airport pickup and drop, one-way and round-trip outstation cabs, hourly rentals, sightseeing tours, tempo traveller and group vans, and full Char Dham Yatra taxi packages — all with verified drivers and fixed fares."],
["How do I book a taxi service from this page?", "Pick any service or route card below, or call " . $phone . " or message on WhatsApp with your pickup, drop, date, passengers and luggage — we confirm the fare and driver details before the trip, with no advance for most bookings."],
["Is one-way outstation taxi available from Dehradun?", "Yes. One-way drops are available to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital, Chandigarh and many more destinations, so you pay only for one side of the journey instead of a full round trip."],
["Which vehicle should I choose for my trip?", "For 1 to 3 travellers a sedan is ideal, families and extra luggage suit an Ertiga or SUV, hill and yatra routes are best in an Innova or Crysta, and groups of 7 or more should pick a Tempo Traveller or Urbania — the choose-your-taxi guide below maps every trip type to the right vehicle."],
["Do you cover routes beyond Dehradun city?", "Yes. Beyond Dehradun we cover the full Uttarakhand circuit plus Delhi NCR, Chandigarh, Shimla, Manali, Agra, Jaipur and pilgrimage routes including Kedarnath, Badrinath, Gangotri and Yamunotri — see the route groups below for the complete list."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$groups = [
'Core Taxi Services' => [
['Dehradun Airport Taxi Service','Jolly Grant Airport pickup/drop for Dehradun, Mussoorie, Rishikesh, Haridwar, Delhi and yatra routes.','/dehradun-airport-taxi-service','fa-plane-departure','/assets/images/services/dehradun-airport-taxi-service.webp'],
['Local Taxi in Dehradun','Hourly and point-to-point city cab service for local rides, errands, hotels, railway station and ISBT.','/local-taxi-in-dehradun','fa-taxi','/assets/images/services/local-taxi-in-dehradun.webp'],
['Dehradun Local Sightseeing Taxi','City tour taxi for Robber\'s Cave, FRI, Tapkeshwar Temple, Buddha Temple, Sahastradhara and local markets.','/dehradun-local-sightseeing-taxi','fa-map-location-dot','/assets/images/services/dehradun-local-sightseeing-taxi.webp'],
['Outstation Taxi from Dehradun','One-way, round-trip and multi-day cab service from Dehradun to Uttarakhand and North India routes.','/outstation-taxi-from-dehradun','fa-route','/assets/images/services/outstation-taxi-from-dehradun.webp'],
['One Way Taxi Service in Dehradun','Pay only one side — one-way drops to airport, station and outstation destinations.','/one-way-taxi-service-in-dehradun','fa-arrow-right-long','/assets/images/services/one-way-taxi-service-in-dehradun.webp'],
['Dehradun Railway Station Taxi','Pre-booked station pickup and drop for local, airport and outstation destinations.','/dehradun-railway-station-taxi','fa-train','/assets/images/services/dehradun-railway-station-taxi.webp'],
['ISBT Dehradun Taxi','Cab pickup from ISBT Dehradun bus stand for city, airport, railway station and outstation drops.','/isbt-dehradun-taxi','fa-bus','/assets/images/services/isbt-dehradun-taxi.webp'],
['Car Rental in Dehradun','Cab rental and taxi hire with driver for local packages, airport transfers, tours and outstation trips.','/car-rental-in-dehradun','fa-car-side','/assets/images/services/car-rental-in-dehradun.webp'],
],
'Fleet & Vehicle Services' => [
['Sedan Taxi in Dehradun','Dzire, Etios and similar AC sedan cabs for local rides, airport transfers and affordable outstation drops.','/sedan-taxi-in-dehradun','fa-car','/assets/images/fleet/dzire.webp'],
['SUV Taxi in Dehradun','Ertiga, Innova and SUV cab options for families, luggage comfort, hill routes and long trips.','/suv-taxi-in-dehradun','fa-truck-monster','/assets/images/fleet/ertiga.webp'],
['Innova Taxi in Dehradun','Toyota Innova and Innova Crysta for airport transfers, hill routes, yatra and premium family travel.','/innova-taxi-in-dehradun','fa-van-shuttle','/assets/images/fleet/innova.webp'],
['Tempo Traveller in Dehradun','12-17 seater Tempo Traveller rental for groups, family tours, airport pickup and pilgrimage trips.','/tempo-traveller-in-dehradun','fa-van-shuttle','/assets/images/fleet/tempo.webp'],
['Force Urbania Rental Dehradun','Premium group traveller for family tours, corporate trips, wedding transfers and Char Dham routes.','/force-urbania-rental-dehradun','fa-bus-simple','/assets/images/fleet/urbania.webp'],
['Luxury Car Rental Dehradun','Chauffeur-driven premium sedans, Crysta and Urbania for VIP airport, corporate and wedding travel.','/luxury-car-rental-dehradun','fa-gem','/assets/images/fleet/innova-crysta.webp'],
['Best Taxi Service in Dehradun','Top rated 4.9★ cab service with verified chauffeurs, fixed pricing and 24x7 support.','/best-taxi-service-in-dehradun','fa-star','/assets/images/fleet/innova-crysta.webp'],
['Cheap Cab in Dehradun','Affordable budget taxi service starting from ₹12/km with zero surge pricing.','/cheap-cab-in-dehradun','fa-tags','/assets/images/fleet/dzire.webp'],
['Wedding Car Rental Dehradun','Decorated bridal cars, baraat processions and guest transfer fleets with wedding-experienced chauffeurs.','/wedding-car-rental-dehradun','fa-ring','/assets/images/fleet/dzire.webp'],
['Fleet Overview','View hatchback, sedan, Ertiga, Innova, Crysta, Tempo Traveller and Urbania options.','/fleet','fa-car-rear','/assets/images/fleet/dzire.webp'],
['Taxi Fare & Pricing','Check local packages, per-km rates and popular route fare guidance from Dehradun.','/pricing','fa-indian-rupee-sign','/assets/images/hero-bg.webp'],
],
'Popular Dehradun Route Taxis' => [
['Dehradun to Haridwar Taxi','One-way and round-trip cab service for Har Ki Pauri, hotels and pilgrimage travel.','/dehradun-to-haridwar-taxi','fa-location-dot','/assets/images/routes/dehradun-to-haridwar-taxi.webp'],
['Dehradun to Rishikesh Taxi','Taxi for Tapovan, Ram Jhula, Triveni Ghat, ashrams, rafting camps and airport pickups.','/dehradun-to-rishikesh-taxi','fa-location-dot','/assets/images/routes/dehradun-to-rishikesh-taxi.webp'],
['Dehradun to Mussoorie Taxi','Hill station taxi for Mall Road, Landour, Kempty Falls and Mussoorie hotels.','/dehradun-to-mussoorie-taxi','fa-mountain-sun','/assets/images/routes/dehradun-to-mussoorie-taxi.webp'],
['Dehradun to Delhi Taxi','One-way cab and IGI Airport / Delhi NCR drop service from Dehradun.','/dehradun-to-delhi-taxi','fa-road','/assets/images/routes/dehradun-to-delhi-taxi.webp'],
['Dehradun to Nainital Taxi','Long-distance Kumaon route cab for Nainital, Haldwani and Kathgodam side trips.','/dehradun-to-nainital-taxi','fa-mountain','/assets/images/routes/dehradun-to-nainital-taxi.webp'],
['Dehradun to Chandigarh Taxi','Highway taxi for Chandigarh, Mohali, Panchkula and business travel.','/dehradun-to-chandigarh-taxi','fa-road','/assets/images/routes/dehradun-to-chandigarh-taxi.webp'],
['Dehradun to Chakrata Taxi','Hill route taxi for Chakrata, Tiger Falls and weekend trips.','/dehradun-to-chakrata-taxi','fa-mountain-sun','/assets/images/routes/dehradun-to-chakrata-taxi.webp'],
['Dehradun to Auli Taxi','Mountain cab service for Auli, Joshimath and Himalayan winter trips.','/dehradun-to-auli-taxi','fa-snowflake','/assets/images/routes/dehradun-to-auli-taxi.webp'],
],
'Kumaon Hills Routes' => [
['Dehradun to Almora Taxi','Crescent-ridge Kumaon town above the Kosi valley with Mall Road and Bright End Corner drops.','/dehradun-to-almora-taxi','fa-mountain','/assets/images/routes/dehradun-to-almora-taxi.webp'],
['Dehradun to Ranikhet Taxi','Quiet cantonment ridge with the Chaubatia orchards and golf links.','/dehradun-to-ranikhet-taxi','fa-mountain','/assets/images/routes/dehradun-to-ranikhet-taxi.webp'],
['Dehradun to Kausani Taxi','Straight-on sunrise views of Nanda Devi and Trishul from the viewpoint hotels.','/dehradun-to-kausani-taxi','fa-mountain','/assets/images/routes/dehradun-to-kausani-taxi.webp'],
['Dehradun to Pithoragarh Taxi','Long Soar-valley run near the Nepal border with a Chaukhutia comfort halt.','/dehradun-to-pithoragarh-taxi','fa-mountain','/assets/images/routes/dehradun-to-pithoragarh-taxi.webp'],
],
'Garhwal & Pilgrimage Stops' => [
['Dehradun to Lansdowne Taxi','Peaceful Garhwal cantonment reached via the Kotdwar plains with a gentle final climb.','/dehradun-to-lansdowne-taxi','fa-mountain','/assets/images/routes/dehradun-to-lansdowne-taxi.webp'],
['Dehradun to Pauri Taxi','High-ridge Garhwal town above Kandolia with Mall and circuit house drops.','/dehradun-to-pauri-taxi','fa-mountain','/assets/images/routes/dehradun-to-pauri-taxi.webp'],
['Dehradun to Rudraprayag Taxi','Alaknanda–Mandakini sangam and the Kedarnath–Badrinath yatra fork.','/dehradun-to-rudraprayag-taxi','fa-om','/assets/images/routes/dehradun-to-rudraprayag-taxi.webp'],
['Dehradun to Devprayag Taxi','First sacred confluence above Rishikesh, right on the yatra highway.','/dehradun-to-devprayag-taxi','fa-om','/assets/images/routes/dehradun-to-devprayag-taxi.webp'],
],
'More Outstation Routes' => [
['Dehradun to Roorkee Taxi','Cab to IIT Roorkee, cantonment area and Roorkee city drops.','/dehradun-to-roorkee-taxi','fa-road','/assets/images/routes/dehradun-to-roorkee-taxi.webp'],
['Dehradun to Saharanpur Taxi','Taxi for Saharanpur city, railway station and family travel.','/dehradun-to-saharanpur-taxi','fa-road','/assets/images/routes/dehradun-to-saharanpur-taxi.webp'],
['Dehradun to Noida Taxi','One-way and round-trip cab for Noida sectors, offices and residential drops.','/dehradun-to-noida-taxi','fa-road','/assets/images/routes/dehradun-to-noida-taxi.webp'],
['Dehradun to Gurgaon Taxi','Cab service to Gurgaon, Cyber City and airport-side NCR areas.','/dehradun-to-gurgaon-taxi','fa-road','/assets/images/routes/dehradun-to-gurgaon-taxi.webp'],
['Dehradun to Ghaziabad Taxi','Taxi service to Ghaziabad, Indirapuram, Vaishali and NCR drops.','/dehradun-to-ghaziabad-taxi','fa-road','/assets/images/routes/dehradun-to-ghaziabad-taxi.webp'],
['Dehradun to Faridabad Taxi','Long-distance cab service to Faridabad and NCR destinations.','/dehradun-to-faridabad-taxi','fa-road','/assets/images/routes/dehradun-to-faridabad-taxi.webp'],
['Dehradun to Meerut Taxi','Fast plains run via the Delhi bypass side for cantonment, university and address drops.','/dehradun-to-meerut-taxi','fa-road','/assets/images/routes/dehradun-to-meerut-taxi.webp'],
['Dehradun to Bareilly Taxi','Straight NH9 run east through Rampur with a planned halt near Moradabad.','/dehradun-to-bareilly-taxi','fa-road','/assets/images/routes/dehradun-to-bareilly-taxi.webp'],
['Dehradun to Jaipur Taxi','Long-distance taxi for Jaipur travel and Rajasthan tours.','/dehradun-to-jaipur-taxi','fa-road','/assets/images/routes/dehradun-to-jaipur-taxi.webp'],
['Dehradun to Agra Taxi','Cab service for Agra and Taj Mahal trips from Dehradun.','/dehradun-to-agra-taxi','fa-road','/assets/images/routes/dehradun-to-agra-taxi.webp'],
['Dehradun to Mathura Taxi','Taxi for Mathura, Vrindavan and pilgrimage travel.','/dehradun-to-mathura-taxi','fa-road','/assets/images/routes/dehradun-to-mathura-taxi.webp'],
['Dehradun to Shimla Taxi','Hill-route taxi for Shimla, Kufri and Himachal trips.','/dehradun-to-shimla-taxi','fa-mountain','/assets/images/routes/dehradun-to-shimla-taxi.webp'],
['Dehradun to Manali Taxi','Long hill-route cab service for Kullu-Manali tours.','/dehradun-to-manali-taxi','fa-mountain','/assets/images/routes/dehradun-to-manali-taxi.webp'],
['Dehradun to Chopta Taxi','Taxi for Chopta, Tungnath and Chandrashila trek base.','/dehradun-to-chopta-taxi','fa-mountain','/assets/images/routes/dehradun-to-chopta-taxi.webp'],
['Dehradun to Kanatal Taxi','Cab service for Kanatal camps, resorts and hill stays.','/dehradun-to-kanatal-taxi','fa-mountain','/assets/images/routes/dehradun-to-kanatal-taxi.webp'],
['Dehradun to Dhanaulti Taxi','Taxi for Dhanaulti, Eco Park and quiet hill trips.','/dehradun-to-dhanaulti-taxi','fa-mountain','/assets/images/routes/dehradun-to-dhanaulti-taxi.webp'],
['Dehradun to Tehri Taxi','Cab service for New Tehri, Tehri Lake and water sports.','/dehradun-to-tehri-taxi','fa-water','/assets/images/routes/dehradun-to-tehri-taxi.webp'],
['Dehradun to Uttarkashi Taxi','Taxi for Uttarkashi, Gangotri route and trekking bases.','/dehradun-to-uttarkashi-taxi','fa-mountain','/assets/images/routes/dehradun-to-uttarkashi-taxi.webp'],
['Dehradun to Srinagar Garhwal Taxi','Cab service for Srinagar Garhwal and Badrinath route halts.','/dehradun-to-srinagar-garhwal-taxi','fa-road','/assets/images/routes/dehradun-to-srinagar-garhwal-taxi.webp'],
['Dehradun to Haldwani Taxi','Taxi for Haldwani, Kathgodam and Kumaon route connections.','/dehradun-to-haldwani-taxi','fa-road','/assets/images/routes/dehradun-to-haldwani-taxi.webp'],
['Dehradun to Jim Corbett Taxi','Cab service for Ramnagar, Corbett resorts and safari gates.','/dehradun-to-jim-corbett-taxi','fa-tree','/assets/images/routes/dehradun-to-jim-corbett-taxi.webp'],
['Dehradun to Kainchi Dham Taxi','Neem Karoli Baba Ashram pilgrimage cab via Nainital and Bhowali with hill-expert drivers.','/dehradun-to-kainchi-dham-taxi','fa-om','/assets/images/routes/dehradun-to-nainital-taxi.webp'],
['Dehradun to Kasol Taxi','Direct Parvati Valley road trip cab to Kasol, Manikaran Gurudwara and Tosh base.','/dehradun-to-kasol-taxi','fa-mountain-sun','/assets/images/routes/dehradun-to-manali-taxi.webp'],
['Dehradun to Valley of Flowers Taxi','UNESCO World Heritage trek taxi with direct drop-off at Govindghat and Pulna base.','/dehradun-to-valley-of-flowers-taxi','fa-mountain','/assets/images/routes/dehradun-to-auli-taxi.webp'],
],
'Pilgrimage & Yatra Taxi Packages' => [
['Char Dham Yatra Taxi','Full Char Dham taxi packages from Dehradun covering Yamunotri, Gangotri, Kedarnath and Badrinath.','/char-dham-yatra-taxi','fa-om','/assets/images/routes/char-dham-yatra-taxi.webp'],
['Do Dham Yatra Taxi','Kedarnath-Badrinath taxi package with hill-expert drivers.','/do-dham-yatra-taxi','fa-om','/assets/images/routes/do-dham-yatra-taxi.webp'],
['Dehradun to Kedarnath Taxi','Taxi up to Sonprayag/Guptkashi side for Kedarnath Yatra travellers.','/dehradun-to-kedarnath-taxi','fa-om','/assets/images/routes/dehradun-to-kedarnath-taxi.webp'],
['Dehradun to Badrinath Taxi','Badrinath Dham taxi route via Joshimath with hill drivers.','/dehradun-to-badrinath-taxi','fa-om','/assets/images/routes/dehradun-to-badrinath-taxi.webp'],
['Dehradun to Gangotri Taxi','Taxi route for Gangotri Dham via Uttarkashi and Harsil side.','/dehradun-to-gangotri-taxi','fa-om','/assets/images/routes/dehradun-to-gangotri-taxi.webp'],
['Dehradun to Yamunotri Taxi','Taxi up to Yamunotri roadhead near Janki Chatti side.','/dehradun-to-yamunotri-taxi','fa-om','/assets/images/routes/dehradun-to-yamunotri-taxi.webp'],
['Jolly Grant Airport to Kedarnath Taxi','Direct airport pickup for Kedarnath Yatra travellers.','/jolly-grant-airport-to-kedarnath-taxi','fa-plane-departure','/assets/images/routes/jolly-grant-airport-to-kedarnath-taxi.webp'],
['Haridwar to Kedarnath Taxi','Haridwar railway station pickup for Kedarnath route taxi.','/haridwar-to-kedarnath-taxi','fa-om','/assets/images/routes/haridwar-to-kedarnath-taxi.webp'],
['Rishikesh to Kedarnath Taxi','Rishikesh pickup for Kedarnath Yatra route via Devprayag and Rudraprayag.','/rishikesh-to-kedarnath-taxi','fa-om','/assets/images/routes/rishikesh-to-kedarnath-taxi.webp'],
['Haridwar to Badrinath Taxi','Taxi package from Haridwar to Badrinath Dham.','/haridwar-to-badrinath-taxi','fa-om','/assets/images/routes/haridwar-to-badrinath-taxi.webp'],
['Rishikesh to Badrinath Taxi','Taxi package from Rishikesh to Badrinath via Joshimath.','/rishikesh-to-badrinath-taxi','fa-om','/assets/images/routes/rishikesh-to-badrinath-taxi.webp'],
],
'Return & Hub Routes' => [
['Haridwar to Dehradun Taxi','Return taxi from Haridwar to Dehradun city, airport or railway station.','/haridwar-to-dehradun-taxi','fa-rotate','/assets/images/routes/haridwar-to-dehradun-taxi.webp'],
['Rishikesh to Dehradun Taxi','Taxi from Rishikesh, Tapovan and ashram areas to Dehradun.','/rishikesh-to-dehradun-taxi','fa-rotate','/assets/images/routes/rishikesh-to-dehradun-taxi.webp'],
['Mussoorie to Dehradun Taxi','Hotel pickup from Mussoorie to Dehradun city, station, ISBT or airport.','/mussoorie-to-dehradun-taxi','fa-rotate','/assets/images/routes/mussoorie-to-dehradun-taxi.webp'],
['Delhi to Dehradun Taxi','Taxi pickup from Delhi, IGI Airport and NCR to Dehradun.','/delhi-to-dehradun-taxi','fa-rotate','/assets/images/routes/delhi-to-dehradun-taxi.webp'],
['Delhi to Mussoorie Taxi','Direct taxi from Delhi/NCR to Mussoorie hotels and hill stays.','/delhi-to-mussoorie-taxi','fa-rotate','/assets/images/routes/delhi-to-mussoorie-taxi.webp'],
['Delhi to Rishikesh Taxi','Taxi from Delhi to Rishikesh, Tapovan, yoga retreats and rafting camps.','/delhi-to-rishikesh-taxi','fa-rotate','/assets/images/routes/delhi-to-rishikesh-taxi.webp'],
['Delhi to Haridwar Taxi','Taxi from Delhi/NCR to Haridwar hotels, railway station and ghats.','/delhi-to-haridwar-taxi','fa-rotate','/assets/images/routes/delhi-to-haridwar-taxi.webp'],
['Haridwar to Mussoorie Taxi','Taxi transfer from Haridwar to Mussoorie hill station.','/haridwar-to-mussoorie-taxi','fa-rotate','/assets/images/routes/haridwar-to-mussoorie-taxi.webp'],
['Haridwar to Rishikesh Taxi','Short taxi transfer from Haridwar to Rishikesh.','/haridwar-to-rishikesh-taxi','fa-rotate','/assets/images/routes/haridwar-to-rishikesh-taxi.webp'],
['Rishikesh to Mussoorie Taxi','Cab transfer from Rishikesh to Mussoorie.','/rishikesh-to-mussoorie-taxi','fa-rotate','/assets/images/routes/rishikesh-to-mussoorie-taxi.webp'],
['Rishikesh to Haridwar Taxi','Short taxi from Rishikesh to Haridwar.','/rishikesh-to-haridwar-taxi','fa-rotate','/assets/images/routes/rishikesh-to-haridwar-taxi.webp'],
['Mussoorie to Rishikesh Taxi','Cab transfer from Mussoorie to Rishikesh.','/mussoorie-to-rishikesh-taxi','fa-rotate','/assets/images/routes/mussoorie-to-rishikesh-taxi.webp'],
['Mussoorie to Haridwar Taxi','Cab transfer from Mussoorie to Haridwar.','/mussoorie-to-haridwar-taxi','fa-rotate','/assets/images/routes/mussoorie-to-haridwar-taxi.webp'],
],
];
$__gac = ['Core Taxi Services'=>'#0057ff','Fleet & Vehicle Services'=>'#7c3aed','Popular Dehradun Route Taxis'=>'#16a34a','Kumaon Hills Routes'=>'#0ea5e9','Garhwal & Pilgrimage Stops'=>'#0891b2','More Outstation Routes'=>'#b45309','Pilgrimage & Yatra Taxi Packages'=>'#e11d48','Return & Hub Routes'=>'#f59e0b'];
$__il = []; $__p = 1;
foreach ($groups['Core Taxi Services'] as $s) { $__il[] = ['@type'=>'ListItem','position'=>$__p++,'name'=>$s[0],'url'=>$domain.$s[2]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'ItemList','@id'=>$page_url.'#services','name'=>'Taxi Services in Dehradun by Anaya Cab Service','description'=>'Complete directory of local, airport, outstation, fleet, route and pilgrimage taxi services from Dehradun.','numberOfItems'=>count($__il),'itemListElement'=>$__il],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__choose = [
['City errands & hotel drops','Local Taxi','Sedan / Hatchback','/local-taxi-in-dehradun','fa-taxi'],
['Flight pickup or drop','Airport Transfer','Sedan / SUV','/dehradun-airport-taxi-service','fa-plane-departure'],
['One-way drop to another city','Outstation Taxi','Sedan / Innova','/outstation-taxi-from-dehradun','fa-route'],
['Family hill or yatra trip','Innova / Crysta','Innova / Crysta','/innova-taxi-in-dehradun','fa-van-shuttle'],
['Group of 7 or more','Tempo / Urbania','Traveller / Van','/tempo-traveller-in-dehradun','fa-bus-simple'],
['Char Dham pilgrimage','Char Dham Package','Innova / Traveller','/char-dham-yatra-taxi','fa-om'],
];
?>
<main id="main">
<style>
.sv{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 440px)}
.sv *{box-sizing:border-box}
.sv::before{content:"";position:absolute;top:-160px;right:-120px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.10),transparent 68%);pointer-events:none}
.sv::after{content:"";position:absolute;top:240px;left:-160px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(22,163,74,.08),transparent 70%);pointer-events:none}
.sv .sv-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.sv .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.sv .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.sv .rv.in{opacity:1;transform:none}
.sv .sv-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.sv .sv-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.sv .sv-crumb a:hover{color:var(--blue)}
.sv .sv-crumb i{font-size:.6rem;color:var(--mute)}.sv .sv-crumb .cur{color:var(--ink);font-weight:600}
.sv .sv-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.sv .sv-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.sv .sv-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.sv .sv-hero h1 em{font-style:normal;color:var(--blue)}
.sv .sv-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}
.sv .sv-lead strong{color:var(--ink)}
.sv .sv-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.sv .sv-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.sv .sv-m i{color:var(--blue)}.sv .sv-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.sv .sv-m span{font-size:.8rem;color:var(--slate)}
.sv .sv-herocta{display:flex;gap:12px;flex-wrap:wrap}
.sv .sv-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.sv .sv-btn-p{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.sv .sv-btn-p:hover{transform:translateY(-2px)}
.sv .sv-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.sv .sv-btn-g:hover{transform:translateY(-2px)}
.sv .sv-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.sv .sv-btn-o:hover{border-color:var(--blue);color:var(--blue)}
.sv .sv-card-side{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,87,255,.5);overflow:hidden}
.sv .sv-card-side .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.sv .sv-card-side h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.sv .sv-fares{display:grid;gap:8px;margin:14px 0 0}
.sv .sv-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.sv .sv-fr .v{font-weight:700;font-size:.9rem}.sv .sv-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.sv .sv-card-side .cta{display:grid;gap:10px;margin-top:16px}
.sv .sv-card-side .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.sv .sv-card-side .cta .w{background:#fff;color:var(--blue)}.sv .sv-card-side .cta .g{background:#25d366;color:#04260f}
.sv .sv-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(0,87,255,.25)}
.sv .sv-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.sv .sv-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}
.sv .sv-qa strong{color:var(--ink)}
.sv .sv-jump{position:sticky;top:68px;z-index:40;background:rgba(255,255,255,.86);backdrop-filter:blur(12px);border-top:1px solid var(--line);border-bottom:1px solid var(--line);margin:8px 0 0}
.sv .sv-jump .sv-in{display:flex;gap:6px;overflow-x:auto;padding:10px 22px;scrollbar-width:none}
.sv .sv-jump .sv-in::-webkit-scrollbar{display:none}
.sv .sv-jump a{flex:none;display:inline-flex;align-items:center;gap:7px;padding:8px 14px;border-radius:999px;font-weight:600;font-size:.84rem;color:var(--slate);text-decoration:none;border:1px solid transparent;transition:.2s;white-space:nowrap}
.sv .sv-jump a i{font-size:.78rem;opacity:.8}
.sv .sv-jump a:hover{color:var(--blue);background:var(--blue-tint)}
.sv .sv-jump a.on{color:#fff;background:var(--blue);box-shadow:0 8px 18px -8px rgba(0,87,255,.6)}
.sv .sv-group{padding:46px 0 6px;scroll-margin-top:132px}
.sv .sv-ghead{display:flex;align-items:center;gap:14px;margin-bottom:22px}
.sv .sv-gbar{flex:none;width:5px;height:42px;border-radius:5px;background:var(--ac)}
.sv .sv-ghead .gt{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.3rem,2.6vw,1.7rem);font-weight:800;letter-spacing:-.02em;margin:0}
.sv .sv-ghead .gc{margin-left:auto;font-size:.78rem;font-weight:700;color:var(--slate);background:#fff;border:1px solid var(--line);border-radius:999px;padding:6px 12px}
.sv .sv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
.sv .sv-card{position:relative;display:flex;flex-direction:column;gap:10px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:14px 16px 18px;text-decoration:none;color:var(--ink);overflow:hidden;transition:transform .35s cubic-bezier(.2,.7,.2,1),box-shadow .35s,border-color .35s}
.sv .sv-card::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:var(--ac);transform:scaleX(0);transform-origin:left;transition:transform .4s}
.sv .sv-card:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.32);border-color:var(--ac)}
.sv .sv-card:hover::after{transform:scaleX(1)}
.sv .sv-media{position:relative;aspect-ratio:16/9;border-radius:12px;overflow:hidden;background:linear-gradient(160deg,var(--soft),#fff);margin-bottom:2px;display:grid;place-items:center}
.sv .sv-media img{width:100%;height:100%;object-fit:cover;transition:transform .5s}
.sv .sv-card:hover .sv-media img{transform:scale(1.05)}
.sv .sv-mfb{position:absolute;inset:0;display:none;place-items:center;font-size:2.2rem;color:var(--ac)}
.sv .sv-ct{display:flex;align-items:center;gap:12px}
.sv .sv-cico{flex:none;width:44px;height:44px;border-radius:12px;display:grid;place-items:center;background:var(--soft);color:var(--ac);font-size:1.05rem;transition:transform .35s}
.sv .sv-card:hover .sv-cico{transform:scale(1.08)}
.sv .sv-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.02rem;font-weight:700;letter-spacing:-.01em;margin:0;line-height:1.25}
.sv .sv-card p{color:var(--slate);font-size:.86rem;line-height:1.55;margin:0;flex:1}
.sv .sv-clink{display:inline-flex;align-items:center;gap:7px;font-weight:700;font-size:.84rem;color:var(--ac);margin-top:2px}
.sv .sv-clink i{transition:transform .3s}.sv .sv-card:hover .sv-clink i{transform:translateX(4px)}
.sv .sv-choose{padding:54px 0}
.sv .sv-chwrap{background:linear-gradient(135deg,#03102e,#0a2a63);border-radius:26px;padding:38px 34px;color:#fff;position:relative;overflow:hidden}
.sv .sv-choose .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#bfe0ff;background:rgba(255,255,255,.12);padding:7px 13px;border-radius:999px;position:relative}
.sv .sv-choose h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:14px 0 6px;position:relative}
.sv .sv-choose .le{color:rgba(255,255,255,.8);max-width:60ch;margin:0 0 24px;position:relative}
.sv .sv-chgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;position:relative}
.sv .sv-chrow{display:flex;align-items:center;gap:14px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:16px;text-decoration:none;color:#fff;transition:transform .3s,background .3s}
.sv .sv-chrow:hover{transform:translateY(-4px);background:rgba(255,255,255,.12)}
.sv .sv-chrow .ci{flex:none;width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,.14);display:grid;place-items:center;font-size:1.05rem;color:#9fe6ff}
.sv .sv-chrow .ct b{font-family:'Sora','Poppins',sans-serif;font-size:.95rem;display:block}
.sv .sv-chrow .ct small{font-size:.78rem;color:rgba(255,255,255,.72)}
.sv .sv-chrow .ca{margin-left:auto;color:#9fe6ff;font-size:.85rem;transition:transform .3s}
.sv .sv-chrow:hover .ca{transform:translateX(4px)}
.sv .sv-seo{padding:8px 0 10px;max-width:880px}
.sv .sv-seo h2{font-family:'Sora','Poppins',sans-serif;font-size:1.4rem;font-weight:800;letter-spacing:-.02em;margin:0 0 12px}
.sv .sv-seo p{color:var(--slate);line-height:1.75;margin:0 0 14px;font-size:.98rem}
.sv .sv-seo strong{color:var(--ink)}
.sv .sv-faq{padding:46px 0}
.sv .sv-fhead{text-align:center;max-width:640px;margin:0 auto 26px}
.sv .sv-fhead .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.sv .sv-fhead h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 0}
.sv .sv-fbox{max-width:820px;margin:0 auto}
.sv .sv-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.sv .sv-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.sv .sv-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.sv .sv-fi.open .sv-ft{transform:rotate(45deg)}
.sv .sv-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.sv .sv-fi.open .sv-fb{max-height:380px;padding:0 20px 18px}
.sv .sv-cta{padding:0 0 70px}
.sv .sv-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px}
.sv .sv-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.sv .sv-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.sv .sv-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.sv .sv-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.sv .sv-cta .w{background:#fff;color:var(--blue)}.sv .sv-cta .g{background:#25d366;color:#04260f}.sv .sv-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.sv .sv-hero{grid-template-columns:1fr;gap:24px}.sv .sv-card-side{position:static}.sv .sv-jump{top:60px}}
@media(prefers-reduced-motion:reduce){.sv *{transition:none!important;animation:none!important}.sv .rv{opacity:1!important;transform:none!important}}
</style>
<div class="sv">
<div class="sv-in">
<nav class="sv-crumb rv" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Services</span></nav>
<section class="sv-hero">
<div class="rv">
<span class="sv-eyebrow"><i class="fa-solid fa-layer-group"></i> Complete service directory</span>
<h1 class="disp">Every <em>taxi service</em> in Dehradun, one trusted team</h1>
<p class="sv-lead">From a quick <strong>local cab in Dehradun</strong> to a <strong>Jolly Grant Airport transfer</strong>, a one-way <strong>outstation taxi</strong>, a <strong>tempo traveller</strong> for the group, or a full <strong>Char Dham Yatra</strong> package — Anaya Cab Service runs it all with police-verified drivers, fixed fares and 24×7 booking. Pick a category below or jump straight to your route.</p>
<div class="sv-metrics">
<span class="sv-m"><i class="fa-solid fa-route"></i> <b>70+</b> <span>services & routes</span></span>
<span class="sv-m"><i class="fa-regular fa-clock"></i> <b>24×7</b> <span>booking</span></span>
<span class="sv-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹12/km</b> <span>local from</span></span>
</div>
<div class="sv-herocta">
<a class="sv-btn sv-btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="sv-btn sv-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, please suggest the right taxi service for my trip.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="sv-btn sv-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="sv-card-side rv" aria-label="Popular Dehradun taxi rates">
<span class="tag"><i class="fa-solid fa-bolt"></i> Guaranteed rates</span>
<h3 class="disp">Dehradun → Top routes</h3>
<div class="sv-fares">
<div class="sv-fr"><span class="v">Jolly Grant Airport</span><span class="p">₹800</span></div>
<div class="sv-fr"><span class="v">Mussoorie</span><span class="p">₹1,050</span></div>
<div class="sv-fr"><span class="v">Rishikesh</span><span class="p">₹1,150</span></div>
<div class="sv-fr"><span class="v">Haridwar</span><span class="p">₹1,400</span></div>
<div class="sv-fr"><span class="v">Delhi (Expressway)</span><span class="p">₹3,500</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
</aside>
</section>
<div class="sv-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> provides every taxi service in Dehradun — local hourly cabs from ₹900, Jolly Grant Airport transfers from ₹800, one-way outstation drops from ₹1,000, tempo travellers and full Char Dham Yatra packages, all with fixed fares and verified drivers.</p>
</div>
</div>
<div class="sv-jump"><div class="sv-in" id="svJump">
<?php $__gi=0; foreach ($groups as $gt => $items): $__ic = ['Core Taxi Services'=>'fa-taxi','Fleet & Vehicle Services'=>'fa-car-side','Popular Dehradun Route Taxis'=>'fa-location-dot','Kumaon Hills Routes'=>'fa-mountain','Garhwal & Pilgrimage Stops'=>'fa-om','More Outstation Routes'=>'fa-road','Pilgrimage & Yatra Taxi Packages'=>'fa-om','Return & Hub Routes'=>'fa-rotate'][$gt] ?? 'fa-list'; ?>
<a href="#grp-<?php echo $__gi; ?>" data-grp="grp-<?php echo $__gi; ?>"><i class="fa-solid <?php echo $__ic; ?>"></i> <?php echo htmlspecialchars($gt); ?></a>
<?php $__gi++; endforeach; ?>
</div></div>
<div class="sv-in">
<?php $__gi=0; foreach ($groups as $gt => $items): $ac = $__gac[$gt] ?? '#0057ff'; ?>
<section class="sv-group rv" id="grp-<?php echo $__gi; ?>" style="--ac:<?php echo $ac; ?>">
<div class="sv-ghead"><span class="sv-gbar"></span><h2 class="gt"><?php echo htmlspecialchars($gt); ?></h2><span class="gc"><?php echo count($items); ?> options</span></div>
<div class="sv-grid">
<?php foreach ($items as $s): $img = $s[4] ?? '/assets/images/hero-bg.webp'; ?>
<a class="sv-card" href="<?php echo $s[2]; ?>">
<span class="sv-media"><img src="<?php echo htmlspecialchars($img, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($s[0], ENT_QUOTES, 'UTF-8'); ?>" width="640" height="360" loading="lazy" decoding="async" onerror="var n=this.nextElementSibling;this.onerror=function(){this.style.display='none';n.style.display='grid';};this.src='/assets/images/hero-bg.webp';"><span class="sv-mfb"><i class="fa-solid <?php echo $s[3]; ?>"></i></span></span>
<span class="sv-ct"><span class="sv-cico"><i class="fa-solid <?php echo $s[3]; ?>"></i></span><h3><?php echo htmlspecialchars($s[0]); ?></h3></span>
<p><?php echo htmlspecialchars($s[1]); ?></p>
<span class="sv-clink">View details <i class="fa-solid fa-arrow-right"></i></span>
</a>
<?php endforeach; ?>
</div>
</section>
<?php $__gi++; endforeach; ?>
<section class="sv-choose rv">
<div class="sv-chwrap">
<span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Not sure which to book?</span>
<h2 class="disp">Choose the right taxi for your trip</h2>
<p class="le">Match your journey to the ideal service and vehicle in seconds — then tap through to book or see fares.</p>
<div class="sv-chgrid">
<?php foreach ($__choose as $c): ?>
<a class="sv-chrow" href="<?php echo $c[3]; ?>">
<span class="ci"><i class="fa-solid <?php echo $c[4]; ?>"></i></span>
<span class="ct"><b><?php echo $c[0]; ?></b><small>Best: <?php echo $c[2]; ?></small></span>
<i class="fa-solid fa-arrow-right ca"></i>
</a>
<?php endforeach; ?>
</div>
</div>
</section>
<section class="sv-seo rv">
<h2 class="disp">A complete Dehradun taxi service, built around your route</h2>
<p><strong>Anaya Cab Service</strong> is a Dehradun-based taxi operator covering the full spectrum of road travel in and out of the city. Whether you need a <strong>local taxi in Dehradun</strong> for hourly errands and hotel transfers, a punctual <strong>Jolly Grant Airport cab</strong> for an early or late flight, or a comfortable <strong>outstation taxi</strong> to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital or Chandigarh, every booking comes with the same promise — a clean, air-conditioned vehicle, a police-verified driver, and a fare that is fixed and shared before you travel.</p>
<p>For families and groups we offer <strong>Innova and Crysta</strong> cabs for hill and yatra routes, and <strong>Tempo Traveller and Force Urbania</strong> vans for larger parties, weddings and corporate travel. Pilgrims can rely on our dedicated <strong>Char Dham, Do Dham, Kedarnath and Badrinath taxi packages</strong>, planned by drivers who know the Uttarakhand hill roads, roadheads and overnight halts inside out. Browse the categories above to compare options, check the <a href="/pricing" style="color:var(--blue);font-weight:700">fare guide</a>, or <a href="/#booking" style="color:var(--blue);font-weight:700">book your cab</a> in under a minute.</p>
</section>
<section class="sv-faq rv" id="faq">
<div class="sv-fhead"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Taxi services in Dehradun — quick answers</h2></div>
<div class="sv-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="sv-fi<?php echo $i===0?' open':''; ?>"><div class="sv-fh"><?php echo htmlspecialchars($f[0]); ?><span class="sv-ft"><i class="fa-solid fa-plus"></i></span></div><div class="sv-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>
<section class="sv-cta rv">
<div class="sv-ctain">
<h2 class="disp">Need help choosing the right taxi?</h2>
<p>Share pickup, drop, date, passengers and luggage — we will suggest the right cab and fare on WhatsApp.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, please suggest the right taxi service for my trip.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>
</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.sv .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
var links=[].slice.call(document.querySelectorAll('#svJump a'));
var secs=links.map(function(a){return document.getElementById(a.getAttribute('data-grp'));});
if('IntersectionObserver' in window && secs.length){
var spy=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){var id=e.target.id;links.forEach(function(a){a.classList.toggle('on',a.getAttribute('data-grp')===id);});}});},{rootMargin:'-45% 0px -50% 0px',threshold:0});
secs.forEach(function(s){if(s)spy.observe(s);});
}
links.forEach(function(a){a.addEventListener('click',function(ev){var t=document.getElementById(a.getAttribute('data-grp'));if(t){ev.preventDefault();var y=t.getBoundingClientRect().top+window.scrollY-120;window.scrollTo({top:y,behavior:'smooth'});}});});
document.querySelectorAll('.sv .sv-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>