CREATE TABLE IF NOT EXISTS agent_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value LONGTEXT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS agent_tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  agent_name VARCHAR(80) NOT NULL,
  task_type VARCHAR(80) NOT NULL,
  input_json LONGTEXT NULL,
  output_json LONGTEXT NULL,
  status ENUM('pending','running','completed','failed','approved','rejected') DEFAULT 'pending',
  priority TINYINT DEFAULT 5,
  error_text TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  completed_at TIMESTAMP NULL DEFAULT NULL,
  KEY idx_status(status),
  KEY idx_agent(agent_name),
  KEY idx_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS agent_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  agent_name VARCHAR(80) NOT NULL,
  level VARCHAR(20) DEFAULT 'info',
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_agent(agent_name),
  KEY idx_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS agent_drafts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  draft_type VARCHAR(60) DEFAULT 'blog',
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NULL,
  content LONGTEXT NULL,
  meta_title VARCHAR(255) NULL,
  meta_description VARCHAR(255) NULL,
  focus_keyword VARCHAR(255) NULL,
  schema_json LONGTEXT NULL,
  status ENUM('draft','needs_review','approved','published','rejected') DEFAULT 'needs_review',
  source_task_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY idx_status(status),
  KEY idx_type(draft_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
