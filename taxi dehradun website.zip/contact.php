<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$email       = defined('BUSINESS_EMAIL') ? BUSINESS_EMAIL : 'anayacabservice.in@gmail.com';

$page_title       = "Contact Anaya Cab Service Dehradun | 24/7 Taxi Booking";
$page_description = 'Contact Anaya Cab Service Dehradun – call +91 80776 11583 for 24x7 taxi booking, fare quotes, Char Dham planning & WhatsApp support. Reply in minutes.';
$page_url         = $domain . "/contact";

$__faqs = [
["What is the fastest way to book a taxi with Anaya Cab Service?", "The fastest way is to call our 24 hour line or message on WhatsApp with your pickup, drop, date and vehicle, and we confirm the fare and driver details within minutes."],
["What details should I share for a quick taxi quote?", "Share your pickup point, drop location, travel date and time, number of passengers and luggage, and for airport pickup your flight number, so we can quote the right fare and vehicle."],
["Where is the Anaya Cab Service office in Dehradun?", "Our office is on Shimla Bypass Road in the Sewla Kalan Majra area of Dehradun, Uttarakhand, and you can also reach us by phone, email or the contact form on this page."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'ContactPage','@id'=>$page_url.'#contact','name'=>$page_title,'description'=>$page_description,'url'=>$page_url,'mainEntity'=>['@id'=>$domain.'/#taxi-service']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__channels = [
['fa-phone','Call us 24×7',$phone,'tel:'.$phone_tel,'Quick voice booking, any hour.'],
['fa-brands fa-whatsapp','WhatsApp desk','Chat & book','https://wa.me/'.$whatsapp.'?text='.rawurlencode('Hi Anaya Cab, I need help with taxi booking.'),'Share details, get fare in minutes.'],
['fa-regular fa-envelope','Email us',$email,'mailto:'.$email,'For quotes, feedback and queries.'],
];

$__share = [
['fa-circle-dot','Pickup & drop','Exact pickup point and destination.'],
['fa-calendar','Date & time','Travel date, time and trip type.'],
['fa-user-group','Passengers & bags','Headcount and luggage for the right car.'],
['fa-plane','Flight or train','Number and arrival time for pickups.'],
];
?>
<main id="main">
<style>
.ct{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#12a150;--teal:#0f766e;--teal-soft:#e1f1ee;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eaf4f1 0%,#ffffff 460px)}
.ct *{box-sizing:border-box}
.ct::before{content:"";position:absolute;top:-200px;left:-120px;width:560px;height:460px;border-radius:50%;background:radial-gradient(circle,rgba(15,118,110,.12),transparent 70%);pointer-events:none}
.ct::after{content:"";position:absolute;top:360px;right:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.07),transparent 70%);pointer-events:none}
.ct .ct-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.ct .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ct .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.ct .rv.in{opacity:1;transform:none}
.ct .ct-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.ct .ct-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.ct .ct-crumb a:hover{color:var(--teal)}
.ct .ct-crumb i{font-size:.6rem;color:var(--mute)}.ct .ct-crumb .cur{color:var(--ink);font-weight:600}
.ct .ct-hero{display:grid;grid-template-columns:1.15fr 1fr;gap:36px;align-items:start;padding:26px 0 12px}
.ct .ct-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:var(--teal-soft);padding:7px 13px;border-radius:999px}
.ct .ct-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.ct .ct-hero h1 em{font-style:normal;color:var(--teal)}
.ct .ct-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:54ch;margin:0 0 22px}.ct .ct-lead strong{color:var(--ink)}
/* channel cards */
.ct .ct-channels{display:flex;flex-direction:column;gap:12px;margin:0 0 8px}
.ct .ct-ch{display:flex;align-items:center;gap:15px;background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px 18px;text-decoration:none;color:var(--ink);transition:transform .3s,box-shadow .3s,border-color .3s}
.ct .ct-ch:hover{transform:translateX(5px);box-shadow:0 18px 40px -24px rgba(9,32,84,.3);border-color:#bfe6e0}
.ct .ct-ch .ci{flex:none;width:50px;height:50px;border-radius:14px;background:var(--teal-soft);color:var(--teal);display:grid;place-items:center;font-size:1.15rem;transition:transform .3s}
.ct .ct-ch:hover .ci{transform:scale(1.08) rotate(-5deg)}
.ct .ct-ch .ctt b{font-family:'Sora','Poppins',sans-serif;font-size:1.02rem;display:block}
.ct .ct-ch .ctt span{font-size:.86rem;color:var(--teal);font-weight:700}
.ct .ct-ch .ctt small{display:block;font-size:.78rem;color:var(--slate);margin-top:2px}
.ct .ct-ch .arr{margin-left:auto;color:var(--mute);transition:transform .3s,color .3s}.ct .ct-ch:hover .arr{transform:translateX(4px);color:var(--teal)}
/* live support card */
.ct .ct-live{position:sticky;top:88px;background:linear-gradient(160deg,#06231f,#0f766e);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(6,35,31,.6);overflow:hidden}
.ct .ct-live::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(127,231,255,.22),transparent 70%)}
.ct .ct-on{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#bdf3ea;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.ct .ct-on::before{content:"";width:7px;height:7px;border-radius:50%;background:#34e39b;box-shadow:0 0 0 0 rgba(52,227,155,.6);animation:ctpl 1.8s infinite}
@keyframes ctpl{70%{box-shadow:0 0 0 7px rgba(52,227,155,0)}100%{box-shadow:0 0 0 0 rgba(52,227,155,0)}}
.ct .ct-live h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.ct .ct-live .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 16px;position:relative}
.ct .ct-live .ring{display:flex;align-items:center;gap:14px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:14px 16px;position:relative}
.ct .ct-live .ring .ic{flex:none;width:42px;height:42px;border-radius:50%;border:2px solid rgba(127,231,255,.5);display:grid;place-items:center;color:#7fe9f5;animation:ctspin 6s linear infinite}
@keyframes ctspin{to{transform:rotate(360deg)}}
.ct .ct-live .ring b{font-family:'Sora','Poppins',sans-serif;font-size:1.05rem;display:block}
.ct .ct-live .ring small{font-size:.74rem;color:rgba(255,255,255,.7)}
.ct .ct-live .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.ct .ct-live .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.ct .ct-live .cta .w{background:#fff;color:var(--teal)}.ct .ct-live .cta .g{background:#25d366;color:#04260f}
.ct .ct-live .cta a:hover{transform:translateY(-2px)}
/* quick answer */
.ct .ct-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--teal);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ct .ct-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);margin-bottom:8px}
.ct .ct-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ct .ct-qa strong{color:var(--ink)}
.ct .ct-sec{padding:50px 0}
.ct .ct-sh{text-align:center;max-width:700px;margin:0 auto 30px}
.ct .ct-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:var(--teal-soft);padding:7px 13px;border-radius:999px}
.ct .ct-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.ct .ct-sh p{color:var(--slate);margin:0}
/* form + map layout */
.ct .ct-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:28px;align-items:start}
.ct .ct-form{background:#fff;border:1px solid var(--line);border-radius:22px;padding:28px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ct .ct-form h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:0 0 4px}
.ct .ct-form .sub{color:var(--slate);font-size:.88rem;margin:0 0 18px}
.ct .ct-frow{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.ct .ct-fg{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
.ct .ct-fg label{font-size:.76rem;font-weight:600;color:var(--slate)}
.ct .ct-fg input,.ct .ct-fg textarea{width:100%;padding:12px 14px;border:1.5px solid var(--line);border-radius:12px;font:inherit;font-size:.92rem;background:var(--soft);transition:border .2s,background .2s,box-shadow .2s}
.ct .ct-fg input:focus,.ct .ct-fg textarea:focus{outline:none;border-color:var(--teal);background:#fff;box-shadow:0 0 0 4px var(--teal-soft)}
.ct .ct-fg textarea{resize:vertical;min-height:104px}
.ct .ct-submit{display:inline-flex;align-items:center;justify-content:center;gap:9px;width:100%;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.95rem;padding:14px;border:none;border-radius:13px;background:var(--teal);color:#fff;cursor:pointer;box-shadow:0 16px 34px -14px rgba(15,118,110,.55);transition:transform .2s,filter .2s}
.ct .ct-submit:hover{transform:translateY(-2px);filter:brightness(1.06)}
.ct .ct-map{border-radius:22px;overflow:hidden;border:1px solid var(--line);box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ct .ct-map iframe{display:block;width:100%;height:300px;border:0}
.ct .ct-map .bar{display:flex;flex-wrap:wrap;gap:10px;padding:14px 16px;background:#fff;border-top:1px solid var(--line)}
.ct .ct-map .bar a{display:inline-flex;align-items:center;gap:8px;font-weight:700;font-size:.84rem;padding:9px 14px;border-radius:11px;text-decoration:none;transition:transform .2s,filter .2s}
.ct .ct-map .bar .m{background:var(--teal);color:#fff}.ct .ct-map .bar .g{background:#25d366;color:#04260f}.ct .ct-map .bar .o{background:#fff;color:var(--ink);border:1px solid var(--line)}
.ct .ct-map .bar a:hover{transform:translateY(-2px)}
/* share grid */
.ct .ct-sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px}
.ct .ct-sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.ct .ct-sitem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.ct .ct-sico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--teal-soft);color:var(--teal);display:grid;place-items:center;font-size:1rem}
.ct .ct-sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.ct .ct-sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
/* faq */
.ct .ct-fbox{max-width:820px;margin:0 auto}
.ct .ct-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.ct .ct-fi:hover{border-color:#bfe6e0}
.ct .ct-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ct .ct-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--teal-soft);color:var(--teal);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.ct .ct-fi.open .ct-ft{transform:rotate(45deg)}
.ct .ct-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ct .ct-fi.open .ct-fb{max-height:340px;padding:0 20px 18px}
.ct .ct-soft{background:linear-gradient(180deg,#eaf4f1,#f6fbfa)}
.ct .ct-cta{padding:0 0 70px}
.ct .ct-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0f766e,transparent 55%),linear-gradient(120deg,#06231f,#0f766e);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.ct .ct-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ct .ct-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ct .ct-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ct .ct-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.ct .ct-cta .w{background:#fff;color:var(--teal)}.ct .ct-cta .g{background:#25d366;color:#04260f}.ct .ct-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.ct .ct-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.ct .ct-hero{grid-template-columns:1fr;gap:24px}.ct .ct-live{position:static}.ct .ct-grid{grid-template-columns:1fr}}
@media(max-width:520px){.ct .ct-frow{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.ct *{transition:none!important;animation:none!important}.ct .rv{opacity:1!important;transform:none!important}}
</style>

<div class="ct">
<div class="ct-in">
<nav class="ct-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Contact</span></nav>

<section class="ct-hero">
<div class="rv">
<span class="ct-eyebrow"><i class="fa-solid fa-headset"></i> Talk to a human · 24×7</span>
<h1 class="disp">Get in touch with <em>Anaya Cab Service</em></h1>
<p class="ct-lead">Booking a cab, checking a fare or planning a Char Dham Yatra — our Dehradun team is one call, message or form away, <strong>every hour of every day</strong>. Pick the channel that suits you and we will respond fast.</p>
<div class="ct-channels">
<?php foreach ($__channels as $c): ?>
<a class="ct-ch" href="<?php echo $c[3]; ?>"<?php echo (strpos($c[3],'http')===0?' target="_blank" rel="noopener"':''); ?>>
<span class="ci"><i class="<?php echo $c[0]; ?>"></i></span>
<span class="ctt"><b><?php echo $c[1]; ?></b><span><?php echo $c[2]; ?></span><small><?php echo $c[4]; ?></small></span>
<i class="fa-solid fa-arrow-right arr"></i>
</a>
<?php endforeach; ?>
</div>
</div>
<aside class="ct-live rv" aria-label="Live support">
<span class="ct-on">Support online now</span>
<h3 class="disp">We reply in minutes</h3>
<p class="sub">Share your trip details and get a confirmed fare on WhatsApp.</p>
<div class="ring" aria-hidden="true">
<span class="ic"><i class="fa-solid fa-bolt"></i></span>
<span><b>Average response</b><small>Under 5 minutes, 24×7</small></span>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need help with taxi booking.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp us</a>
</div>
</aside>
</section>

<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="ct-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p>The fastest way to reach <strong>Anaya Cab Service</strong> is to call <a href="tel:<?php echo $phone_tel; ?>" style="color:var(--teal);font-weight:700"><?php echo $phone; ?></a> or message on WhatsApp with your pickup, drop, date and vehicle — our Dehradun desk confirms the fare and driver details within minutes, 24×7. You can also email <?php echo $email; ?> or use the form below.</p>
</div>

</div>

<!-- FORM + MAP -->
<section class="ct-sec rv"><div class="ct-in">
<div class="ct-sh"><span class="ey"><i class="fa-regular fa-paper-plane"></i> Send a message</span><h2 class="disp">Write to us or find us on the map</h2><p>Use the form for quotes and queries, or open our Dehradun location for directions.</p></div>
<div class="ct-grid">
<div class="ct-form">
<h3>Send us a message</h3>
<p class="sub">We read every message and reply as fast as we can.</p>
<form action="/includes/contact-handler.php" method="POST">
<div class="ct-frow">
<div class="ct-fg"><label for="cName">Full name</label><input type="text" id="cName" name="name" autocomplete="name" required></div>
<div class="ct-fg"><label for="cPhone">Phone number</label><input type="tel" id="cPhone" name="phone" autocomplete="tel" required></div>
</div>
<div class="ct-fg"><label for="cEmail">Email (optional)</label><input type="email" id="cEmail" name="email" autocomplete="email"></div>
<div class="ct-fg"><label for="cMsg">Your message</label><textarea id="cMsg" name="message" rows="4" placeholder="Pickup, drop, date, passengers, luggage…" required></textarea></div>
<button type="submit" class="ct-submit"><i class="fa-solid fa-paper-plane"></i> Send message</button>
</form>
</div>
<div class="ct-map">
<iframe src="https://www.google.com/maps?q=<?php echo urlencode(BUSINESS_FULL_ADDRESS); ?>&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Anaya Cab Service Dehradun location map"></iframe>
<div class="bar">
<a class="m" href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode(BUSINESS_FULL_ADDRESS); ?>" target="_blank" rel="noopener"><i class="fa-solid fa-diamond-turn-right"></i> Directions</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need help with taxi booking.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="<?php echo defined('GOOGLE_BUSINESS_PROFILE_URL') ? GOOGLE_BUSINESS_PROFILE_URL : 'https://share.google/FAiRE7cBSQ6bqiT49'; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-google"></i> Google listing</a>
</div>
</div>
</div>
</div></section>

<!-- WHAT TO SHARE -->
<section class="ct-sec ct-soft rv"><div class="ct-in">
<div class="ct-sh"><span class="ey"><i class="fa-solid fa-list-check"></i> For a faster quote</span><h2 class="disp">What to share when you contact us</h2><p>These four details help us confirm the right fare and vehicle instantly.</p></div>
<div class="ct-sgrid">
<?php foreach ($__share as $s): ?>
<div class="ct-sitem rv"><span class="ct-sico"><i class="fa-solid <?php echo $s[0]; ?>"></i></span><div><h3><?php echo $s[1]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- FAQ -->
<section class="ct-sec rv" id="faq"><div class="ct-in">
<div class="ct-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Contact &amp; booking — FAQs</h2></div>
<div class="ct-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="ct-fi<?php echo $i===0?' open':''; ?>"><div class="ct-fh"><?php echo htmlspecialchars($f[0]); ?><span class="ct-ft"><i class="fa-solid fa-plus"></i></span></div><div class="ct-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- CTA -->
<section class="ct-cta rv"><div class="ct-in">
<div class="ct-ctain">
<h2 class="disp">Ready to book your Dehradun cab?</h2>
<p>Call, WhatsApp or send a message — a verified driver and a fixed fare are one step away.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ct .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ct .ct-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
