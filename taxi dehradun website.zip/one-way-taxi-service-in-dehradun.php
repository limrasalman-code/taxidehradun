<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$V = [
'slug'=>'one-way-taxi-service-in-dehradun','name'=>'One Way Taxi Service in Dehradun','short'=>'One Way Taxi','cls'=>'One-way drop · pay one side',
'char'=>'One-way · no return fare','char_icon'=>'fa-arrow-right-long','glyph'=>'fa-car-side','img'=>'/assets/images/fleet/sedan.webp',
'ac'=>'#b45309','ac2'=>'#fcd34d','d1'=>'#451a03','d2'=>'#92400e','tint'=>'#fbf0db',
'headline'=>'Pay for the drop, not the return',
'lead'=>'Book a one way taxi in Dehradun and pay only for the side you travel — the cab drops you and returns on its own schedule, so you never fund an empty return seat. Ideal for Jolly Grant Airport drops, Delhi and Chandigarh outstation drops, Haridwar and Rishikesh pilgrimage runs and hospital or station transfers, with the fare fixed before pickup.',
'pax'=>'1–4+','bags'=>'3–4','rate_range'=>'From Rs 1,150 one way',
'service_type'=>'One-way taxi service','offers_price'=>'1150','offer_desc'=>'One-way taxi drops from Dehradun start around Rs 1,150 for a sedan, subject to route and availability.',
'area'=>['Dehradun','Delhi','Chandigarh','Haridwar','Rishikesh','Mussoorie','Nainital'],
'best_for'=>[
['fa-plane-departure','Airport & station drops','Jolly Grant, Dehradun station and ISBT transfers timed to your flight or train, with waiting handled calmly.'],
['fa-road','Outstation one-way drops','Delhi, Chandigarh, Nainital and more — dropped at your address or terminal while the cab returns on its own clock.'],
['fa-om','Pilgrimage drops','Haridwar and Rishikesh runs planned around aarti and temple timings, one-way or with a short wait.'],
['fa-hospital','Hospital & urgent transfers','Quick, calm one-way transfers for medical visits, with luggage and wheelchair space planned in.'],
],
'compare_title'=>'One-way vs round trip — which should you book?',
'compare'=>[['One-way drop','You pay one side only','Airport, station and outstation drops'],['Round trip','Cab waits and returns with you','Day trips, shopping and temple runs'],['Multi-day package','Per-day billing with driver halt','Char Dham and outstation tours']],
'routes'=>[['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi'],['Dehradun → Chandigarh','/dehradun-to-chandigarh-taxi'],['Dehradun → Nainital','/dehradun-to-nainital-taxi']],
'use_cases'=>['Airport / railway drops','Outstation one-way drops','Hospital & medical transfers','Wedding / event guest drops','College & office commutes'],
'faqs'=>[
['What does a one-way taxi fare include?','The fare covers the cab, driver and fuel for your side of the journey. Tolls, parking and any night or hill charges are spelled out in the quote before you book, so the price you confirm is the price you pay.'],
['Do I pay for the return trip of the cab?','No. A one-way booking charges you only for the distance you travel. The cab returns on its own schedule or picks up another booking, which is exactly why the fare is lower than a round trip.'],
['Is one-way taxi available at night for airport drops?','Yes, one-way drops run 24x7, including early-morning flights from Jolly Grant and late-night railway arrivals. Share your flight or train number and the driver tracks it.'],
['Which vehicles can I book one-way?','Sedans for 1 to 4 travellers, Ertiga or Innova for families with luggage, and Tempo Traveller for groups — all one-way, all with verified drivers.'],
],
'title'=>'One Way Taxi Service in Dehradun | Pay Only One Side - Anaya Cab',
'desc'=>'Book one way taxi service in Dehradun for airport, station and outstation drops. Pay only one side - no return fare. Sedan one-way from Rs 1,150. Call '.$phone.'.',
];
$page_url = $domain . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];
require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<style>
.vp-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line,#e7edf6);border-left:4px solid var(--vp-ac,#b45309);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.vp-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--vp-ac,#b45309);margin-bottom:8px}
.vp-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.vp-qa strong{color:#0b1220}
</style>
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-arrow-right-long"></i><b>One side</b><span>you pay</span></span>
<span class="vp-m"><i class="fa-regular fa-clock"></i><b>24x7</b><span>availability</span></span>
<span class="vp-m"><i class="fa-solid fa-user-shield"></i><b>Verified</b><span>drivers</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b>Rs 1,150+</b><span>one-way drops</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?>" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>sedan drop</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="vp-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>One-way taxi service in Dehradun</strong> charges you only for the drop — no return fare. Sedan one-way drops start around <strong>Rs 1,150 (Rishikesh)</strong>, <strong>Rs 1,350 (Haridwar)</strong> and <strong>Rs 5,000 (Delhi)</strong>, with the fare fixed before pickup, verified drivers and 24x7 availability for airport, station and outstation drops.</p>
</div>
</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where one-way saves you money</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp">Popular one-way drops at a glance</h2><p>Sedan one-way fares from the live fare desk — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>One-way drop</th><th>What you get</th><th>Sedan fare</th></tr></thead>
<tbody>
<tr><td>Rishikesh</td><td>Door drop, about 45 km</td><td class="fare">Rs 1,150</td></tr>
<tr><td>Haridwar</td><td>Aarti-timed drop, about 55 km</td><td class="fare">Rs 1,350</td></tr>
<tr><td>Mussoorie</td><td>Hill climb included, about 35 km</td><td class="fare">Rs 1,050</td></tr>
<tr><td>Chandigarh</td><td>Sector or ISBT drop, about 210 km</td><td class="fare">Rs 4,000</td></tr>
<tr><td>Delhi</td><td>Terminal or address drop, about 250 km</td><td class="fare">Rs 5,000</td></tr>
<tr><td>Nainital</td><td>Mall Road drop, about 280 km</td><td class="fare">Rs 5,600</td></tr>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="One way versus round trip comparison">
<thead><tr><th>Booking type</th><th>How billing works</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> Why one-way works</span><h2 class="disp">The logic behind the lower fare</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">A round-trip cab bills you for both sides of the journey because the vehicle returns empty with you or waits for you. A one-way booking flips that model: you pay for the distance you actually travel, and the cab returns on its own schedule or picks up another booking on the way back. That single difference is why a one-way Dehradun to Delhi drop costs a fraction of a round trip, and why it is the default choice for airport transfers, station drops and relocation travel.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">The practical details matter, so we keep them transparent. Your quote is fixed before pickup and spells out tolls, parking and any night or hill charge for your side of the journey. The driver tracks your flight or train when you share the number, waits calmly at arrivals, and handles luggage without a rush. If your plan changes en route — a breakfast stop, a temple on the way, an extra drop in the same city — tell the driver and it is usually absorbed without drama.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">One-way does not mean basic. You get the same police-verified drivers, the same clean AC sedans, SUVs and Innovas, and the same 24x7 support desk as any premium booking. Whether it is a 4 am Jolly Grant drop or an evening Delhi transfer after a meeting, the fare you confirm on the phone is the fare you pay at the drop.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Pay only for your side — the empty return seat is never your cost.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Fixed quote before pickup with tolls and night charges spelled out.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Flight and train tracking for early-morning and late-night drops.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Same verified drivers and clean AC fleet as premium round trips.</li>
</ul>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular one-way routes</span><h2 class="disp">Drops travellers book most</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This service is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share pickup, drop and time — we confirm a fixed one-way fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>