<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title       = "Dehradun to Nainital Taxi | Cab Fare & Booking - Anaya Cab";
$page_description = 'Dehradun to Nainital taxi from ₹5,500 (280 km, 7–8 hr). One-way & round trips to Mallital, Bhimtal, Kainchi Dham. Hill-expert drivers, fixed fares.';
$page_url         = $domain . "/dehradun-to-nainital-taxi";

$__faqs = [
["How far is Nainital from Dehradun by taxi?", "The distance from Dehradun to Nainital is approximately 280 km via Haridwar-Haldwani highway, taking around 6 to 7 hours of comfortable driving."],
["What is the one-way taxi fare from Dehradun to Nainital?", "One-way sedan taxi fare from Dehradun to Nainital starts at ₹5,500 for a Dzire, ₹6,500 for an Ertiga (SUV), and ₹7,500 for an Innova Crysta."],
["Can I book a Kumaon tour cab covering Nainital, Bhimtal, and Jim Corbett?", "Yes. We offer multi-day Kumaon tour packages covering Nainital, Bhimtal, Sattal, Mukteshwar, and Jim Corbett National Park with the same vehicle and driver."],
["Do drivers have experience on Kumaon hill roads?", "Yes. All our drivers are police-verified and experienced in navigating Uttarakhand mountain highways and Kumaon hill curves."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Nainital Taxi Service','serviceType'=>'Outstation hill taxi transfer','description'=>'One-way and round-trip taxi from Dehradun to Nainital over 280 km with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Nainital'],['@type'=>'City','name'=>'Haldwani']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'5500','description'=>'One way sedan taxi fare from Dehradun to Nainital starts from 5,500 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Nainital Mall Road','~280 km','5,500','6,500','7,500','/dehradun-to-nainital-taxi'],
['Dehradun → Bhimtal & Sattal','~290 km','5,800','6,800','7,800','/dehradun-to-nainital-taxi'],
['Dehradun → Mukteshwar','~310 km','6,200','7,200','8,200','/dehradun-to-nainital-taxi'],
['Dehradun → Haldwani / Kathgodam','~260 km','5,200','6,200','7,200','/dehradun-to-haldwani-taxi-service'],
];

$__sights = [
['Naini Lake & Mall Road','fa-water','Famous lake for boating, lakeside walks, and shopping.'],
['Bhimtal & Sattal Lakes','fa-mountain','Serene freshwater lakes surrounded by pine forests.'],
['Mukteshwar & Ramgarh','fa-mountain-sun','Apple orchards and panoramic Himalayan views.'],
['Jim Corbett National Park','fa-tree','Wilderness safari hub near Ramnagar.'],
];

$__related = [
['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi','fa-om'],
['Dehradun → Delhi','/dehradun-to-delhi-taxi','fa-road'],['Dehradun → Auli','/dehradun-to-auli-taxi-service','fa-snowflake'],
];
?>
<main id="main">
<style>
.nl{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--teal:#0891b2;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef8fa 0%,#ffffff 440px)}
.nl *{box-sizing:border-box}
.nl .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.nl .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.nl .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.nl .rv.in{opacity:1;transform:none}
.nl .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.nl .crumb a{color:var(--slate);text-decoration:none}.nl .crumb a:hover{color:var(--teal)}.nl .crumb i{font-size:.6rem;color:var(--mute)}.nl .crumb .cur{color:var(--ink);font-weight:600}
.nl .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.nl .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:#e0f2fe;padding:7px 13px;border-radius:999px}
.nl .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.nl .hero h1 em{font-style:normal;color:var(--teal)}
.nl .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.nl .lead strong{color:var(--ink)}
.nl .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.nl .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.nl .m i{color:var(--teal)}.nl .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.nl .m span{font-size:.8rem;color:var(--slate)}
.nl .herocta{display:flex;gap:12px;flex-wrap:wrap}
.nl .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.nl .btn-p{background:var(--teal);color:#fff;box-shadow:0 16px 34px -14px rgba(8,145,178,.55)}.nl .btn-p:hover{transform:translateY(-2px)}
.nl .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.nl .btn-g:hover{transform:translateY(-2px)}
.nl .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.nl .btn-o:hover{border-color:var(--teal);color:var(--teal)}
.nl .card{position:sticky;top:88px;background:linear-gradient(160deg,#031f28,#0891b2);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(8,145,178,.5);overflow:hidden}
.nl .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c7f0f8;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.nl .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.nl .fares{display:grid;gap:8px;margin:14px 0 0}
.nl .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.nl .fr .v{font-weight:700;font-size:.9rem}.nl .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.nl .card .cta{display:grid;gap:10px;margin-top:16px}
.nl .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.nl .card .cta .w{background:#fff;color:var(--teal)}.nl .card .cta .g{background:#25d366;color:#04260f}
.nl .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--teal);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.nl .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);margin-bottom:8px}
.nl .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.nl .qa strong{color:var(--ink)}
.nl .sec{padding:48px 0}
.nl .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.nl .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:#e0f2fe;padding:7px 13px;border-radius:999px}
.nl .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.nl .sh p{color:var(--slate);margin:0}
.nl .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.nl .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.nl .sico{flex:none;width:44px;height:44px;border-radius:12px;background:#e0f2fe;color:var(--teal);display:grid;place-items:center;font-size:1rem}
.nl .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.nl .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.nl .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.nl .tscroll{overflow-x:auto}
.nl table{width:100%;border-collapse:collapse;min-width:560px}
.nl th,.nl td{padding:15px 18px;text-align:left;font-size:.92rem}
.nl thead th{background:var(--soft);color:var(--teal);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.nl tbody tr{border-top:1px solid var(--line)}
.nl .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.nl .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.nl .rchip i{color:var(--teal)}.nl .rchip:hover{border-color:var(--teal);color:var(--teal);transform:translateY(-2px)}
.nl .fbox{max-width:820px;margin:0 auto}
.nl .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.nl .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.nl .ft{flex:none;width:26px;height:26px;border-radius:8px;background:#e0f2fe;color:var(--teal);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.nl .fi.open .ft{transform:rotate(45deg)}
.nl .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.nl .fi.open .fb{max-height:380px;padding:0 20px 18px}
.nl .soft{background:linear-gradient(180deg,#eef8fa,#f6fbfa)}
.nl .cta{padding:0 0 70px}
.nl .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0891b2,transparent 55%),linear-gradient(120deg,#031f28,#0891b2);color:#fff;text-align:center;padding:50px 24px}
.nl .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.nl .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.nl .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.nl .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.nl .cta .w{background:#fff;color:var(--teal)}.nl .cta .g{background:#25d366;color:#04260f}.nl .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.nl .hero{grid-template-columns:1fr;gap:24px}.nl .card{position:static}}
</style>

<div class="nl">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Nainital Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-water"></i> Lake District · 280 km</span>
<h1 class="disp">Dehradun to Nainital <em>taxi service</em> — Kumaon Hill Drops</h1>
<p class="lead"><strong>Dehradun to Nainital taxi fare starts from ₹5,500 for a sedan.</strong> Anaya Cab Service offers comfortable transfers to Naini Lake, Bhimtal, Sattal, Mukteshwar, and Jim Corbett with verified hill drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>280 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>6–7 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-mountain"></i> <b>Kumaon Hills</b> <span>tour circuit</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹5,500+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Nainital cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Nainital taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Nainital fare">
<span class="tag"><i class="fa-solid fa-mountain"></i> Route fare</span>
<h3 class="disp">Dehradun → Nainital</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹5,500</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹6,500</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹7,500</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Nainital taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> operates daily <strong>Dehradun to Nainital taxi service</strong> (~280 km, 6.5 hours drive via Haldwani) with fixed fares starting at <strong>₹5,500 for Sedan</strong> (Dzire), <strong>₹6,500 for SUV</strong> (Ertiga), and <strong>₹7,500 for Innova Crysta</strong>. Direct door-to-door drops to Naini Lake, Bhimtal, Sattal, Mukteshwar, and Corbett National Park.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Nainital taxi fares by drop location</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Nainital taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Kumaon</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Nainital taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Nainital or Kumaon? Book your cab now</h2>
<p>Fixed fare, verified hill driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Nainital cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Nainital taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.nl .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.nl .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

