<?php
require_once __DIR__ . '/includes/config.php';
$page_title       = "Dehradun to Badrinath Taxi | Yatra Cab & Fare - Anaya Cab";
$page_description = 'Dehradun to Badrinath taxi via Devprayag, Rudraprayag & Joshimath (320 km, 10–11 hr). Hill-expert drivers, Mana Village stop, fixed fare quoted upfront.';
$page_url         = SITE_DOMAIN . "/dehradun-to-badrinath-taxi";
$__faqs = [
['Does the taxi reach the Badrinath temple?', 'Yes, the road goes up to Badrinath town close to the temple, so the taxi reaches the temple area directly and from the parking it is a short walk to the shrine.'],
['How much does a Dehradun to Badrinath taxi cost?', 'The fare is shared as a custom quote because it depends on vehicle, number of days, season and route conditions, and it is confirmed on WhatsApp or call before you travel.'],
['Which vehicle is best for the Badrinath route?', 'An Innova or Innova Crysta is recommended for hill comfort for families, an Ertiga or SUV for budget travel, and a Tempo Traveller for groups and joint families.'],
['When is the best time for the Badrinath yatra?', 'Badrinath usually opens around April to May and closes around October to November, with exact dates announced each year, so confirm the opening before planning your taxi.'],
['Should I keep buffer days on the Badrinath trip?', 'Yes, keeping one or two buffer days is wise in peak and monsoon season for weather, road closures and a relaxed darshan, and our drivers help plan the halts accordingly.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Badrinath Taxi','serviceType'=>'Pilgrimage taxi service','description'=>'Taxi from Dehradun to Badrinath Dham via Joshimath for pilgrims and families, with hill-expert drivers, Innova, Crysta and Tempo Traveller options and a custom yatra quote.','provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Badrinath'],['@type'=>'City','name'=>'Joshimath']],'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','description'=>'Dehradun to Badrinath taxi fare is a custom yatra quote per vehicle and duration; call or WhatsApp for a confirmed price.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$__metrics=[['fa-road','~335 km','distance'],['fa-clock','10–12 hr','drive time'],['fa-om','Vishnu temple','highlight'],['fa-indian-rupee-sign','Custom','yatra quote']];
$__fares=[['Innova / Crysta','Custom quote'],['Tempo Traveller','Custom quote'],['Sedan / SUV','On request']];
$__tl=[['fa-circle-dot','Pickup in Dehradun','Usually an early start for the long yatra day.'],['fa-water','Rishikesh to Devprayag','The first confluence and the start of the hill road.'],['fa-place-of-worship','Joshimath overnight','A common halt before the final climb.'],['fa-om','Badrinath darshan','Temple visit plus optional Mana village and Tapt Kund.']];
$__see=[['Badrinath Temple','fa-place-of-worship','The sacred Vishnu shrine set against the Neelkanth peak.'],['Tapt Kund','fa-water','The natural hot spring where pilgrims take a holy dip before darshan.'],['Mana Village','fa-house-chimney','The last village before the border, with caves and local legend.'],['Vasudhara Falls','fa-person-hiking','A scenic waterfall trek a short distance beyond Mana.'],['Neelkanth Peak','fa-mountain-sun','The towering snow peak that watches over the temple town.']];
$__veh=[['Sedan / Dzire','fa-car','1–4 pax','Budget solo / couple yatra'],['Ertiga / SUV','fa-truck-monster','4–6 pax','Small families with luggage'],['Innova / Crysta','fa-van-shuttle','5–7 pax','Hill comfort (recommended)'],['Tempo / Urbania','fa-bus-simple','Groups','Joint families & groups']];
$__matrix=[['Dehradun','Badrinath via Joshimath','10 to 12 hours; most plans include an overnight halt.'],['Rishikesh / Haridwar','Badrinath','Common yatra start points after a Ganga-side halt.'],['Char Dham circuit','Badrinath leg','Badrinath is usually the final dham in the sequence.']];
$__rel=[['Dehradun to Kedarnath','/dehradun-to-kedarnath-taxi','fa-om'],['Dehradun to Gangotri','/dehradun-to-gangotri-taxi','fa-om'],['Dehradun to Yamunotri','/dehradun-to-yamunotri-taxi','fa-om'],['Char Dham Yatra','/char-dham-yatra-taxi','fa-om'],['Dehradun to Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],['Dehradun to Auli','/dehradun-to-auli-taxi','fa-snowflake']];
?>
<main id="main">
<style>
.rt{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--soft:#f5f8ff;--green:#16a34a;--radius:20px;--rsm:14px;--ac:#6d28d9;--ac2:#c4b5fd;--acsoft:#efe9fd;--d1:#1e1240;--d2:#4c1d95;--bg1:#f1ecfb;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,var(--bg1) 0%,#fff 440px)}
.rt *{box-sizing:border-box}
.rt::before{content:"";position:absolute;top:-200px;right:-120px;width:560px;height:440px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac) 14%,transparent),transparent 70%);pointer-events:none}
.rt .rt-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.rt .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rt .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.rt .rv.in{opacity:1;transform:none}
.rt .rt-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.rt .rt-crumb a{color:var(--slate);text-decoration:none}.rt .rt-crumb a:hover{color:var(--ac)}.rt .rt-crumb i{font-size:.6rem;color:var(--mute)}.rt .rt-crumb .cur{color:var(--ink);font-weight:600}
.rt .rt-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.rt .rt-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:var(--acsoft);padding:7px 13px;border-radius:999px}
.rt .rt-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.rt .rt-hero h1 em{font-style:normal;color:var(--ac)}
.rt .rt-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.rt .rt-lead strong{color:var(--ink)}
.rt .rt-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}.rt .rt-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}.rt .rt-m i{color:var(--ac)}.rt .rt-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800}.rt .rt-m span{font-size:.8rem;color:var(--slate)}
.rt .rt-herocta{display:flex;gap:12px;flex-wrap:wrap}
.rt .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rsm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.rt .btn-a{background:var(--ac);color:#fff;box-shadow:0 16px 34px -14px color-mix(in srgb,var(--ac) 60%,transparent)}.rt .btn-a:hover{transform:translateY(-2px);filter:brightness(1.06)}
.rt .btn-g{background:#25d366;color:#04260f}.rt .btn-g:hover{transform:translateY(-2px)}
.rt .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.rt .btn-o:hover{border-color:var(--ac);color:var(--ac)}
.rt .rt-card{position:sticky;top:88px;background:linear-gradient(160deg,var(--d1),var(--d2));border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px color-mix(in srgb,var(--d1) 70%,transparent);overflow:hidden}
.rt .rt-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac2) 30%,transparent),transparent 70%)}
.rt .rt-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:var(--ac2);background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.rt .rt-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.rt .rt-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 14px;position:relative}
.rt .rt-anim{position:relative;height:64px;margin:0 0 8px}.rt .rt-anim .path{position:absolute;left:0;right:0;top:50%;height:3px;transform:translateY(-50%);background:repeating-linear-gradient(90deg,var(--ac2) 0 10px,transparent 10px 20px);opacity:.8}.rt .rt-anim .car{position:absolute;top:50%;left:6%;transform:translate(-50%,-50%);color:#fff;font-size:1rem;animation:rtdrv 5s ease-in-out infinite}.rt .rt-anim .om{position:absolute;right:4%;top:50%;transform:translateY(-50%);color:var(--ac2);font-size:1.3rem;animation:rtom 2.4s ease-in-out infinite}
@keyframes rtdrv{0%,100%{left:6%}50%{left:84%}}
@keyframes rtom{0%,100%{opacity:.6;transform:translateY(-50%) scale(1)}50%{opacity:1;transform:translateY(-50%) scale(1.15)}}
.rt .rt-fares{display:grid;gap:8px;position:relative}.rt .rt-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}.rt .rt-fr .v{font-weight:700;font-size:.9rem}.rt .rt-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.rt .rt-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}.rt .rt-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}.rt .rt-card .cta .w{background:#fff;color:var(--d1)}.rt .rt-card .cta .g{background:#25d366;color:#04260f}.rt .rt-card .cta a:hover{transform:translateY(-2px)}
.rt .rt-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.rt .rt-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--ac);border-radius:16px;padding:20px 22px;box-shadow:0 18px 40px -26px rgba(9,32,84,.25)}.rt .rt-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin-bottom:8px}.rt .rt-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.rt .rt-qa strong{color:var(--ink)}
.rt .sec{padding:48px 0}
.rt .sh{text-align:center;max-width:680px;margin:0 auto 28px}.rt .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:var(--acsoft);padding:7px 13px;border-radius:999px}.rt .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.rt .sh p{color:var(--slate);margin:0}
.rt .tl{position:relative;max-width:780px;margin:0 auto;padding-left:8px}.rt .tl::before{content:"";position:absolute;left:23px;top:8px;bottom:8px;width:2px;background:linear-gradient(180deg,var(--ac),var(--ac2))}
.rt .trow{position:relative;display:grid;grid-template-columns:48px 1fr;gap:18px;padding:0 0 18px}.rt .tdot{position:relative;z-index:1;width:48px;height:48px;border-radius:14px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--ac);font-size:1.05rem;box-shadow:0 8px 18px -10px color-mix(in srgb,var(--ac) 50%,transparent)}.rt .tbody{background:#fff;border:1px solid var(--line);border-radius:16px;padding:15px 18px;transition:transform .3s,box-shadow .3s}.rt .trow:hover .tbody{transform:translateX(4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.3)}.rt .tbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}.rt .tbody p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
.rt .cgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}.rt .citem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--rsm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}.rt .citem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:color-mix(in srgb,var(--ac) 35%,var(--line))}.rt .cico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--acsoft);color:var(--ac);display:grid;place-items:center;font-size:1rem;transition:transform .3s}.rt .citem:hover .cico{transform:scale(1.08) rotate(-5deg)}.rt .citem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.rt .citem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.rt .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 24px 50px -30px rgba(9,32,84,.25)}.rt .tscr{overflow-x:auto}.rt table{width:100%;border-collapse:collapse;min-width:520px}.rt th,.rt td{padding:14px 18px;text-align:left;font-size:.92rem}.rt thead th{background:var(--soft);color:var(--ac);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}.rt tbody tr{border-top:1px solid var(--line);transition:background .2s}.rt tbody tr:hover{background:var(--soft)}
.rt .prose{max-width:840px;margin:24px auto 0}.rt .prose h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 10px}.rt .prose p{color:var(--slate);line-height:1.72;margin:0 0 12px;font-size:.96rem}.rt .prose strong{color:var(--ink)}
.rt .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}.rt .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}.rt .rchip i{color:var(--ac)}.rt .rchip:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-2px);box-shadow:0 12px 24px -14px color-mix(in srgb,var(--ac) 45%,transparent)}
.rt .fbox{max-width:820px;margin:0 auto}.rt .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.rt .fi:hover{border-color:color-mix(in srgb,var(--ac) 35%,var(--line))}.rt .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}.rt .ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--acsoft);color:var(--ac);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}.rt .fi.open .ft{transform:rotate(45deg)}.rt .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}.rt .fi.open .fb{max-height:400px;padding:0 20px 18px}
.rt .soft{background:linear-gradient(180deg,var(--bg1),#fff)}
.rt .cta2{padding:0 0 70px}.rt .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--ac),transparent 55%),linear-gradient(120deg,var(--d1),var(--d2));color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}.rt .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}.rt .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}.rt .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.rt .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}.rt .cta2 .w{background:#fff;color:var(--d1)}.rt .cta2 .g{background:#25d366;color:#04260f}.rt .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.rt .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:900px){.rt .rt-hero{grid-template-columns:1fr;gap:24px}.rt .rt-card{position:static}}
@media(prefers-reduced-motion:reduce){.rt *{transition:none!important;animation:none!important}.rt .rv{opacity:1!important;transform:none!important}}
</style>
<div class="rt"><div class="rt-in">
<nav class="rt-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Badrinath Taxi</span></nav>
<section class="rt-hero">
<div class="rv">
<span class="rt-ey"><i class="fa-solid fa-om"></i> Sacred yatra · Vishnu Dham</span>
<h1 class="disp">Dehradun to Badrinath <em>taxi</em> — a sacred drive to the Vishnu temple</h1>
<p class="rt-lead"><strong>Book a Dehradun to Badrinath taxi with Anaya Cab Service</strong> for pilgrims and families. The ~335 km yatra route runs via Rishikesh, Devprayag and Joshimath, with hill-expert drivers, comfortable Innova / Crysta and Tempo Traveller options, and a flexible plan built around your darshan — with a custom fare confirmed before you travel.</p>
<div class="rt-metrics"><?php foreach($__metrics as $m): ?><span class="rt-m"><i class="fa-solid <?php echo $m[0]; ?>"></i> <b><?php echo $m[1]; ?></b> <span><?php echo $m[2]; ?></span></span><?php endforeach; ?></div>
<div class="rt-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-om"></i> Plan my yatra</a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a quote for Dehradun to Badrinath taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get quote on WhatsApp</a>
<a class="btn btn-o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> <?php echo BUSINESS_PHONE; ?></a>
</div>
</div>
<aside class="rt-card rv" aria-label="Badrinath yatra quote">
<span class="tag"><i class="fa-solid fa-place-of-worship"></i> Yatra planning desk</span>
<h3 class="disp">Your Badrinath taxi</h3>
<p class="sub">Share dates, group size and vehicle — we build the plan and quote.</p>
<div class="rt-anim" aria-hidden="true"><div class="path"></div><i class="fa-solid fa-car-side car"></i><i class="fa-solid fa-om om"></i></div>
<div class="rt-fares"><?php foreach($__fares as $f): ?><div class="rt-fr"><span class="v"><?php echo $f[0]; ?></span><span class="p"><?php echo $f[1]; ?></span></div><?php endforeach; ?></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Plan now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a quote for Dehradun to Badrinath taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp quote</a>
</div>
<p class="note">Custom fare per vehicle &amp; duration · buffer days advised</p>
</aside>
</section>
<div class="rt-qa rv"><div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> provides a Dehradun to Badrinath taxi over the ~335 km yatra route via Joshimath in about 10 to 12 hours, with an Innova or Crysta recommended for hill comfort and a Tempo Traveller for groups. The road reaches Badrinath town close to the temple, the fare is a custom yatra quote, and keeping one or two buffer days is advised in peak and monsoon season.</p></div>
</div>

<?php if (file_exists(__DIR__ . '/includes/yatra-facts.php')) { require_once __DIR__ . '/includes/yatra-facts.php'; if (function_exists('anaya_yatra_facts')) { echo '<div class="rt-in"><div class="rv" style="margin:8px 0 24px">' . anaya_yatra_facts('badrinath') . '</div></div>'; } } ?>

<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-route"></i> The yatra route</span><h2 class="disp">How the Dehradun to Badrinath drive goes</h2><p>River confluences, an overnight halt and the final climb to the Dham.</p></div>
<div class="tl"><?php foreach($__tl as $t): ?><div class="trow rv"><div class="tdot"><i class="fa-solid <?php echo $t[0]; ?>"></i></div><div class="tbody"><h3><?php echo $t[1]; ?></h3><p><?php echo $t[2]; ?></p></div></div><?php endforeach; ?></div>
</div></section>

<section class="sec soft rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-place-of-worship"></i> At Badrinath</span><h2 class="disp">Sacred and scenic stops around the Dham</h2></div>
<div class="cgrid"><?php foreach($__see as $s): ?><div class="citem rv"><span class="cico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div><?php endforeach; ?></div>
</div></section>

<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-van-shuttle"></i> Vehicle &amp; planning</span><h2 class="disp">The right cab and plan for the yatra</h2></div>
<div class="cgrid" style="margin-bottom:24px"><?php foreach($__veh as $v): ?><div class="citem rv"><span class="cico"><i class="fa-solid <?php echo $v[1]; ?>"></i></span><div><h3><?php echo $v[0]; ?></h3><p><?php echo $v[2]; ?> · <?php echo $v[3]; ?></p></div></div><?php endforeach; ?></div>
<div class="twrap"><div class="tscr"><table aria-label="Dehradun to Badrinath taxi planning options">
<thead><tr><th>Starting point</th><th>Plan</th><th>Planning note</th></tr></thead>
<tbody><?php foreach($__matrix as $m): ?><tr><td><strong><?php echo $m[0]; ?></strong></td><td><?php echo $m[1]; ?></td><td><?php echo $m[2]; ?></td></tr><?php endforeach; ?></tbody>
</table></div></div>
<div class="prose">
<h2>Planning a Dehradun to Badrinath taxi yatra</h2>
<p>Badrinath is usually the final and most remote of the Char Dham, and the road to it climbs steadily through the Alaknanda valley via Joshimath, where most travellers take an <strong>overnight halt</strong> to break the journey and acclimatise. Our hill-expert drivers plan the pickup timing, the halt and the final climb so you reach the temple with time for a calm darshan, a dip at Tapt Kund and, if you wish, a visit to Mana village and the Vasudhara Falls trek beyond it.</p>
<p>Because the Dham opens only from around <strong>April to May until October to November</strong>, and because monsoon and peak season can bring road closures, we strongly recommend keeping <strong>one or two buffer days</strong> in your plan. Yatra registration is required, so keep your ID and confirmation handy for checkpoints. Whether you are travelling solo, as a family in an Innova Crysta or as a joint family in a Tempo Traveller, the same verified driver stays with you throughout — with a custom fare confirmed on WhatsApp or call before you set out.</p>
</div>
</div></section>

<section class="sec soft rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related yatra routes</span><h2 class="disp">Other pilgrimage taxis travellers book</h2></div>
<div class="rchips"><?php foreach($__rel as $r): ?><a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a><?php endforeach; ?></div>
</div></section>

<section class="sec rv" id="faq"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Badrinath taxi — FAQs</h2></div>
<div class="fbox"><?php foreach($__faqs as $i=>$f): ?><div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo $f[0]; ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div><?php endforeach; ?></div>
</div></section>

<section class="cta2 rv"><div class="rt-in"><div class="ctain">
<h2 class="disp">Planning your Badrinath yatra? Get a custom quote now</h2>
<p>Share dates, group size and vehicle — we build the itinerary and fare on WhatsApp.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-om"></i> Plan my yatra</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a quote for Dehradun to Badrinath taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div></main>
<script>
(function(){var r=document.querySelectorAll('.rt .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rt .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>