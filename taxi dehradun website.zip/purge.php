<?php
/**
 * Anaya Cab Service — ONE-CLICK FULL CACHE PURGE
 * 1) PHP opcache reset (Hostinger)
 * 2) Cloudflare "Purge Everything" (API se)
 *
 * Usage (bookmark bana lo):
 * https://www.taxidehradun.com/purge.php?key=APNA_KEY
 *
 * Setup: neeche CF_ZONE + CF_TOKEN ek baar daal do (neeche steps hain).
 */
require_once __DIR__ . '/includes/config.php';

/* ── SECURITY: ye key zaroor change karna (apna secret) ── */
$MY_KEY = 'anaya2026';

/* ── CLOUDFLARE: ek baar set karo, phir bhool jao ── */
$CF_ZONE  = 'YOUR_ZONE_ID';    // CF Overview page pe right side mein "Zone ID"
$CF_TOKEN = 'YOUR_API_TOKEN';  // CF API token (purge permission wala)

header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');

if (!isset($_GET['key']) || !hash_equals($MY_KEY, (string)$_GET['key'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'forbidden']);
    exit;
}

$out = ['ok' => true, 'time' => date('Y-m-d H:i:s')];

/* 1) PHP opcache reset */
if (function_exists('opcache_reset')) {
    $out['opcache'] = opcache_reset();
} else {
    $out['opcache'] = 'not-available';
}

/* 2) Cloudflare purge everything */
if ($CF_ZONE !== '7400f88e20e9ad232d97191808f478c2' && $CF_TOKEN !== 'cfk_GZn2z16Akv5deo5GJPqCEqwPG0U9AGUB5BLYns31a7810145') {
    $ch = curl_init('https://api.cloudflare.com/client/v4/zones/' . $CF_ZONE . '/purge_cache');
    curl_setopt_array($ch, array(
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer ' . $CF_TOKEN,
            'Content-Type: application/json',
        ),
        CURLOPT_POSTFIELDS => json_encode(['purge_everything' => true]),
        CURLOPT_TIMEOUT => 20,
    ));
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    $json = json_decode((string)$res, true);
    $out['cloudflare'] = array(
        'http' => $code,
        'success' => !empty($json['success']),
        'error' => $err !== '' ? $err : null,
    );
} else {
    $out['cloudflare'] = array('success' => false, 'note' => 'CF_ZONE / CF_TOKEN abhi set nahi hai');
}

echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);