﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title       = "Cheap Cab in Dehradun | Budget Taxi | Anaya Cab";
$page_description = "Book cheap cab in Dehradun with Anaya Cab. Affordable hatchback & sedan rates from ₹12/km, flat ₹800 airport drops, AC cars, verified drivers. Call " .";
$page_url         = $domain . "/cheap-cab-in-dehradun";

$__faqs = [
    ["What is the cheapest cab rate in Dehradun?", "Cheapest cab in Dehradun starts from ₹12/km for AC Hatchback (WagonR/Glanza), ₹900 for a 4-hour local package, and flat ₹800 for Jolly Grant Airport transfers."],
    ["Are there hidden charges or midnight surge on cheap cabs?", "No. Anaya Cab guarantees 100% transparent billing. Toll, parking, and driver allowance are communicated upfront with zero surge pricing."],
    ["Can I book affordable outstation cabs from Dehradun?", "Yes. We offer low-cost one-way drops to Mussoorie (₹1,050), Rishikesh (₹1,150), Haridwar (₹1,350), and Delhi NCR (₹3,500)."],
    ["How do I book a budget cab in Dehradun?", "You can book instantly by calling +91 80776 11583 or sending a quick WhatsApp message. No advance payment required."]
];

$__faq_entities = [];
foreach ($__faqs as $f) {
    $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
    [
        '@type'=>'Service',
        '@id'=>$page_url.'#service',
        'name'=>'Cheap Cab in Dehradun',
        'serviceType'=>'Affordable Taxi Service',
        'description'=>'Affordable budget taxi service in Dehradun starting at ₹12/km for local city rides and outstation transfers.',
        'provider'=>[
            '@type'=>'TaxiService',
            'name'=>'Anaya Cab Service',
            'telephone'=>$phone_tel,
            'url'=>$domain.'/'
        ],
        'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'800','description'=>'Budget taxi starting from ₹800.']
    ],
    ['@type'=>'BreadcrumbList','itemListElement'=>[
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>$domain.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Pricing','item'=>$domain.'/pricing'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Cheap Cab Dehradun','item'=>$page_url]
    ]],
    ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities]
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
.cheap-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef6ff 0%,#ffffff 460px);padding-bottom:60px}
.cheap-pg *{box-sizing:border-box}
.cheap-in{max-width:1200px;margin:0 auto;padding:0 24px}
.cheap-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:0.82rem;color:var(--slate);padding:24px 0 0}
.cheap-crumb a{color:var(--slate);text-decoration:none;transition:color 0.2s}.cheap-crumb a:hover{color:var(--blue)}
.cheap-crumb i{font-size:0.6rem;color:#94a3b8}.cheap-crumb .cur{color:var(--ink);font-weight:700}
.cheap-hero{display:grid;grid-template-columns:1.24fr 0.86fr;gap:36px;align-items:start;padding:20px 0 10px}
.cheap-badge{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 14px;border-radius:999px}
.cheap-hero h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2rem,4.4vw,3.1rem);font-weight:800;letter-spacing:-0.035em;line-height:1.06;margin:14px 0 12px;color:#07142f}
.cheap-hero h1 em{font-style:normal;color:var(--blue)}

/* Big Featured Hero Image Layout (Screenshot 2 Match) */
.cheap-hero-img-wrap{position:relative;width:100%;height:320px;border-radius:22px;overflow:hidden;margin:16px 0 20px;box-shadow:0 18px 42px -16px rgba(9,32,84,0.22);background:#07142f}
.cheap-hero-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease}
.cheap-hero-img-wrap:hover .cheap-hero-img{transform:scale(1.03)}




.cheap-lead-bold{font-weight:700;color:#07142f;font-size:1.06rem;line-height:1.55;margin:0 0 10px}
.cheap-lead{color:var(--slate);font-size:1rem;line-height:1.66;margin:0 0 18px;max-width:58ch}
.cheap-ai-box{background:#ffffff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:14px;padding:18px 20px;margin:0 0 24px;box-shadow:0 4px 16px rgba(0,87,255,0.05)}
.cheap-ai-box h3{font-size:0.88rem;font-weight:800;color:var(--blue);margin:0 0 6px;display:flex;align-items:center;gap:6px}
.cheap-ai-box p{margin:0;font-size:0.92rem;line-height:1.55;color:#334155}
.cheap-actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.cheap-btn-p{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.cheap-btn-w{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
.cheap-btn-s{display:inline-flex;align-items:center;gap:8px;padding:13px 20px;border-radius:14px;background:#fff;border:1px solid var(--line);color:#07142f;font-weight:700;text-decoration:none}

/* Right Column Luxury Fare Card (Screenshot 2 Match) */
.cheap-fare-card{position:sticky;top:88px;background:linear-gradient(160deg,#0a2540,#0e4a7a);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,0.5);overflow:hidden}
.cheap-fare-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,0.12);padding:6px 12px;border-radius:999px}
.cheap-fare-card h3{font-family:'Sora',sans-serif;font-size:1.25rem;font-weight:800;margin:14px 0 14px}
.cheap-fares-list{display:grid;gap:8px;margin:14px 0 0}
.cheap-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);border-radius:12px;padding:11px 14px}
.cheap-fr .v{font-weight:700;font-size:0.9rem}
.cheap-fr .p{font-family:'Sora',sans-serif;font-weight:800;color:#00c2ff}
.cheap-fare-card .cta{display:grid;gap:10px;margin-top:16px}
.cheap-fare-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform 0.2s}
.cheap-fare-card .cta .w{background:#fff;color:#0a2540}
.cheap-fare-card .cta .g{background:#25d366;color:#04260f}
.cheap-fare-card .cta a:hover{transform:translateY(-2px)}
.cheap-fare-card .note{font-size:0.76rem;color:rgba(255,255,255,0.66);text-align:center;margin:12px 0 0}

.cheap-sec{padding:48px 0;border-top:1px solid var(--line)}
.cheap-sec h2{font-family:'Sora',sans-serif;font-size:clamp(1.7rem,3.4vw,2.3rem);font-weight:800;color:#07142f;margin:0 0 16px;letter-spacing:-0.03em}
.cheap-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:24px}
.cheap-box{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 4px 16px rgba(11,18,32,0.04)}
.cheap-box h4{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#07142f;margin:0 0 8px}
.cheap-box p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
.cheap-faq-item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 22px;margin-bottom:12px}
.cheap-faq-item h4{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#07142f;margin:0 0 8px}
.cheap-faq-item p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
@media (max-width:960px){.cheap-hero{grid-template-columns:1fr;gap:24px}.cheap-hero-img-wrap{height:230px;border-radius:16px}.cheap-fare-card{position:static}.cheap-in{padding:0 16px}}
</style>

<div class="cheap-pg">
    <div class="cheap-in">
        <nav class="cheap-crumb" aria-label="Breadcrumb">
            <a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>
            <a href="/pricing">Pricing</a><i class="fa-solid fa-chevron-right"></i>
            <span class="cur">Cheap Cab Dehradun</span>
        </nav>

        <div class="cheap-hero">
            <div>
                <span class="cheap-badge"><i class="fa-solid fa-tag"></i> BEST PRICE GUARANTEE · FROM ₹12/KM</span>
                <h1>Cheap Cab in <em>Dehradun</em></h1>

                <div class="cheap-hero-img-wrap">
                    <img 
                        src="/assets/images/fleet/dzire.webp" 
                        alt="Cheap Cab in Dehradun - Anaya Cab" 
                        width="680" 
                        height="360" 
                        loading="eager" 
                        decoding="async" 
                        class="cheap-hero-img"
                    >
                </div>

                <p class="cheap-lead-bold">Affordable taxi booking in Dehradun starting at ₹12/km, flat ₹800 airport drops, and zero midnight surge.</p>
                <p class="cheap-lead">Looking for a cheap cab in Dehradun without compromising on comfort and safety? Anaya Cab provides clean, air-conditioned hatchbacks and sedans with verified drivers at budget-friendly standardized fares.</p>

                <div class="cheap-ai-box">
                    <h3><i class="fa-solid fa-bolt"></i> Quick Direct Answer</h3>
                    <p>Cheap cabs in Dehradun start at ₹12/km for Hatchbacks and ₹14/km for Sedans. Local 4hr/40km package costs ₹900, flat airport drops start at ₹800, and outstation trips start from ₹1,050 with upfront billing.</p>
                </div>

                <div class="cheap-actions">
                    <a class="cheap-btn-p" href="/#booking"><i class="fa-solid fa-car-side"></i> Book Cheap Cab</a>
                    <a class="cheap-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a budget cab in Dehradun'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                    <a class="cheap-btn-s" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
                </div>
            </div>

            <!-- Right Column Luxury Fare Card (Screenshot 2 Match) -->
            <aside class="cheap-fare-card" aria-label="Budget cab fares">
                <span class="tag"><i class="fa-solid fa-bolt"></i> Pocket-Friendly Fares</span>
                <h3>Dehradun → Budget Drops</h3>
                <div class="cheap-fares-list">
                    <div class="cheap-fr"><span class="v">Jolly Grant Airport</span><span class="p">₹800</span></div>
                    <div class="cheap-fr"><span class="v">Railway Station / ISBT</span><span class="p">₹400</span></div>
                    <div class="cheap-fr"><span class="v">Mussoorie Tour</span><span class="p">₹1,050</span></div>
                    <div class="cheap-fr"><span class="v">Rishikesh / Haridwar</span><span class="p">₹1,150</span></div>
                    <div class="cheap-fr"><span class="v">Delhi One-Way</span><span class="p">₹3,500</span></div>
                </div>
                <div class="cta">
                    <a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
                    <a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a cheap cab'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
                </div>
                <p class="note">Sedan fare · SUV &amp; Crysta available · 24×7</p>
            </aside>
        </div>

        <section class="cheap-sec">
            <h2>Why Choose Our Budget Taxi Service?</h2>
            <div class="cheap-grid">
                <div class="cheap-box">
                    <h4><i class="fa-solid fa-wallet" style="color:var(--blue);margin-right:8px;"></i> Lowest Per-KM Rates</h4>
                    <p>Standardized rates starting at ₹12/km with zero surge during peak hours or rainfall.</p>
                </div>
                <div class="cheap-box">
                    <h4><i class="fa-solid fa-snowflake" style="color:#16a34a;margin-right:8px;"></i> 100% AC Cabs Guaranteed</h4>
                    <p>Travel in cool comfort across all city traffic and highway routes without AC extra charges.</p>
                </div>
                <div class="cheap-box">
                    <h4><i class="fa-solid fa-shield-halved" style="color:#f59e0b;margin-right:8px;"></i> No Compromise on Safety</h4>
                    <p>All vehicles undergo routine maintenance and are chauffeured by police-verified drivers.</p>
                </div>
            </div>
        </section>

        <section class="cheap-sec">
            <h2>Frequently Asked Questions (Cheap Cab Booking)</h2>
            <?php foreach ($__faqs as $faq): ?>
            <div class="cheap-faq-item">
                <h4><?php echo htmlspecialchars($faq[0]); ?></h4>
                <p><?php echo htmlspecialchars($faq[1]); ?></p>
            </div>
            <?php endforeach; ?>
        </section>
    </div>
</div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
