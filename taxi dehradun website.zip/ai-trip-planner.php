﻿<?php
/**
 * Anaya Cab Service — AI Trip Planner (Devbhoomi Namaste Edition)
 * Production / SEO / AEO / GEO / Responsive UI (English)
 */

require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = "AI Trip Planner Dehradun | Instant Itinerary & Taxi Fare";
$page_description = "Plan your Uttarakhand holiday, hill tours & Char Dham Yatra with Anaya Cab's AI Trip Planner.";
$page_url         = $domain . "/ai-trip-planner";

$page_schema = '<script type="application/ld+json">' . json_encode([
  '@context' => 'https://schema.org',
  '@graph' => [
    [
      '@type' => 'WebApplication',
      '@id' => $page_url . '#app',
      'name' => 'Anaya Cab AI Trip & Fare Planner',
      'applicationCategory' => 'TravelApplication',
      'operatingSystem' => 'Any',
      'url' => $page_url,
      'description' => 'Instant AI powered Uttarakhand tour planner and taxi fare estimator by Anaya Cab Service.',
      'offers' => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'INR'],
      'provider' => [
        '@type' => 'TaxiService',
        'name' => 'Anaya Cab Service',
        'telephone' => $phone_tel,
        'url' => $domain . '/'
      ]
    ],
    [
      '@type' => 'BreadcrumbList',
      '@id' => $page_url . '#breadcrumb',
      'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $domain . '/'],
        ['@type' => 'ListItem', 'position' => 2, 'name' => 'AI Trip Planner', 'item' => $page_url]
      ]
    ]
  ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
/* ==========================================================================
   ANAYA CAB — AI TRIP PLANNER (PREMIUM NAMASTE THEME - ENGLISH)
   ========================================================================== */
.nt-app {
  --blue: #0057ff;
  --blue-dark: #0039ad;
  --blue-light: #eef4ff;
  --cyan: #00c2ff;
  --gold: #d97706;
  --gold-light: #fffbeb;
  --gold-border: #fde68a;
  --ink: #0a0f1e;
  --slate: #475569;
  --mute: #94a3b8;
  --line: #e2e8f0;
  --bg-soft: #f8fafc;
  --green: #16a34a;
  --green-light: #f0fdf4;
  --card-shadow: 0 20px 40px -15px rgba(0, 87, 255, 0.08), 0 1px 3px rgba(0,0,0,0.05);
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  color: var(--ink);
  background: linear-gradient(180deg, #f0f6ff 0%, #ffffff 480px);
  position: relative;
  overflow: hidden;
  padding: 48px 0 80px;
}

.nt-app * { box-sizing: border-box; }
.nt-in { max-width: 1200px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 1; }
.nt-disp { font-family: 'Sora', 'Poppins', sans-serif; letter-spacing: -0.03em; }

.nt-rv { opacity: 0; transform: translateY(28px); transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1); }
.nt-rv.in { opacity: 1; transform: none; }

/* Namaste Eyebrow Badge */
.nt-badge {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-size: 0.76rem;
  font-weight: 800;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--gold);
  background: var(--gold-light);
  border: 1px solid var(--gold-border);
  padding: 8px 18px;
  border-radius: 999px;
  box-shadow: 0 4px 12px rgba(217, 119, 6, 0.1);
  margin-bottom: 16px;
}
.nt-badge i { color: var(--gold); font-size: 0.9rem; }

/* Hero Headings */
.nt-hero-grid {
  display: grid;
  grid-template-columns: 1.15fr 0.85fr;
  gap: 36px;
  align-items: start;
  margin-bottom: 48px;
}

.nt-title {
  font-size: clamp(2.1rem, 4.4vw, 3.1rem);
  font-weight: 800;
  line-height: 1.1;
  color: var(--ink);
  margin: 0 0 16px;
}
.nt-title span {
  background: linear-gradient(135deg, var(--blue), var(--cyan));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.nt-lead {
  color: var(--slate);
  font-size: 1.05rem;
  line-height: 1.7;
  margin-bottom: 24px;
}

/* AI Planner Console Card */
.nt-console {
  background: #ffffff;
  border: 1px solid var(--line);
  border-radius: 24px;
  padding: 26px;
  box-shadow: var(--card-shadow);
  position: relative;
}
.nt-console-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
}
.nt-console-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 0.74rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--blue);
}
.nt-pulse-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--green);
  box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.2);
}

.nt-input-box {
  width: 100%;
  min-height: 105px;
  background: var(--bg-soft);
  border: 1.5px solid var(--line);
  border-radius: 16px;
  padding: 16px 18px;
  font-family: inherit;
  font-size: 1rem;
  color: var(--ink);
  resize: vertical;
  outline: none;
  transition: all 0.25s ease;
  line-height: 1.6;
}
.nt-input-box:focus {
  border-color: var(--blue);
  background: #ffffff;
  box-shadow: 0 0 0 4px rgba(0, 87, 255, 0.1);
}

/* Suggestion Chips */
.nt-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 16px 0;
}
.nt-chip {
  background: var(--bg-soft);
  border: 1px solid var(--line);
  color: var(--slate);
  font-size: 0.82rem;
  font-weight: 600;
  padding: 8px 14px;
  border-radius: 999px;
  cursor: pointer;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.nt-chip:hover {
  background: var(--blue-light);
  border-color: var(--blue);
  color: var(--blue);
  transform: translateY(-1px);
}
.nt-chip i { font-size: 0.75rem; color: var(--gold); }

/* Controls Row */
.nt-controls {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 18px;
}
.nt-select {
  flex: 1;
  min-width: 160px;
  background: var(--bg-soft);
  border: 1.5px solid var(--line);
  border-radius: 14px;
  padding: 13px 16px;
  font-family: inherit;
  font-size: 0.92rem;
  font-weight: 600;
  color: var(--ink);
  outline: none;
  cursor: pointer;
  transition: border-color 0.2s;
}
.nt-select:focus { border-color: var(--blue); }

.nt-btn-generate {
  flex: 1.2;
  min-width: 190px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  background: linear-gradient(135deg, var(--blue), var(--blue-dark));
  color: #ffffff;
  border: none;
  border-radius: 14px;
  font-family: 'Sora', sans-serif;
  font-size: 0.96rem;
  font-weight: 700;
  padding: 14px 24px;
  cursor: pointer;
  box-shadow: 0 10px 24px -6px rgba(0, 87, 255, 0.4);
  transition: all 0.25s ease;
}
.nt-btn-generate:hover {
  transform: translateY(-2px);
  box-shadow: 0 16px 32px -8px rgba(0, 87, 255, 0.5);
}

/* Premium Namaste Itinerary Ticket Card */
.nt-ticket {
  background: #ffffff;
  border: 1.5px solid var(--line);
  border-radius: 24px;
  box-shadow: var(--card-shadow);
  overflow: hidden;
  position: relative;
  min-height: 380px;
}
.nt-ticket-head {
  padding: 18px 22px;
  background: linear-gradient(135deg, #0b1220, #17243e);
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 2px dashed rgba(255,255,255,0.15);
}
.nt-ticket-head .nt-th-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: 'Sora', sans-serif;
  font-size: 0.94rem;
  font-weight: 700;
  letter-spacing: 0.05em;
}
.nt-ticket-head .nt-th-title i { color: #f59e0b; }
.nt-ticket-tag {
  font-size: 0.68rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  background: rgba(255,255,255,0.12);
  padding: 4px 10px;
  border-radius: 6px;
}

.nt-ticket-body {
  padding: 22px;
  max-height: 480px;
  overflow-y: auto;
}

/* Empty State */
.nt-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 14px;
  text-align: center;
  padding: 70px 20px;
  color: var(--mute);
}
.nt-empty-icon {
  width: 68px;
  height: 68px;
  border-radius: 50%;
  background: var(--blue-light);
  color: var(--blue);
  display: grid;
  place-items: center;
  font-size: 1.8rem;
}
.nt-empty p {
  margin: 0;
  font-size: 0.95rem;
  line-height: 1.6;
  color: var(--slate);
}

/* Day Plan Item */
.nt-day-item {
  background: var(--bg-soft);
  border: 1px solid var(--line);
  border-left: 4px solid var(--blue);
  border-radius: 14px;
  padding: 14px 16px;
  margin-bottom: 12px;
  transition: transform 0.2s;
}
.nt-day-item:hover { transform: translateX(3px); background: #ffffff; }
.nt-day-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}
.nt-day-num {
  font-size: 0.72rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--blue);
}
.nt-day-km {
  font-size: 0.74rem;
  font-weight: 700;
  color: var(--slate);
  background: #ffffff;
  border: 1px solid var(--line);
  padding: 2px 8px;
  border-radius: 6px;
}
.nt-day-route {
  font-family: 'Sora', sans-serif;
  font-size: 0.98rem;
  font-weight: 700;
  color: var(--ink);
  margin: 2px 0 4px;
}
.nt-day-highlights {
  font-size: 0.86rem;
  color: var(--slate);
  line-height: 1.5;
  margin: 0;
}

/* Summary & Fare Calculation */
.nt-ticket-summary {
  border-top: 2px dashed var(--line);
  padding: 18px 22px 14px;
  background: var(--bg-soft);
}
.nt-sum-row {
  display: flex;
  justify-content: space-between;
  font-size: 0.88rem;
  color: var(--slate);
  margin-bottom: 6px;
}
.nt-sum-total {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: 'Sora', sans-serif;
  font-size: 1.22rem;
  font-weight: 800;
  color: var(--ink);
  padding-top: 10px;
  border-top: 1px solid var(--line);
  margin-top: 8px;
}
.nt-sum-total b { color: var(--green); font-size: 1.32rem; }

.nt-btn-wa {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin: 14px 22px 18px;
  background: #25d366;
  color: #ffffff;
  border-radius: 14px;
  font-family: 'Sora', sans-serif;
  font-size: 0.96rem;
  font-weight: 700;
  padding: 14px 20px;
  text-decoration: none;
  box-shadow: 0 8px 20px -4px rgba(37, 211, 102, 0.4);
  transition: all 0.25s ease;
}
.nt-btn-wa:hover {
  transform: translateY(-2px);
  box-shadow: 0 14px 28px -6px rgba(37, 211, 102, 0.5);
  color: #ffffff;
}

.nt-ticket-note {
  padding: 0 22px 18px;
  font-size: 0.76rem;
  color: var(--mute);
  margin: 0;
  line-height: 1.5;
}

/* Feature Bento / How it works */
.nt-features {
  padding: 50px 0 20px;
  border-top: 1px solid var(--line);
}
.nt-sh { text-align: center; max-width: 640px; margin: 0 auto 36px; }
.nt-sh h2 { font-size: clamp(1.6rem, 3.2vw, 2.2rem); font-weight: 800; margin: 8px 0; }
.nt-sh p { color: var(--slate); font-size: 0.96rem; }

.nt-steps-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}
.nt-step-card {
  background: #ffffff;
  border: 1px solid var(--line);
  border-radius: 20px;
  padding: 26px 22px;
  text-align: center;
  box-shadow: 0 4px 16px rgba(0,0,0,0.03);
  transition: transform 0.3s;
}
.nt-step-card:hover { transform: translateY(-4px); }
.nt-step-icon {
  width: 54px;
  height: 54px;
  border-radius: 16px;
  background: var(--blue-light);
  color: var(--blue);
  display: grid;
  place-items: center;
  font-size: 1.35rem;
  margin: 0 auto 16px;
}
.nt-step-card h3 { font-size: 1.05rem; font-weight: 800; margin: 0 0 8px; font-family: 'Sora', sans-serif; }
.nt-step-card p { margin: 0; color: var(--slate); font-size: 0.88rem; line-height: 1.6; }

@media (max-width: 960px) {
  .nt-hero-grid { grid-template-columns: 1fr; }
  .nt-steps-grid { grid-template-columns: 1fr; }
}
</style>

<div class="nt-app">
<div class="nt-in">

  <!-- HERO & CONSOLE GRID -->
  <section class="nt-hero-grid">
    
    <!-- LEFT: Inputs & Prompts -->
    <div class="nt-rv">
      <div class="nt-badge">
        <i class="fa-solid fa-hands-praying"></i> Atithi Devo Bhava &middot; Devbhoomi AI Trip Planner
      </div>
      <h1 class="nt-disp nt-title">
        Plan Your Uttarakhand Tour with AI,<br>
        <span>Instant Itinerary &amp; Cab Fares</span>
      </h1>
      <p class="nt-lead">
        Type your trip idea like <em>"3 days family tour to Mussoorie and Dhanaulti"</em> or <em>"10 days Char Dham Yatra in Innova Crysta"</em> — our AI engine creates your daily route, scenic milestones, and transparent fixed taxi fare in seconds.
      </p>

      <!-- AI Console Form Card -->
      <div class="nt-console">
        <div class="nt-console-top">
          <span class="nt-console-label"><i class="fa-solid fa-wand-magic-sparkles"></i> AI Route Engine</span>
          <span class="nt-pulse-dot" title="Ready to plan"></span>
        </div>

        <textarea id="apPrompt" class="nt-input-box" placeholder="e.g. 3 days family tour to Mussoorie and Dhanaulti from Dehradun, Innova Crysta cab..."></textarea>

        <!-- Suggestion Chips -->
        <div class="nt-chips">
          <button class="nt-chip" type="button" data-q="2 days Mussoorie + Dhanaulti scenic family tour"><i class="fa-solid fa-mountain-sun"></i> 2 Days Mussoorie + Dhanaulti</button>
          <button class="nt-chip" type="button" data-q="Char Dham Yatra 10 days package with driver"><i class="fa-solid fa-om"></i> Char Dham 10 Days</button>
          <button class="nt-chip" type="button" data-q="1 Day Dehradun local sightseeing tour"><i class="fa-solid fa-city"></i> Dehradun Sightseeing</button>
          <button class="nt-chip" type="button" data-q="Dehradun to Delhi airport drop sedan expressway"><i class="fa-solid fa-plane-departure"></i> Delhi Airport Drop</button>
          <button class="nt-chip" type="button" data-q="Rishikesh river rafting and Ganga aarti 2 days"><i class="fa-solid fa-water"></i> Rishikesh 2 Days</button>
          <button class="nt-chip" type="button" data-q="Jim Corbett wildlife safari weekend tour 2 days"><i class="fa-solid fa-tree"></i> Jim Corbett Weekend</button>
        </div>

        <!-- Dropdowns & CTA -->
        <div class="nt-controls">
          <select id="apVeh" class="nt-select" aria-label="Choose vehicle type">
            <option value="auto">Vehicle: Auto-Detect</option>
            <option value="sedan">Sedan (Dzire / Etios) - 4 Seater</option>
            <option value="ertiga">Ertiga (SUV) - 6 Seater</option>
            <option value="crysta">Innova Crysta - Premium 7 Seater</option>
            <option value="tempo">Tempo Traveller - 12 to 17 Seater</option>
          </select>
          <button class="nt-btn-generate" id="apGo" type="button">
            <i class="fa-solid fa-bolt"></i> Generate Tour Itinerary
          </button>
        </div>
      </div>
    </div>

    <!-- RIGHT: Itinerary & Ticket Output Card -->
    <aside class="nt-ticket nt-rv" aria-label="Trip Itinerary Ticket">
      <div class="nt-ticket-head">
        <div class="nt-th-title">
          <i class="fa-solid fa-ticket"></i>
          <span>DEVBHOHMI TOUR ITINERARY</span>
        </div>
        <span class="nt-ticket-tag">ANAYA CAB SERVICE</span>
      </div>

      <!-- Live Generated Itinerary Body -->
      <div class="nt-ticket-body" id="apBody">
        <div class="nt-empty">
          <div class="nt-empty-icon">
            <i class="fa-solid fa-route"></i>
          </div>
          <p>
            <strong>No tour plan generated yet.</strong><br>
            Describe your trip above or click a suggestion chip, then press <b>Generate Tour Itinerary</b>.
          </p>
        </div>
      </div>

      <!-- Total Calculation Block -->
      <div class="nt-ticket-summary" id="apSum" style="display:none"></div>

      <!-- WhatsApp Booking CTA -->
      <a class="nt-btn-wa" id="apWA" style="display:none" target="_blank" rel="noopener">
        <i class="fa-brands fa-whatsapp"></i> Confirm Fare on WhatsApp
      </a>

      <p class="nt-ticket-note" id="apNote" style="display:none">
        * Indicative AI estimated rate. Final confirmed fare is locked with zero hidden charges on WhatsApp booking desk (Toll, state taxes &amp; parking as per actuals).
      </p>
    </aside>

  </section>

  <!-- HOW IT WORKS SECTION -->
  <section class="nt-features nt-rv">
    <div class="nt-sh">
      <div class="nt-badge" style="margin-bottom:8px">
        <i class="fa-solid fa-shield-halved"></i> 3 Easy Steps
      </div>
      <h2 class="nt-disp">How Does the AI Trip Planner Work?</h2>
      <p>Plan your customized Uttarakhand holiday and book verified hill-expert drivers in 3 effortless steps.</p>
    </div>

    <div class="nt-steps-grid">
      <div class="nt-step-card">
        <div class="nt-step-icon"><i class="fa-solid fa-pen-fancy"></i></div>
        <h3>1. Describe Your Trip Idea</h3>
        <p>Enter your duration, destination, family size, or vehicle preference in natural language.</p>
      </div>
      <div class="nt-step-card">
        <div class="nt-step-icon"><i class="fa-solid fa-microchip"></i></div>
        <h3>2. Instant Route &amp; Fare Match</h3>
        <p>Our smart engine calculates accurate Uttarakhand hill distances, drive times, and transparent rate matrix.</p>
      </div>
      <div class="nt-step-card">
        <div class="nt-step-icon"><i class="fa-brands fa-whatsapp"></i></div>
        <h3>3. 1-Click WhatsApp Booking</h3>
        <p>Your day-by-day roadmap is pre-formatted into a direct WhatsApp message ready for instant confirmation.</p>
      </div>
    </div>
  </section>

</div>
</div>
</main>

<script>
(function(){
  /* Master Destination Matrix (Fares & Distance from Dehradun) */
  var D = {
    mussoorie: { n: 'Mussoorie', f: 1200, km: 35, h: 'Mall Road, Kempty Falls, Gun Hill, George Everest Peak' },
    dhanaulti: { n: 'Dhanaulti', f: 2200, km: 60, h: 'Eco Park, Surkanda Devi Temple, Pristine Deodar Forests' },
    kanatal:   { n: 'Kanatal', f: 2600, km: 80, h: 'Adventure Camps, Himalayan Sunset Viewpoints' },
    chakrata:  { n: 'Chakrata', f: 3200, km: 90, h: 'Tiger Falls, Chilmiri Neck, Peaceful Pine Forests' },
    haridwar:  { n: 'Haridwar', f: 1350, km: 55, h: 'Har Ki Pauri, Evening Ganga Aarti, Mansa Devi Temple' },
    rishikesh: { n: 'Rishikesh', f: 1000, km: 45, h: 'Ram Jhula, Tapovan, River Rafting, Parmarth Niketan Ashram' },
    delhi:     { n: 'Delhi NCR / IGI', f: 3500, km: 213, h: 'Direct Delhi-Dehradun Expressway Drop, Airport Terminals' },
    nainital:  { n: 'Nainital', f: 5500, km: 280, h: 'Naini Lake Boating, Mall Road, Bhimtal, Naukuchiatal' },
    corbett:   { n: 'Jim Corbett', f: 3800, km: 240, h: 'Jungle Jeep Safari, Ramnagar Resort Stay, Wildlife Trail' },
    chandigarh:{ n: 'Chandigarh', f: 4000, km: 170, h: 'Sector 17 Plaza, Rock Garden, Sukhna Lake Promenade' },
    auli:      { n: 'Auli', f: 8500, km: 300, h: 'Himalayan Snow Slopes, Auli Ropeway, Joshimath Halt' },
    chopta:    { n: 'Chopta', f: 4500, km: 200, h: 'Mini Switzerland of India, Tungnath & Chandrashila Base' },
    local:     { n: 'Dehradun Sightseeing', f: 1600, km: 80, h: 'Robbers Cave, Sahastradhara, FRI Campus, Tapkeshwar Temple' },
    yatra:     { n: 'Char Dham Yatra', f: 3500, km: 0, h: 'Yamunotri, Gangotri, Kedarnath, Badrinath (10-12 Days Circuit)', perday: true }
  };

  var MULT = { sedan: 1, ertiga: 1.35, crysta: 1.6, tempo: 2.3 };
  var VNAME = { sedan: 'Sedan (Dzire / Etios)', ertiga: 'Ertiga (SUV)', crysta: 'Innova Crysta', tempo: 'Tempo Traveller' };

  function r50(x) { return Math.round(x / 50) * 50; }

  function parse(q) {
    q = q.toLowerCase();
    var daysMatch = q.match(/(\d+)\s*(days?|din|nights?|raat)/);
    var days = daysMatch ? parseInt(daysMatch[1], 10) : 0;
    
    var word = { 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'ten': 10, 'ek': 1, 'do': 2, 'teen': 3, 'char': 4, 'paanch': 5, 'das': 10 };
    for (var w in word) {
      if (q.indexOf(w + ' day') > -1 || q.indexOf(w + ' din') > -1) {
        days = word[w];
      }
    }

    var veh = document.getElementById('apVeh').value;
    if (veh === 'auto') {
      if (/tempo|group|traveller|12|17|large/.test(q)) veh = 'tempo';
      else if (/luxury|crysta|vip|innova/.test(q)) veh = 'crysta';
      else if (/family|ertiga|suv|6 seater/.test(q)) veh = 'ertiga';
      else veh = 'sedan';
    }

    var hits = [];
    ['mussoorie', 'dhanaulti', 'kanatal', 'chakrata', 'haridwar', 'rishikesh', 'delhi', 'nainital', 'corbett', 'chandigarh', 'auli', 'chopta'].forEach(function(k){
      if (q.indexOf(k) > -1 || (k === 'mussoorie' && /mussoorie|musouri|mansuri/.test(q)) || (k === 'corbett' && /jim\s*corbett|safari/.test(q))) {
        hits.push(k);
      }
    });

    if (/char\s*dham|kedarnath|badrinath|yatra|do\s*dham/.test(q)) hits = ['yatra'];
    if (/local|sightsee|city|dehradun/.test(q) && hits.length === 0) hits = ['local'];
    if (hits.length === 0) hits = ['mussoorie'];

    return { days: days, veh: veh, hits: hits, round: /round|return|both|wapas/.test(q) };
  }

  function build(p) {
    var m = MULT[p.veh] || 1, days = p.days, legs = [], total = 0;

    if (p.hits[0] === 'yatra') {
      days = days || 10;
      var seq = [
        ['Day 1-2', 'Dehradun → Barkot → Yamunotri', 'Yamunotri Dham Darshan, Barkot night halt'],
        ['Day 3-4', 'Barkot → Uttarkashi → Gangotri', 'Gangotri Dham Darshan, Bhagirathi River halt'],
        ['Day 5-7', 'Uttarkashi → Guptkashi → Kedarnath', 'Kedarnath Dham Trek & Temple Darshan, Guptkashi halt'],
        ['Day 8-9', 'Guptkashi → Joshimath → Badrinath', 'Badrinath Dham Darshan, Mana Village, Joshimath halt'],
        ['Day 10',  'Joshimath → Rishikesh → Dehradun', 'Return journey via Devprayag Sangam & drop']
      ];
      seq.forEach(function(s){ legs.push({ d: s[0], t: s[1], h: s[2] }); });
      total = days * D.yatra.f * m;
    } else {
      if (!days) days = p.hits.length > 1 ? p.hits.length + 1 : 2;
      var per = Math.max(1, Math.round(days / p.hits.length));
      var di = 1;
      
      p.hits.forEach(function(k){
        var d = D[k];
        var n = (k === p.hits[p.hits.length - 1] && p.hits.length > 1) ? Math.max(1, days - (di - 1)) : Math.min(per, Math.max(1, days - (di - 1)));
        for (var i = 0; i < Math.max(1, n); i++) {
          legs.push({
            d: 'Day ' + di,
            t: 'Dehradun → ' + d.n + (i > 0 ? ' (Exploration & Stay)' : ''),
            h: d.h
          });
          di++;
        }
      });

      p.hits.forEach(function(k){ var d = D[k]; total += d.f * m * (p.round ? 1.8 : 1); });
      if (days > p.hits.length) total += (days - p.hits.length) * 900 * m; // Outstation driver day allowance & halt
    }

    return { legs: legs, total: r50(total), days: days, veh: p.veh };
  }

  function render(b, p) {
    var body = document.getElementById('apBody');
    var sum  = document.getElementById('apSum');
    var wa   = document.getElementById('apWA');
    var note = document.getElementById('apNote');

    var html = '';
    b.legs.forEach(function(l){
      var km = '';
      for (var k in D) {
        if (l.t.indexOf(D[k].n) > -1 && D[k].km) {
          km = D[k].km + ' km';
        }
      }
      html += '<div class="nt-day-item">' +
              '<div class="nt-day-header"><span class="nt-day-num">' + l.d + '</span>' +
              (km ? '<span class="nt-day-km"><i class="fa-solid fa-road"></i> ~' + km + '</span>' : '') +
              '</div>' +
              '<div class="nt-day-route">' + l.t + '</div>' +
              '<p class="nt-day-highlights">' + l.h + '</p>' +
              '</div>';
    });

    body.innerHTML = html;
    sum.style.display = '';
    note.style.display = '';
    wa.style.display = 'flex';

    sum.innerHTML = '<div class="nt-sum-row"><span>Suggested Vehicle</span><b>' + VNAME[b.veh] + '</b></div>' +
                    '<div class="nt-sum-row"><span>Total Duration</span><b>' + b.days + ' Days Tour</b></div>' +
                    '<div class="nt-sum-total"><span>Estimated Cab Fare</span><b>₹' + b.total.toLocaleString('en-IN') + '*</b></div>';

    var txt = 'Namaste Anaya Cab, I generated a tour plan on your AI Trip Planner:\n' +
              '• Duration: ' + b.days + ' Days\n' +
              '• Vehicle: ' + VNAME[b.veh] + '\n' +
              '• Route: ' + b.legs.map(function(l){ return l.t; }).join(' -> ') + '\n' +
              '• Estimated Total: ₹' + b.total.toLocaleString('en-IN') + '\n\n' +
              'Please confirm vehicle availability and share the final booking quote.';

    wa.href = 'https://wa.me/<?php echo $whatsapp; ?>?text=' + encodeURIComponent(txt);
  }

  document.getElementById('apGo').addEventListener('click', function(){
    var q = document.getElementById('apPrompt').value.trim() || '2 days Mussoorie family tour';
    var parsed = parse(q);
    render(build(parsed), parsed);
  });

  document.querySelectorAll('.nt-chip').forEach(function(c){
    c.addEventListener('click', function(){
      document.getElementById('apPrompt').value = c.getAttribute('data-q');
      document.getElementById('apGo').click();
    });
  });

  // Reveal Animations
  var r = document.querySelectorAll('.nt-rv');
  if ('IntersectionObserver' in window) {
    var o = new IntersectionObserver(function(es){
      es.forEach(function(e){
        if (e.isIntersecting) {
          e.target.classList.add('in');
          o.unobserve(e.target);
        }
      });
    }, { threshold: 0.1 });
    r.forEach(function(e){ o.observe(e); });
  } else {
    r.forEach(function(e){ e.classList.add('in'); });
  }
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>