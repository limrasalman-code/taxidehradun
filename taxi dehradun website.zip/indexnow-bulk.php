<?php
/**
 * IndexNow BULK submitter — submits every URL from sitemap.xml to Bing/IndexNow.
 * Guarded by the IndexNow key. Place this file in the SITE ROOT (same folder as sitemap.xml).
 *
 * Run:  https://www.taxidehradun.com/indexnow-bulk.php?run=YOUR_INDEXNOW_KEY
 */
error_reporting(E_ALL);
@ini_set('display_errors', '1');
header('Content-Type: text/plain; charset=utf-8');

// --- locate config.php + indexnow.php robustly (root or one level up) ---
$candidates = [__DIR__, dirname(__DIR__)];
$config = null; $indexnow = null;
foreach ($candidates as $base) {
    if (!$config   && is_file($base . '/includes/config.php'))   $config   = $base . '/includes/config.php';
    if (!$indexnow && is_file($base . '/includes/indexnow.php')) $indexnow = $base . '/includes/indexnow.php';
}
if (!$config)   { http_response_code(500); exit("ERROR: includes/config.php not found. Put indexnow-bulk.php in the site root.\n"); }
if (!$indexnow) { http_response_code(500); exit("ERROR: includes/indexnow.php not found. Upload it to /includes/ first.\n"); }
require_once $config;
require_once $indexnow;

if (!defined('INDEXNOW_KEY')) { http_response_code(500); exit("ERROR: INDEXNOW_KEY not defined in indexnow.php.\n"); }

// --- guard ---
if (php_sapi_name() !== 'cli' && (($_GET['run'] ?? '') !== INDEXNOW_KEY)) {
    http_response_code(403);
    exit("Forbidden. Append ?run=YOUR_INDEXNOW_KEY to run this.\n");
}

// --- find sitemap.xml (root) ---
$sitemap = null;
foreach ($candidates as $base) { if (is_file($base . '/sitemap.xml')) { $sitemap = $base . '/sitemap.xml'; break; } }
if (!$sitemap) { http_response_code(500); exit("ERROR: sitemap.xml not found in site root.\n"); }

$xml = @simplexml_load_file($sitemap);
if (!$xml) exit("ERROR: could not parse sitemap.xml\n");

$urls = [];
foreach ($xml->url as $u) { $loc = trim((string)$u->loc); if ($loc !== '') $urls[] = $loc; }
$urls = array_values(array_unique($urls));
$total = count($urls);
echo "IndexNow key: " . INDEXNOW_KEY . "\n";
echo "Host: " . (function_exists('indexnow_host') ? indexnow_host() : '?') . "\n";
echo "Found {$total} URLs in sitemap.\n\n";
if (!$total) exit("No URLs to submit.\n");

$ok = 0; $fail = 0; $batchNo = 0;
foreach (array_chunk($urls, 100) as $batch) {
    $batchNo++;
    $res = indexnow_submit($batch);
    if (!empty($res['ok'])) { $ok += count($batch); echo "Batch {$batchNo}: OK (HTTP {$res['code']}) — " . count($batch) . " URLs\n"; }
    else { $fail += count($batch); echo "Batch {$batchNo}: FAILED (HTTP {$res['code']}) {$res['error']} {$res['resp']}\n"; }
    usleep(400000);
}
echo "\nDone. OK: {$ok} · Failed: {$fail} · Total: {$total}\n";
echo "200/202 = accepted. Check Bing Webmaster Tools > IndexNow for status.\n";
