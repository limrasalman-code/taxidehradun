<?php
/**
 * SITE CLEANUP DOCTOR v3 - Anaya Cab Service
 * File: site-cleanup-doctor.php (ROOT /public_html/)
 * URL: ?key=cleanup2026 (preview) | &deploy=1 | &kill=1
 * Fixes: 1) /blog/ canonical self  2) joshimath stub  3) broken webp  4) long/double-brand titles
 */
set_time_limit(600);
$KEY = 'cleanup2026';
if (!isset($_REQUEST['key']) || $_REQUEST['key'] !== $KEY) { http_response_code(403); die('Access denied.'); }
if (isset($_REQUEST['kill'])) { @unlink(__FILE__); die('site-cleanup-doctor.php deleted ✅'); }

$deploy = isset($_REQUEST['deploy']);
$BK = __DIR__ . '/meta-backups/cleanup3';
$report = [];

function cl3_bak($BK, $f) { if (!is_dir($BK)) @mkdir($BK, 0755, true); @copy($f, $BK . '/' . basename($f) . '.bak'); }

/* ---------- 1) /blog/ canonical self ---------- */
$f = __DIR__ . '/blog/index.php';
$c = @file_get_contents($f);
if ($c !== false) {
    $n = preg_replace_callback('#\$page_url\s*=\s*\$domain\s*\.\s*(["\'])/blog\1\s*;#', function ($m) {
        return '$page_url = $domain . ' . $m[1] . '/blog/' . $m[1] . ';';
    }, $c, 1, $cnt);
    if ($cnt > 0) {
        if ($deploy && $n !== $c) { cl3_bak($BK, $f); file_put_contents($f, $n); }
        $report['blog/ canonical'] = $deploy ? 'FIXED ✅ (/blog/ self)' : 'ready (1 match)';
    } else $report['blog/ canonical'] = 'pattern nahi mila (manual check)';
} else $report['blog/ canonical'] = 'blog/index.php read fail ❌';

/* ---------- 2) joshimath stub (clone auli) ---------- */
$src = __DIR__ . '/dehradun-to-auli-taxi.php';
$dst = __DIR__ . '/dehradun-to-joshimath-taxi.php';
if (is_file($dst)) $report['joshimath'] = 'already exists ✅';
elseif (is_file($src)) {
    $s = str_replace('dehradun-to-auli-taxi', 'dehradun-to-joshimath-taxi', (string) file_get_contents($src));
    if ($deploy) file_put_contents($dst, $s);
    $report['joshimath'] = $deploy ? 'CREATED ✅' : 'ready (clone auli)';
} else $report['joshimath'] = 'auli stub nahi mila ❌';

/* ---------- 3) broken webp ---------- */
$wsrc = __DIR__ . '/assets/images/services/dehradun-airport-taxi-service.webp';
$wdst = __DIR__ . '/assets/images/routes/dehradun-airport-taxi-guide.webp';
if (is_file($wdst)) $report['webp'] = 'already exists ✅';
elseif (is_file($wsrc)) {
    if ($deploy) @copy($wsrc, $wdst);
    $report['webp'] = $deploy ? 'FIXED ✅ (copied)' : 'ready (copy)';
} else $report['webp'] = 'source webp nahi mila ❌';

/* ---------- 4) long / double-brand titles ---------- */
$EXCL = ['site-cleanup-doctor','blog-seo-doctor','schema-fixer','schema-doctor','link-doctor','orphan-fixer','image-doctor','pwa-fix','emergency-restore','sitemap','index','404','clear-opcache','track','booking'];
$tFix = 0; $tList = [];
foreach (array_merge(glob(__DIR__ . '/blog/*.php') ?: [], glob(__DIR__ . '/*.php') ?: []) as $f) {
    $slug = basename($f, '.php');
    if (in_array($slug, $EXCL, true)) continue;
    $c = @file_get_contents($f);
    if ($c === false) continue;
    $orig = $c;
    $c = preg_replace_callback('#\$page_title\s*=\s*(["\'])(.*?)\1\s*;#s', function ($m) use (&$tFix, &$tList, $slug) {
        $q = $m[1]; $t = $m[2];
        $nt = str_replace([' | Anaya Cab Service', ' | Anaya Cab | Anaya Cab'], ' | Anaya Cab Service', $t);
        if (mb_strlen($nt) > 60 && preg_match('/^(.*?)(\s*[|\-]\s*Anaya Cab(?: Service)?)$/s', $nt, $mm)) {
            $base = trim($mm[1]); $brand = $mm[2];
            $max = 60 - mb_strlen($brand);
            if (mb_strlen($base) > $max) {
                $base = mb_substr($base, 0, $max);
                $sp = mb_strrpos($base, ' ');
                if ($sp !== false && $sp > 15) $base = mb_substr($base, 0, $sp);
                $base = rtrim($base, ' ,–-:');
            }
            $nt = $base . $brand;
        }
        if ($nt === $t || $nt === '' || mb_strlen($nt) > 60) return $m[0];
        $esc = ($q === '"') ? str_replace('"', '\\"', $nt) : str_replace("'", "\\'", $nt);
        $tFix++; $tList[] = $slug;
        return '$page_title = ' . $q . $esc . $q . ';';
    }, $c, 1);
    if ($deploy && $c !== $orig) { cl3_bak($BK, $f); file_put_contents($f, $c); }
}
$report['titles'] = $tFix ? $tFix . ' fixed → ' . implode(', ', array_slice($tList, 0, 10)) : '0 (sab ≤60 ya pattern alag)';
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Site Cleanup Doctor v3 - Anaya Cab</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Plus Jakarta Sans',sans-serif;background:#0A1633;color:#F5F8FF;padding:30px}.wrap{max-width:950px;margin:0 auto}h1{font-family:'Sora',sans-serif;font-size:1.7rem;margin-bottom:20px}.card{background:rgba(255,255,255,.05);border:1px solid #E3EAF8;border-radius:12px;padding:25px}.mono{font-family:monospace;font-size:.85rem;background:rgba(0,0,0,.3);padding:8px 12px;border-radius:6px;margin:6px 0;word-break:break-all}.btn{display:inline-block;padding:14px 28px;background:#0057FF;color:#fff;font-weight:700;border-radius:8px;cursor:pointer;margin:10px 10px 0 0;border:none}.btn.red{background:#EF4444}.note{font-size:.85rem;color:#94a3b8;margin-top:14px}</style>
</head><body><div class="wrap"><h1>🧹 Site Cleanup Doctor v3</h1><div class="card">
<?php foreach ($report as $k => $v): ?><div class="mono"><b><?= htmlspecialchars($k) ?></b>: <?= htmlspecialchars($v) ?></div><?php endforeach; ?>
<?php if (!$deploy): ?>
<form method="GET"><input type="hidden" name="key" value="<?= htmlspecialchars($KEY) ?>"><input type="hidden" name="deploy" value="1"><button class="btn" type="submit">🚀 APPLY ALL (backup ke saath)</button></form>
<a class="btn red" href="?key=<?= htmlspecialchars($KEY) ?>&kill=1" onclick="return confirm('Delete?')">🗑️ Self-Delete</a>
<p class="note">Backups: /meta-backups/cleanup3/. Apply ke baad /clear-opcache chalao.</p>
<?php else: ?>
<p class="note">✅ Applied. /clear-opcache chalao, phir verify: /blog/ canonical, /dehradun-to-joshimath-taxi (200), webp (200). Self-delete kar dena.</p>
<a class="btn red" href="?key=<?= htmlspecialchars($KEY) ?>&kill=1">🗑️ Self-Delete tool</a>
<?php endif; ?>
</div></div></body></html>