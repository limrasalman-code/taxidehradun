<?php
require_once __DIR__ . '/includes/config.php';
$V = [
'slug'=>'force-urbania-rental-dehradun','name'=>'Force Urbania Rental Dehradun','short'=>'Urbania','cls'=>'Luxury Van · Premium Group',
'char'=>'Luxury Van · Premium Group','char_icon'=>'fa-bus-simple','glyph'=>'fa-bus-simple','img'=>'/assets/images/fleet/urbania.webp',
'ac'=>'#e11d48','ac2'=>'#fb7185','d1'=>'#2a0612','d2'=>'#7f1d3a','tint'=>'#fdeef1',
'headline'=>'The premium way to move a group',
'lead'=>'Book Force Urbania rental in Dehradun when a group deserves more than a basic traveller — the Urbania is a monocoque luxury van with pushback seats, full air-conditioning, charging points and large windows for around 13 passengers, giving weddings, corporate teams and premium Char Dham groups a noticeably calmer, quieter ride than a regular Tempo Traveller.',
'pax'=>'~13','bags'=>'12+','rate_range'=>'From ₹25 / km','pkg4'=>'On request','pkg8'=>'On request',
'service_type'=>'Force Urbania premium rental','offers_price'=>'25','offer_desc'=>'Force Urbania rental in Dehradun available from approx. ₹25 per km for premium group travel, subject to availability.',
'area'=>['Dehradun','Uttarakhand','Char Dham','Mussoorie','Rishikesh','Haridwar'],
'best_for'=>[
['fa-gem','Premium group travel','Pushback seats, AC and a smooth monocoque ride — the comfortable choice when the group experience matters.'],
['fa-cake-candles','Weddings & VIP guests','Stylish, comfortable transfers for wedding parties and VIP movement between venues.'],
['fa-briefcase','Corporate & offsites','Quiet cabins and charging points keep the team productive on the road.'],
['fa-om','Char Dham, premium','Long yatra days made easier with better seating, space and ride comfort.'],
],
'compare_title'=>'Force Urbania vs Tempo Traveller',
'compare'=>[['Force Urbania','~13 passengers','Premium group travel & family tours'],['Tempo Traveller','12–17 passengers','Budget group travel & pilgrimage']],
'routes'=>[['Char Dham Yatra','/char-dham-yatra-taxi'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi'],['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Dehradun → Nainital','/dehradun-to-nainital-taxi']],
'use_cases'=>['Premium airport group pickup','Wedding & VIP transfers','Corporate travel & offsites','Char Dham premium group','Comfort-focused outstation tours'],
'faqs'=>[
['How many people can travel in Force Urbania?','Force Urbania comfortably seats around 13 passengers in premium pushback seating, with space for luggage.'],
['Can Urbania be booked for Char Dham Yatra?','Yes, the Urbania is available for Char Dham and Do Dham Yatra for groups that want premium comfort on long pilgrimage days.'],
['Is Urbania available for airport group pickup?','Yes, premium group pickup and drop from Jolly Grant Airport can be arranged with advance booking.'],
['How is the Urbania different from a Tempo Traveller?','A Tempo Traveller uses a truck-style ladder-frame chassis, while the Urbania uses a car-style monocoque body, giving a lower floor, a quieter cabin and a more planted, less bouncy ride.'],
['Is the fare fixed before the trip?','Yes, like every Anaya Cab booking the fare is agreed upfront with tolls, parking and any hill or night charges explained before you start — no surprises at the end.'],
],
'title'=>'Force Urbania Rental Dehradun | 13-Seater Luxury Van',
'desc'=>'Book Force Urbania in Dehradun for premium group travel. 13-seater luxury van for weddings, corporate trips, Char Dham. From ₹25/km. Call '.BUSINESS_PHONE.'.',
];
$page_url = SITE_DOMAIN . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];
require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-user-group"></i><b><?php echo htmlspecialchars($V['pax']); ?></b><span>passengers</span></span>
<span class="vp-m"><i class="fa-solid fa-suitcase-rolling"></i><b><?php echo htmlspecialchars($V['bags']); ?></b><span>luggage</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>AC</b><span>sanitised</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b><?php echo htmlspecialchars($V['rate_range']); ?></b><span>base fare</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?> in Dehradun" width="384" height="256" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where this cab shines</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['cls']); ?> fare at a glance</h2><p>Per-km and group quotes — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Plan</th><th>What you get</th><th>Fare</th></tr></thead>
<tbody>
<tr><td>Per kilometre</td><td>Premium group outstation &amp; yatra</td><td class="fare"><?php echo htmlspecialchars($V['rate_range']); ?></td></tr>
<tr><td>Full-day premium tour</td><td>Sightseeing or short outstation with the group</td><td class="fare"><?php echo htmlspecialchars($V['pkg4']); ?></td></tr>
<tr><td>Multi-day / yatra</td><td>Char Dham, Do Dham, multi-day premium tours</td><td class="fare"><?php echo htmlspecialchars($V['pkg8']); ?></td></tr>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> comparison">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> The Urbania difference</span><h2 class="disp">What makes the Urbania feel different</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">A regular tempo traveller is built on a ladder-frame chassis — the same idea as a truck — so the cabin sits high, the ride stays bouncy on broken tarmac and the engine noise is never quite far away. The Force Urbania turns that around. It uses a monocoque body the way a car does, which means a lower floor, a better centre of gravity and a cabin that feels planted rather than perched. On a long Char Dham day or a wedding transfer across Dehradun, that difference is usually the first thing a group notices.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">Inside, the seats recline through a pushback mechanism and there is genuine legroom from row to row, which starts to matter when a family is sitting for four or five hours at a stretch. Large side windows keep the cabin bright on hill routes, individual charging points stop people fighting over a single socket, and the air-conditioning is sized for a full load instead of a half-empty van. Luggage goes into a dedicated rear space rather than piling up on the seats between passengers.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">None of this changes how Anaya Cab actually runs the trip. You still get the same police-verified driver, the same fixed fare agreed before you start, the same 24x7 support and the same sanitised, AC-ready vehicle you would get on any other booking. The Urbania simply gives a group that cares about comfort a noticeably calmer way to travel together — without having to split into two separate cabs.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Monocoque body for a lower, more stable and quieter ride than a ladder-frame traveller.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Pushback reclining seats with real row-to-row legroom for long journeys.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Individual charging points and large windows for a brighter, more comfortable cabin.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Dedicated rear luggage space so bags never crowd the passengers.</li>
</ul>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular routes</span><h2 class="disp">Routes travellers book</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This cab is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your group size, route and dates — we confirm a transparent fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>