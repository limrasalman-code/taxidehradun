<?php
require_once __DIR__ . '/includes/config.php';
$domain    = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone     = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp  = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$gbp_link  = defined('GOOGLE_BUSINESS_PROFILE_URL') ? GOOGLE_BUSINESS_PROFILE_URL : 'https://share.google/j96GFirtHp7CzVY0e';
$page_title       = "Customer Reviews | 4.9★ Rated - Anaya Cab Dehradun";
$page_description = "Read authentic customer reviews for Anaya Cab Service Dehradun. 4.9★ rating on Google Business Profile, verified drivers, transparent fares.";
$page_url         = $domain . "/reviews";

/* ---- Real GBP metrics (single source) ---- */
$gbp_rating = 4.9;
$gbp_reviews_count = 22;

/* ---- FAQs (visible text == schema text, exact match) ---- */
$faqs = [
['How is Anaya Cab Service rated on Google?', 'Anaya Cab Service is rated 4.9 stars from 22+ verified Google reviews, with riders highlighting on-time pickups, clean cars and transparent fixed fares.'],
['Are the fares really fixed before pickup?', 'Yes. Every fare — local, airport or outstation — is confirmed on call or WhatsApp before the driver starts, with no hidden charges.'],
['What do riders mention most in their reviews?', 'Riders most often mention punctual airport pickups, polite hill-experienced drivers, clean AC cars and honest one-way pricing on routes like Delhi, Mussoorie and Char Dham.'],
['Can I read real reviews before booking?', 'Yes. The live Google review widget on this page shows unedited reviews from our Google Business Profile, and all 22+ reviews are readable on Google.'],
];

/* ---- SCHEMA: NO self-Review entities (Google policy). Sirf aggregateRating + FAQ. ---- */
$faq_entities = [];
foreach ($faqs as $f) {
$faq_entities[] = ['@type'=>'Question','name'=>$f[0],'text'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}
$graph = [
[
'@type' => 'TaxiService',
'@id' => $domain . '/#taxi-service',
'name' => 'Anaya Cab Service',
'url' => $domain . '/',
'telephone' => $phone_tel,

],
[
'@type' => 'Service',
'@id' => $page_url . '#service',
'name' => 'Anaya Cab Service Customer Reviews',
'serviceType' => 'Taxi Service Customer Reviews',
'provider' => ['@id' => $domain . '/#taxi-service'],
'url' => $page_url,
],
[
'@type' => 'FAQPage',
'@id' => $page_url . '#faq',
'mainEntity' => $faq_entities,
],
];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>$graph], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
?>
<style>
.rvw{--blue:#0057ff;--cyan:#00c2ff;--ink:#0a1633;--slate:#5b6b8c;--cloud:#f5f8ff;--line:#e3eaf8;--gold:#f5a623;--green:#12a150;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#fff 520px)}
.rvw *{box-sizing:border-box}
.rvw .amb{position:absolute;inset:0;pointer-events:none;background-image:radial-gradient(rgba(0,87,255,.07) 1px,transparent 1.4px);background-size:28px 28px;-webkit-mask-image:radial-gradient(120% 80% at 82% 0%,#000,transparent 72%);mask-image:radial-gradient(120% 80% at 82% 0%,#000,transparent 72%)}
.rvw .wrap{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.rvw .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rvw .rv{opacity:0;transform:translateY(24px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.rvw .rv.in{opacity:1;transform:none}
.rvw .crumb{display:flex;gap:8px;align-items:center;font-size:.82rem;color:var(--slate);padding:30px 0 0}.rvw .crumb a{color:var(--slate);text-decoration:none}.rvw .crumb a:hover{color:var(--blue)}.rvw .crumb i{font-size:.6rem;color:#94a3b8}.rvw .crumb .cur{color:var(--ink);font-weight:600}
.rvw .hero{display:grid;grid-template-columns:1.1fr .9fr;gap:30px;align-items:start;padding:24px 0 8px}
.rvw .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.rvw h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3rem);font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:14px 0 12px}
.rvw h1 em{font-style:normal;color:var(--blue)}
.rvw .lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:54ch;margin:0}
.rvw .sum{background:linear-gradient(160deg,#03102e,#0a2a63);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,40,120,.5);position:relative;overflow:hidden}
.rvw .sum::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(57,182,255,.3),transparent 70%)}
.rvw .sum .big{display:flex;align-items:baseline;gap:12px;position:relative}
.rvw .sum .num{font-family:'Sora','Poppins',sans-serif;font-size:3.4rem;font-weight:800;line-height:1;color:#fff}
.rvw .sum .stars{color:var(--gold);font-size:1rem;display:flex;gap:3px}.rvw .sum .stars i.off{opacity:.25}
.rvw .sum .cnt{font-size:.88rem;color:rgba(255,255,255,.85);margin-top:6px;position:relative}
.rvw .bars{margin:16px 0 0;position:relative}
.rvw .bar{display:flex;align-items:center;gap:10px;margin-bottom:7px;font-size:.78rem}
.rvw .bar .lab{width:34px;color:rgba(255,255,255,.8)}
.rvw .bar .track{flex:1;height:7px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}
.rvw .bar .fill{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--cyan),var(--blue))}
.rvw .bar .n{width:26px;text-align:right;color:rgba(255,255,255,.7)}
.rvw .gcard{margin-top:14px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:14px;padding:14px 16px;position:relative}
.rvw .gcard a{color:#9fe0ff;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:8px}
.rvw .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:28px 0 6px}
.rvw .st{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px 12px;text-align:center;box-shadow:0 12px 30px -16px rgba(9,32,84,.16)}
.rvw .st b{font-family:'Sora','Poppins',sans-serif;font-size:1.35rem;color:var(--ink);display:block}
.rvw .st span{font-size:.75rem;color:var(--slate);font-weight:600}
.rvw .sec-head{padding-top:30px}
.rvw .sec-head h3{font-family:'Sora',sans-serif;font-size:1.3rem;font-weight:800;color:#07142f;margin:0 0 4px}
.rvw .sec-head p{color:var(--slate);font-size:0.92rem;margin:0}
.rvw .widgetbox{padding:20px 0 10px;min-height:140px}
.rvw .fq{background:#fff;border:1px solid var(--line);border-radius:16px;margin-bottom:12px;overflow:hidden}
.rvw .fq-h{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:17px 21px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer;color:var(--ink)}
.rvw .fq-t{flex:none;width:28px;height:28px;border-radius:9px;background:rgba(0,87,255,.1);color:var(--blue);display:grid;place-items:center;font-size:.86rem;transition:transform .3s}
.rvw .fq.open .fq-t{transform:rotate(45deg)}
.rvw .fq-b{max-height:0;overflow:hidden;color:var(--slate);font-size:.94rem;line-height:1.66;padding:0 21px;transition:max-height .4s,padding .4s}
.rvw .fq.open .fq-b{max-height:300px;padding:0 21px 18px}
.rvw .cta{padding:40px 0 70px}
.rvw .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0057ff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:46px 24px;box-shadow:0 34px 70px -28px rgba(0,40,120,.55);position:relative;overflow:hidden}
.rvw .ctain h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);margin:0 0 8px;color:#fff}
.rvw .ctain p{color:rgba(255,255,255,.84);margin:0 0 20px}
.rvw .ctain .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.rvw .ctain a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}
.rvw .ctain .w{background:#fff;color:#0a2a63}.rvw .ctain .g{background:#25d366;color:#04260f}.rvw .ctain .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.rvw .ctain a:hover{transform:translateY(-2px)}
@media(max-width:900px){.rvw .hero{grid-template-columns:1fr}.rvw .stats{grid-template-columns:repeat(2,1fr)}}
@media(prefers-reduced-motion:reduce){.rvw *{transition:none!important;animation:none!important}.rvw .rv{opacity:1!important;transform:none!important}}
</style>
<div class="rvw">
<div class="amb" aria-hidden="true"></div>
<div class="wrap">
<nav class="crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Reviews</span></nav>
<section class="hero">
<div class="rv">
<span class="ey"><i class="fa-solid fa-star"></i> Verified Google Ratings</span>
<h1 class="disp">Real reviews from <em>real riders</em></h1>
<p class="lead">Every review below is pulled live from our Google Business Profile — no edits, no filters. Airport transfers, outstation trips, Char Dham yatra, and local rides across Dehradun.</p>
</div>
<aside class="sum rv" aria-label="Rating summary">
<div class="big"><span class="num"><?php echo number_format($gbp_rating,1); ?></span><span class="stars"><?php for($i=1;$i<=5;$i++){ echo '<i class="fa-solid fa-star'.($i<=round($gbp_rating)?'':' off').'"></i>'; } ?></span></div>
<div class="cnt">Based on <strong><?php echo $gbp_reviews_count; ?> verified Google reviews</strong> (4.9★ Average)</div>
<div class="bars">
<?php $dist=[5=>20,4=>2,3=>0,2=>0,1=>0]; foreach($dist as $s=>$n){ $pct=round($n/$gbp_reviews_count*100); echo '<div class="bar"><span class="lab">'.$s.'★</span><span class="track"><span class="fill" style="width:'.$pct.'%"></span></span><span class="n">'.$n.'</span></div>'; } ?>
</div>
<div class="gcard"><a href="<?php echo $gbp_link; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-google"></i> Read all reviews on Google Business Profile</a></div>
</aside>
</section>
<div class="stats rv">
<div class="st"><b>500+</b><span>Happy Customers</span></div>
<div class="st"><b>50+</b><span>Verified Drivers</span></div>
<div class="st"><b>25+</b><span>Cities Covered</span></div>
<div class="st"><b>100%</b><span>Safety Record</span></div>
</div>
<div class="sec-head rv">
<h3>Live Google Reviews</h3>
<p>Unedited, real-time reviews straight from our Google Business Profile.</p>
</div>
<div class="widgetbox rv">
<!-- Trustindex Google Reviews Widget (single source of visible reviews) -->
<script defer async src='https://cdn.trustindex.io/loader.js?c40b2f079d02660789462470352'></script>
</div>
<div class="sec-head rv">
<h3>Review FAQs</h3>
<p>Quick answers about our ratings and how we keep them honest.</p>
</div>
<div style="padding-top:14px">
<?php foreach ($faqs as $i => $f): ?>
<div class="fq rv<?php echo $i===0?' open':''; ?>">
<div class="fq-h"><?php echo htmlspecialchars($f[0]); ?><span class="fq-t"><i class="fa-solid fa-plus"></i></span></div>
<div class="fq-b"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div>
</div>
<?php endforeach; ?>
</div>
<section class="cta rv"><div class="ctain">
<h2 class="disp">How was your journey?</h2>
<p>Tell us — or leave a review on Google to help fellow travellers.</p>
<div class="row">
<a class="g" href="<?php echo $gbp_link; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-google"></i> Review us on Google</a>
<a class="w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to share feedback about my trip.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp feedback</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></section>
</div></div>
<script>
(function(){var r=document.querySelectorAll('.rvw .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rvw .fq-h').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>