﻿<?php
require_once __DIR__ . '/includes/config.php';
$page_title = "Dehradun Railway Station Taxi | 24/7 Cabs - Anaya Cab";
$page_description = "Book taxi from Dehradun Railway Station for local hotels, ISBT, Jolly Grant Airport, Mussoorie, Rishikesh, Haridwar and outstation trips.";
$page_url         = SITE_DOMAIN . "/dehradun-railway-station-taxi";
/* ONE source -> Service + Offer + FAQPage. Visible FAQ = SAME array => exact-match safe. */
$__faqs = [
["Can I book a taxi pickup from Dehradun Railway Station?", "Yes, taxi pickup is available from Dehradun Railway Station for hotels, homes, Jolly Grant Airport, Mussoorie, Rishikesh, Haridwar and other outstation destinations."],
["Will the driver wait if my train is delayed?", "Share your train number and arrival time when you book and the driver plans around the actual arrival, with any waiting charge confirmed with you before the trip."],
["Which vehicles can I get at Dehradun Railway Station?", "Sedan, Ertiga, Innova, Innova Crysta and Tempo Traveller options can be arranged at the station depending on passengers, luggage and availability."],
["Can I book a taxi from the station to Mussoorie or the airport?", "Yes, direct taxis are available from Dehradun Railway Station to Mussoorie, Jolly Grant Airport, Rishikesh, Haridwar, Nainital and outstation routes, with the fare confirmed before pickup."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun Railway Station Taxi','serviceType'=>'Railway station taxi pickup and drop','description'=>'24/7 taxi pickup and drop from Dehradun Railway Station for local, airport and outstation transfers with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>BUSINESS_PHONE_TEL,'url'=>SITE_DOMAIN.'/'],'areaServed'=>[['@type'=>'Place','name'=>'Dehradun Railway Station'],['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Mussoorie'],['@type'=>'City','name'=>'Rishikesh'],['@type'=>'City','name'=>'Haridwar'],['@type'=>'Airport','name'=>'Jolly Grant Airport']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','description'=>'Railway station taxi fare depends on route and vehicle; call or WhatsApp for an exact quote before pickup.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__routes = [
['Railway Station → Dehradun hotel / home','Local drop','fa-hotel','/local-taxi-in-dehradun'],
['Railway Station → Jolly Grant Airport','Airport transfer','fa-plane-departure','/dehradun-airport-taxi-service'],
['Railway Station → Mussoorie','Hill station','fa-mountain-sun','/dehradun-to-mussoorie-taxi'],
['Railway Station → Rishikesh','Yoga & rafting','fa-water','/dehradun-to-rishikesh-taxi'],
['Railway Station → Haridwar','Pilgrimage','fa-om','/dehradun-to-haridwar-taxi'],
['Railway Station → ISBT Dehradun','Bus connection','fa-bus','/isbt-dehradun-taxi'],
];
$__steps = [
['fa-ticket','Share train details','Send train number, arrival time, passenger count and luggage on WhatsApp or call.','We assign a driver who tracks the train, not just the timetable.'],
['fa-user-shield','Driver coordinated','Driver details and meeting point are shared before you arrive.','No searching for a cab on a crowded platform.'],
['fa-people-arrows','Meet at the exit','Come toward the main exit or prepaid taxi area; the driver confirms the exact spot.','Smooth handover even with luggage and at odd hours.'],
['fa-location-dot','Direct drop','A direct drop to your hotel, home, airport or outstation destination.','Faster, calmer travel after a long journey.'],
];
$__share = ['Train number & arrival time','Coach / exit point if known','Number of passengers & luggage','Destination (hotel, home, airport or route)','A phone reachable on arrival'];
?>
<main id="main">
<style>
.rs{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--steel:#334155;--amber:#d97706;--amber-soft:#fdf0db;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef2f7 0%,#ffffff 440px)}
.rs *{box-sizing:border-box}
.rs::before{content:"";position:absolute;top:-200px;right:-120px;width:560px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(51,65,85,.12),transparent 70%);pointer-events:none}
.rs::after{content:"";position:absolute;top:340px;left:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(217,119,6,.08),transparent 70%);pointer-events:none}
.rs .rs-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.rs .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rs .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.rs .rv.in{opacity:1;transform:none}
.rs .rs-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.rs .rs-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.rs .rs-crumb a:hover{color:var(--steel)}
.rs .rs-crumb i{font-size:.6rem;color:var(--mute)}.rs .rs-crumb .cur{color:var(--ink);font-weight:600}
.rs .rs-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.rs .rs-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--steel);background:#e8edf4;padding:7px 13px;border-radius:999px}
.rs .rs-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.rs .rs-hero h1 em{font-style:normal;color:var(--steel)}
.rs .rs-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.rs .rs-lead strong{color:var(--ink)}
.rs .rs-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}
.rs .rs-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.rs .rs-trust i{color:var(--green)}
.rs .rs-herocta{display:flex;gap:12px;flex-wrap:wrap}
.rs .rs-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.rs .rs-btn-s{background:var(--steel);color:#fff;box-shadow:0 16px 34px -14px rgba(51,65,85,.55)}.rs .rs-btn-s:hover{transform:translateY(-2px);filter:brightness(1.1)}
.rs .rs-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.rs .rs-btn-g:hover{transform:translateY(-2px)}
.rs .rs-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.rs .rs-btn-o:hover{border-color:var(--steel);color:var(--steel)}
/* train tracking card */
.rs .rs-card{position:sticky;top:88px;background:linear-gradient(160deg,#1e293b,#334155);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(30,41,59,.6);overflow:hidden}
.rs .rs-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(217,119,6,.3),transparent 70%)}
.rs .rs-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#fcd9a3;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.rs .rs-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.rs .rs-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 18px;position:relative}
.rs .rs-track{position:relative;height:64px;margin:0 0 8px}
.rs .rs-track .rail{position:absolute;left:0;right:0;top:50%;height:4px;transform:translateY(-50%);background:repeating-linear-gradient(90deg,#94a3b8 0 14px,#475569 14px 22px);border-radius:4px}
.rs .rs-track .stn{position:absolute;top:50%;transform:translate(-50%,-50%);width:12px;height:12px;border-radius:50%;background:#fcd9a3;box-shadow:0 0 0 4px rgba(252,217,163,.25)}
.rs .rs-track .stn.a{left:8%}.rs .rs-track .stn.b{left:92%}
.rs .rs-track .train{position:absolute;top:50%;left:8%;transform:translate(-50%,-50%);color:#fff;font-size:1.1rem;animation:rstrain 4s ease-in-out infinite}
@keyframes rstrain{0%,100%{left:8%}50%{left:92%}}
.rs .rs-track .lab{position:absolute;bottom:0;font-size:.64rem;letter-spacing:.08em;color:rgba(255,255,255,.7)}
.rs .rs-track .lab.a{left:0}.rs .rs-track .lab.b{right:0}
.rs .rs-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.rs .rs-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.rs .rs-card .cta .w{background:#fff;color:var(--steel)}.rs .rs-card .cta .g{background:#25d366;color:#04260f}
.rs .rs-card .cta a:hover{transform:translateY(-2px)}
.rs .rs-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.rs .rs-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--steel);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.rs .rs-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--steel);margin-bottom:8px}
.rs .rs-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.rs .rs-qa strong{color:var(--ink)}
.rs .rs-sec{padding:48px 0}
.rs .rs-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.rs .rs-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--steel);background:#e8edf4;padding:7px 13px;border-radius:999px}
.rs .rs-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.rs .rs-sh p{color:var(--slate);margin:0}
/* route cards */
.rs .rs-rgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
.rs .rs-rcard{display:flex;gap:14px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:16px 18px;text-decoration:none;color:var(--ink);transition:transform .3s,box-shadow .3s,border-color .3s}
.rs .rs-rcard:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#cdd6e3}
.rs .rs-rcard .ri{flex:none;width:44px;height:44px;border-radius:12px;background:var(--amber-soft);color:var(--amber);display:grid;place-items:center;font-size:1rem;transition:transform .3s}
.rs .rs-rcard:hover .ri{transform:scale(1.08) rotate(-5deg)}
.rs .rs-rcard .rt b{font-family:'Sora','Poppins',sans-serif;font-size:.96rem;display:block}
.rs .rs-rcard .rt small{font-size:.78rem;color:var(--slate)}
.rs .rs-rcard .arr{margin-left:auto;color:var(--mute);transition:transform .3s,color .3s}.rs .rs-rcard:hover .arr{transform:translateX(4px);color:var(--steel)}
/* timeline */
.rs .rs-tl{position:relative;max-width:820px;margin:0 auto;padding-left:8px}
.rs .rs-tl::before{content:"";position:absolute;left:23px;top:8px;bottom:8px;width:2px;background:linear-gradient(180deg,var(--steel),var(--amber))}
.rs .rs-trow{position:relative;display:grid;grid-template-columns:48px 1fr;gap:18px;padding:0 0 20px}
.rs .rs-tdot{position:relative;z-index:1;width:48px;height:48px;border-radius:14px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--steel);font-size:1.05rem;box-shadow:0 8px 18px -10px rgba(51,65,85,.4)}
.rs .rs-tbody{background:#fff;border:1px solid var(--line);border-radius:16px;padding:15px 18px;transition:transform .3s,box-shadow .3s}
.rs .rs-trow:hover .rs-tbody{transform:translateX(4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.3)}
.rs .rs-tbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}
.rs .rs-tbody p{margin:0 0 4px;color:var(--slate);font-size:.88rem;line-height:1.6}
.rs .rs-tbody .why{color:var(--green);font-weight:600;font-size:.82rem}
/* share chips */
.rs .rs-chips{display:flex;flex-wrap:wrap;gap:11px;justify-content:center;max-width:820px;margin:0 auto}
.rs .rs-chip{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:11px 17px;font-weight:600;font-size:.9rem;color:var(--ink);transition:.25s}
.rs .rs-chip i{color:var(--amber);font-size:.78rem}
.rs .rs-chip:hover{border-color:var(--amber);color:var(--amber);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(217,119,6,.4)}
.rs .rs-prose{max-width:840px;margin:26px auto 0}
.rs .rs-prose h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 10px}
.rs .rs-prose p{color:var(--slate);line-height:1.72;margin:0 0 12px;font-size:.96rem}.rs .rs-prose strong{color:var(--ink)}
.rs .rs-fbox{max-width:820px;margin:0 auto}
.rs .rs-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.rs .rs-fi:hover{border-color:#cdd6e3}
.rs .rs-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.rs .rs-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--amber-soft);color:var(--amber);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.rs .rs-fi.open .rs-ft{transform:rotate(45deg)}
.rs .rs-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.rs .rs-fi.open .rs-fb{max-height:380px;padding:0 20px 18px}
.rs .rs-soft{background:linear-gradient(180deg,#eef2f7,#f7f9fc)}
.rs .rs-cta{padding:0 0 70px}
.rs .rs-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#334155,transparent 55%),linear-gradient(120deg,#1e293b,#334155);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.rs .rs-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.rs .rs-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.rs .rs-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.rs .rs-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.rs .rs-cta .w{background:#fff;color:var(--steel)}.rs .rs-cta .g{background:#25d366;color:#04260f}.rs .rs-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.rs .rs-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.rs .rs-hero{grid-template-columns:1fr;gap:24px}.rs .rs-card{position:static}}
@media(prefers-reduced-motion:reduce){.rs *{transition:none!important;animation:none!important}.rs .rv{opacity:1!important;transform:none!important}}
</style>

<div class="rs">
<div class="rs-in">
<nav class="rs-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Railway Station Taxi</span></nav>

<section class="rs-hero">
<div class="rv">
<span class="rs-eyebrow"><i class="fa-solid fa-train"></i> Station pickup · 24×7</span>
<h1 class="disp">Dehradun Railway Station <em>taxi</em> — a cab waiting when you are</h1>
<p class="rs-lead"><strong>Book a taxi from Dehradun Railway Station</strong> for local hotel transfers, ISBT, Jolly Grant Airport, Mussoorie, Rishikesh, Haridwar and outstation trips. Anaya Cab Service tracks your train and coordinates the pickup, so a verified driver and a clean AC cab are ready at the exit — even for early-morning and late-night arrivals.</p>
<div class="rs-trust">
<span><i class="fa-solid fa-circle-check"></i> Train tracking</span>
<span><i class="fa-solid fa-circle-check"></i> Fixed fare upfront</span>
<span><i class="fa-solid fa-circle-check"></i> Verified drivers</span>
<span><i class="fa-solid fa-circle-check"></i> 24×7 pickup</span>
</div>
<div class="rs-herocta">
<a class="rs-btn rs-btn-s" href="/#booking"><i class="fa-solid fa-taxi"></i> Book station taxi</a>
<a class="rs-btn rs-btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from Dehradun Railway Station.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Share train details</a>
<a class="rs-btn rs-btn-o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> <?php echo BUSINESS_PHONE; ?></a>
</div>
</div>
<aside class="rs-card rv" aria-label="Book your station taxi">
<span class="tag"><i class="fa-solid fa-train-subway"></i> Live station desk</span>
<h3 class="disp">Your station pickup</h3>
<p class="sub">Share train number &amp; arrival — driver tracks the train for you.</p>
<div class="rs-track" aria-hidden="true">
<div class="rail"></div>
<span class="stn a"></span><span class="stn b"></span>
<i class="fa-solid fa-train train"></i>
<span class="lab a">ARRIVAL</span><span class="lab b">YOUR CAB</span>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from Dehradun Railway Station.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp train no.</a>
</div>
<p class="note">Driver details shared before arrival · 24×7</p>
</aside>
</section>

<div class="rs-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> provides 24×7 taxi pickup from Dehradun Railway Station for local drops, Jolly Grant Airport transfers and outstation routes to Mussoorie, Rishikesh, Haridwar and Nainital. Share your train number and arrival time and the driver tracks the train, with the fare confirmed before pickup and no advance on most bookings.</p>
</div>
</div>

<!-- ROUTES -->
<section class="rs-sec rv"><div class="rs-in">
<div class="rs-sh"><span class="ey"><i class="fa-solid fa-route"></i> Where to from the station</span><h2 class="disp">Popular railway station taxi routes</h2><p>Local, airport and outstation — all bookable from the platform exit.</p></div>
<div class="rs-rgrid">
<?php foreach ($__routes as $r): ?>
<a class="rs-rcard rv" href="<?php echo $r[3]; ?>">
<span class="ri"><i class="fa-solid <?php echo $r[2]; ?>"></i></span>
<span class="rt"><b><?php echo $r[0]; ?></b><small><?php echo $r[1]; ?></small></span>
<i class="fa-solid fa-arrow-right arr"></i>
</a>
<?php endforeach; ?>
</div>
</div></section>

<!-- PICKUP TIMELINE -->
<section class="rs-sec rs-soft rv"><div class="rs-in">
<div class="rs-sh"><span class="ey"><i class="fa-solid fa-list-check"></i> Pickup guide</span><h2 class="disp">How our railway station pickup works</h2><p>Four steps from platform to a calm, direct drop.</p></div>
<div class="rs-tl">
<?php foreach ($__steps as $s): ?>
<div class="rs-trow rv"><div class="rs-tdot"><i class="fa-solid <?php echo $s[0]; ?>"></i></div><div class="rs-tbody"><h3><?php echo $s[1]; ?></h3><p><?php echo $s[2]; ?></p><span class="why"><i class="fa-solid fa-circle-check"></i> <?php echo $s[3]; ?></span></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- WHAT TO SHARE -->
<section class="rs-sec rv"><div class="rs-in">
<div class="rs-sh"><span class="ey"><i class="fa-solid fa-clipboard-list"></i> For a smooth pickup</span><h2 class="disp">What to share when you book</h2></div>
<div class="rs-chips">
<?php foreach ($__share as $s): ?><span class="rs-chip"><i class="fa-solid fa-circle-check"></i> <?php echo $s; ?></span><?php endforeach; ?>
</div>
<div class="rs-prose">
<h2>Early-morning &amp; late-night trains</h2>
<p>Many trains reach Dehradun very early or late at night, when finding a reliable cab on the spot is hardest. A pre-booked station taxi means a verified driver is already coordinated for your arrival, so you are never left waiting at odd hours with luggage. If a train is delayed, the driver adjusts to the new time and any waiting charge is confirmed with you in advance — no surprises on the platform.</p>
<p>Travelling onward to <strong>Mussoorie, Rishikesh, Haridwar or the airport</strong>? We plan the direct route from the station so you skip the city detour and travel door to door after a long journey. For families and groups, an <strong>Ertiga, Innova or Tempo Traveller</strong> can be arranged with advance notice to fit passengers and bags comfortably.</p>
</div>
</div></section>

<!-- FAQ -->
<section class="rs-sec rs-soft rv" id="faq"><div class="rs-in">
<div class="rs-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Railway station taxi — FAQs</h2></div>
<div class="rs-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="rs-fi<?php echo $i===0?' open':''; ?>"><div class="rs-fh"><?php echo $f[0]; ?><span class="rs-ft"><i class="fa-solid fa-plus"></i></span></div><div class="rs-fb"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- CTA -->
<section class="rs-cta rv"><div class="rs-in">
<div class="rs-ctain">
<h2 class="disp">Arriving at Dehradun Railway Station? Book your cab now</h2>
<p>Share your train number and we will have a verified driver waiting at the exit.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book station taxi</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from Dehradun Railway Station.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.rs .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rs .rs-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>