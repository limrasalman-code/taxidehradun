<?php
require_once __DIR__ . '/includes/config.php';
$page_title       = "Privacy Policy | Anaya Cab Service Dehradun";
$page_description = "How Anaya Cab Service, Dehradun collects, uses and protects your data when you book a taxi by form, call or WhatsApp. Read our privacy policy.";
$page_url         = SITE_DOMAIN . "/privacy-policy";
/* FAQPage schema — visible accordion se EXACT match (Google rule). */
$__faqs = [
['Does Anaya Cab Service share my personal data with third parties?', 'We never sell your personal data. We share trip details only with the assigned driver and, where needed, trusted payment or messaging partners (such as WhatsApp) strictly to deliver your booking. We do not share your information for advertising or marketing by unrelated companies.'],
['How can I request deletion or correction of my data?', 'You can ask us to correct or delete the personal information we hold about you at any time by emailing ' . BUSINESS_EMAIL . ' or calling ' . BUSINESS_PHONE . '. We will action valid requests within a reasonable period, except where we are legally required to retain certain records.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', '@id' => $page_url . '#faq', 'mainEntity' => $__faq_entities], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
?>
<main>
<style>
.lp{--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f6f9ff;--radius:18px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef3fb,#ffffff 240px)}
.lp *{box-sizing:border-box}
.lp .lp-in{max-width:1120px;margin:0 auto;padding:0 22px}
.lp .lp-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:18px 0 0;font-size:.82rem;color:var(--slate)}
.lp .lp-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}
.lp .lp-crumb a:hover{color:var(--blue)}
.lp .lp-crumb i{font-size:.62rem;color:#94a3b8}
.lp .lp-crumb .cur{color:var(--ink);font-weight:600}
.lp .lp-head{padding:26px 0 8px;max-width:760px}
.lp .lp-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.lp .lp-head h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.8rem,4vw,2.6rem);font-weight:800;letter-spacing:-.03em;line-height:1.08;margin:14px 0 10px}
.lp .lp-head p{color:var(--slate);font-size:1.02rem;line-height:1.6;margin:0}
.lp .lp-meta{display:flex;flex-wrap:wrap;gap:16px;margin-top:14px;font-size:.8rem;color:var(--slate)}
.lp .lp-meta span{display:inline-flex;align-items:center;gap:7px}
.lp .lp-meta i{color:var(--blue)}
.lp .lp-layout{display:grid;grid-template-columns:248px 1fr;gap:40px;padding:30px 0 60px;align-items:start}
.lp .lp-toc{position:sticky;top:88px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:18px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 12px 30px -16px rgba(9,32,84,.18)}
.lp .lp-toc h2{font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#94a3b8;margin:0 0 12px}
.lp .lp-toc a{display:block;padding:7px 10px;border-radius:10px;color:var(--slate);font-size:.86rem;font-weight:500;text-decoration:none;border-left:2px solid transparent;transition:.2s}
.lp .lp-toc a:hover{background:var(--soft);color:var(--blue);border-left-color:var(--blue)}
.lp .lp-body{background:#fff;border:1px solid var(--line);border-radius:22px;padding:34px 38px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -28px rgba(9,32,84,.22)}
.lp .lp-body section{scroll-margin-top:96px;padding:6px 0 4px}
.lp .lp-body section+section{border-top:1px solid var(--line);margin-top:18px;padding-top:24px}
.lp .lp-body h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:700;letter-spacing:-.02em;margin:0 0 10px}
.lp .lp-body h3{font-size:1.02rem;font-weight:700;margin:18px 0 6px}
.lp .lp-body p{color:#3b4456;line-height:1.72;margin:0 0 12px;font-size:.96rem}
.lp .lp-body ul{margin:0 0 12px;padding-left:2px;list-style:none;display:flex;flex-direction:column;gap:8px}
.lp .lp-body li{position:relative;padding-left:24px;color:#3b4456;line-height:1.6;font-size:.95rem}
.lp .lp-body li::before{content:"\f058";font-family:"Font Awesome 6 Free";font-weight:900;position:absolute;left:0;top:2px;color:var(--blue);font-size:.82rem}
.lp .lp-body a{color:var(--blue);font-weight:600;text-decoration:none}
.lp .lp-body a:hover{text-decoration:underline}
.lp .lp-table{width:100%;border-collapse:collapse;margin:6px 0 14px;border:1px solid var(--line);border-radius:14px;overflow:hidden;font-size:.92rem}
.lp .lp-table th,.lp .lp-table td{padding:13px 16px;text-align:left;border-bottom:1px solid var(--line)}
.lp .lp-table thead th{background:var(--soft);color:#0039ad;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.8rem;letter-spacing:.02em}
.lp .lp-table tbody tr:last-child td{border-bottom:0}
.lp .lp-table tbody tr:hover{background:var(--soft)}
.lp .lp-faq{margin-top:26px}
.lp .lp-faq h2{margin-bottom:14px}
.lp .lp-faq-i{border:1px solid var(--line);border-radius:14px;margin-bottom:10px;overflow:hidden;background:#fff;transition:border-color .3s,box-shadow .3s}
.lp .lp-faq-i:hover{border-color:#cfe0ff}
.lp .lp-faq-h{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:15px 18px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:.98rem;cursor:pointer}
.lp .lp-faq-t{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.lp .lp-faq-i.open .lp-faq-t{transform:rotate(45deg)}
.lp .lp-faq-b{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.65;padding:0 18px;transition:max-height .35s,padding .35s}
.lp .lp-faq-i.open .lp-faq-b{max-height:340px;padding:0 18px 16px}
.lp .lp-cta{margin:8px 0 60px;border-radius:24px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;padding:40px 28px;text-align:center}
.lp .lp-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.4rem,3vw,1.9rem);letter-spacing:-.02em;color:#fff;margin:0 0 8px}
.lp .lp-cta p{color:rgba(255,255,255,.84);margin:0 0 20px}
.lp .lp-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.lp .lp-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:12px 20px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.lp .lp-cta .w{background:#fff;color:#0057ff}.lp .lp-cta .g{background:#25d366;color:#04260f}.lp .lp-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.lp .lp-cta a:hover{transform:translateY(-2px)}
@media(max-width:880px){.lp .lp-layout{grid-template-columns:1fr;gap:18px}.lp .lp-toc{position:static}.lp .lp-body{padding:24px 20px}}
@media(prefers-reduced-motion:reduce){.lp *{transition:none!important}}
</style>

<div class="lp"><div class="lp-in">
<nav class="lp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Privacy Policy</span></nav>

<header class="lp-head">
<span class="lp-eyebrow"><i class="fa-solid fa-shield-halved"></i> Privacy &amp; data</span>
<h1>Privacy Policy</h1>
<p>Anaya Cab Service (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;our&rdquo;) respects your privacy. This policy explains what information we collect when you book a Dehradun taxi through our website, phone or WhatsApp, how we use it, and the choices you have. By using our services you agree to the practices described below.</p>
<div class="lp-meta"><span><i class="fa-regular fa-calendar"></i> Last updated: 25 July 2026</span><span><i class="fa-solid fa-scale-balanced"></i> Jurisdiction: Uttarakhand, India</span><span><i class="fa-regular fa-clock"></i> 4 min read</span></div>
</header>

<div class="lp-layout">
<aside class="lp-toc" aria-label="On this page">
<h2>On this page</h2>
<a href="#collect">Information we collect</a>
<a href="#use">How we use it</a>
<a href="#cookies">Cookies &amp; tracking</a>
<a href="#sharing">Sharing your data</a>
<a href="#security">Data security</a>
<a href="#rights">Your rights</a>
<a href="#children">Children&rsquo;s privacy</a>
<a href="#thirdparty">Third-party links</a>
<a href="#changes">Policy changes</a>
<a href="#contact-legal">Contact us</a>
</aside>

<article class="lp-body">
<section id="collect"><h2>1. Information we collect</h2>
<p>We collect only the information needed to provide and improve our taxi service in Dehradun and across Uttarakhand.</p>
<ul>
<li><strong>Booking details</strong> &mdash; your name, phone number, pickup and drop location, travel date, time and chosen vehicle, submitted through our booking form, call or WhatsApp.</li>
<li><strong>Trip details</strong> &mdash; route, distance, fare quoted and driver assigned, generated to fulfil your ride.</li>
<li><strong>Device &amp; usage data</strong> &mdash; browser type, IP address, pages visited and referring source, collected automatically to keep the site secure and measure performance.</li>
<li><strong>Communication records</strong> &mdash; messages, call logs and WhatsApp chats related to your enquiry or booking, retained for support and quality purposes.</li>
</ul></section>

<section id="use"><h2>2. How we use your information</h2>
<p>Your data is used strictly to deliver the service you requested and to operate our business responsibly.</p>
<ul>
<li>Confirming your booking and sharing trip details with your assigned, verified driver.</li>
<li>Contacting you about your ride, including pickup coordination and support.</li>
<li>Calculating fares, processing payments where applicable, and maintaining trip records.</li>
<li>Improving our website, fleet allocation and customer experience using aggregated, non-identifying usage data.</li>
<li>Complying with legal obligations and protecting against fraud or misuse.</li>
</ul></section>

<section id="cookies"><h2>3. Cookies &amp; tracking</h2>
<p>Our website uses essential cookies and lightweight analytics to remember your preferences, keep sessions secure and understand which pages help travellers most. We do not use cookies to build advertising profiles of individuals. You can disable non-essential cookies in your browser settings; doing so may affect some convenience features but not your ability to book a cab by phone or WhatsApp.</p></section>

<section id="sharing"><h2>4. Sharing your information</h2>
<p><strong>We do not sell your personal data.</strong> We share information only in the following limited situations:</p>
<ul>
<li>With the <strong>assigned driver</strong> so they can complete your pickup and drop.</li>
<li>With <strong>service providers</strong> who help us operate (for example WhatsApp for booking confirmations and payment processors), bound by confidentiality.</li>
<li>Where <strong>required by law</strong>, a court order, or to protect the safety of passengers, drivers or the public.</li>
</ul></section>

<section id="security"><h2>5. Data security</h2>
<p>We protect your information with industry-standard measures, including HTTPS encryption in transit, access controls and limited staff access on a need-to-know basis. While no system is 100% secure, we continuously review our practices to safeguard your data against unauthorised access, loss or misuse.</p></section>

<section id="rights"><h2>6. Your rights &amp; choices</h2>
<p>Depending on your location, you may have the right to access, correct, delete or restrict the personal data we hold, and to withdraw consent where processing is based on consent. To exercise any of these rights, contact us using the details below and we will respond within a reasonable timeframe.</p></section>

<section id="children"><h2>7. Children&rsquo;s privacy</h2>
<p>Our taxi booking service is intended for adults. We do not knowingly collect personal information from children under 13. If you believe a child has provided us with data, please contact us and we will promptly remove it.</p></section>

<section id="thirdparty"><h2>8. Third-party links</h2>
<p>Our site may link to external services such as Google Maps and our Google Business Profile. These third parties have their own privacy policies, and we encourage you to review them. We are not responsible for the privacy practices of websites we do not control.</p></section>

<section id="changes"><h2>9. Changes to this policy</h2>
<p>We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. The &ldquo;Last updated&rdquo; date at the top will always show the latest revision. Continued use of our services after changes constitutes acceptance of the updated policy.</p></section>

<section id="contact-legal"><h2>10. Contact us</h2>
<p>For any privacy-related question or request, reach our team at <a href="mailto:<?php echo BUSINESS_EMAIL; ?>"><?php echo BUSINESS_EMAIL; ?></a>, call <a href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><?php echo BUSINESS_PHONE; ?></a>, or write to us at <?php echo BUSINESS_FULL_ADDRESS; ?>.</p></section>

<div class="lp-faq" id="faq">
<h2>Privacy &mdash; quick answers</h2>
<?php foreach ($__faqs as $i => $f): ?>
<div class="lp-faq-i<?php echo $i===0?' open':''; ?>"><div class="lp-faq-h"><?php echo $f[0]; ?><span class="lp-faq-t"><i class="fa-solid fa-plus"></i></span></div><div class="lp-faq-b"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div>
<?php endforeach; ?>
</div>
</article>
</div>

<div class="lp-cta">
<h2>Questions about your data or a booking?</h2>
<p>Our Dehradun team is available 24&times;7 &mdash; call, WhatsApp or visit the contact page.</p>
<div class="row">
<a class="w" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I have a question about your privacy policy.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="/contact"><i class="fa-solid fa-envelope"></i> Contact page</a>
</div>
</div>
</div></div>
</main>
<script>
document.querySelectorAll('.lp .lp-faq-h').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>