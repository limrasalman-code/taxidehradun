﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/fleet-config.php';
if (!isset($FLEET) || !is_array($FLEET) || !$FLEET) {
$FLEET = [
'zest'=>['name'=>'Toyota Glanza','rate'=>12,'pax'=>4,'bags'=>2],
'dzire'=>['name'=>'Maruti Suzuki Dzire','rate'=>14,'pax'=>4,'bags'=>2],
'ertiga'=>['name'=>'Maruti Suzuki Ertiga','rate'=>16,'pax'=>6,'bags'=>4],
'innova'=>['name'=>'Toyota Innova','rate'=>18,'pax'=>7,'bags'=>5],
'innova-crysta'=>['name'=>'Toyota Innova Crysta','rate'=>20,'pax'=>7,'bags'=>5],
'tempo'=>['name'=>'Tempo Traveller','rate'=>22,'pax'=>17,'bags'=>10],
'urbania'=>['name'=>'Force Urbania','rate'=>25,'pax'=>13,'bags'=>12],
];
}
$page_title = 'Taxi Fleet in Dehradun | Dzire to Urbania';
$page_description = 'Anaya Cab fleet: Dzire, Ertiga, Innova, Crysta, Tempo Traveller & Urbania with verified drivers. From ₹12/km. Call +91 80776 11583.';
$page_url         = SITE_DOMAIN . "/fleet";
/* fleet_meta: category, accent, icon, filter-cat, badge, best-for, features, dedicated url */
$fleet_extra = [
'zest'         => ['Hatchback','#12b76a','fa-car','hatchback','Budget pick','Quick, fuel-efficient city rides',['Fuel-efficient','Easy city parking','Great for solo or couples'],'/sedan-taxi-in-dehradun'],
'dzire'        => ['Sedan','#0057ff','fa-car','sedan','Most popular','Airport transfers & outstation',['Smooth sedan comfort','Popular for airport runs','Reliable for outstation'],'/sedan-taxi-in-dehradun'],
'ertiga'       => ['MPV','#7c3aed','fa-car-rear','mpv','Family pick','Extra space for families',['6–7 seater','Extra luggage room','Ideal for families'],'/suv-taxi-in-dehradun'],
'innova'       => ['MPV','#f79009','fa-van-shuttle','mpv','Hill ready','Power for hill roads',['Strong hill performance','Comfortable long drives','Good luggage space'],'/innova-taxi-in-dehradun'],
'innova-crysta'=> ['Premium MPV','#0ea5e9','fa-van-shuttle','mpv','Most requested','Yatra & premium travel',['Premium comfort','Best for Char Dham','Spacious and powerful'],'/innova-taxi-in-dehradun'],
'tempo'        => ['Traveller','#0891b2','fa-bus-simple','traveller','Groups 12–17','Group tours & pilgrimages',['12–17 seater','Group tours','Family functions'],'/tempo-traveller-in-dehradun'],
'urbania'      => ['Luxury Van','#e11d48','fa-bus-simple','traveller','Luxury groups','Premium group travel',['Premium interiors','Wedding & corporate','Long-distance comfort'],'/force-urbania-rental-dehradun'],
];
$__faqs = [
['Which vehicle is best for hill routes and Char Dham Yatra?','The Toyota Innova and Innova Crysta are recommended for hill routes and the Char Dham Yatra because of their power, ground clearance and luggage space, while a Tempo Traveller or Force Urbania suits larger groups.'],
['Which cab is best for airport transfers and local rides?','A sedan like the Dzire is the most popular and economical choice for airport transfers and local rides, and a hatchback works well for quick, budget city trips.'],
['Are your vehicles sanitised and air-conditioned?','Yes, every vehicle is air-conditioned, regularly serviced and sanitised before each ride, and is driven by a verified, experienced driver.'],
['How many passengers and bags can each vehicle take?','Hatchbacks and sedans take up to 4 passengers with light luggage, the Ertiga takes up to 6 with extra bags, the Innova and Crysta take up to 7, and the Tempo Traveller and Urbania take 12 to 17 for groups.'],
['Do you provide self-drive car rental?','No, all our vehicles come with a professional verified driver. We provide chauffeur-driven taxi and car rental, not self-drive cars.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__items = []; $__pos = 1;
foreach ($FLEET as $key => $v) { $ex = $fleet_extra[$key] ?? ['Taxi','#0057ff','fa-car','sedan','','',[],'/fleet']; $__items[] = ['@type'=>'ListItem','position'=>$__pos++,'name'=>$v['name'].' — '.$ex[0],'url'=>SITE_DOMAIN.$ex[7]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'ItemList','@id'=>$page_url.'#fleet','name'=>'Anaya Cab Service Fleet in Dehradun','numberOfItems'=>count($__items),'itemListElement'=>$__items],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$featured = 'innova-crysta';
$choose = [
['City & airport','Sedan or Hatchback','Budget-friendly for 1–4 passengers','fa-taxi'],
['Family trip','Ertiga / SUV','Better luggage and seating comfort','fa-user-group'],
['Hill & long route','Innova / Crysta','Recommended for Mussoorie, Nainital, yatra','fa-mountain-sun'],
['Group & pilgrimage','Tempo Traveller / Urbania','Best for groups and family functions','fa-bus-simple'],
];
?>
<main id="main">
<style>
.fl{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--soft:#f5f8ff;--green:#16a34a;--blue:#0057ff;--radius:20px;--rsm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef1f6 0%,#fff 460px)}
.fl *{box-sizing:border-box}
.fl::before{content:"";position:absolute;top:-200px;right:-140px;width:580px;height:460px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.10),transparent 70%);pointer-events:none}
.fl .fl-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.fl .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.fl .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.fl .rv.in{opacity:1;transform:none}
.fl .fl-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.fl .fl-crumb a{color:var(--slate);text-decoration:none}.fl .fl-crumb a:hover{color:var(--blue)}.fl .fl-crumb i{font-size:.6rem;color:var(--mute)}.fl .fl-crumb .cur{color:var(--ink);font-weight:600}
.fl .fl-hero{display:grid;grid-template-columns:1.15fr 1fr;gap:34px;align-items:start;padding:24px 0 12px}
.fl .fl-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:#eaf1ff;padding:7px 13px;border-radius:999px}
.fl .fl-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.fl .fl-hero h1 em{font-style:normal;color:var(--blue)}
.fl .fl-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:54ch;margin:0 0 18px}.fl .fl-lead strong{color:var(--ink)}
.fl .fl-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}.fl .fl-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.fl .fl-trust i{color:var(--green)}
.fl .fl-herocta{display:flex;gap:12px;flex-wrap:wrap}
.fl .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rsm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.fl .btn-a{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.fl .btn-a:hover{transform:translateY(-2px);filter:brightness(1.06)}
.fl .btn-g{background:#25d366;color:#04260f}.fl .btn-g:hover{transform:translateY(-2px)}
.fl .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.fl .btn-o:hover{border-color:var(--blue);color:var(--blue)}
/* spotlight card */
.fl .spot{position:sticky;top:88px;border-radius:24px;overflow:hidden;background:radial-gradient(120% 100% at 100% 0%,color-mix(in srgb,#0ea5e9 55%,transparent),transparent 60%),linear-gradient(160deg,#0a1b2e,#123a5e);color:#fff;box-shadow:0 30px 60px -28px rgba(10,27,46,.6);padding:26px}
.fl .spot .badge{display:inline-flex;align-items:center;gap:8px;font-size:.7rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;background:rgba(255,255,255,.16);padding:6px 12px;border-radius:999px}
.fl .spot .stage{position:relative;height:150px;display:grid;place-items:center;margin:8px 0}
.fl .spot .stage img{max-height:150px;max-width:100%;object-fit:contain;animation:flfloat 4.5s ease-in-out infinite;filter:drop-shadow(0 18px 22px rgba(0,0,0,.4))}
.fl .spot .glyph{font-size:5rem;color:rgba(255,255,255,.28);animation:flfloat 4.5s ease-in-out infinite}
@keyframes flfloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-9px)}}
.fl .spot h3{font-family:'Sora','Poppins',sans-serif;font-size:1.5rem;font-weight:800;margin:0 0 4px}
.fl .spot .cat{font-size:.8rem;color:#bfe6ff;font-weight:700;margin:0 0 14px}
.fl .spot .specs{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 16px}.fl .spot .specs span{display:inline-flex;align-items:center;gap:7px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.16);border-radius:11px;padding:8px 12px;font-size:.82rem;font-weight:600}.fl .spot .specs i{color:#bfe6ff}
.fl .spot .rate{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.5rem;margin:0 0 14px}.fl .spot .rate small{font-size:.78rem;font-weight:600;color:rgba(255,255,255,.75)}
.fl .spot .cta{display:grid;gap:10px}.fl .spot .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}.fl .spot .cta .w{background:#fff;color:#123a5e}.fl .spot .cta .g{background:#25d366;color:#04260f}.fl .spot .cta a:hover{transform:translateY(-2px)}
/* filter */
.fl .fl-fbar{display:flex;flex-wrap:wrap;gap:9px;justify-content:center;margin:0 0 26px}
.fl .fl-pill{border:1px solid var(--line);background:#fff;color:var(--slate);font-weight:700;font-size:.86rem;padding:9px 18px;border-radius:999px;cursor:pointer;transition:.2s}
.fl .fl-pill:hover{border-color:var(--blue);color:var(--blue)}
.fl .fl-pill.on{background:var(--blue);color:#fff;border-color:var(--blue);box-shadow:0 8px 18px -8px rgba(0,87,255,.6)}
/* grid */
.fl .fl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.fl .fcard{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 12px 30px -16px rgba(9,32,84,.16);transition:transform .4s cubic-bezier(.2,.7,.2,1),box-shadow .4s;display:flex;flex-direction:column}
.fl .fcard.hide{display:none}
.fl .fcard:hover{transform:translateY(-7px);box-shadow:0 1px 2px rgba(11,18,32,.05),0 34px 66px -22px rgba(9,32,84,.34)}
.fl .fstage{position:relative;min-height:170px;display:grid;place-items:center;background:radial-gradient(120% 90% at 30% 0%,color-mix(in srgb,var(--ac) 22%,#fff),#fff 62%);overflow:hidden}
.fl .fstage img{width:100%;height:100%;object-fit:contain;padding:18px;animation:flfloat 4.5s ease-in-out infinite}
.fl .fglyph{font-size:3.6rem;color:color-mix(in srgb,var(--ac) 55%,#334155);animation:flfloat 4.5s ease-in-out infinite}
.fl .fbadge{position:absolute;top:12px;left:12px;z-index:2;display:inline-flex;align-items:center;gap:6px;font-size:.66rem;font-weight:800;color:#fff;background:var(--ac);padding:6px 11px;border-radius:999px;box-shadow:0 6px 14px -4px color-mix(in srgb,var(--ac) 70%,transparent)}
.fl .fbody{padding:20px 22px;display:flex;flex-direction:column;flex:1}
.fl .fbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:700;letter-spacing:-.02em;margin:0 0 2px}
.fl .fbody .fdesc{color:var(--slate);font-size:.86rem;margin:0 0 12px}
.fl .fmeta{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 12px}.fl .fmeta span{display:inline-flex;align-items:center;gap:6px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:.84rem;color:var(--ink)}.fl .fmeta i{color:var(--ac);font-size:.72rem}
.fl .ffeat{list-style:none;margin:0 0 14px;padding:0;display:flex;flex-direction:column;gap:6px}.fl .ffeat li{display:flex;gap:8px;color:var(--slate);font-size:.85rem}.fl .ffeat i{color:var(--ac);margin-top:3px}
.fl .ffoot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:14px;border-top:1px solid var(--line)}
.fl .fprice{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.35rem;color:var(--ink)}.fl .fprice small{font-weight:600;font-size:.74rem;color:var(--slate)}.fl .fprice em{display:block;font-style:normal;font-size:.6rem;color:var(--mute);font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.fl .fbook{display:inline-flex;align-items:center;gap:8px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.84rem;color:#fff;background:var(--ac);padding:11px 16px;border-radius:12px;text-decoration:none;box-shadow:0 10px 22px -8px color-mix(in srgb,var(--ac) 75%,transparent);transition:gap .3s,filter .2s}.fl .fbook:hover{gap:11px;filter:brightness(1.06)}
/* choose */
.fl .ch-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}
.fl .ch{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--rsm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}.fl .ch:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#cfe0ff}
.fl .ch .ci{flex:none;width:44px;height:44px;border-radius:12px;background:#eaf1ff;color:var(--blue);display:grid;place-items:center;font-size:1rem}
.fl .ch h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.fl .ch p{margin:0;color:var(--slate);font-size:.85rem;line-height:1.5}.fl .ch .best{color:var(--blue);font-weight:700;font-size:.8rem}
.fl .sec{padding:48px 0}.fl .soft{background:linear-gradient(180deg,#eef1f6,#f7f9fc)}
.fl .sh{text-align:center;max-width:700px;margin:0 auto 28px}.fl .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:#eaf1ff;padding:7px 13px;border-radius:999px}.fl .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.fl .sh p{color:var(--slate);margin:0}
.fl .fbox{max-width:820px;margin:0 auto}.fl .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.fl .fi:hover{border-color:#cfe0ff}.fl .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}.fl .ft{flex:none;width:26px;height:26px;border-radius:8px;background:#eaf1ff;color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}.fl .fi.open .ft{transform:rotate(45deg)}.fl .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}.fl .fi.open .fb{max-height:400px;padding:0 20px 18px}
.fl .cta2{padding:0 0 70px}.fl .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px}.fl .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}.fl .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}.fl .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.fl .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}.fl .cta2 .w{background:#fff;color:#0057ff}.fl .cta2 .g{background:#25d366;color:#04260f}.fl .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.fl .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:900px){.fl .fl-hero{grid-template-columns:1fr;gap:24px}.fl .spot{position:static}}
@media(prefers-reduced-motion:reduce){.fl *{transition:none!important;animation:none!important}.fl .rv{opacity:1!important;transform:none!important}}
</style>
<div class="fl"><div class="fl-in">
<nav class="fl-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Fleet</span></nav>
<section class="fl-hero">
<div class="rv">
<span class="fl-ey"><i class="fa-solid fa-car-side"></i> Verified drivers · from ₹12/km</span>
<h1 class="disp">Our fleet — the right ride for <em>every journey</em></h1>
<p class="fl-lead"><strong>Every vehicle is serviced, sanitised and air-conditioned, with a verified driver.</strong> From a budget hatchback for city errands to an Innova Crysta for the Char Dham and a Tempo Traveller for groups — pick the cab that fits your trip and group size.</p>
<div class="fl-trust"><span><i class="fa-solid fa-circle-check"></i> Sanitised &amp; AC</span><span><i class="fa-solid fa-circle-check"></i> Verified drivers</span><span><i class="fa-solid fa-circle-check"></i> Fixed per-km fares</span></div>
<div class="fl-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, help me choose a vehicle.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See pricing</a>
</div>
</div>
<?php $fv = $FLEET[$featured] ?? null; $fe = $fleet_extra[$featured] ?? null; if ($fv && $fe): ?>
<aside class="spot rv" style="--ac:<?php echo $fe[1]; ?>" aria-label="Featured vehicle">
<span class="badge"><i class="fa-solid fa-star"></i> Most requested</span>
<div class="stage">
<img src="/assets/images/fleet/<?php echo $featured; ?>.webp" alt="<?php echo htmlspecialchars($fv['name']); ?> taxi in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $fe[2]; ?> glyph" style="display:none"></i>
</div>
<h3 class="disp"><?php echo htmlspecialchars($fv['name']); ?></h3>
<p class="cat"><?php echo $fe[0]; ?> · <?php echo $fe[5]; ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo $fv['pax']; ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo $fv['bags']; ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
</div>
<div class="rate">₹<?php echo $fv['rate']; ?><small>/km base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book <?php echo htmlspecialchars($fv['name']); ?></a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$fv['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
<?php endif; ?>
</section>
</div>
<section class="sec"><div class="fl-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-car"></i> Full fleet</span><h2 class="disp">Choose your vehicle</h2><p>Filter by type — every cab comes with a verified driver and a fixed per-km fare.</p></div>
<div class="fl-fbar rv">
<button class="fl-pill on" data-f="all">All</button>
<button class="fl-pill" data-f="hatchback">Hatchback</button>
<button class="fl-pill" data-f="sedan">Sedan</button>
<button class="fl-pill" data-f="mpv">MPV / SUV</button>
<button class="fl-pill" data-f="traveller">Traveller</button>
</div>
<div class="fl-grid">
<?php foreach ($FLEET as $key => $v): $ex = $fleet_extra[$key] ?? ['Taxi','#0057ff','fa-car','sedan','','Comfortable ride',['Verified driver','AC vehicle','Fixed fare'],$ex[7] ?? '/fleet']; ?>
<article class="fcard rv" data-cat="<?php echo $ex[3]; ?>" style="--ac:<?php echo $ex[1]; ?>">
<div class="fstage">
<span class="fbadge"><i class="fa-solid <?php echo $ex[2]; ?>"></i> <?php echo $ex[0]; ?></span>
<img src="/assets/images/fleet/<?php echo $key; ?>.webp" alt="<?php echo htmlspecialchars($v['name']); ?> taxi in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $ex[2]; ?> fglyph" style="display:none"></i>
</div>
<div class="fbody">
<h3><?php echo htmlspecialchars($v['name']); ?></h3>
<p class="fdesc"><?php echo htmlspecialchars($ex[5]); ?></p>
<div class="fmeta">
<span><i class="fa-solid fa-user-group"></i> <?php echo $v['pax']; ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo $v['bags']; ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
</div>
<ul class="ffeat"><?php foreach ($ex[6] as $ft): ?><li><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($ft); ?></li><?php endforeach; ?></ul>
<div class="ffoot">
<div class="fprice"><em>Base fare</em>₹<?php echo $v['rate']; ?><small>/km</small></div>
<a class="fbook" href="<?php echo $ex[7]; ?>">Book <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="fl-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Not sure?</span><h2 class="disp">How to choose the right cab</h2></div>
<div class="ch-grid">
<?php foreach ($choose as $c): ?>
<div class="ch rv"><span class="ci"><i class="fa-solid <?php echo $c[3]; ?>"></i></span><div><h3><?php echo $c[0]; ?></h3><p class="best"><?php echo $c[1]; ?></p><p><?php echo $c[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec" id="faq"><div class="fl-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Fleet — FAQs</h2></div>
<div class="fbox"><?php foreach ($__faqs as $i => $f): ?><div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?></div>
</div></section>
<section class="cta2 rv"><div class="fl-in"><div class="ctain">
<h2 class="disp">Not sure which car to pick?</h2>
<p>Tell us your route, passengers and luggage — we will recommend the best vehicle.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, help me choose a vehicle.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div></main>
<script>
(function(){
var r=document.querySelectorAll('.fl .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.fl .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
var pills=document.querySelectorAll('.fl .fl-pill'),cards=document.querySelectorAll('.fl .fcard');
pills.forEach(function(p){p.addEventListener('click',function(){pills.forEach(function(x){x.classList.remove('on');});p.classList.add('on');var f=p.getAttribute('data-f');cards.forEach(function(c){c.classList.toggle('hide',!(f==='all'||c.getAttribute('data-cat')===f));});});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>