<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/route-page.php';
$V = [
 'name' => 'Dehradun to Agra Taxi', 'short' => 'Agra taxi', 'crumb' => 'Dehradun to Agra Taxi', 'from' => 'Dehradun',
 'url' => SITE_DOMAIN . '/dehradun-to-agra-taxi',
 'title' => 'Dehradun to Agra Taxi | Taj Mahal Trip Cab Fare - Anaya Cab',
 'desc' => 'Book Dehradun to Agra taxi for Taj Mahal trips. ~430 km via Yamuna Expressway, 7.5-9 hr, sedan from ₹9,000, verified drivers, day and overnight options. Call ' . BUSINESS_PHONE . '.',
 'service_type' => 'One-way and round-trip taxi service',
 'area' => ['Dehradun', 'Agra', 'Meerut', 'Delhi'],
 'offers_price' => '9000', 'offer_desc' => 'Dehradun to Agra one-way sedan taxi fare starts from ₹9,000. Toll and parking extra where applicable.',
 'ac' => '#b45309', 'ac2' => '#f59e0b', 'd1' => '#2a1602', 'd2' => '#7a3d05', 'tint' => '#fbf0db', 'char_icon' => 'fa-monument',
 'eyebrow' => 'Long highway · Taj Mahal',
 'headline' => 'Dehradun to Agra taxi, built for the Taj run',
 'lead_strong' => 'Dehradun to Agra taxi fare starts from ₹9,000 for a sedan.',
 'lead' => 'The ~430 km highway run via the Yamuna Expressway usually takes 7.5 to 9 hours — ideal for sunrise Taj Mahal visits, overnight stays and same-day returns, with a verified driver and a fare fixed before you travel.',
 'metrics' => [['fa-road','~430 km'],['fa-clock','7.5–9 hr'],['fa-indian-rupee-sign','₹9,000+ sedan'],['fa-shield-halved','Verified AC']],
 'card' => ['badge' => 'Live fare desk', 'rows' => [['Sedan / Dzire','₹9,000 – ₹12,000'],['Innova / Crysta','₹11,000 – ₹15,000'],['Tempo Traveller','On request']], 'note' => 'Toll and parking extra where applicable.'],
 'highlights' => [
   ['fa-monument','Sunrise at the Taj','Leave before dawn to beat the heat and the crowds, with the driver handling expressway tolls and Agra entry.'],
   ['fa-road','Yamuna Expressway','A fast, smooth finish after Meerut that cuts hours off the journey.'],
   ['fa-moon','Overnight option','Rest in Agra and visit the Taj and Agra Fort at a relaxed pace.'],
   ['fa-rotate','Round-trip value','Keep the same car and driver for the return — usually cheaper per km.'],
 ],
 'timeline' => [
   ['fa-circle-dot','Pickup in Dehradun','Door-to-door from your home, hotel or station at the agreed time.'],
   ['fa-road','Expressway stretch','Open highway after Meerut for a quick, comfortable run.'],
   ['fa-mug-hot','Comfort stop','A planned break on the long drive.'],
   ['fa-monument','Drop in Agra','At your hotel or the monument gate.'],
 ],
 'related' => [['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Outstation taxi','/outstation-taxi-from-dehradun']],
 'faqs' => [
   ['What is the taxi fare from Dehradun to Agra?','A one-way sedan fare from Dehradun to Agra usually starts from around ₹9,000 to ₹12,000, depending on vehicle and travel plan.'],
   ['How far is Agra from Dehradun and how long does it take?','Agra is about 430 km from Dehradun and the drive usually takes 7.5 to 9 hours via the Yamuna Expressway.'],
   ['Can I book a return or overnight trip to Agra?','Yes, one-way, round-trip and overnight taxi bookings are available so you can visit the Taj Mahal at your own pace.'],
 ],
];
$page_title = $V['title']; $page_description = $V['desc']; $page_url = $V['url'];
$page_schema = anaya_rp_schema($V);
require_once __DIR__ . '/includes/header.php';
anaya_rp_body($V);
require_once __DIR__ . '/includes/footer.php';