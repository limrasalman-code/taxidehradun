﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title       = "Dehradun to Kainchi Dham Taxi | Anaya Cab";
$page_description = "Book Dehradun to Kainchi Dham taxi service. Fares from ₹5,800 for Sedan, AC cabs, verified mountain drivers, door pickup. Call " . $phone . ".";
$page_url         = $domain . "/dehradun-to-kainchi-dham-taxi";

$__faqs = [
    ["How much is a taxi from Dehradun to Kainchi Dham?", "Taxi fare from Dehradun to Kainchi Dham starts from ₹5,800 for Sedan (Dzire) and ₹8,500 for 6-seater SUV (Ertiga), covering full one-way door-to-door drop."],
    ["How far is Kainchi Dham from Dehradun and travel duration?", "Distance is approximately 290 km taking around 7.5 to 8.5 hours via the scenic Corbett / Nainital highway."],
    ["Do you offer same-day or 2-day round-trip packages for Kainchi Dham?", "Yes. We offer customized 2-day and 3-day round-trip darshan packages with night halt in Bhowali/Nainital and return drop in Dehradun."],
    ["Can the driver pick up from Jolly Grant Airport or Railway Station?", "Yes, we provide direct pickups from Dehradun Airport, Railway Station, ISBT, or any hotel at any scheduled time."]
];

$__faq_entities = [];
foreach ($__faqs as $f) {
    $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
    [
        '@type'=>'Service',
        '@id'=>$page_url.'#service',
        'name'=>'Dehradun to Kainchi Dham Taxi Service',
        'serviceType'=>'Outstation Taxi Service',
        'description'=>'Comfortable outstation taxi from Dehradun to Kainchi Dham (Neem Karoli Baba Ashram) with experienced hill chauffeurs and transparent fixed pricing.',
        'provider'=>[
            '@type'=>'TaxiService',
            'name'=>'Anaya Cab Service',
            'telephone'=>$phone_tel,
            'url'=>$domain.'/'
        ],
        'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'5800','description'=>'One-way Sedan taxi to Kainchi Dham starting from ₹5,800.']
    ],
    ['@type'=>'BreadcrumbList','itemListElement'=>[
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>$domain.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Routes','item'=>$domain.'/outstation-taxi-from-dehradun'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Kainchi Dham Taxi','item'=>$page_url]
    ]],
    ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities]
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
.gen-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef6ff 0%,#ffffff 460px);padding-bottom:60px}
.gen-pg *{box-sizing:border-box}
.gen-in{max-width:1200px;margin:0 auto;padding:0 24px}
.gen-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:0.82rem;color:var(--slate);padding:24px 0 0}
.gen-crumb a{color:var(--slate);text-decoration:none;transition:color 0.2s}.gen-crumb a:hover{color:var(--blue)}
.gen-crumb i{font-size:0.6rem;color:#94a3b8}.gen-crumb .cur{color:var(--ink);font-weight:700}
.gen-hero{display:grid;grid-template-columns:1.24fr 0.86fr;gap:36px;align-items:start;padding:20px 0 10px}
.gen-badge{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 14px;border-radius:999px}
.gen-hero h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2rem,4.4vw,3.1rem);font-weight:800;letter-spacing:-0.035em;line-height:1.06;margin:14px 0 12px;color:#07142f}
.gen-hero h1 em{font-style:normal;color:var(--blue)}

/* Big Featured Hero Image Layout (Screenshot 2 Match) */
.gen-hero-img-wrap{position:relative;width:100%;height:320px;border-radius:22px;overflow:hidden;margin:16px 0 20px;box-shadow:0 18px 42px -16px rgba(9,32,84,0.22);background:#07142f}
.gen-hero-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease}
.gen-hero-img-wrap:hover .gen-hero-img{transform:scale(1.03)}




.gen-lead-bold{font-weight:700;color:#07142f;font-size:1.06rem;line-height:1.55;margin:0 0 10px}
.gen-lead{color:var(--slate);font-size:1rem;line-height:1.66;margin:0 0 18px;max-width:58ch}
.gen-ai-box{background:#ffffff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:14px;padding:18px 20px;margin:0 0 24px;box-shadow:0 4px 16px rgba(0,87,255,0.05)}
.gen-ai-box h3{font-size:0.88rem;font-weight:800;color:var(--blue);margin:0 0 6px;display:flex;align-items:center;gap:6px}
.gen-ai-box p{margin:0;font-size:0.92rem;line-height:1.55;color:#334155}
.gen-actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.gen-btn-p{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.gen-btn-w{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
.gen-btn-s{display:inline-flex;align-items:center;gap:8px;padding:13px 20px;border-radius:14px;background:#fff;border:1px solid var(--line);color:#07142f;font-weight:700;text-decoration:none}

/* Right Column Luxury Fare Card (Screenshot 2 Match) */
.gen-fare-card{position:sticky;top:88px;background:linear-gradient(160deg,#0a2540,#0e4a7a);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,0.5);overflow:hidden}
.gen-fare-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,0.12);padding:6px 12px;border-radius:999px}
.gen-fare-card h3{font-family:'Sora',sans-serif;font-size:1.25rem;font-weight:800;margin:14px 0 14px}
.gen-fares-list{display:grid;gap:8px;margin:14px 0 0}
.gen-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);border-radius:12px;padding:11px 14px}
.gen-fr .v{font-weight:700;font-size:0.9rem}
.gen-fr .p{font-family:'Sora',sans-serif;font-weight:800;color:#00c2ff}
.gen-fare-card .cta{display:grid;gap:10px;margin-top:16px}
.gen-fare-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform 0.2s}
.gen-fare-card .cta .w{background:#fff;color:#0a2540}
.gen-fare-card .cta .g{background:#25d366;color:#04260f}
.gen-fare-card .cta a:hover{transform:translateY(-2px)}
.gen-fare-card .note{font-size:0.76rem;color:rgba(255,255,255,0.66);text-align:center;margin:12px 0 0}

.gen-sec{padding:48px 0;border-top:1px solid var(--line)}
.gen-sec h2{font-family:'Sora',sans-serif;font-size:clamp(1.7rem,3.4vw,2.3rem);font-weight:800;color:#07142f;margin:0 0 16px;letter-spacing:-0.03em}
.gen-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:24px}
.gen-box{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 4px 16px rgba(11,18,32,0.04)}
.gen-box h4{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#07142f;margin:0 0 8px}
.gen-box p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
.gen-faq-item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 22px;margin-bottom:12px}
.gen-faq-item h4{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#07142f;margin:0 0 8px}
.gen-faq-item p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}
@media (max-width:960px){.gen-hero{grid-template-columns:1fr;gap:24px}.gen-hero-img-wrap{height:230px;border-radius:16px}.gen-fare-card{position:static}.gen-in{padding:0 16px}}
</style>

<div class="gen-pg">
    <div class="gen-in">
        <nav class="gen-crumb" aria-label="Breadcrumb">
            <a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>
            <a href="/outstation-taxi-from-dehradun">Outstation Taxi</a><i class="fa-solid fa-chevron-right"></i>
            <span class="cur">Dehradun to Kainchi Dham Taxi</span>
        </nav>

        <div class="gen-hero">
            <div>
                <span class="gen-badge"><i class="fa-solid fa-om"></i> Neem Karoli Baba Darshan · 290 km</span>
                <h1>Dehradun to <em>Kainchi Dham</em> Taxi</h1>

                <div class="gen-hero-img-wrap">
                    <img 
                        src="/assets/images/routes/dehradun-to-nainital-taxi.webp" 
                        alt="Dehradun to Kainchi Dham Taxi Service - Anaya Cab" 
                        width="680" 
                        height="360" 
                        loading="eager" 
                        decoding="async" 
                        class="gen-hero-img"
                    >
                </div>

                <p class="gen-lead-bold">Direct outstation cab from Dehradun to Kainchi Dham (Neem Karoli Baba Ashram) starting at ₹5,800.</p>
                <p class="gen-lead">Plan a sacred pilgrimage from Dehradun to Kainchi Dham (Neem Karoli Baba Ashram near Bhowali/Nainital). Anaya Cab Service offers one-way drops, same-day darshan, and multi-day packages with experienced mountain chauffeurs.</p>

                <div class="gen-ai-box">
                    <h3><i class="fa-solid fa-bolt"></i> Quick Summary</h3>
                    <p>Taxi fare from Dehradun to Kainchi Dham starts from ₹5,800 for Sedan and ₹8,500 for Ertiga. Distance is 290 km taking 7.5 to 8.5 hours via Nainital road with safe mountain drivers and customized temple stops.</p>
                </div>

                <div class="gen-actions">
                    <a class="gen-btn-p" href="/#booking"><i class="fa-solid fa-car-side"></i> Book Online</a>
                    <a class="gen-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book Kainchi Dham taxi'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                    <a class="gen-btn-s" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
                </div>
            </div>

            <!-- Right Column Luxury Fare Card (Screenshot 2 Match) -->
            <aside class="gen-fare-card" aria-label="Kainchi Dham fares">
                <span class="tag"><i class="fa-solid fa-bolt"></i> Route Fares</span>
                <h3>Dehradun → Kainchi Dham</h3>
                <div class="gen-fares-list">
                    <div class="gen-fr"><span class="v">Sedan (Dzire / Etios)</span><span class="p">₹5,800</span></div>
                    <div class="gen-fr"><span class="v">Ertiga (6-Seater SUV)</span><span class="p">₹8,500</span></div>
                    <div class="gen-fr"><span class="v">Innova Crysta (Luxury)</span><span class="p">₹11,500</span></div>
                    <div class="gen-fr"><span class="v">Tempo Traveller (17S)</span><span class="p">₹16,000</span></div>
                </div>
                <div class="cta">
                    <a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
                    <a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book Kainchi Dham taxi'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
                </div>
                <p class="note">All tolls, hill permits &amp; driver allowance included</p>
            </aside>
        </div>

        <section class="gen-sec">
            <h2>Neem Karoli Baba Ashram Pilgrimage Guide</h2>
            <div class="gen-grid">
                <div class="gen-box">
                    <h4><i class="fa-solid fa-shield-halved" style="color:var(--blue);margin-right:8px;"></i> Police Verified Drivers</h4>
                    <p>All chauffeurs are local Uttarakhand mountain veterans with extensive commercial driving experience.</p>
                </div>
                <div class="gen-box">
                    <h4><i class="fa-solid fa-receipt" style="color:#16a34a;margin-right:8px;"></i> Zero Hidden Costs</h4>
                    <p>Pay comfortably after completing your trip. Complete transparency with digital receipts.</p>
                </div>
                <div class="gen-box">
                    <h4><i class="fa-solid fa-car" style="color:#f59e0b;margin-right:8px;"></i> 100% AC &amp; Sanitized</h4>
                    <p>Modern fleet maintained in immaculate condition for smooth hill rides and expressway cruising.</p>
                </div>
            </div>
        </section>

        <section class="gen-sec">
            <h2>Frequently Asked Questions (Kainchi Dham Tour)</h2>
            <?php foreach ($__faqs as $faq): ?>
            <div class="gen-faq-item">
                <h4><?php echo htmlspecialchars($faq[0]); ?></h4>
                <p><?php echo htmlspecialchars($faq[1]); ?></p>
            </div>
            <?php endforeach; ?>
        </section>
    </div>
</div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
