<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
/* Rate Manager wiring — admin se change hote hi page update */
$__tkm = anaya_rate('tempo_per_km');
if ($__tkm <= 0) { $__tkm = 22; }
$V = [
'slug'=>'tempo-traveller-in-dehradun','name'=>'Tempo Traveller in Dehradun','short'=>'Tempo Traveller','cls'=>'Traveller · 12–17 seater',
'char'=>'Traveller · 12–17 seater','char_icon'=>'fa-bus-simple','glyph'=>'fa-bus-simple','img'=>'/assets/images/fleet/tempo.webp',
'ac'=>'#0891b2','ac2'=>'#67e8f9','d1'=>'#062830','d2'=>'#0e4f5c','tint'=>'#e0f6fa',
'headline'=>'Tempo Traveller in Dehradun — 12, 14 & 17 Seater Rental with Driver',
'lead'=>'Book a Tempo Traveller in Dehradun to move 12 to 17 people in a single vehicle — the cost-effective way to handle Char Dham Yatra groups, family functions, wedding guests, college trips and corporate outings across Uttarakhand and North India, with one driver, one fare and no splitting into multiple cabs.',
'pax'=>'12–17','bags'=>'10+','rate_range'=>'From ₹' . $__tkm . ' / km','pkg4'=>'On request','pkg8'=>'On request',
'service_type'=>'Tempo Traveller rental','offers_price'=>(string)$__tkm,'offer_desc'=>'Tempo Traveller rental in Dehradun available from approx. ₹' . $__tkm . ' per km, subject to route and availability.',
'area'=>['Dehradun','Uttarakhand','Char Dham','Mussoorie','Rishikesh','Haridwar'],
'best_for'=>[
['fa-om','Char Dham & Do Dham groups','The standard group cab for the full yatra circuit, with luggage space for a large family travelling together.'],
['fa-cake-candles','Weddings & functions','Guest movement between venues, hotels and the airport on a single schedule.'],
['fa-graduation-cap','College & corporate trips','Picnics, offsites and conferences with the whole team in one vehicle.'],
['fa-plane-departure','Airport group pickup','Coordinated Jolly Grant group pickup and drop with advance booking.'],
],
'compare_title'=>'Tempo Traveller vs Force Urbania',
'compare'=>[['Tempo Traveller','12–17 passengers','Budget group travel & pilgrimage'],['Force Urbania','~13 passengers','Premium group comfort & tours']],
'routes'=>[['Char Dham Yatra','/char-dham-yatra-taxi'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi'],['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Dehradun → Nainital','/dehradun-to-nainital-taxi']],
'use_cases'=>['12–17 passenger groups','Char Dham / Do Dham','Wedding guest transfers','College / corporate trips','Airport group pickup'],
'faqs'=>[
['How many seats are available in a Tempo Traveller?','Tempo Traveller options are usually available for 12 to 17 passengers, depending on availability and route requirement.'],
['Can I book a Tempo Traveller for Char Dham Yatra?','Yes, the Tempo Traveller is available for Char Dham Yatra, Do Dham Yatra, family tours and group pilgrimage trips from Dehradun.'],
['Is a Tempo Traveller available for airport group pickup?','Yes, group pickup and drop from Jolly Grant Airport can be arranged with advance booking.'],
['What is the difference between Tempo Traveller and Force Urbania?','A Tempo Traveller uses a truck-style ladder-frame chassis suited for budget group travel, while the Urbania uses a car-style monocoque body that gives a quieter, more planted ride for premium tours.'],
],
'title'=>'Tempo Traveller in Dehradun | 12 to 17 Seater on Rent (2026)',
'desc'=>'Rent Tempo Traveller in Dehradun (12, 14, 17 seater) for Char Dham Yatra, group tours, family weddings, airport pickup & outstation trips. Call Anaya Cab at '.$phone.'.',
];
$page_url = $domain . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = 'Tempo Traveller on rent in Dehradun: 12-17 seater from ₹22/km or ₹3,500/4hr. Group, wedding & Char Dham packages with driver.';
require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<style>
.vp-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line,#e7edf6);border-left:4px solid var(--vp-ac,#0891b2);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.vp-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--vp-ac,#0891b2);margin-bottom:8px}
.vp-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.vp-qa strong{color:#0b1220}
</style>
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-user-group"></i><b><?php echo htmlspecialchars($V['pax']); ?></b><span>passengers</span></span>
<span class="vp-m"><i class="fa-solid fa-suitcase-rolling"></i><b><?php echo htmlspecialchars($V['bags']); ?></b><span>luggage</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>AC</b><span>sanitised</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b><?php echo htmlspecialchars($V['rate_range']); ?></b><span>base fare</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?> in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="vp-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Tempo Traveller in Dehradun Rates</div>
<p itemprop="text"><strong>Tempo Traveller in Dehradun</strong> (12, 14, 17 &amp; 20 seater AC minibuses) is available starting at <strong>₹<?php echo $__tkm; ?> / km</strong>. Anaya Cab Service provides luxury push-back seating, AC, and expert hill drivers for Char Dham Yatra group packages, joint family tours, wedding transfers, corporate offsites, and Jolly Grant Airport group transfers.</p>
</div>
</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where this cab shines</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['cls']); ?> fare at a glance</h2><p>Per-km and group quotes — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Plan</th><th>What you get</th><th>Fare</th></tr></thead>
<tbody>
<tr><td>Per kilometre</td><td>Group outstation &amp; yatra, metered by route</td><td class="fare"><?php echo htmlspecialchars($V['rate_range']); ?></td></tr>
<tr><td>Full-day group tour</td><td>City sightseeing or short outstation with the group</td><td class="fare"><?php echo htmlspecialchars($V['pkg4']); ?></td></tr>
<tr><td>Multi-day / yatra</td><td>Char Dham, Do Dham, multi-day group tours</td><td class="fare"><?php echo htmlspecialchars($V['pkg8']); ?></td></tr>
</tbody>
</table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> comparison">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody>
</table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> Why Tempo Traveller for groups</span><h2 class="disp">The practical choice for large parties</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">When 12 to 17 people need to travel together, the Tempo Traveller is the most practical solution on Dehradun's roads. It keeps the entire group in a single vehicle, which means one driver, one fare, one schedule and no one getting left behind at a temple queue or a highway dhaba. For Char Dham Yatra this is not a luxury — it is a coordination necessity, because splitting a family across two cabs on a 10-day pilgrimage creates endless timing and logistics problems.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">The vehicle is built on a ladder-frame chassis with a high ground clearance, which is exactly what you want on the rough stretches near Sonprayag, Badrinath and Auli. The seats are forward-facing and there is a dedicated luggage area at the rear, so pilgrim bags, duffels and yatra kits do not end up on passengers' laps. Push-back recliners are available on some variants for the longer runs.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">The cost per head works out significantly lower than booking multiple Innova or SUV cabs, which is why it is the default choice for wedding guest transfers, college trips, corporate offsites and large family pilgrimages from Dehradun. Anaya Cab assigns a driver who has done the route before and confirms the fare, halts and drop points before the trip starts.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Single-vehicle coordination for groups of 12 to 17 — no splitting, no timing chaos.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>High ground clearance and ladder-frame strength for rough yatra stretches.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Dedicated rear luggage area keeps pilgrim bags off passengers' laps.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Cost per head works out far lower than multiple Innova or SUV cabs.</li>
</ul>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular routes</span><h2 class="disp">Routes travellers book</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This cab is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your group size, route and dates — we confirm a transparent fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>