﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$h4 = anaya_rate('local_hatch_4');  if ($h4 <= 0) { $h4 = 900; }
$h8 = anaya_rate('local_hatch_8');  if ($h8 <= 0) { $h8 = 1600; }
$s4 = anaya_rate('local_sedan_4');  if ($s4 <= 0) { $s4 = 1100; }
$s8 = anaya_rate('local_sedan_8');  if ($s8 <= 0) { $s8 = 1900; }
$m4 = anaya_rate('local_mpv_4');    if ($m4 <= 0) { $m4 = 1350; }
$m8 = anaya_rate('local_mpv_8');    if ($m8 <= 0) { $m8 = 2300; }
$p4 = anaya_rate('local_prem_4');   if ($p4 <= 0) { $p4 = 1600; }
$p8 = anaya_rate('local_prem_8');   if ($p8 <= 0) { $p8 = 2800; }

$fh4 = number_format($h4); $fh8 = number_format($h8);
$fs4 = number_format($s4); $fs8 = number_format($s8);
$fm4 = number_format($m4); $fm8 = number_format($m8);
$fp4 = number_format($p4); $fp8 = number_format($p8);

$page_title       = "Taxi Service in Ballupur Dehradun | 24x7 Cabs - Anaya Cab";
$page_description = "Book 24x7 taxi service in Ballupur Dehradun. 5-min pickup at Ballupur Chowk, GMS Road belt, airport drop from ₹800. AC cabs, fixed fares.";
$page_url         = $domain . "/taxi-service-in-ballupur";

$__faqs = [
    ["How fast can a cab reach my location in Ballupur Dehradun?", "We maintain active vehicle stands near Ballupur Chowk, GMS Road, FRI Gate, Kanwali Road junction, Kishan Nagar, General Mahadev Singh Road. Once you confirm your booking via phone call or WhatsApp, a verified cab reaches your doorstep within 5 to 12 minutes."],
    ["What is the taxi fare from Ballupur to Jolly Grant Airport?", "Sedan taxi fare from Ballupur to Jolly Grant Airport is fixed starting from ₹800 to ₹1,000. SUV Ertiga starts from ₹1,200, with all tolls, airport parking, and luggage handling included."],
    ["Can I book outstation cabs from Ballupur to Mussoorie, Delhi, or Haridwar?", "Yes, we provide 24x7 one-way drops and round-trip outstation cabs from Ballupur to Mussoorie (₹1,050), Rishikesh (₹1,150), Haridwar (₹1,350), Delhi NCR (₹3,500), and Char Dham pilgrimage routes."],
    ["Are nighttime and early-morning pickups available in Ballupur?", "Yes. Anaya Cab operates 24 hours a day, 7 days a week. Night pickups from Ballupur for early morning trains at Dehradun Railway Station or 6:00 AM flights are fully guaranteed without midnight surge."],
    ["Which vehicles can I hire in Ballupur?", "You can choose from Maruti Dzire (4-Seater AC Sedan), Maruti Ertiga (6-Seater SUV), Toyota Innova Crysta (Luxury 7-Seater MPV), and Force Tempo Traveller (12 to 17-Seater) for group trips."],
    ["Do I need to pay any advance amount for booking a cab?", "No advance payment is required for standard local city packages or airport transfers. You can pay conveniently via UPI, Cash, or Card after completing your journey."]
];

$__faq_entities = [];
foreach ($__faqs as $f) {
    $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
}

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
    [
        '@type'=>'Service',
        '@id'=>$page_url.'#service',
        'name'=>'Taxi Service in Ballupur Dehradun',
        'serviceType'=>'Local and Outstation Taxi Service',
        'description'=>'Verified 24x7 taxi service in Ballupur Dehradun by Anaya Cab Service. Fast pickups near Ballupur Chowk, GMS Road, FRI Gate, Kanwali Road junction, Kishan Nagar, General Mahadev Singh Road with upfront fixed fares and experienced mountain drivers.',
        'provider'=>[
            '@type'=>'TaxiService',
            'name'=>'Anaya Cab Service',
            'telephone'=>$phone_tel,
            'url'=>$domain.'/'
        ],
        'areaServed'=>['Ballupur', 'Dehradun', 'Uttarakhand'],
        'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>(string)$h4,'description'=>'Local taxi starting from ₹'.$fh4.' for 4hr/40km package in Ballupur.']
    ],
    ['@type'=>'BreadcrumbList','itemListElement'=>[
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>$domain.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Local Taxi','item'=>$domain.'/local-taxi-in-dehradun'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Ballupur Taxi','item'=>$page_url]
    ]],
    ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities]
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
.loc-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;--navy:#0a2540;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef6ff 0%,#ffffff 460px);padding-bottom:60px}
.loc-pg *{box-sizing:border-box}
.loc-in{max-width:1200px;margin:0 auto;padding:0 24px}
.loc-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:0.82rem;color:var(--slate);padding:24px 0 0}
.loc-crumb a{color:var(--slate);text-decoration:none;transition:color 0.2s}.loc-crumb a:hover{color:var(--blue)}
.loc-crumb i{font-size:0.6rem;color:#94a3b8}.loc-crumb .cur{color:var(--ink);font-weight:700}
.loc-hero{display:grid;grid-template-columns:1.24fr 0.86fr;gap:36px;align-items:start;padding:20px 0 10px}
.loc-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 14px;border-radius:999px}
.loc-hero h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2rem,4.4vw,3.1rem);font-weight:800;letter-spacing:-0.035em;line-height:1.06;margin:14px 0 12px;color:#07142f}
.loc-hero h1 em{font-style:normal;color:var(--blue)}

/* Big Featured Hero Image Layout (Screenshot 2 Match) */
.loc-hero-img-wrap{position:relative;width:100%;height:320px;border-radius:22px;overflow:hidden;margin:16px 0 20px;box-shadow:0 18px 42px -16px rgba(9,32,84,0.22);background:#07142f}
.loc-hero-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease}
.loc-hero-img-wrap:hover .loc-hero-img{transform:scale(1.03)}

.loc-lead-bold{font-weight:700;color:#07142f;font-size:1.06rem;line-height:1.55;margin:0 0 10px}
.loc-lead{color:var(--slate);font-size:1rem;line-height:1.66;margin:0 0 18px;max-width:58ch}
.loc-ai-box{background:#ffffff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:14px;padding:18px 20px;margin:0 0 24px;box-shadow:0 4px 16px rgba(0,87,255,0.05)}
.loc-ai-box h3{font-size:0.88rem;font-weight:800;color:var(--blue);margin:0 0 6px;display:flex;align-items:center;gap:6px}
.loc-ai-box p{margin:0;font-size:0.92rem;line-height:1.55;color:#334155}
.loc-actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.loc-btn-p{display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.loc-btn-w{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
.loc-btn-s{display:inline-flex;align-items:center;gap:8px;padding:13px 20px;border-radius:14px;background:#fff;border:1px solid var(--line);color:#07142f;font-weight:700;text-decoration:none}

/* Right Column Luxury Fare Card (Screenshot 2 Match) */
.loc-fare-card{position:sticky;top:88px;background:linear-gradient(160deg,#0a2540,#0e4a7a);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(10,37,64,0.5);overflow:hidden}
.loc-fare-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:0.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,0.12);padding:6px 12px;border-radius:999px}
.loc-fare-card h3{font-family:'Sora',sans-serif;font-size:1.25rem;font-weight:800;margin:14px 0 14px}
.loc-fares-list{display:grid;gap:8px;margin:14px 0 0}
.loc-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);border-radius:12px;padding:11px 14px}
.loc-fr .v{font-weight:700;font-size:0.9rem}
.loc-fr .p{font-family:'Sora',sans-serif;font-weight:800;color:#00c2ff}
.loc-fare-card .cta{display:grid;gap:10px;margin-top:16px}
.loc-fare-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform 0.2s}
.loc-fare-card .cta .w{background:#fff;color:#0a2540}
.loc-fare-card .cta .g{background:#25d366;color:#04260f}
.loc-fare-card .cta a:hover{transform:translateY(-2px)}
.loc-fare-card .note{font-size:0.76rem;color:rgba(255,255,255,0.66);text-align:center;margin:12px 0 0}

.loc-sec{padding:48px 0;border-top:1px solid var(--line)}
.loc-sec h2{font-family:'Sora',sans-serif;font-size:clamp(1.7rem,3.4vw,2.3rem);font-weight:800;color:#07142f;margin:0 0 16px;letter-spacing:-0.03em}
.loc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:24px}
.loc-box{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 4px 16px rgba(11,18,32,0.04)}
.loc-box h4{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#07142f;margin:0 0 8px}
.loc-box p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}

/* Rich Structured Table */
.loc-table-wrap{background:#fff;border:1px solid var(--line);border-radius:18px;overflow:hidden;box-shadow:0 4px 18px rgba(11,18,32,0.04);margin:24px 0}
.loc-table{width:100%;border-collapse:collapse;text-align:left;font-size:0.92rem}
.loc-table th{background:#f8fafc;padding:14px 18px;font-family:'Sora',sans-serif;font-weight:800;color:#07142f;border-bottom:1px solid var(--line)}
.loc-table td{padding:14px 18px;border-bottom:1px solid var(--line);color:#334155}
.loc-table tr:last-child td{border-bottom:none}
.loc-table tr:hover td{background:#f8fbff}
.loc-table .price-hl{font-weight:800;color:var(--blue)}

.loc-faq-item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 22px;margin-bottom:12px}
.loc-faq-item h4{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#07142f;margin:0 0 8px}
.loc-faq-item p{color:var(--slate);font-size:0.92rem;line-height:1.6;margin:0}

.loc-silo-links{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}
.loc-silo-links a{display:inline-flex;align-items:center;gap:6px;background:#ffffff;border:1px solid var(--line);padding:8px 16px;border-radius:12px;color:#07142f;font-weight:700;font-size:0.85rem;text-decoration:none;transition:all 0.2s}
.loc-silo-links a:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px)}
@media (max-width:960px){.loc-hero{grid-template-columns:1fr;gap:24px}.loc-hero-img-wrap{height:230px;border-radius:16px}.loc-fare-card{position:static}.loc-in{padding:0 16px}.loc-table-wrap{overflow-x:auto}}
</style>

<div class="loc-pg">
    <div class="loc-in">
        <!-- Breadcrumb -->
        <nav class="loc-crumb" aria-label="Breadcrumb">
            <a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>
            <a href="/local-taxi-in-dehradun">Local Taxi</a><i class="fa-solid fa-chevron-right"></i>
            <span class="cur">Ballupur Taxi</span>
        </nav>

        <!-- 1. HERO SECTION (Screenshot 2 Match) -->
        <div class="loc-hero">
            <div>
                <span class="loc-eyebrow"><i class="fa-solid fa-location-dot"></i> Ballupur · DEHRADUN 24×7</span>
                <h1>Taxi Service in <em>Ballupur</em> Dehradun</h1>

                <?php 
                $loc_custom_img = '/assets/images/localities/taxi-service-in-ballupur.webp';
                $loc_display_img = file_exists(__DIR__ . $loc_custom_img) ? $loc_custom_img : '/assets/images/routes/dehradun-to-mussoorie-taxi.webp';
                ?>
                <div class="loc-hero-img-wrap">
                    <img 
                        src="<?php echo $loc_display_img; ?>" 
                        alt="Taxi Service in Ballupur Dehradun - Anaya Cab" 
                        width="680" 
                        height="360" 
                        loading="eager" 
                        decoding="async" 
                        class="loc-hero-img"
                        onerror="this.src='/assets/images/routes/dehradun-to-mussoorie-taxi.webp'"
                    >
                </div>

                <p class="loc-lead-bold">Doorstep taxi pickups in Ballupur Dehradun starting from ₹<?php echo $fh4; ?> for local packages, and flat ₹800 to Jolly Grant Airport.</p>
                <p class="loc-lead">Looking for an immediate, reliable cab in Ballupur Dehradun? Anaya Cab Service provides 24×7 doorstep taxi pickups across Ballupur Chowk, GMS Road, FRI Gate, Kanwali Road junction, Kishan Nagar, General Mahadev Singh Road with verified local chauffeurs, clean air-conditioned vehicles, and 100% transparent pricing.</p>

                <div class="loc-ai-box">
                    <h3><i class="fa-solid fa-bolt"></i> Quick Direct Answer for Travellers</h3>
                    <p>Anaya Cab Service operates round-the-clock in Ballupur Dehradun. Local city packages start from ₹<?php echo $fh4; ?> (4hr/40km), flat airport drops from ₹800, and outstation trips to Mussoorie (₹1,050), Rishikesh (₹1,150), and Delhi (₹3,500) with guaranteed 5-minute pickups near Ballupur Chowk, GMS Road, FRI Gate, Kanwali Road junction, Kishan Nagar, General Mahadev Singh Road.</p>
                </div>

                <div class="loc-actions">
                    <a class="loc-btn-p" href="/#booking"><i class="fa-solid fa-car-side"></i> Book Taxi Now</a>
                    <a class="loc-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need a taxi in Ballupur'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                    <a class="loc-btn-s" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
                </div>
            </div>

            <!-- Right Column Luxury Fare Card (Screenshot 2 Match) -->
            <aside class="loc-fare-card" aria-label="Ballupur taxi fares">
                <span class="tag"><i class="fa-solid fa-bolt"></i> Popular Rates</span>
                <h3>Ballupur → Popular Drops</h3>
                <div class="loc-fares-list">
                    <div class="loc-fr"><span class="v">Jolly Grant Airport</span><span class="p">₹800</span></div>
                    <div class="loc-fr"><span class="v">Railway Station / ISBT</span><span class="p">₹400</span></div>
                    <div class="loc-fr"><span class="v">Mussoorie Mall Road</span><span class="p">₹1,050</span></div>
                    <div class="loc-fr"><span class="v">Rishikesh / Haridwar</span><span class="p">₹1,150</span></div>
                    <div class="loc-fr"><span class="v">Delhi NCR Expressway</span><span class="p">₹3,500</span></div>
                </div>
                <div class="cta">
                    <a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
                    <a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi from Ballupur'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
                </div>
                <p class="note">Sedan fare · SUV &amp; Crysta available · 24×7</p>
            </aside>
        </div>

        <!-- 2. STRUCTURED FARE CARD TABLE (100% TRANSPARENCY) -->
        <section class="loc-sec">
            <h2>Complete Cab Fare Chart from Ballupur Dehradun</h2>
            <p style="color:var(--slate);line-height:1.7;max-width:75ch;">Whether you need an economical hatchback for quick city errands or a luxury SUV for mountain outstation tours, Anaya Cab offers standardized per-kilometer and fixed package rates.</p>
            
            <div class="loc-table-wrap">
                <table class="loc-table">
                    <thead>
                        <tr>
                            <th>Vehicle Category</th>
                            <th>Seating & Luggage</th>
                            <th>Local (4hr / 40km)</th>
                            <th>Local (8hr / 80km)</th>
                            <th>Airport Drop</th>
                            <th>Outstation Rate</th>
                            <th>Best Suited For</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><b>Wagon R / Glanza</b> (Hatchback)</td>
                            <td>4 Pax · 2 Bags</td>
                            <td class="price-hl">₹<?php echo $fh4; ?></td>
                            <td class="price-hl">₹<?php echo $fh8; ?></td>
                            <td class="price-hl">₹800</td>
                            <td class="price-hl">₹12 / km</td>
                            <td>Solo commuters, quick city shopping</td>
                        </tr>
                        <tr>
                            <td><b>Maruti Dzire / Etios</b> (Sedan)</td>
                            <td>4 Pax · 3 Bags</td>
                            <td class="price-hl">₹<?php echo $fs4; ?></td>
                            <td class="price-hl">₹<?php echo $fs8; ?></td>
                            <td class="price-hl">₹900</td>
                            <td class="price-hl">₹14 / km</td>
                            <td>Family rides, airport drops, Mussoorie</td>
                        </tr>
                        <tr>
                            <td><b>Maruti Ertiga</b> (6-Seater SUV)</td>
                            <td>6 Pax · 4 Bags</td>
                            <td class="price-hl">₹<?php echo $fm4; ?></td>
                            <td class="price-hl">₹<?php echo $fm8; ?></td>
                            <td class="price-hl">₹1,300</td>
                            <td class="price-hl">₹17 / km</td>
                            <td>Family trips, extra luggage, hill tours</td>
                        </tr>
                        <tr>
                            <td><b>Toyota Innova Crysta</b> (Luxury)</td>
                            <td>7 Pax · 5 Bags</td>
                            <td class="price-hl">₹<?php echo $fp4; ?></td>
                            <td class="price-hl">₹<?php echo $fp8; ?></td>
                            <td class="price-hl">₹1,800</td>
                            <td class="price-hl">₹21 / km</td>
                            <td>VIP business, Char Dham pilgrimage</td>
                        </tr>
                        <tr>
                            <td><b>Force Tempo Traveller</b></td>
                            <td>12–17 Pax · 12 Bags</td>
                            <td class="price-hl">₹2,800</td>
                            <td class="price-hl">₹4,800</td>
                            <td class="price-hl">₹2,800</td>
                            <td class="price-hl">₹25 / km</td>
                            <td>Group tours, wedding guests, corporate</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- 3. PICKUP HOTSPOTS & TRAVEL TIME LOGISTICS -->
        <section class="loc-sec">
            <h2>Doorstep Pickup Coverage & Travel Times from Ballupur</h2>
            <p style="color:var(--slate);line-height:1.7;max-width:75ch;">Ballupur Chowk junction and GMS Road corridor connecting West Dehradun to city center and airport expressway. Our dedicated fleet provides prompt response across all residential societies, institutional campuses, and commercial hubs in Ballupur.</p>

            <div class="loc-grid">
                <div class="loc-box">
                    <h4><i class="fa-solid fa-plane-departure" style="color:var(--blue);margin-right:8px;"></i> To Jolly Grant Airport</h4>
                    <p><strong>Distance:</strong> ~30–35 km | <strong>Time:</strong> 45–55 minutes via Haridwar/Thano Bypass. 24x7 flight tracking available.</p>
                </div>
                <div class="loc-box">
                    <h4><i class="fa-solid fa-train" style="color:#16a34a;margin-right:8px;"></i> To Railway Station & ISBT</h4>
                    <p><strong>Distance:</strong> ~4–8 km | <strong>Time:</strong> 12–20 minutes. Direct drops to main platform departure gates.</p>
                </div>
                <div class="loc-box">
                    <h4><i class="fa-solid fa-mountain-sun" style="color:#f59e0b;margin-right:8px;"></i> To Mussoorie Mall Road</h4>
                    <p><strong>Distance:</strong> ~35 km | <strong>Time:</strong> 60–75 minutes via Rajpur Road / Mussoorie Diversion.</p>
                </div>
            </div>
        </section>

        <!-- 4. VALUE PILLARS -->
        <section class="loc-sec">
            <h2>Why Choose Anaya Cab Service in Ballupur?</h2>
            <div class="loc-grid">
                <div class="loc-box">
                    <h4><i class="fa-solid fa-clock-rotate-left" style="color:var(--blue);margin-right:8px;"></i> 5 to 10-Minute Rapid Pickup</h4>
                    <p>With drivers stationed continuously around Ballupur Chowk, GMS Road, FRI Gate, Kanwali Road junction, Kishan Nagar, General Mahadev Singh Road, we guarantee the lowest wait times in Dehradun.</p>
                </div>
                <div class="loc-box">
                    <h4><i class="fa-solid fa-shield-halved" style="color:#16a34a;margin-right:8px;"></i> Police Verified Hill Chauffeurs</h4>
                    <p>Every driver is background-verified with 8+ years of expertise in mountain highway driving.</p>
                </div>
                <div class="loc-box">
                    <h4><i class="fa-solid fa-receipt" style="color:#00c2ff;margin-right:8px;"></i> 100% Upfront Billing</h4>
                    <p>Pay fixed prices with zero hidden tolls, no surge multipliers, and digital GST invoicing for corporate claims.</p>
                </div>
            </div>
        </section>

        <!-- 5. FAQS WITH SCHEMA -->
        <section class="loc-sec">
            <h2>Frequently Asked Questions (Ballupur Cab Booking)</h2>
            <?php foreach ($__faqs as $faq): ?>
            <div class="loc-faq-item">
                <h4><?php echo htmlspecialchars($faq[0]); ?></h4>
                <p><?php echo htmlspecialchars($faq[1]); ?></p>
            </div>
            <?php endforeach; ?>
        </section>

        <!-- 6. INTERNAL SILO CROSS-LINKS -->
        <section class="loc-sec">
            <h2>Explore Related Dehradun Taxi Services & Nearby Localities</h2>
            <div class="loc-silo-links">
                <a href="/taxi-service-in-gms-road-dehradun"><i class="fa-solid fa-location-dot"></i> Taxi in GMS Road</a>
                <a href="/taxi-service-in-kaulagarh-dehradun"><i class="fa-solid fa-location-dot"></i> Taxi in Kaulagarh</a>
                <a href="/taxi-service-in-vasant-vihar-dehradun"><i class="fa-solid fa-location-dot"></i> Taxi in Vasant Vihar</a>
                <a href="/taxi-service-in-prem-nagar"><i class="fa-solid fa-location-dot"></i> Taxi in Prem Nagar</a>
                <a href="/pricing"><i class="fa-solid fa-indian-rupee-sign"></i> All Dehradun Taxi Rates</a>
                <a href="/dehradun-airport-taxi-service"><i class="fa-solid fa-plane"></i> Airport Taxi Service</a>
                <a href="/fleet"><i class="fa-solid fa-car"></i> View Vehicle Fleet</a>
                <a href="/reviews"><i class="fa-solid fa-star"></i> Customer Reviews</a>
            </div>
        </section>
    </div>
</div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
