<?php
/**
 * SCHEMA DOCTOR v1 - Anaya Cab Service (SCAN + VALIDATE)
 * File: schema-doctor.php (ROOT)
 * URL: ?key=schema2026 | &view=/slug (raw JSON-LD dekho) | &kill=1
 * Kaam: key pages ka JSON-LD extract karo, schema.org rules se validate karo,
 *       exact issues flag karo (fix agla round mein).
 */
set_time_limit(600);
$KEY = 'schema2026';
if (!isset($_REQUEST['key']) || $_REQUEST['key'] !== $KEY) { http_response_code(403); die('Access denied.'); }
if (isset($_REQUEST['kill'])) { @unlink(__FILE__); die('schema-doctor.php deleted ✅'); }

$SITE = 'https://www.taxidehradun.com';
$SAMPLES = ['/', '/services', '/pricing', '/fleet', '/reviews', '/faq', '/contact', '/about',
    '/char-dham-yatra-taxi', '/dehradun-airport-taxi-service', '/dehradun-to-mussoorie-taxi',
    '/dehradun-to-kedarnath-taxi', '/dehradun-to-delhi-taxi', '/local-taxi-in-dehradun',
    '/dehradun-local-sightseeing-taxi', '/dehradun-to-jim-corbett-taxi', '/blog/',
    '/blog/best-time-to-visit-mussoorie', '/blog/char-dham-yatra-planning-guide'];

$WHITELIST = ['WebSite','Organization','LocalBusiness','TaxiService','Service','Offer','OfferCatalog',
    'PriceSpecification','FAQPage','Question','Answer','BreadcrumbList','ListItem','Place','GeoCoordinates',
    'TouristAttraction','Trip','Person','PostalAddress','OpeningHoursSpecification','AggregateRating',
    'Review','ContactPoint','WebPage','ItemList','Article','BlogPosting','ImageObject','MonetaryAmount',
    'AutoDealer','Brand','Product','HowTo','HowToStep','Speakable','CollectionPage'];

function fetch_page($url) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 20, CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'AnayaSchemaDoctor/1.0']);
    $h = curl_exec($ch); curl_close($ch);
    return $h ?: '';
}

function extract_jsonld($html) {
    $blocks = [];
    if (preg_match_all('#<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
        foreach ($m[1] as $raw) {
            $j = json_decode(trim($raw), true);
            if ($j === null) $j = json_decode(html_entity_decode(trim($raw), ENT_QUOTES, 'UTF-8'), true);
            if ($j !== null) $blocks[] = $j;
        }
    }
    return $blocks;
}

function schema_walk($node, $path, &$issues, &$types) {
    if (is_array($node)) {
        if (isset($node['@type'])) {
            $t = $node['@type'];
            $tlist = is_array($t) ? $t : [$t];
            foreach ($tlist as $tt) {
                $types[$tt] = ($types[$tt] ?? 0) + 1;
                if (!in_array($tt, $GLOBALS['WHITELIST'], true)) $issues[] = "UNKNOWN TYPE: `$tt` at $path";
            }
            $main = $tlist[0];
            // offers must be Offer, not PriceSpecification
            if (in_array($main, ['Service','TaxiService','Product']) && isset($node['offers'])) {
                $off = $node['offers'];
                $offs = (is_array($off) && isset($off[0])) ? $off : [$off];
                foreach ($offs as $o) {
                    if (is_array($o) && isset($o['@type']) && $o['@type'] === 'PriceSpecification') {
                        $issues[] = "offers=PriceSpecification at $path (sahi: Offer → priceSpecification ke andar PriceSpecification)";
                    }
                }
            }
            // FAQPage rules
            if ($main === 'FAQPage' && isset($node['mainEntity'])) {
                $qs = is_array($node['mainEntity']) ? $node['mainEntity'] : [$node['mainEntity']];
                foreach ($qs as $i => $q) {
                    if (!is_array($q)) continue;
                    if (empty($q['text'])) $issues[] = "FAQ Q#$i missing text";
                    if (empty($q['acceptedAnswer'])) $issues[] = "FAQ Q#$i missing acceptedAnswer";
                    else {
                        $a = $q['acceptedAnswer'];
                        if (is_array($a)) {
                            $at = is_array($a['@type'] ?? '') ? $a['@type'] : [$a['@type'] ?? ''];
                            if (!in_array('Answer', $at, true)) $issues[] = "FAQ Q#$i acceptedAnswer @type != Answer";
                            if (empty($a['text'])) $issues[] = "FAQ Q#$i answer missing text";
                        }
                    }
                }
            }
            // AggregateRating rules
            if ($main === 'AggregateRating') {
                if (!isset($node['ratingValue'])) $issues[] = "AggregateRating missing ratingValue at $path";
                if (!isset($node['reviewCount']) && !isset($node['bestRating'])) $issues[] = "AggregateRating missing reviewCount/bestRating at $path";
            }
            // BreadcrumbList rules
            if ($main === 'BreadcrumbList' && isset($node['itemListElement'])) {
                foreach ((array)$node['itemListElement'] as $i => $li) {
                    if (is_array($li) && (!isset($li['position']) || empty($li['name']))) $issues[] = "Breadcrumb #$i missing position/name";
                }
            }
        }
        foreach ($node as $k => $v) schema_walk($v, $path . '/' . $k, $issues, $types);
    }
}

$rows = [];
foreach ($SAMPLES as $s) {
    $html = fetch_page($SITE . $s);
    $blocks = extract_jsonld($html);
    $issues = []; $types = [];
    foreach ($blocks as $b) schema_walk($b, $s, $issues, $types);
    $rows[] = ['page' => $s, 'blocks' => count($blocks), 'types' => array_keys($types), 'issues' => $issues];
}
$total = array_sum(array_map(fn($r) => count($r['issues']), $rows));
$view = isset($_GET['view']) ? $_GET['view'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Schema Doctor - Anaya Cab Service</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Plus Jakarta Sans',sans-serif;background:#0A1633;color:#F5F8FF;padding:20px}
.wrap{max-width:1050px;margin:0 auto}
h1{font-family:'Sora',sans-serif;font-size:1.8rem;background:linear-gradient(135deg,#0057FF,#00C2FF);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin:20px 0}
.card{background:rgba(255,255,255,.05);border:1px solid #E3EAF8;border-radius:12px;padding:25px;margin-bottom:20px}
.stat{display:inline-block;background:rgba(0,87,255,.12);border-radius:8px;padding:10px 18px;margin:6px 10px 6px 0;font-weight:700}
table{width:100%;border-collapse:collapse;font-size:.85rem;margin-top:10px}
th,td{padding:9px;border-bottom:1px solid rgba(227,234,248,.12);text-align:left;vertical-align:top}
th{background:rgba(0,87,255,.12)}
.r{color:#EF4444}.g{color:#10B981}.y{color:#F59E0B}
pre{background:rgba(0,0,0,.4);padding:14px;border-radius:8px;overflow:auto;font-size:.78rem;max-height:420px}
.btn{display:inline-block;padding:12px 24px;background:linear-gradient(135deg,#EF4444,#F97316);border:none;color:#fff;font-weight:700;border-radius:8px;text-decoration:none;margin-top:14px}
a{color:#00C2FF}
</style>
</head>
<body>
<div class="wrap">
<h1>🩺 Schema Doctor v1</h1>
<div class="card">
    <span class="stat r">Total Issues: <?= $total ?></span>
    <span class="stat">Pages Scanned: <?= count($rows) ?></span>
    <table><tr><th>Page</th><th>Blocks</th><th>Types</th><th>Issues</th><th>Raw</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td><?= htmlspecialchars($r['page']) ?></td>
        <td><?= $r['blocks'] ?></td>
        <td><?= htmlspecialchars(implode(', ', $r['types'])) ?></td>
        <td class="<?= count($r['issues']) ? 'r' : 'g' ?>"><?= count($r['issues']) ? htmlspecialchars(implode(' | ', $r['issues'])) : '✅ clean' ?></td>
        <td><a href="?key=<?= htmlspecialchars($KEY) ?>&view=<?= urlencode($r['page']) ?>">view</a></td>
    </tr>
    <?php endforeach; ?>
    </table>
    <a class="btn" href="?key=<?= htmlspecialchars($KEY) ?>&kill=1" onclick="return confirm('Delete schema-doctor?')">🗑️ Self-Delete</a>
</div>
<?php if ($view): $vh = fetch_page($SITE . $view); $vb = extract_jsonld($vh); ?>
<div class="card">
    <h3>Raw JSON-LD: <?= htmlspecialchars($view) ?></h3>
    <?php foreach ($vb as $i => $b): ?><pre><?= htmlspecialchars(json_encode($b, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) ?></pre><?php endforeach; ?>
</div>
<?php endif; ?>
</div>
</body>
</html>