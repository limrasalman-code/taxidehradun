<?php
/**
* Anaya Cab Service — SAFE Auto-Fix Script (v2)
* No exec(), no complex regex. Just simple string replacements.
* 
* USAGE:
* 1. Upload to root folder (same level as index.php)
* 2. Open in browser: https://www.taxidehradun.com/safe-fix.php?key=anaya2026
* 3. Check results, then DELETE this file immediately.
*/

// Security
$SECRET = 'anaya2026';
if (!isset($_GET['key']) || $_GET['key'] !== $SECRET) {
    http_response_code(403);
    die('<h1 style="font-family:sans-serif;color:#dc2626;">Access Denied</h1><p>Use ?key=' . $SECRET . '</p>');
}

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Anaya Safe Fix</title>
<style>
    body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; background: #0f172a; color: #e2e8f0; padding: 40px 20px; line-height: 1.6; }
    .container { max-width: 800px; margin: 0 auto; }
    h1 { color: #fff; margin-bottom: 10px; }
    .subtitle { color: #94a3b8; margin-bottom: 30px; }
    .log { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 20px; font-family: monospace; font-size: 0.9rem; }
    .ok { color: #4ade80; }
    .warn { color: #fbbf24; }
    .err { color: #f87171; }
    .info { color: #60a5fa; }
    .warning-box { background: #7f1d1d; border: 1px solid #991b1b; border-radius: 12px; padding: 16px; margin-bottom: 24px; color: #fecaca; }
    .btn { display: inline-block; background: #16a34a; color: #fff; padding: 12px 24px; border-radius: 10px; text-decoration: none; font-weight: 700; margin-top: 20px; }
</style>
</head>
<body>
<div class="container">
    <h1>🔧 Anaya Safe Fix</h1>
    <p class="subtitle">Simple text replacements. No exec(). No risk.</p>
    
    <div class="warning-box">
        <strong>️ IMPORTANT:</strong> After this script runs successfully, DELETE <code>safe-fix.php</code> from your server immediately for security.
    </div>

    <div class="log">
<?php
$root = __DIR__;
$fixes_applied = 0;
$fixes_skipped = 0;

function safe_replace($file_path, $search, $replace, $label) {
    global $fixes_applied, $fixes_skipped;
    
    if (!file_exists($file_path)) {
        echo "<div class='err'>❌ File not found: $file_path</div>";
        $fixes_skipped++;
        return;
    }
    
    $content = file_get_contents($file_path);
    if ($content === false) {
        echo "<div class='err'>❌ Cannot read: $file_path</div>";
        $fixes_skipped++;
        return;
    }
    
    if (strpos($content, $search) === false) {
        echo "<div class='warn'>⚠️ Already fixed or pattern not found in: $label</div>";
        $fixes_skipped++;
        return;
    }
    
    // Create backup
    $backup_path = $file_path . '.bak-' . date('Ymd-His');
    copy($file_path, $backup_path);
    
    // Replace
    $new_content = str_replace($search, $replace, $content);
    
    if (file_put_contents($file_path, $new_content) !== false) {
        echo "<div class='ok'>✅ Fixed: $label (Backup: " . basename($backup_path) . ")</div>";
        $fixes_applied++;
    } else {
        echo "<div class='err'>❌ Failed to write: $file_path</div>";
        $fixes_skipped++;
    }
}

echo "<div class='info'>🚀 Starting fixes...</div><br>";

// FIX 1: HEADING_SKIP in route-render-v2.php (Change h3 to div in card)
safe_replace(
    $root . '/includes/route-render-v2.php',
    "<h3>' . (\$T_from ? (\$T_from . ' to ' . \$T_to) : \$T_to) . '</h3>'",
    "<div class='rv2-card-title' style='font-family:Sora,Poppins,sans-serif;font-size:1.2rem;font-weight:800;margin:0 0 12px;color:#fff;'>' . (\$T_from ? (\$T_from . ' to ' . \$T_to) : \$T_to) . '</div>'",
    "route-render-v2.php (HEADING_SKIP)"
);

// FIX 2: SCHEMA_DUPLICATE_ID in route-schema.php (Add static guard)
safe_replace(
    $root . '/includes/route-schema.php',
    "function anaya_route_service_schema(string \$slug): string {\n\$allow",
    "function anaya_route_service_schema(string \$slug): string {\nstatic \$emitted = [];\nif (isset(\$emitted[\$slug])) { return ''; }\n\$emitted[\$slug] = true;\n\n\$allow",
    "route-schema.php (SCHEMA_DUPLICATE_ID)"
);

// FIX 3: HEADING_SKIP in fleet pages (Change h3.disp to div.disp)
$fleet_files = [
    'suv-taxi-in-dehradun.php',
    'force-urbania-rental-dehradun.php',
    'innova-taxi-in-dehradun.php',
    'sedan-taxi-in-dehradun.php',
    'tempo-traveller-in-dehradun.php',
];

foreach ($fleet_files as $fleet_file) {
    safe_replace(
        $root . '/' . $fleet_file,
        '<h3 class="disp"><?php echo htmlspecialchars($V[\'cls\']); ?></h3>',
        '<div class="disp" style="font-family:\'Sora\',\'Poppins\',sans-serif;font-size:1.2rem;font-weight:800;margin:0 0 12px;"><?php echo htmlspecialchars($V[\'cls\']); ?></div>',
        "$fleet_file (HEADING_SKIP)"
    );
}

// FIX 4: INTERNAL_REDIRECT_LINK in services.php (gurugram -> gurgaon)
safe_replace(
    $root . '/services.php',
    'dehradun-to-gurugram-taxi',
    'dehradun-to-gurgaon-taxi',
    "services.php (INTERNAL_REDIRECT)"
);

echo "<br><div class='info'>════════════════════════════════════</div>";
echo "<div class='ok'><strong>✅ Fixes applied: $fixes_applied</strong></div>";
echo "<div class='warn'><strong>⚠️ Skipped/Already fixed: $fixes_skipped</strong></div>";
echo "<div class='info'>════════════════════════════════════</div>";
echo "<br><div class='ok'>🗑️ NOW DELETE THIS FILE (safe-fix.php) FROM YOUR SERVER!</div>";
?>
    </div>
    
    <a href="/" class="btn">Go to Homepage</a>
</div>
</body>
</html>