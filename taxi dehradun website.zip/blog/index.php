<?php
require_once __DIR__ . '/../includes/config.php';
if (!isset($pdo) && function_exists('db')) $pdo = db();
$domain   = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone    = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel= defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$page_title = "Dehradun Taxi Blog & Travel Guides 2026 - Anaya Cab";
$page_description = "Expert Dehradun taxi guides: airport transfers, Mussoorie routes, Char Dham Yatra planning, local sightseeing and outstation fares. Updated 2026. Call " . $phone . ".";
/* P1 SEO FIX: Trailing slash mandatory for /blog/ canonical to avoid split signal */
$page_url         = $domain . '/blog/';

/* ---- DB-only post router (fallback for /blog/{slug} without physical file) ---- */
$__slug_req = '';
if (!empty($_GET['slug'])) { $__slug_req = preg_replace('/[^a-z0-9-]/', '', strtolower((string)$_GET['slug'])); }
if ($__slug_req && !is_file(__DIR__ . '/' . $__slug_req . '.php') && is_file(__DIR__ . '/post-view.php')) { require __DIR__ . '/post-view.php'; exit; }

function bl_date_iso(string $d): string { $t = strtotime($d); return $t ? date('Y-m-01', $t) : ''; }
require_once __DIR__ . '/../includes/header.php';

$posts = [];
if ($pdo) {
  try {
    $dyn = $pdo->query("SELECT * FROM blogs WHERE status='published' ORDER BY id DESC")->fetchAll();
    foreach ($dyn as $p) {
      $posts[] = ['slug'=>$p['slug'],'title'=>$p['title'],
        'excerpt'=>$p['excerpt'] ?: ($p['meta_description'] ?: ''),
        'content'=>$p['content'] ?? '',
        'image'=>$p['featured_image'] ?: ('/assets/images/blog/'.$p['slug'].'.webp'),
        'date'=>!empty($p['updated_at']) ? date('F Y', strtotime($p['updated_at'])) : date('F Y'),
        'category'=>$p['category'] ?: 'Travel Guide'];
    }
  } catch (Throwable $e) { $posts = []; }
}
if (empty($posts)) {
  $posts = [
  ['slug'=>'best-time-to-visit-mussoorie','title'=>'Best Time to Visit Mussoorie: Season-by-Season Guide','excerpt'=>'When to go for clear views, cool weather, or snow — month-by-month tips.','content'=>'Detailed guide covering all seasons in Mussoorie including snowfall and monsoon.','image'=>'/assets/images/blog/best-time-to-visit-mussoorie.webp','date'=>'June 2026','category'=>'Travel Guide','read_time'=>5],
  ['slug'=>'char-dham-yatra-planning-guide','title'=>'Char Dham Yatra Planning Guide: Routes, Timing & Tips','excerpt'=>'Everything first-time pilgrims need before starting the Char Dham Yatra from Dehradun.','content'=>'Complete 10-day itinerary and packing list for Char Dham.','image'=>'/assets/images/blog/char-dham-yatra-planning-guide.webp','date'=>'June 2026','category'=>'Yatra Guide','read_time'=>8],
  ['slug'=>'dehradun-airport-taxi-guide','title'=>'Jolly Grant Airport Taxi Guide: What to Expect','excerpt'=>'How to book a reliable airport taxi and what fares to expect.','content'=>'Flight tracking, meet and greet, and fare table for Jolly Grant.','image'=>'/assets/images/blog/dehradun-airport-taxi-guide.webp','date'=>'June 2026','category'=>'Airport Guide','read_time'=>4],
  ['slug'=>'dehradun-to-mussoorie-distance-taxi','title'=>'Dehradun to Mussoorie Distance by Taxi','excerpt'=>'Distance, travel time, hill-road notes and taxi booking tips.','content'=>'35 km route breakdown via Rajpur and Kempty.','image'=>'/assets/images/blog/dehradun-to-mussoorie-distance-taxi.webp','date'=>'July 2026','category'=>'Route Guide','read_time'=>6],
  ['slug'=>'dehradun-to-haridwar-distance-taxi','title'=>'Dehradun to Haridwar Distance by Taxi','excerpt'=>'Distance, time, route and fare guidance for Haridwar trips.','content'=>'55 km highway drive guide and Ganga Aarti timing tips.','image'=>'/assets/images/blog/dehradun-to-haridwar-distance-taxi.webp','date'=>'July 2026','category'=>'Route Guide','read_time'=>4],
  ['slug'=>'dehradun-to-rishikesh-distance-taxi','title'=>'Dehradun to Rishikesh Distance by Taxi','excerpt'=>'Taxi distance, travel time and pickup options for Rishikesh.','content'=>'Tapovan and Ram Jhula drop details for 45 km trip.','image'=>'/assets/images/blog/dehradun-to-rishikesh-distance-taxi.webp','date'=>'July 2026','category'=>'Route Guide','read_time'=>5],
  ['slug'=>'dehradun-to-delhi-taxi-time','title'=>'Dehradun to Delhi Taxi Time: What to Expect','excerpt'=>'Expressway route, traffic buffers and airport drop planning.','content'=>'Delhi-Dehradun Expressway toll and time breakdown.','image'=>'/assets/images/blog/dehradun-to-delhi-taxi-time.webp','date'=>'July 2026','category'=>'Route Guide','read_time'=>7],
  ['slug'=>'one-day-trip-from-dehradun-by-taxi','title'=>'One Day Trip from Dehradun by Taxi','excerpt'=>'Best one-day taxi trip ideas: Mussoorie, Rishikesh, Haridwar, Dhanaulti.','content'=>'6 curated one-day itineraries for families and couples.','image'=>'/assets/images/blog/one-day-trip-from-dehradun-by-taxi.webp','date'=>'July 2026','category'=>'Travel Guide','read_time'=>9],
  ];
}
$seen = []; $ordered = [];
foreach ($posts as $p) { 
    if (empty($p['slug']) || isset($seen[$p['slug']])) continue; 
    $seen[$p['slug']] = true; 
    // Calculate Reading Time dynamically if not hardcoded
    if (!isset($p['read_time'])) {
        $words = str_word_count(strip_tags(($p['content'] ?? '') . ' ' . ($p['excerpt'] ?? '')));
        $p['read_time'] = max(3, ceil($words / 200));
    }
    $ordered[] = $p; 
}
$posts = $ordered;
$cat_counts = [];
foreach ($posts as $p) { $c = $p['category'] ?: 'Travel Guide'; $cat_counts[$c] = ($cat_counts[$c] ?? 0) + 1; }

$__blog_items = [];
foreach ($posts as $__i => $__p) {
  $__bp = ['@type'=>'BlogPosting','@id'=>$domain.'/blog/'.$__p['slug'].'#post','headline'=>$__p['title'],'description'=>$__p['excerpt'],'image'=>$domain.$__p['image'],'url'=>$domain.'/blog/'.$__p['slug'],'author'=>['@type'=>'Organization','name'=>'Anaya Cab Service'],'publisher'=>['@id'=>$domain.'/#taxi-service'],'mainEntityOfPage'=>$domain.'/blog/'.$__p['slug']];
  $__iso = bl_date_iso($__p['date']);
  if ($__iso) { $__bp['datePublished'] = $__iso; $__bp['dateModified'] = $__iso; }
  $__blog_items[] = ['@type'=>'ListItem','position'=>$__i+1,'item'=>$__bp];
}
$__faqs = [
 ['What topics does the Anaya Cab blog cover?','Our blog covers Dehradun taxi travel guides including Jolly Grant Airport transfers, outstation routes (Mussoorie, Haridwar, Rishikesh, Delhi, Nainital), Char Dham Yatra planning, local sightseeing itineraries, and vehicle selection tips.'],
 ['How often are the blog guides updated?','We update our travel guides monthly with current 2026 taxi fares, route conditions, and seasonal travel tips based on real trips completed by our drivers.'],
 ['Can I book a taxi directly from a blog guide?','Yes — every guide links to our booking form and WhatsApp. Just pick the route mentioned in the guide and book with the exact fare we quote.'],
 ['Are the taxi fares in blog posts accurate for 2026?','All fares mentioned are updated for 2026 and match our live pricing. Local rides start at ₹12/km, hourly packages from ₹900, and one-way outstation fares are fixed before booking.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

/* P1 SEO FIX: Schema URLs updated to /blog/ to match canonical */
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
 ['@type'=>'Blog','@id'=>$domain.'/blog/#blog','name'=>'Anaya Cab Service Travel Blog','description'=>'Expert Dehradun taxi travel guides covering airport transfers, outstation routes, Char Dham Yatra planning, and local sightseeing.','url'=>$domain.'/blog/','publisher'=>['@id'=>$domain.'/#taxi-service'],'inLanguage'=>'en-IN'],
 ['@type'=>'ItemList','@id'=>$domain.'/blog/#posts','name'=>'Dehradun Taxi Travel Guides','numberOfItems'=>count($__blog_items),'itemListElement'=>$__blog_items],
 ['@type'=>'FAQPage','@id'=>$domain.'/blog/#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$featured = $posts[0] ?? null;
$rest = array_slice($posts, 1);

/* ---- Internal Linking Matrix (hub -> service + route clusters) ---- */
$__matrix_services = [
['/local-taxi-in-dehradun','fa-city','Local Taxi Dehradun','Hourly 4hr/8hr city rides'],
['/dehradun-airport-taxi-service','fa-plane-departure','Airport Transfer','Jolly Grant 24×7 pickup'],
['/outstation-taxi-from-dehradun','fa-road','Outstation Taxi','One-way & round trips'],
['/char-dham-yatra-taxi','fa-om','Char Dham Yatra','10–12 day circuit'],
['/dehradun-local-sightseeing-taxi','fa-camera','Local Sightseeing','Themed day circuits'],
['/tempo-traveller-in-dehradun','fa-bus-simple','Tempo Traveller','12–17 seater groups'],
];
/* P2 FIX: Fare drift aligned with live route pages (Haridwar 1400, Nainital 5200) */
$__matrix_routes = [
['/dehradun-to-delhi-taxi','Dehradun → Delhi','₹3,500'],
['/dehradun-to-mussoorie-taxi','Dehradun → Mussoorie','₹1,050'],
['/dehradun-to-haridwar-taxi','Dehradun → Haridwar','₹1,400'],
['/dehradun-to-rishikesh-taxi','Dehradun → Rishikesh','₹1,150'],
['/dehradun-to-nainital-taxi','Dehradun → Nainital','₹5,200'],
['/dehradun-to-kedarnath-taxi','Dehradun → Kedarnath','Yatra'],
['/dehradun-to-jim-corbett-taxi','Dehradun → Jim Corbett','₹3,500'],
['/dehradun-to-chandigarh-taxi','Dehradun → Chandigarh','₹4,000'],
];
?>
<style>
.bl{--ac:#0057ff;--ac2:#39b6ff;--ink:#0a1633;--slate:#5b6577;--mute:#94a3b8;--line:#e6ebf3;--soft:#f6f9ff;--radius:22px;--rsm:16px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#fff 520px)}
.bl *{box-sizing:border-box}
.bl-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.bl .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.bl .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.bl .rv.in{opacity:1;transform:none}
/* ambient */
.bl::before{content:"";position:absolute;top:-200px;left:-140px;width:620px;height:480px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.12),transparent 70%);pointer-events:none;z-index:0}
.bl-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0;position:relative;z-index:1}.bl-crumb a{color:var(--slate);text-decoration:none}.bl-crumb a:hover{color:var(--ac)}.bl-crumb i{font-size:.6rem;color:var(--mute)}.bl-crumb .cur{color:var(--ink);font-weight:600}
.bl-hero{padding:24px 0 6px;max-width:820px;position:relative;z-index:1}
.bl-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.bl-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 12px}.bl-hero h1 em{font-style:normal;color:var(--ac)}
.bl-hero p{color:var(--slate);font-size:1.05rem;line-height:1.66;margin:0}
.bl-count{display:inline-flex;align-items:center;gap:8px;margin-top:14px;font-size:.84rem;font-weight:700;color:var(--ink);background:#fff;border:1px solid var(--line);border-radius:999px;padding:8px 15px;box-shadow:0 6px 18px -8px rgba(0,87,255,.2)}.bl-count i{color:var(--ac)}
/* Quick Answer */
.bl-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--ac);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(0,87,255,.25)}
.bl-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin-bottom:8px}
.bl-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.bl-qa strong{color:var(--ink)}
/* Featured post (full-size hero) */
.bl-feat{display:block;position:relative;border-radius:26px;overflow:hidden;margin:28px 0 10px;text-decoration:none;color:#fff;min-height:420px;box-shadow:0 34px 70px -22px rgba(0,40,120,.45);transition:transform .5s,box-shadow .5s}
.bl-feat:hover{transform:translateY(-5px);box-shadow:0 44px 90px -28px rgba(0,40,120,.6)}
.bl-feat.hide{display:none}
.bl-fmedia{position:absolute;inset:0;overflow:hidden;background:linear-gradient(135deg,#03102e,#0057ff)}
.bl-fmedia img{width:100%;height:100%;object-fit:cover;transition:transform .8s ease;opacity:.55}
.bl-feat:hover .bl-fmedia img{transform:scale(1.06);opacity:.65}
.bl-fmedia::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(3,16,46,.1) 0%,rgba(3,16,46,.4) 50%,rgba(3,16,46,.92) 100%)}
.bl-glyph{position:absolute;inset:0;display:grid;place-items:center;font-size:5rem;color:rgba(255,255,255,.12);z-index:0}
.bl-badge{position:absolute;top:18px;left:18px;z-index:2;display:inline-flex;align-items:center;gap:6px;font-size:.68rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:#fff;background:var(--ac);padding:7px 13px;border-radius:999px;box-shadow:0 8px 18px -6px rgba(0,87,255,.6)}
.bl-flag{position:absolute;top:18px;right:18px;z-index:2;display:inline-flex;align-items:center;gap:6px;font-size:.66rem;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--ac);background:#fff;padding:7px 13px;border-radius:999px}
.bl-fbody{position:absolute;inset:auto 0 0 0;padding:32px;z-index:1}
.bl-fcat{font-size:.74rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--ac2);margin-bottom:8px;display:inline-block}
.bl-fbody h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.6rem,3.4vw,2.4rem);font-weight:800;letter-spacing:-.03em;line-height:1.1;margin:0 0 10px;color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.3)}
.bl-fbody p{color:rgba(255,255,255,.88);font-size:1.02rem;line-height:1.58;margin:0 0 14px;max-width:60ch}
.bl-fmeta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:rgba(255,255,255,.78);font-size:.82rem;font-weight:600;margin-bottom:16px}
.bl-fmeta i{color:var(--ac2)}
.bl-read{display:inline-flex;align-items:center;gap:8px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;color:#fff;background:var(--ac);align-self:flex-start;padding:12px 20px;border-radius:13px;box-shadow:0 12px 24px -8px rgba(0,87,255,.55);transition:transform .3s,filter .2s}
.bl-read:hover{transform:translateX(4px);filter:brightness(1.1)}
.bl-read i{transition:transform .3s}.bl-feat:hover .bl-read i{transform:translateX(4px)}

/* Search Bar */
.bl-search-wrap{max-width:480px;margin:24px auto 10px;position:relative}
.bl-search-wrap i{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--mute);font-size:.95rem;pointer-events:none}
.bl-search{width:100%;padding:15px 20px 15px 48px;border:1px solid var(--line);border-radius:999px;font-size:.94rem;font-weight:600;color:var(--ink);background:#fff;box-shadow:0 8px 24px -12px rgba(0,87,255,.15);transition:all .3s ease}
.bl-search:focus{outline:none;border-color:var(--ac);box-shadow:0 12px 32px -12px rgba(0,87,255,.35)}
.bl-search::placeholder{color:var(--mute);font-weight:500}

/* Filter pills */
.bl-filter{display:flex;flex-wrap:wrap;gap:9px;justify-content:center;margin:20px 0 26px}
.bl-pill{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);background:#fff;color:var(--slate);font-weight:700;font-size:.84rem;padding:9px 16px;border-radius:999px;cursor:pointer;transition:.2s;box-shadow:0 4px 12px -6px rgba(11,18,32,.1)}
.bl-pill .n{font-size:.72rem;color:var(--mute);font-weight:800}
.bl-pill:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-1px)}
.bl-pill.on{background:var(--ac);color:#fff;border-color:var(--ac);box-shadow:0 12px 24px -10px rgba(0,87,255,.5)}
.bl-pill.on .n{color:rgba(255,255,255,.9)}

/* Grid cards (larger images) + Performance fix */
.bl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:22px}
.bl-card{position:relative;display:flex;flex-direction:column;background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;text-decoration:none;color:var(--ink);transition:transform .4s,box-shadow .4s,border-color .4s;content-visibility:auto;contain-intrinsic-size:350px}
.bl-card.hide{display:none}
.bl-card:hover{transform:translateY(-6px);box-shadow:0 30px 60px -22px rgba(0,40,120,.28);border-color:color-mix(in srgb,var(--ac) 30%,#fff)}
.bl-media{position:relative;height:220px;overflow:hidden;background:linear-gradient(135deg,color-mix(in srgb,var(--ac) 18%,#fff),#fff 62%);display:grid;place-items:center}
.bl-media .fallback{position:absolute;inset:0;display:grid;place-items:center;font-size:3.5rem;color:color-mix(in srgb,var(--ac) 25%,#fff);z-index:0}
.bl-media img{position:relative;z-index:1;width:100%;height:100%;object-fit:cover;transition:transform .7s ease}
.bl-card:hover .bl-media img{transform:scale(1.08)}
.bl-media .bl-badge{top:14px;left:14px;z-index:2}
.bl-cbody{padding:22px 24px;display:flex;flex-direction:column;flex:1;gap:10px}
.bl-ccat{font-size:.68rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ac)}
.bl-cbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1.18rem;font-weight:700;letter-spacing:-.02em;line-height:1.22;margin:0}
.bl-cbody p{color:var(--slate);font-size:.9rem;line-height:1.6;margin:0}
.bl-cfoot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:14px;border-top:1px solid var(--line)}
.bl-cdate{color:var(--mute);font-size:.78rem;font-weight:700;display:inline-flex;align-items:center;gap:6px}
.bl-clink{display:inline-flex;align-items:center;gap:7px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.86rem;color:var(--ac)}
.bl-clink i{transition:transform .3s}.bl-card:hover .bl-clink i{transform:translateX(4px)}
.bl-empty{display:none;text-align:center;color:var(--slate);padding:40px 0;font-size:.95rem;background:#fff;border:1px dashed var(--line);border-radius:var(--radius)}
.bl-empty.show{display:block}

/* Internal Linking Matrix (hub -> cluster) */
.bl-il{margin:46px 0 10px;background:#fff;border:1px solid var(--line);border-radius:24px;padding:26px;box-shadow:0 12px 30px -16px rgba(9,32,84,.16)}
.bl-il h2{font-family:'Sora','Poppins',sans-serif;font-size:1.25rem;font-weight:800;margin:0 0 6px;letter-spacing:-.02em}
.bl-il .sub{color:var(--slate);font-size:.92rem;margin:0 0 18px}
.bl-il-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.bl-il-card{display:flex;gap:13px;align-items:center;background:var(--soft);border:1px solid var(--line);border-radius:14px;padding:15px;text-decoration:none;color:var(--ink);transition:transform .25s,border-color .25s,box-shadow .25s,background .25s}
.bl-il-card:hover{transform:translateY(-3px);border-color:var(--ac);background:#fff;box-shadow:0 14px 30px -16px rgba(0,87,255,.35)}
.bl-il-card .ic{flex:none;width:44px;height:44px;border-radius:12px;background:color-mix(in srgb,var(--ac) 14%,#fff);color:var(--ac);display:grid;place-items:center;font-size:1.05rem;transition:transform .3s}
.bl-il-card:hover .ic{transform:scale(1.08)}
.bl-il-card b{display:block;font-size:.92rem;font-weight:800}
.bl-il-card span{display:block;font-size:.76rem;color:var(--slate);margin-top:2px}
.bl-il-routes{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px;padding-top:18px;border-top:1px solid var(--line)}
.bl-il-chip{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:10px 16px;font-weight:700;font-size:.86rem;color:var(--ink);text-decoration:none;transition:.2s}
.bl-il-chip i{color:var(--ac)}
.bl-il-chip .fare{font-size:.72rem;font-weight:800;color:var(--ac);background:rgba(0,87,255,.1);padding:3px 9px;border-radius:999px}
.bl-il-chip:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}

/* FAQ (a11y fixed) */
.bl-faqsec{margin:54px 0 10px}
.bl-faqhead{text-align:center;margin-bottom:28px}
.bl-faqhead h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:0 0 8px}
.bl-faqhead p{color:var(--slate);margin:0}
.bl-fbox{max-width:820px;margin:0 auto}
.bl-fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}
.bl-fi:hover{border-color:color-mix(in srgb,var(--ac) 30%,#fff);box-shadow:0 10px 24px -14px rgba(0,87,255,.2)}
.bl-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:17px 21px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer;color:var(--ink);background:transparent;border:none;width:100%;text-align:left}
.bl-ft{flex:none;width:28px;height:28px;border-radius:9px;background:rgba(0,87,255,.1);color:var(--ac);display:grid;place-items:center;font-size:.86rem;transition:transform .3s}
.bl-fi.open .bl-ft{transform:rotate(45deg)}
.bl-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.94rem;line-height:1.66;padding:0 21px;transition:max-height .4s,padding .4s}
.bl-fi.open .bl-fb{max-height:380px;padding:0 21px 18px}

/* CTA */
.bl .cta2{padding:54px 0 70px}.bl .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--ac),transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:54px 24px;box-shadow:0 34px 70px -28px rgba(0,40,120,.55);position:relative;overflow:hidden}
.bl .ctain::before{content:"";position:absolute;top:-80px;right:-60px;width:280px;height:280px;border-radius:50%;background:radial-gradient(circle,rgba(57,182,255,.3),transparent 70%)}
.bl .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px;position:relative;color:#fff}
.bl .cta2 p{color:rgba(255,255,255,.88);margin:0 0 22px;position:relative}
.bl .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;position:relative}
.bl .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.bl .cta2 .w{background:#fff;color:var(--ac);box-shadow:0 12px 24px -10px rgba(0,0,0,.3)}.bl .cta2 .g{background:#25d366;color:#04260f}.bl .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.bl .cta2 a:hover{transform:translateY(-2px);filter:brightness(1.08)}
@media(max-width:820px){.bl-feat{min-height:340px}.bl-fbody{padding:24px}.bl-fbody h2{font-size:1.4rem}.bl-grid{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.bl *{transition:none!important;animation:none!important}.bl .rv{opacity:1!important;transform:none!important}}
</style>
<div class="bl"><div class="bl-in">
<nav class="bl-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Blog</span></nav>
<section class="bl-hero rv">
<span class="bl-ey"><i class="fa-solid fa-newspaper"></i> Taxi guides &amp; travel tips</span>
<h1 class="disp">Plan smarter trips from <em>Dehradun</em></h1>
<p>Expert-written travel guides covering Jolly Grant Airport transfers, outstation taxi routes, Char Dham Yatra planning, and local sightseeing — based on 500+ real trips completed by Anaya Cab Service drivers in 2026.</p>
<span class="bl-count"><i class="fa-solid fa-layer-group"></i> <?php echo count($posts); ?> guides · <?php echo count($cat_counts); ?> topics</span>
</section>
<div class="bl-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service Travel Blog</strong> provides updated 2026 route guides, distance breakdowns, vehicle recommendations, and fixed taxi fares for Dehradun city, Jolly Grant Airport, Mussoorie (~35 km), Haridwar (~55 km), Rishikesh (~45 km), Delhi (~250 km), and Char Dham Yatra pilgrimage circuits.</p>
</div>
<?php if ($featured): ?>
<a class="bl-feat rv" data-cat="<?php echo htmlspecialchars($featured['category']); ?>" href="/blog/<?php echo htmlspecialchars($featured['slug']); ?>">
<div class="bl-fmedia">
<img src="<?php echo htmlspecialchars($featured['image']); ?>" alt="<?php echo htmlspecialchars($featured['title']); ?>" width="1200" height="675" loading="eager" decoding="async" onerror="this.style.display='none'">
<i class="fa-solid fa-mountain-sun bl-glyph"></i>
</div>
<span class="bl-badge"><i class="fa-solid fa-star"></i> <?php echo htmlspecialchars($featured['category']); ?></span>
<span class="bl-flag">Featured</span>
<div class="bl-fbody">
<span class="bl-fcat"><?php echo htmlspecialchars($featured['category']); ?></span>
<h2 class="disp"><?php echo htmlspecialchars($featured['title']); ?></h2>
<p><?php echo htmlspecialchars($featured['excerpt']); ?></p>
<div class="bl-fmeta"><span><i class="fa-regular fa-user"></i> Anaya Cab Service</span><span><i class="fa-regular fa-calendar"></i> <?php echo htmlspecialchars($featured['date']); ?></span><span><i class="fa-regular fa-clock"></i> <?php echo (int)$featured['read_time']; ?> min read</span></div>
<span class="bl-read">Read guide <i class="fa-solid fa-arrow-right"></i></span>
</div>
</a>
<?php endif; ?>

<div class="bl-search-wrap rv">
    <i class="fa-solid fa-magnifying-glass"></i>
    <input type="text" class="bl-search" id="blSearchInput" placeholder="Search guides (e.g. Mussoorie, Airport, Char Dham...)" autocomplete="off">
</div>

<div class="bl-filter rv">
<button class="bl-pill on" data-f="all" aria-pressed="true">All <span class="n"><?php echo count($posts); ?></span></button>
<?php foreach ($cat_counts as $__c => $__n): ?>
<button class="bl-pill" data-f="<?php echo htmlspecialchars($__c); ?>" aria-pressed="false"><?php echo htmlspecialchars($__c); ?> <span class="n"><?php echo $__n; ?></span></button>
<?php endforeach; ?>
</div>
<div class="bl-grid">
<?php foreach ($rest as $post): ?>
<a href="/blog/<?php echo htmlspecialchars($post['slug']); ?>" class="bl-card rv" data-cat="<?php echo htmlspecialchars($post['category']); ?>">
<div class="bl-media">
    <i class="fa-solid fa-mountain-sun fallback"></i>
    <span class="bl-badge"><?php echo htmlspecialchars($post['category']); ?></span>
    <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" width="600" height="340" loading="lazy" decoding="async" onerror="this.style.display='none'">
</div>
<div class="bl-cbody">
<span class="bl-ccat"><?php echo htmlspecialchars($post['category']); ?></span>
<h3><?php echo htmlspecialchars($post['title']); ?></h3>
<p><?php echo htmlspecialchars($post['excerpt']); ?></p>
<div class="bl-cfoot"><span class="bl-cdate"><i class="fa-regular fa-calendar"></i> <?php echo htmlspecialchars($post['date']); ?> &nbsp;·&nbsp; <i class="fa-regular fa-clock"></i> <?php echo (int)$post['read_time']; ?> min</span><span class="bl-clink">Read <i class="fa-solid fa-arrow-right"></i></span></div>
</div>
</a>
<?php endforeach; ?>
</div>
<div class="bl-empty" id="blEmpty"><i class="fa-regular fa-folder-open" style="font-size:1.5rem;display:block;margin-bottom:8px;color:var(--ac)"></i>No guides match your search — try another keyword or category.</div>

<!-- INTERNAL LINKING MATRIX (hub -> service + route clusters) -->
<section class="bl-il rv" aria-label="Popular taxi services and routes">
<span class="bl-ey"><i class="fa-solid fa-link"></i> Plan by service or route</span>
<h2 class="disp">Jump straight to the page you need</h2>
<p class="sub">Fares, vehicles and booking on each service or route page — all linked from our guides.</p>
<div class="bl-il-grid">
<?php foreach ($__matrix_services as $s): ?>
<a class="bl-il-card" href="<?php echo $s[0]; ?>"><span class="ic"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><span><b><?php echo $s[2]; ?></b><span><?php echo $s[3]; ?></span></span></a>
<?php endforeach; ?>
</div>
<div class="bl-il-routes">
<?php foreach ($__matrix_routes as $r): ?>
<a class="bl-il-chip" href="<?php echo $r[0]; ?>"><i class="fa-solid fa-route"></i> <?php echo $r[1]; ?> <span class="fare"><?php echo $r[2]; ?></span></a>
<?php endforeach; ?>
</div>
</section>

<section class="bl-faqsec rv">
<div class="bl-faqhead">
<span class="bl-ey"><i class="fa-regular fa-circle-question"></i> Blog FAQs</span>
<h2 class="disp">Common questions about our travel guides</h2>
<p>Quick answers to help you navigate our Dehradun taxi blog</p>
</div>
<div class="bl-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="bl-fi<?php echo $i===0?' open':''; ?>">
<button type="button" class="bl-fh" aria-expanded="<?php echo $i===0?'true':'false'; ?>"><?php echo htmlspecialchars($f[0]); ?><span class="bl-ft"><i class="fa-solid fa-plus"></i></span></button>
<div class="bl-fb" role="region"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div>
</div>
<?php endforeach; ?>
</div>
</section>
<section class="cta2 rv"><div class="ctain">
<h2 class="disp">Read it, then ride it</h2>
<p>Picked a route from our guides? Book the taxi in under a minute — fixed fare, verified driver.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I read your blog and want to book a taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></section>
</div></div>
<script>
(function(){
var r=document.querySelectorAll('.bl .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
/* UX Polish: Staggered waterfall reveal for grid cards */
var cards=document.querySelectorAll('.bl-card.rv');
cards.forEach(function(c, i){ c.style.transitionDelay = (i * 0.06) + 's'; });

var searchInput = document.getElementById('blSearchInput');
var pills = document.querySelectorAll('.bl-pill');
var cardsAll = document.querySelectorAll('.bl-card.rv');
var empty = document.getElementById('blEmpty');

function filterCards() {
    var activePill = document.querySelector('.bl-pill.on');
    var f = activePill ? activePill.getAttribute('data-f') : 'all';
    var q = searchInput ? searchInput.value.toLowerCase().trim() : '';
    var vis = 0;
    
    cardsAll.forEach(function(c) {
        var title = c.querySelector('h3') ? c.querySelector('h3').textContent.toLowerCase() : '';
        var exc = c.querySelector('p') ? c.querySelector('p').textContent.toLowerCase() : '';
        var cat = (c.getAttribute('data-cat') || '').toLowerCase();
        
        var matchCat = (f === 'all' || cat === f);
        var matchQ = !q || title.includes(q) || exc.includes(q) || cat.includes(q);
        
        var show = matchCat && matchQ;
        c.classList.toggle('hide', !show);
        if (show) vis++;
    });
    
    empty.classList.toggle('show', vis === 0);
}

if (searchInput) {
    searchInput.addEventListener('input', filterCards);
}

pills.forEach(function(p) {
    p.addEventListener('click', function() {
        pills.forEach(function(x) {
            x.classList.remove('on');
            x.setAttribute('aria-pressed', 'false');
        });
        p.classList.add('on');
        p.setAttribute('aria-pressed', 'true');
        filterCards();
    });
});

document.querySelectorAll('.bl-fh').forEach(function(h){
    h.addEventListener('click',function(){
        var parent = h.parentElement;
        var isOpen = parent.classList.toggle('open');
        h.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
});
})();
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>