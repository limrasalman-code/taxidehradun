<?php
/* blog/post-view.php — DB-driven post detail (fallback for /blog/{slug} without physical file) */
if (!defined('SITE_NAME')) { require_once dirname(__DIR__) . '/includes/config.php'; }
if (!isset($pdo)) { $pdo = function_exists('db') ? db() : null; }

// Load Google Preferred Source Component
require_once dirname(__DIR__) . '/includes/google-preferred-source.php';

$domain = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$whatsapp = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$slug = $__slug_req ?? '';
$row = null;
if ($pdo && $slug) { try { $st = $pdo->prepare("SELECT * FROM blogs WHERE slug=? AND status='published' LIMIT 1"); $st->execute([$slug]); $row = $st->fetch(); } catch (Throwable $e) { $row = null; } }
if (!$row) { http_response_code(404); echo '<!doctype html><meta charset="utf-8"><title>Post not found</title><p style="font-family:sans-serif;padding:40px">Post not found. <a href="/blog/">Back to blog</a></p>'; exit; }
/* ---- markdown-lite renderer: headings, lists, bold, pipe-tables, {{img:N}} ---- */
function pv_inline($t){ return preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $t); }
function pv_row($line){ $line = trim(trim($line), '|'); $line = str_replace('\\|', "\x01", $line); $cells = explode('|', $line); return array_map(function($c){ return pv_inline(htmlspecialchars(trim(str_replace("\x01", '|', $c)), ENT_QUOTES)); }, $cells); }
function pv_img($num, $images){ $num = (int)$num; $img = $images[$num] ?? null; if (!$img || empty($img['src'])) return ''; return '<figure class="bp-fig"><img src="' . htmlspecialchars($img['src'], ENT_QUOTES) . '" alt="' . htmlspecialchars($img['alt'] ?? '', ENT_QUOTES) . '" loading="lazy" decoding="async"></figure>'; }
function pv_content($raw, $images){
$lines = preg_split('/\r\n|\r|\n/', (string)$raw); $html = ''; $inUl = false; $i = 0; $n = count($lines);
$close = function() use (&$inUl, &$html){ if ($inUl) { $html .= '</ul>'; $inUl = false; } };
while ($i < $n) { $trim = trim($lines[$i]);
if ($trim === '') { $close(); $i++; continue; }
if (preg_match('/^###\s+(.*)$/', $trim, $m)) { $close(); $html .= '<h3>' . pv_inline(htmlspecialchars($m[1], ENT_QUOTES)) . '</h3>'; $i++; continue; }
if (preg_match('/^##\s+(.*)$/', $trim, $m)) { $close(); $id = preg_replace('/[^a-z0-9-]+/', '-', strtolower(trim($m[1]))); $html .= '<h2 id="' . $id . '">' . pv_inline(htmlspecialchars($m[1], ENT_QUOTES)) . '</h2>'; $i++; continue; }
if (strpos($trim, '|') === 0 && $i + 1 < $n && preg_match('/^\|[\s\-:|]+\|?$/', trim($lines[$i+1]))) {
$close(); $header = pv_row($trim); $i += 2; $rows = [];
while ($i < $n && strpos(trim($lines[$i]), '|') === 0) { $rows[] = pv_row(trim($lines[$i])); $i++; }
$html .= '<div class="rTableWrap"><table class="rTable blogTable"><thead><tr>';
foreach ($header as $c) $html .= '<th>' . $c . '</th>';
$html .= '</tr></thead><tbody>';
foreach ($rows as $r) { $html .= '<tr>'; foreach ($r as $c) $html .= '<td>' . $c . '</td>'; $html .= '</tr>'; }
$html .= '</tbody></table></div>'; continue;
}
if (preg_match('/^\{\{img:(\d)\}\}$/', $trim, $m)) { $close(); $html .= pv_img($m[1], $images); $i++; continue; }
if (preg_match('/^[-*]\s+(.*)$/', $trim, $m)) { if (!$inUl) { $close(); $html .= '<ul class="bp-ul">'; $inUl = true; } $html .= '<li>' . pv_inline(htmlspecialchars($m[1], ENT_QUOTES)) . '</li>'; $i++; continue; }
$close(); $p = htmlspecialchars($trim, ENT_QUOTES);
$p = preg_replace_callback('/\{\{img:(\d)\}\}/', function($mm) use ($images){ return pv_img($mm[1], $images); }, $p);
$html .= '<p>' . pv_inline($p) . '</p>'; $i++;
}
$close(); return $html;
}
/* ---- per-post fields (backward compatible) ---- */
$title = trim((string)($row['meta_title'] ?? '')) ?: $row['title'];
$excerpt = trim((string)($row['meta_description'] ?? '')) ?: ($row['excerpt'] ?? '');
$url = $domain . '/blog/' . $row['slug'];
$og = trim((string)($row['og_image'] ?? '')) ?: ($row['featured_image'] ?: '/assets/images/blog/' . $row['slug'] . '.webp');
if ($og && strpos($og, '/') === 0) $og = $domain . $og;
$images = []; for ($k = 1; $k <= 3; $k++) { $src = trim((string)($row['image_' . $k] ?? '')); if ($src) { if (strpos($src, '/') === 0) $src = $domain . $src; $images[$k] = ['src' => $src, 'alt' => trim((string)($row['image_alt_' . $k] ?? ''))]; } }
$faqs = [];
if (!empty($row['faq_json'])) { $j = json_decode($row['faq_json'], true); if (is_array($j)) foreach ($j as $f) { if (isset($f['q'], $f['a'])) $faqs[] = ['q' => $f['q'], 'a' => $f['a']]; } }
if (!$faqs && !empty($row['aeo_faqs'])) { foreach (preg_split('/\R/', $row['aeo_faqs']) as $ln) { $ln = trim($ln); if ($ln === '' || strpos($ln, '|') === false) continue; $pp = array_map('trim', explode('|', $ln, 2)); $faqs[] = ['q' => $pp[0], 'a' => $pp[1] ?? '']; } }
$quick = trim((string)($row['ai_summary'] ?? '')) ?: trim((string)($row['geo_summary'] ?? ''));
$iso = ''; $d = $row['updated_at'] ?? ($row['created_at'] ?? ''); if ($d) { $t = strtotime($d); if ($t) $iso = date('c', $t); }
$canonical = trim((string)($row['canonical_url'] ?? '')) ?: $url;
$readmin = !empty($row['read_min']) ? (int)$row['read_min'] : max(1, (int)round(str_word_count(strip_tags((string)$row['content'])) / 200));
$page_title = $title . ' | Anaya Cab Service';
$page_description = $excerpt ?: $title;
$page_url = $canonical;
$page_image = $og;
$graph = [['@type' => ($row['schema_type'] ?? 'BlogPosting'), 'headline' => $row['title'], 'description' => $excerpt, 'url' => $url, 'mainEntityOfPage' => $url, 'author' => ['@type'=>'Organization','name'=>'Anaya Cab Service'], 'publisher' => ['@type'=>'Organization','name'=>'Anaya Cab Service'], 'image' => [$og]]];
if ($iso) { $graph[0]['datePublished'] = $iso; $graph[0]['dateModified'] = $iso; }
if ($quick) { $graph[] = ['@type'=>'WebPage','@id'=>$url.'#page','speakable'=>['@type'=>'SpeakableSpecification','cssSelector'=>['.bp-qa']]]; }
if ($faqs) { $graph[] = ['@type'=>'FAQPage','@id'=>$url.'#faq','mainEntity'=>array_map(function($f){ return ['@type'=>'Question','name'=>$f['q'],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f['a']]]; }, $faqs)]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>$graph], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once dirname(__DIR__) . '/includes/header.php';
$content = pv_content($row['content'] ?? '', $images);
$toc = []; preg_match_all('/<h2 id="([^"]+)">([^<]+)</', $content, $mm, PREG_SET_ORDER); foreach ($mm as $m) { $toc[] = ['id' => $m[1], 't' => strip_tags($m[2])]; }
?>
<style>
.bp{--bp-ink:#0f172a;--bp-slate:#5b6577;--bp-line:#e6ebf3;--bp-soft:#f6f9ff;--bp-ac:#ea7317;position:relative;font-family:"Plus Jakarta Sans",system-ui,sans-serif;color:var(--bp-ink);background:linear-gradient(180deg,#eef3fb,#fff 520px)}
.bp *{box-sizing:border-box}
.bp-in{position:relative;z-index:1;max-width:1140px;margin:0 auto;padding:0 22px}
.bp-crumb{display:flex;gap:8px;align-items:center;font-size:.82rem;color:var(--bp-slate);padding:28px 0 0}.bp-crumb a{color:var(--bp-slate);text-decoration:none}.bp-crumb i{font-size:.6rem;color:#94a3b8}.bp-crumb .cur{color:var(--bp-ink);font-weight:600}
.bp-hero{padding:22px 0 8px;max-width:820px}
.bp-ey{display:inline-flex;align-items:center;gap:8px;font-size:.7rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--bp-ac);background:color-mix(in srgb,var(--bp-ac) 12%,#fff);padding:7px 13px;border-radius:999px}
.bp-h1{font-family:"Sora","Poppins",sans-serif;font-size:clamp(1.9rem,4.6vw,3rem);font-weight:800;letter-spacing:-.035em;line-height:1.08;margin:14px 0}
.bp-meta{display:flex;flex-wrap:wrap;gap:16px;color:var(--bp-slate);font-size:.85rem;font-weight:600}.bp-meta span{display:inline-flex;align-items:center;gap:7px}.bp-meta i{color:var(--bp-ac)}
.bp-figure{margin:20px 0 0;border-radius:22px;overflow:hidden;max-width:980px}.bp-figure img{width:100%;height:auto;display:block;max-height:460px;object-fit:cover}
.bp-layout{display:grid;grid-template-columns:240px 1fr;gap:40px;padding:34px 0 10px;align-items:start}
.bp-side{position:sticky;top:90px}
.bp-toc{background:#fff;border:1px solid var(--bp-line);border-radius:16px;padding:16px}
.bp-toc-h{display:flex;align-items:center;gap:8px;font-family:"Sora",sans-serif;font-weight:800;font-size:.82rem;text-transform:uppercase;letter-spacing:.06em;color:var(--bp-slate);margin-bottom:10px}.bp-toc-h i{color:var(--bp-ac)}
.bp-toc ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}
.bp-toc a{display:block;padding:7px 10px;border-radius:9px;border-left:2px solid transparent;color:var(--bp-slate);font-size:.85rem;font-weight:600;text-decoration:none}
.bp-toc a:hover{color:var(--bp-ink);background:var(--bp-soft)}
.bp-body{min-width:0;max-width:760px}
.bp-qa{background:linear-gradient(160deg,color-mix(in srgb,var(--bp-ac) 8%,#fff),#fff);border:1px solid color-mix(in srgb,var(--bp-ac) 25%,#fff);border-left:4px solid var(--bp-ac);border-radius:16px;padding:18px 20px;margin:0 0 26px}
.bp-qa-ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--bp-ac);margin-bottom:8px}
.bp-qa p{margin:0;font-size:1.02rem;line-height:1.65;color:#1f2a44}
.bp-content{font-size:1.04rem;line-height:1.78;color:#27324a}
.bp-content h2{font-family:"Sora","Poppins",sans-serif;font-size:clamp(1.3rem,2.6vw,1.7rem);font-weight:800;margin:36px 0 12px;scroll-margin-top:96px}
.bp-content h3{font-family:"Sora","Poppins",sans-serif;font-size:1.15rem;font-weight:700;margin:24px 0 8px}
.bp-content p{margin:0 0 16px}
.bp-content strong{color:var(--bp-ink)}
.bp-content a{color:var(--bp-ac);font-weight:700;text-decoration:none}
.bp-ul{margin:0 0 18px;padding-left:0;list-style:none;display:flex;flex-direction:column;gap:10px}
.bp-ul li{position:relative;padding-left:28px;color:#27324a}
.bp-ul li::before{content:"";position:absolute;left:4px;top:.62em;width:8px;height:8px;border-radius:3px;background:linear-gradient(135deg,var(--bp-ac),#00c2ff)}
.bp-fig{margin:22px 0;border-radius:18px;overflow:hidden}
.bp-fig img{width:100%;height:auto;display:block}
.rTableWrap{overflow-x:auto;margin:20px 0;border-radius:14px;border:1px solid var(--bp-line)}
.rTable{width:100%;border-collapse:collapse;min-width:480px;font-size:.95rem}
.rTable thead th{background:linear-gradient(135deg,#0a1b3d,#0057ff);color:#fff;text-transform:uppercase;font-size:.72rem;letter-spacing:.06em;padding:12px 16px;text-align:left}
.rTable tbody td{padding:12px 16px;border-top:1px solid var(--bp-line);color:#27324a}
.rTable tbody tr:nth-child(even){background:var(--bp-soft)}
.bp-faqsec{margin:40px 0 0}
.bp-h2{font-family:"Sora","Poppins",sans-serif;font-size:1.5rem;font-weight:800;margin:0 0 16px}
.bp-fq{background:#fff;border:1px solid var(--bp-line);border-radius:14px;margin-bottom:11px;overflow:hidden}
.bp-fq-h{width:100%;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;background:none;border:none;cursor:pointer;font-family:"Sora",sans-serif;font-weight:600;font-size:1rem;text-align:left;color:var(--bp-ink)}
.bp-fq-t{flex:none;width:26px;height:26px;border-radius:8px;background:color-mix(in srgb,var(--bp-ac) 12%,#fff);color:var(--bp-ac);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.bp-fq.open .bp-fq-t{transform:rotate(45deg)}
.bp-fq-a{max-height:0;overflow:hidden;transition:max-height .4s,padding .4s;padding:0 20px;color:var(--bp-slate);line-height:1.66}
.bp-fq.open .bp-fq-a{max-height:340px;padding:0 20px 18px}
.bp-related{padding:30px 0 70px}
.bp-relcard{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;background:radial-gradient(120% 140% at 90% 0%,var(--bp-ac),transparent 60%),linear-gradient(120deg,#0a1b3d,#0057ff);color:#fff;border-radius:24px;padding:30px}
.bp-relcard h3{font-family:"Sora",sans-serif;font-size:1.4rem;font-weight:800;margin:10px 0 6px}
.bp-relcard p{margin:0;color:rgba(255,255,255,.82)}
.bp-relact{display:flex;gap:10px;flex-wrap:wrap}
.bp-btn{display:inline-flex;align-items:center;gap:9px;font-family:"Sora",sans-serif;font-weight:700;font-size:.9rem;padding:12px 20px;border-radius:13px;text-decoration:none}
.bp-btna{background:#fff;color:#0057ff}.bp-btng{background:#25d366;color:#04260f}
@media(max-width:900px){.bp-layout{grid-template-columns:1fr;gap:24px}.bp-side{position:static;order:2}}
</style>
<main id="main"><div class="bp"><div class="bp-in">
<nav class="bp-crumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/blog/">Blog</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($row['category'] ?: 'Guide'); ?></span></nav>
<header class="bp-hero"><span class="bp-ey"><i class="fa-solid fa-tag"></i> <?php echo htmlspecialchars($row['category'] ?: 'Travel Guide'); ?></span><h1 class="bp-h1"><?php echo htmlspecialchars($row['title']); ?></h1>
<div class="bp-meta"><span><i class="fa-regular fa-user"></i> <?php echo htmlspecialchars($row['author'] ?: 'Anaya Cab Service'); ?></span><?php if ($iso) { echo '<span><i class="fa-regular fa-calendar"></i> ' . date('d M Y', strtotime($d)) . '</span>'; } ?><span><i class="fa-regular fa-clock"></i> <?php echo $readmin; ?> min read</span></div></header>
<?php if ($og) { ?><figure class="bp-figure"><img src="<?php echo htmlspecialchars($og); ?>" alt="<?php echo htmlspecialchars($row['og_image_alt'] ?? $row['title']); ?>" loading="eager" decoding="async" onerror="this.parentElement.style.display='none'"></figure><?php } ?>
<?php if ($quick) { ?><div class="bp-qa"><div class="bp-qa-ey"><i class="fa-solid fa-bolt"></i> Quick Answer</div><p><?php echo htmlspecialchars($quick); ?></p></div><?php } ?>

<!-- Google Preferred Source Button (Blog Placement) -->
<?php if (function_exists('gps_render_button')) { gps_render_button('blog'); } ?>

<div class="bp-layout">
<?php if ($toc) { ?><aside class="bp-side"><nav class="bp-toc"><div class="bp-toc-h"><i class="fa-solid fa-list"></i> On this page</div><ol><?php foreach ($toc as $t) { echo '<li><a href="#' . $t['id'] . '">' . htmlspecialchars($t['t']) . '</a></li>'; } ?></ol></nav></aside><?php } ?>
<article class="bp-body"><div class="bp-content"><?php echo $content; ?></div>
<?php if ($faqs) { ?><div class="bp-inlinks"><i class="fa-solid fa-link"></i> <strong>Plan your ride:</strong> <a href="/dehradun-to-mussoorie-taxi">Dehradun → Mussoorie Taxi</a> · <a href="/char-dham-yatra-taxi">Char Dham Yatra Taxi</a> · <a href="/dehradun-airport-taxi-service">Jolly Grant Airport Taxi</a> · <a href="/dehradun-local-sightseeing-taxi">Dehradun Local Sightseeing</a></div><section class="bp-faqsec"><h2 class="bp-h2">Frequently Asked Questions</h2><?php foreach ($faqs as $i => $f) { echo '<div class="bp-fq' . ($i === 0 ? ' open' : '') . '"><button type="button" class="bp-fq-h">' . htmlspecialchars($f['q']) . '<span class="bp-fq-t"><i class="fa-solid fa-plus"></i></span></button><div class="bp-fq-a"><p>' . htmlspecialchars($f['a']) . '</p></div></div>'; } ?></section><?php } ?>
</article>
</div>
<section class="bp-related"><div class="bp-relcard"><div><span class="bp-ey"><i class="fa-solid fa-arrow-right"></i> Keep reading</span><h3>Plan your trip with Anaya Cab</h3><p>Ready to book? Get a fixed fare in minutes.</p></div><div class="bp-relact"><a class="bp-btn bp-btna" href="<?php echo htmlspecialchars($row['related_url'] ?: '/#booking'); ?>">View service <i class="fa-solid fa-arrow-right"></i></a><a class="bp-btn bp-btng" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I read your blog and want to book a taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a></div></div></section>
</div></div></main>
<script>document.querySelectorAll('.bp-fq-h').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});</script>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>