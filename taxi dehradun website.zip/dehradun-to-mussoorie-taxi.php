<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Mussoorie Taxi Fare | Cab from ₹1,050';
$page_description = 'Dehradun to Mussoorie taxi from ₹1,050 (35 km, 1–1.5 hr). One-way & round trips to Mall Road, Kempty Falls, Landour. Hill-expert drivers, fixed fares.';
$page_url         = $domain . "/dehradun-to-mussoorie-taxi";

$__faqs = [
["How far is Mussoorie from Dehradun by taxi?", "Mussoorie is about 35 km from Dehradun, and the scenic hill road drive usually takes 1 to 1.5 hours depending on weekend traffic and weather."],
["What is the taxi fare from Dehradun to Mussoorie?", "A one way sedan fare from Dehradun to Mussoorie typically ranges from 900 to 1200 rupees, while an SUV or Innova ranges from 1400 to 1800 rupees, confirmed before you book."],
["Do your drivers have experience on the Mussoorie hill road?", "Yes. Our drivers are experienced with the winding hill road to Mussoorie and drive with extra caution in monsoon and winter, planning for fog, traffic and occasional snowfall."],
["Can I book a one way or round trip taxi to Mussoorie?", "Yes. Both one way drops and round trip cabs are available, and you can also add local Mussoorie sightseeing to Mall Road, Kempty Falls, Gun Hill and Landour on the same booking."],
["Which pickup points in Dehradun do you cover for Mussoorie?", "We pick up from anywhere in Dehradun including Jolly Grant Airport, the railway station, ISBT, Rajpur Road and Sahastradhara Road, and drop at Mussoorie hotels around Mall Road, Library Chowk, Landour and Kempty Falls."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Mussoorie Taxi','serviceType'=>'Hill station taxi transfer','description'=>'One-way and round-trip taxi from Dehradun to Mussoorie over the 35 km scenic hill road with verified hill drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Mussoorie']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'900','description'=>'One way sedan taxi fare from Dehradun to Mussoorie starts from 900 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__matrix = [
['Jolly Grant Airport','Library Chowk / Mall Road','Airport to Mussoorie takes longer due to the hill approach.'],
['Railway Station / ISBT','Picture Palace / Camel\'s Back Road','Ideal for travellers arriving by train or bus.'],
['Rajpur / Sahastradhara Rd','Landour / Kempty Falls side','Weekend traffic can add time near Mussoorie entry points.'],
];

$__sights = [
['Mall Road & Camel\'s Back Road','fa-road','The heart of Mussoorie for walks, cafes and views.'],
['Kempty Falls','fa-water','Popular waterfall picnic spot a short drive from town.'],
['Gun Hill','fa-mountain','Scenic viewpoint reached by road or rope-way.'],
['Lal Tibba','fa-binoculars','Highest point in Mussoorie with Himalayan views.'],
['Company Garden','fa-tree','Family park with flowers, rides and a small lake.'],
['Landour','fa-house-chimney','Quiet colonial cantonment with cafes and viewpoints.'],
];

$__related = [
['Dehradun → Dhanaulti','/dehradun-to-dhanaulti-taxi','fa-mountain'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi','fa-om'],
['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],['Delhi → Mussoorie','/delhi-to-mussoorie-taxi','fa-road'],
['Mussoorie → Dehradun','/mussoorie-to-dehradun-taxi','fa-rotate'],['Dehradun → Chakrata','/dehradun-to-chakrata-taxi','fa-mountain-sun'],
];
?>
<main id="main">
<style>
.ms{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--pine:#0f766e;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eaf4f1 0%,#ffffff 440px)}
.ms *{box-sizing:border-box}
.ms::before{content:"";position:absolute;top:-200px;left:-120px;width:580px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(15,118,110,.12),transparent 70%);pointer-events:none}
.ms::after{content:"";position:absolute;top:340px;right:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.08),transparent 70%);pointer-events:none}
.ms .ms-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.ms .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ms .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.ms .rv.in{opacity:1;transform:none}
.ms .ms-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.ms .ms-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.ms .ms-crumb a:hover{color:var(--pine)}
.ms .ms-crumb i{font-size:.6rem;color:var(--mute)}.ms .ms-crumb .cur{color:var(--ink);font-weight:600}
.ms .ms-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.ms .ms-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.ms .ms-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.ms .ms-hero h1 em{font-style:normal;color:var(--pine)}
.ms .ms-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.ms .ms-lead strong{color:var(--ink)}
.ms .ms-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.ms .ms-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.ms .ms-m i{color:var(--pine)}.ms .ms-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.ms .ms-m span{font-size:.8rem;color:var(--slate)}
.ms .ms-herocta{display:flex;gap:12px;flex-wrap:wrap}
.ms .ms-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.ms .ms-btn-p{background:var(--pine);color:#fff;box-shadow:0 16px 34px -14px rgba(15,118,110,.55)}.ms .ms-btn-p:hover{transform:translateY(-2px);filter:brightness(1.08)}
.ms .ms-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.ms .ms-btn-g:hover{transform:translateY(-2px)}
.ms .ms-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.ms .ms-btn-o:hover{border-color:var(--pine);color:var(--pine)}
/* ascent fare card */
.ms .ms-card{position:sticky;top:88px;background:linear-gradient(160deg,#06231f,#0f766e);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(6,35,31,.6);overflow:hidden}
.ms .ms-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(127,231,255,.22),transparent 70%)}
.ms .ms-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#bdf3ea;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.ms .ms-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px;position:relative}
/* ascent visual */
.ms .ms-ascent{position:relative;height:74px;margin:0 0 6px}
.ms .ms-ascent .slope{position:absolute;left:0;right:0;bottom:14px;height:3px;background:repeating-linear-gradient(90deg,#7fe9f5 0 10px,transparent 10px 20px);transform:rotate(-7deg);transform-origin:left center}
.ms .ms-ascent .car{position:absolute;bottom:18px;left:6%;color:#fff;font-size:1rem;animation:msclimb 4s ease-in-out infinite}
@keyframes msclimb{0%,100%{left:6%;bottom:18px}50%{left:84%;bottom:42px}}
.ms .ms-ascent .from,.ms .ms-ascent .to{position:absolute;bottom:-2px;font-size:.66rem;letter-spacing:.08em;color:rgba(255,255,255,.7)}
.ms .ms-ascent .from{left:0}.ms .ms-ascent .to{right:0}
.ms .ms-fares{display:grid;gap:8px;margin:14px 0 0;position:relative}
.ms .ms-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.ms .ms-fr .v{font-weight:700;font-size:.9rem}
.ms .ms-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.ms .ms-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.ms .ms-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.ms .ms-card .cta .w{background:#fff;color:var(--pine)}.ms .ms-card .cta .g{background:#25d366;color:#04260f}
.ms .ms-card .cta a:hover{transform:translateY(-2px)}
.ms .ms-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.ms .ms-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--pine);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ms .ms-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);margin-bottom:8px}
.ms .ms-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ms .ms-qa strong{color:var(--ink)}
.ms .ms-sec{padding:48px 0}
.ms .ms-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.ms .ms-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.ms .ms-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.ms .ms-sh p{color:var(--slate);margin:0}
/* route timeline */
.ms .ms-rtl{position:relative;max-width:760px;margin:0 auto;padding-left:8px}
.ms .ms-rtl::before{content:"";position:absolute;left:23px;top:8px;bottom:8px;width:2px;background:linear-gradient(180deg,var(--blue),var(--pine))}
.ms .ms-rrow{position:relative;display:grid;grid-template-columns:48px 1fr;gap:18px;padding:0 0 18px}
.ms .ms-rdot{position:relative;z-index:1;width:48px;height:48px;border-radius:14px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--pine);font-size:1.05rem;box-shadow:0 8px 18px -10px rgba(15,118,110,.4)}
.ms .ms-rbody{background:#fff;border:1px solid var(--line);border-radius:16px;padding:15px 18px;transition:transform .3s,box-shadow .3s}
.ms .ms-rrow:hover .ms-rbody{transform:translateX(4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.3)}
.ms .ms-rbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}
.ms .ms-rbody p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
/* sights */
.ms .ms-sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.ms .ms-sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.ms .ms-sitem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.ms .ms-sico{flex:none;width:44px;height:44px;border-radius:12px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:1rem}
.ms .ms-sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.ms .ms-sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
/* matrix */
.ms .ms-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ms .ms-tscroll{overflow-x:auto}
.ms table{width:100%;border-collapse:collapse;min-width:560px}
.ms th,.ms td{padding:15px 18px;text-align:left;font-size:.92rem}
.ms thead th{background:var(--soft);color:var(--blue-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.ms tbody tr{border-top:1px solid var(--line);transition:background .2s}.ms tbody tr:hover{background:var(--soft)}
.ms .ms-prose{max-width:840px;margin:24px auto 0}
.ms .ms-prose h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 10px}
.ms .ms-prose p{color:var(--slate);line-height:1.72;margin:0 0 12px;font-size:.96rem}.ms .ms-prose strong{color:var(--ink)}
/* related */
.ms .ms-rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.ms .ms-rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.ms .ms-rchip i{color:var(--pine)}.ms .ms-rchip:hover{border-color:var(--pine);color:var(--pine);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(15,118,110,.4)}
.ms .ms-fbox{max-width:820px;margin:0 auto}
.ms .ms-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.ms .ms-fi:hover{border-color:#bfe6e0}
.ms .ms-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ms .ms-ft{flex:none;width:26px;height:26px;border-radius:8px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.ms .ms-fi.open .ms-ft{transform:rotate(45deg)}
.ms .ms-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ms .ms-fi.open .ms-fb{max-height:380px;padding:0 20px 18px}
.ms .ms-soft{background:linear-gradient(180deg,#eaf4f1,#f6fbfa)}
.ms .ms-cta{padding:0 0 70px}
.ms .ms-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0f766e,transparent 55%),linear-gradient(120deg,#06231f,#0f766e);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.ms .ms-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ms .ms-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ms .ms-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ms .ms-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.ms .ms-cta .w{background:#fff;color:var(--pine)}.ms .ms-cta .g{background:#25d366;color:#04260f}.ms .ms-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.ms .ms-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.ms .ms-hero{grid-template-columns:1fr;gap:24px}.ms .ms-card{position:static}}
@media(prefers-reduced-motion:reduce){.ms *{transition:none!important;animation:none!important}.ms .rv{opacity:1!important;transform:none!important}}
</style>

<div class="ms">
<div class="ms-in">
<nav class="ms-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Mussoorie Taxi</span></nav>

<section class="ms-hero">
<div class="rv">
<span class="ms-eyebrow"><i class="fa-solid fa-mountain-sun"></i> Queen of Hills · 35 km</span>
<h1 class="disp">Dehradun to Mussoorie Taxi Fare <em>&amp; Cab Booking Service</em></h1>
<p class="ms-lead"><strong>Dehradun to Mussoorie taxi fare starts from ₹900 for a sedan</strong> over the 35 km scenic hill road. Anaya Cab Service offers one-way and round-trip cabs with drivers experienced on the winding mountain route — comfortable for day trips to Mall Road and Kempty Falls or longer hill getaways, with fares fixed before you book.</p>
<div class="ms-metrics">
<span class="ms-m"><i class="fa-solid fa-road"></i> <b>35 km</b> <span>distance</span></span>
<span class="ms-m"><i class="fa-regular fa-clock"></i> <b>1–1.5 hr</b> <span>drive time</span></span>
<span class="ms-m"><i class="fa-solid fa-mountain"></i> <b>~2,000 m</b> <span>hill climb</span></span>
<span class="ms-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹900+</b> <span>sedan</span></span>
</div>
<div class="ms-herocta">
<a class="ms-btn ms-btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book this route</a>
<a class="ms-btn ms-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Mussoorie taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get fare on WhatsApp</a>
<a class="ms-btn ms-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="ms-card rv" aria-label="Dehradun to Mussoorie fare">
<span class="tag"><i class="fa-solid fa-mountain-sun"></i> Hill route fare</span>
<h3 class="disp">Dehradun → Mussoorie</h3>
<div class="ms-ascent" aria-hidden="true">
<div class="slope"></div>
<i class="fa-solid fa-car-side car"></i>
<span class="from">DEHRADUN</span><span class="to">MUSSOORIE</span>
</div>
<div class="ms-fares">
<div class="ms-fr"><span class="v">Sedan</span><span class="p">₹900 – ₹1,200</span></div>
<div class="ms-fr"><span class="v">SUV / Innova</span><span class="p">₹1,400 – ₹1,800</span></div>
<div class="ms-fr"><span class="v">Tempo Traveller</span><span class="p">On request</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Mussoorie taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · verified hill drivers</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="ms-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Dehradun to Mussoorie Taxi Guide</div>
<p itemprop="text"><strong>Dehradun to Mussoorie distance is 35 km and takes 1 to 1.5 hours via the Mussoorie-Dehradun hill road.</strong> One-way taxi fare starts at <strong>₹1,200 for Sedan (Dzire)</strong>, <strong>₹1,600 for SUV (Ertiga)</strong>, and <strong>₹2,000 for Innova Crysta</strong>. Anaya Cab Service provides 24x7 door-to-door hill drops from Dehradun Railway Station, ISBT, Rajpur Road, and Jolly Grant Airport to Mussoorie Mall Road, Library Chowk, Landour, and Kempty Falls with hill-certified drivers.</p>
</div>
</div>

<!-- ROUTE TIMELINE -->
<section class="ms-sec rv"><div class="ms-in">
<div class="ms-sh"><span class="ey"><i class="fa-solid fa-route"></i> The route</span><h2 class="disp">How the Dehradun to Mussoorie drive goes</h2><p>A short but scenic climb — our drivers know every turn and parking point.</p></div>
<div class="ms-rtl">
<div class="ms-rrow rv"><div class="ms-rdot"><i class="fa-solid fa-circle-dot"></i></div><div class="ms-rbody"><h3>Pickup in Dehradun</h3><p>From your hotel, home, the airport, railway station or ISBT — at the time you choose.</p></div></div>
<div class="ms-rrow rv"><div class="ms-rdot"><i class="fa-solid fa-road"></i></div><div class="ms-rbody"><h3>City exit &amp; hill approach</h3><p>Out of Dehradun toward the Rajpur / Mussoorie road, where the gradient begins to rise.</p></div></div>
<div class="ms-rrow rv"><div class="ms-rdot"><i class="fa-solid fa-mountain"></i></div><div class="ms-rbody"><h3>The winding hill road</h3><p>Hairpin bends and valley views — driven carefully, with extra caution in fog, rain or snow.</p></div></div>
<div class="ms-rrow rv"><div class="ms-rdot"><i class="fa-solid fa-location-dot"></i></div><div class="ms-rbody"><h3>Drop in Mussoorie</h3><p>At your hotel or sightseeing point around Mall Road, Library Chowk, Landour or Kempty Falls.</p></div></div>
</div>
</div></section>

<!-- SIGHTS -->
<section class="ms-sec ms-soft rv"><div class="ms-in">
<div class="ms-sh"><span class="ey"><i class="fa-solid fa-camera"></i> In Mussoorie</span><h2 class="disp">Popular Mussoorie destinations we drop you at</h2><p>Add local sightseeing to the same booking on a round trip.</p></div>
<div class="ms-sgrid">
<?php foreach ($__sights as $s): ?>
<div class="ms-sitem rv"><span class="ms-sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- PICKUP/DROP MATRIX -->
<section class="ms-sec rv"><div class="ms-in">
<div class="ms-sh"><span class="ey"><i class="fa-solid fa-map-location-dot"></i> Pickup &amp; drop</span><h2 class="disp">Common pickup and drop combinations</h2></div>
<div class="ms-twrap"><div class="ms-tscroll">
<table aria-label="Dehradun to Mussoorie pickup and drop points">
<thead><tr><th>Pickup in Dehradun</th><th>Drop in Mussoorie</th><th>Travel note</th></tr></thead>
<tbody>
<?php foreach ($__matrix as $m): ?>
<tr><td><strong><?php echo $m[0]; ?></strong></td><td><?php echo $m[1]; ?></td><td><?php echo $m[2]; ?></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
<div class="ms-prose">
<h2>Weekend &amp; hill-road travel advice</h2>
<p>Mussoorie sees its heaviest traffic on weekends, long holidays and snowfall days. For a smooth hotel check-in or a full day of sightseeing, an <strong>early-morning pickup from Dehradun</strong> is usually the smartest choice. Our drivers are familiar with the hill-road turns, one-way sections, parking restrictions and the common hotel access points around Mall Road, Landour and Library Chowk — and they plan for fog in winter and landslip risk in the monsoon.</p>
<p>Travelling with family or extra luggage? An <strong>SUV or Innova</strong> handles the climb more comfortably than a small hatchback, and for groups a <strong>Tempo Traveller</strong> can be arranged with advance notice. Whether you need a simple one-way drop or a round trip with Mussoorie sightseeing included, the fare is confirmed before you travel — no surprises on the hill road.</p>
</div>
</div></section>

<!-- RELATED ROUTES -->
<section class="ms-sec ms-soft rv"><div class="ms-in">
<div class="ms-sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other taxis travellers book with this</h2></div>
<div class="ms-rchips">
<?php foreach ($__related as $r): ?>
<a class="ms-rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</div></section>

<!-- FAQ -->
<section class="ms-sec rv" id="faq"><div class="ms-in">
<div class="ms-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Mussoorie taxi — FAQs</h2></div>
<div class="ms-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="ms-fi<?php echo $i===0?' open':''; ?>"><div class="ms-fh"><?php echo htmlspecialchars($f[0]); ?><span class="ms-ft"><i class="fa-solid fa-plus"></i></span></div><div class="ms-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- CTA -->
<section class="ms-cta rv"><div class="ms-in">
<div class="ms-ctain">
<h2 class="disp">Heading up to Mussoorie? Book your cab now</h2>
<p>Fixed fare, verified hill driver and pickup from anywhere in Dehradun — confirmed in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book this route</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Mussoorie taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ms .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ms .ms-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

