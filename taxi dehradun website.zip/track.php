<?php
/**
 * Anaya Cab — lightweight real-visitor tracker (public endpoint).
 * Receives sendBeacon POSTs from the footer snippet; logs page views + clicks.
 * Self-healing tables, bot filter, server-side UA parsing. No external deps.
 * Clean URL: footer posts to /track  (rule 6 rewrites /track -> track.php).
 */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store, no-cache, must-revalidate');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(204); exit; }

require_once __DIR__ . '/includes/config.php';

$raw = (string)file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? ($data['u'] ?? ''));
if ($ua === '' || preg_match('/bot|crawl|spider|slurp|headless|phantom|curl|wget|python|go-http|semrush|ahrefs|mj12bot/i', $ua)) { http_response_code(204); exit; }

if (!function_exists('db')) { http_response_code(204); exit; }
$pdo = db();
if (!$pdo) { http_response_code(204); exit; }

try {
$pdo->exec("CREATE TABLE IF NOT EXISTS `analytics_views` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `session_id` varchar(64) NOT NULL DEFAULT '',
 `path` varchar(500) NOT NULL DEFAULT '/',
 `ref_host` varchar(120) NOT NULL DEFAULT 'direct',
 `ip` varchar(64) NOT NULL DEFAULT '',
 `ua` varchar(500) NOT NULL DEFAULT '',
 `device` varchar(20) NOT NULL DEFAULT 'desktop',
 `browser` varchar(40) NOT NULL DEFAULT 'Other',
 `os` varchar(40) NOT NULL DEFAULT 'Other',
 `lang` varchar(16) NOT NULL DEFAULT '',
 `screen_w` int(11) NOT NULL DEFAULT 0,
 `screen_h` int(11) NOT NULL DEFAULT 0,
 `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`), KEY `idx_av_created` (`created_at`), KEY `idx_av_path` (`path`(191)), KEY `idx_av_session` (`session_id`), KEY `idx_av_ref` (`ref_host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
$pdo->exec("CREATE TABLE IF NOT EXISTS `analytics_clicks` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `session_id` varchar(64) NOT NULL DEFAULT '',
 `type` varchar(20) NOT NULL DEFAULT 'link',
 `label` varchar(120) NOT NULL DEFAULT '',
 `href` varchar(500) NOT NULL DEFAULT '',
 `path` varchar(500) NOT NULL DEFAULT '/',
 `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`), KEY `idx_ac_created` (`created_at`), KEY `idx_ac_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (Throwable $e) { http_response_code(204); exit; }

function trk_ua(string $ua): array {
    if (preg_match('/tablet|ipad|playbook|silk/i', $ua)) $device = 'tablet';
    elseif (preg_match('/mobile|iphone|ipod|opera mini|iemobile|android.*mobile/i', $ua)) $device = 'mobile';
    else $device = 'desktop';
    if (preg_match('/edg\//i', $ua)) $br = 'Edge';
    elseif (preg_match('/opr\/|opera/i', $ua)) $br = 'Opera';
    elseif (preg_match('/chrome\//i', $ua)) $br = 'Chrome';
    elseif (preg_match('/safari\//i', $ua)) $br = 'Safari';
    elseif (preg_match('/firefox\//i', $ua)) $br = 'Firefox';
    else $br = 'Other';
    if (preg_match('/windows/i', $ua)) $os = 'Windows';
    elseif (preg_match('/android/i', $ua)) $os = 'Android';
    elseif (preg_match('/iphone|ipad|ipod/i', $ua)) $os = 'iOS';
    elseif (preg_match('/mac/i', $ua)) $os = 'macOS';
    elseif (preg_match('/linux/i', $ua)) $os = 'Linux';
    else $os = 'Other';
    return [$device, $br, $os];
}

$sid = (string)($data['s'] ?? '');
$sid = substr(preg_replace('/[^a-z0-9]/', '', $sid), 0, 64);
if ($sid === '') $sid = 'x';
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
list($device, $br, $os) = trk_ua($ua);

$type = (string)($data['t'] ?? 'view');
try {
if ($type === 'click') {
    $cat   = substr(preg_replace('/[^a-z0-9_-]/', '', (string)($data['cat'] ?? 'link')), 0, 20);
    $label = substr((string)($data['label'] ?? ''), 0, 120);
    $href  = substr((string)($data['href'] ?? ''), 0, 500);
    $path  = substr((string)($data['p'] ?? '/'), 0, 500);
    $st = $pdo->prepare('INSERT INTO analytics_clicks (session_id,type,label,href,path,created_at) VALUES (?,?,?,?,?,NOW())');
    $st->execute([$sid, $cat, $label, $href, $path === '' ? '/' : $path]);
} else {
    $path = (string)($data['p'] ?? '/'); if ($path === '') $path = '/';
    $ref  = (string)($data['r'] ?? '');
    $refhost = 'direct';
    if ($ref !== '') {
        $h = parse_url($ref, PHP_URL_HOST);
        if (is_string($h) && $h !== '') {
            $refhost = strtolower(preg_replace('/^www\./', '', $h));
            if (isset($_SERVER['HTTP_HOST']) && $refhost === strtolower((string)$_SERVER['HTTP_HOST'])) $refhost = 'internal';
        }
    }
    $lang = substr((string)($data['l'] ?? ''), 0, 16);
    $sw = (int)($data['sw'] ?? 0); $sh = (int)($data['sh'] ?? 0);
    $st = $pdo->prepare('INSERT INTO analytics_views (session_id,path,ref_host,ip,ua,device,browser,os,lang,screen_w,screen_h,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())');
    $st->execute([$sid, substr($path, 0, 500), substr($refhost, 0, 120), substr($ip, 0, 64), substr($ua, 0, 500), $device, $br, $os, $lang, $sw, $sh]);
}
} catch (Throwable $e) { /* silent */ }
http_response_code(204);
exit;