<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$V = [
'slug'=>'luxury-car-rental-dehradun','name'=>'Luxury Car Rental in Dehradun','short'=>'Luxury Cars','cls'=>'Chauffeur-driven · Crysta & premium sedans',
'char'=>'Chauffeur-driven · VIP etiquette','char_icon'=>'fa-crown','glyph'=>'fa-car-side','img'=>'/assets/images/fleet/innova-crysta.webp',
'ac'=>'#b08a2e','ac2'=>'#e6c86e','d1'=>'#171310','d2'=>'#3a2f1b','tint'=>'#faf6ec',
'headline'=>'Arrive like you mean it',
'lead'=>'Book luxury car rental in Dehradun with a professional chauffeur — Innova Crysta and premium sedans for VIP airport meets, corporate roadshows, wedding arrivals and private outstation tours, with immaculate cars, discreet drivers and a fixed quote before the keys turn.',
'pax'=>'3–7','bags'=>'4–6','rate_range'=>'From ₹3,000 / day',
'service_type'=>'Chauffeur-driven luxury car rental','offers_price'=>'3000','offer_desc'=>'Chauffeur-driven luxury car rental in Dehradun from approx. ₹3,000 per day for premium sedans; Innova Crysta and Urbania priced by usage.',
'area'=>['Dehradun','Delhi','Chandigarh','Mussoorie','Uttarakhand'],
'best_for'=>[
['fa-plane-departure','VIP airport meet & greet','Driver with name board at Jolly Grant or Delhi IGI arrivals, flight tracking and door-side luggage help.'],
['fa-briefcase','Corporate & business travel','Quiet cabins for calls, punctual multi-meeting schedules and monthly corporate billing with GST invoices.'],
['fa-ring','Wedding & celebration arrivals','Polished cars for the couple and family, coordinated with your event timeline and decorators.'],
['fa-mountain-sun','Private premium tours','Crysta comfort for Mussoorie weekends, Char Dham VIP yatras and outstation circuits at your pace.'],
],
'compare_title'=>'Which premium car fits your day?',
'compare'=>[['Premium sedan','3–4 passengers','Business meetings, airport transfers','₹3,000–₹3,500 / day'],['Innova Crysta','6–7 passengers','Family tours, VIP yatra, corporate groups','₹4,000–₹5,000 / day'],['Force Urbania','~13 passengers','Premium group tours and delegations','₹9,000–₹12,000 / day']],
'routes'=>[['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Wedding cars','/wedding-car-rental-dehradun'],['Char Dham Yatra','/char-dham-yatra-taxi'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Force Urbania','/force-urbania-rental-dehradun']],
'use_cases'=>['VIP airport meet & greet','Corporate roadshows & delegations','Wedding & celebration arrivals','Private outstation tours','Hotel & event guest shuttles','Film & media crew movement'],
'faqs'=>[
['Which luxury cars are available in Dehradun?','Innova Crysta for 6 to 7 passengers, premium sedans for 3 to 4, and Force Urbania for premium groups of around 13. Every car is chauffeur-driven, immaculately maintained and passes our quality checks before your trip.'],
['Is luxury car rental self-drive or with driver?','Chauffeur-driven only. Our drivers are trained for VIP etiquette — punctual, formally dressed, discreet on calls and conversations, and careful with luggage and doors.'],
['Can companies book monthly corporate contracts?','Yes. Corporate retainers include priority cars, a standby backup vehicle, monthly GST invoicing and a single point of contact for all travel planning.'],
['How far in advance should I book?','For airport meets and business days, 24 hours is usually enough. For weddings, delegations and peak-season tours, book 48 to 72 hours ahead to lock your preferred car.'],
],
'title'=>'Luxury Car Rental in Dehradun | Chauffeur-Driven Premium Cars - Anaya Cab',
'desc'=>'Book luxury car rental in Dehradun with professional chauffeurs. Innova Crysta, premium sedans & Urbania for VIP airport, corporate, weddings & tours. From ₹3,000/day. Call '.$phone.'.',
];
$page_url = $domain . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];
require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<style>
.vp-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line,#e7edf6);border-left:4px solid var(--vp-ac,#b08a2e);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.vp-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--vp-ac,#b08a2e);margin-bottom:8px}
.vp-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.vp-qa strong{color:#0b1220}
</style>
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-crown"></i><b>Chauffeur</b><span>driven</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>Crysta</b><span>& sedans</span></span>
<span class="vp-m"><i class="fa-solid fa-user-tie"></i><b>Corporate</b><span>billing</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b>₹3,000+</b><span>per day</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/fleet"><i class="fa-solid fa-car"></i> See fleet</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Premium fleet</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?>" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>premium sedan</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="vp-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Luxury car rental in Dehradun</strong> is chauffeur-driven only — <strong>Innova Crysta from about ₹4,000/day</strong> and <strong>premium sedans from about ₹3,000/day</strong>, used for VIP airport meets at Jolly Grant and Delhi IGI, corporate travel, wedding arrivals and private outstation tours, with GST invoicing available for companies.</p>
</div>
</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where the premium fleet earns its keep</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2><p>Indicative day rates with chauffeur — final quote confirmed before booking.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th><th>Day rate</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td><td class="fare"><?php echo htmlspecialchars($c[3]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> The luxury standard</span><h2 class="disp">What premium actually means here</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">Luxury is not a badge on the door — it is a standard kept on every single trip. Cars in this fleet are under five years old, deep-cleaned before your day, and the AC is chilled before pickup, not after. The chauffeur arrives in formal dress, opens doors, handles luggage door-side, and stays discreet through your calls and conversations. If a car ever falls short of the standard on the day, a standby vehicle is dispatched — that is the promise behind the crown.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">For companies, the value is in the system, not just the car. Monthly retainers come with priority vehicles, a backup car on standby, a single point of contact for planning, and clean GST invoicing at month end. Delegation schedules change at the last minute; our drivers are trained to absorb those changes calmly, whether it is a shifted meeting in Dehradun, an extra stop in Rajpur Road, or a 5 am departure for Delhi IGI with flight tracking already on.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">Booking is deliberately simple and transparent. You get a fixed quote before confirmation, driver name and number shared the night before, and the same accountable desk on WhatsApp through the trip. Whether it is a wedding baraat coordination with your decorators, a CEO's two-day Uttarakhand circuit, or a family Crysta tour of Mussoorie and Dhanaulti, the experience is the same: punctual, polished, and quietly handled.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Cars under five years old, deep-cleaned, AC chilled before pickup.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Chauffeurs trained in VIP etiquette — formal dress, door service, discretion.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Corporate retainers with standby backup and monthly GST invoicing.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Fixed quote before confirmation; driver details shared the night before.</li>
</ul>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular premium bookings</span><h2 class="disp">Where clients take the fleet</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This service is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your date, route and car preference — we confirm a fixed premium quote before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>