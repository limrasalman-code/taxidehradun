/* ═══════════════════════════════════════════════════════════
   ANAYA CAB SERVICE — PWA Service Worker v2 (NETWORK-FIRST)
   Option B: Real installable PWA + guaranteed fresh content.

   Strategy:
   • HTML pages  -> NETWORK-FIRST (hamesha fresh, offline pe cache fallback)
   • Images      -> CACHE-FIRST (fast load, offline ready)
   • CSS/JS/font -> STALE-WHILE-REVALIDATE (instant + background update)
   • /api/, /admin, POST -> KABHI cache NAHI (booking data safe)

   Fresh-content guarantee: pages network se aati hain, isliye deploy
   ke baad naya fare/blog turant dikhega — stale page ka risk NAHI.
   ═══════════════════════════════════════════════════════════ */

const VERSION = 'anaya-v2-2026';
const CACHE_STATIC = VERSION + '-static';   // css/js/fonts
const CACHE_PAGES  = VERSION + '-pages';    // html
const CACHE_IMAGES = VERSION + '-images';   // webp/jpg/png

/* Offline ke liye minimal shell (sirf homepage) */
const OFFLINE_SHELL = ['/', '/offline-fallback'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_STATIC)
      .then((cache) => cache.addAll(['/', '/assets/css/theme.css']).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Sirf same-origin GET handle karo
  if (url.origin !== self.location.origin) return;
  if (req.method !== 'GET') return;

  // Booking API + admin KABHI cache nahi
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/admin')) return;

  // Navigation / HTML pages -> network-first
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(networkFirst(req, CACHE_PAGES));
    return;
  }

  // Images -> cache-first
  if (/\.(webp|avif|jpg|jpeg|png|gif|svg|ico)$/i.test(url.pathname)) {
    event.respondWith(cacheFirst(req, CACHE_IMAGES));
    return;
  }

  // CSS / JS / fonts -> stale-while-revalidate
  if (/\.(css|js|mjs|woff2?|ttf|otf)$/i.test(url.pathname)) {
    event.respondWith(staleWhileRevalidate(req, CACHE_STATIC));
    return;
  }
});

/* ── Strategies ─────────────────────────────────────────── */
async function networkFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const fresh = await fetch(req);
    if (fresh && fresh.ok) cache.put(req, fresh.clone());
    return fresh;
  } catch (err) {
    const cached = await cache.match(req);
    if (cached) return cached;
    // Offline + page cache nahi -> homepage shell dikhao
    const shell = await cache.match('/');
    if (shell) return shell;
    return new Response('<h1 style="font-family:sans-serif;text-align:center;padding:40px">Offline — please check your connection</h1>', {
      status: 503, headers: { 'Content-Type': 'text/html' }
    });
  }
}

async function cacheFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(req);
  if (cached) return cached;
  try {
    const fresh = await fetch(req);
    if (fresh && fresh.ok) cache.put(req, fresh.clone());
    return fresh;
  } catch (err) {
    return new Response('', { status: 404 });
  }
}

async function staleWhileRevalidate(req, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(req);
  const network = fetch(req).then((fresh) => {
    if (fresh && fresh.ok) cache.put(req, fresh.clone());
    return fresh;
  }).catch(() => cached);
  return cached || network;
}