﻿<?php
require_once __DIR__ . '/includes/config.php';
$domain    = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone     = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp  = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = "Dehradun Local Sightseeing Taxi | Day Tours - Anaya Cab";
$page_description = 'Dehradun sightseeing taxi for Robbers Cave, FRI, Sahastradhara, Tapkeshwar & Mussoorie.';
$page_url         = $domain . "/dehradun-local-sightseeing-taxi";

/* ---------- data ---------- */
$__pkgs = [
['Half-Day City Tour','4 hr / 40 km','fa-sun','Best for a quick taste of Dehradun — 2-3 highlights before dinner.',
 [['Hatchback','₹900'],['Sedan','₹1,100'],['Ertiga','₹1,350'],['Innova Crysta','₹1,600']]],
['Full-Day Sightseeing','8 hr / 80 km','fa-mountain-sun','The complete Doon Valley loop — caves, ghats, temples and monasteries.',
 [['Hatchback','₹1,600'],['Sedan','₹1,900'],['Ertiga','₹2,300'],['Innova Crysta','₹2,800']]],
];
$__circuits = [
['Family Fun Day','6–7 hr','fa-people-roof','Kids-first loop with caves, deer park and the waterfall ghats.',
 ['Robber\'s Cave (Guchhupani)','Malsi Deer Park','Sahastradhara ghats','Fun Valley amusement stop']],
['Spiritual Circuit','5–6 hr','fa-om','Temple-and-monastery trail across the Doon — calm, early start.',
 ['Tapkeshwar Mahadev Temple','Guru Ram Rai Darbar Sahib','Mindrolling Monastery','Santala Devi temple (optional)']],
['Nature & Colonial','6 hr','fa-tree','Forest institute boulevards, picnic spots and river-side calm.',
 ['Forest Research Institute (FRI)','Lachhiwala picnic spot','Botanical garden walk','Rajaji nature fringe stop']],
];
$__spots = [
['Robber\'s Cave','Guchhupani','Walk-in river cave with a hidden waterfall — Dehradun\'s signature natural wonder.','Morning','fa-water'],
['Sahastradhara','Thousand springs','Sulphur springs and rope-way views at the Baldi river confluence.','Mid-day','fa-mountain-sun'],
['Tapkeshwar Temple','Cave shrine','Ancient Shiva cave where a natural spring drips on the lingam.','Early AM','fa-om'],
['Mindrolling Monastery','Buddhist landmark','One of India\'s largest Buddhist centres — 35 m Buddha statue and gardens.','Afternoon','fa-dharmachakra'],
['Forest Research Institute','Colonial campus','Greco-Roman FRI campus with museums and tree-lined boulevards.','Late PM','fa-building-columns'],
['Malsi Deer Park','Family park','Small deer park at the Mussoorie foothills — perfect with kids.','Evening','fa-paw'],
];
$__faqs = [
['How much does a Dehradun local sightseeing taxi cost?','A half-day 4-hour/40 km sightseeing taxi starts at Rs 900 in a hatchback and Rs 1,100 in a sedan; a full-day 8-hour/80 km tour starts at Rs 1,600 and Rs 1,900 respectively. Ertiga and Innova Crysta rates are in the fare table below.'],
['Which places are covered in the full-day Dehradun sightseeing tour?','The full-day tour typically covers Robber\'s Cave, Sahastradhara, Tapkeshwar Temple, Mindrolling Monastery, the Forest Research Institute and Lachhiwala or Malsi Deer Park — or any custom mix you choose within 8 hours and 80 km.'],
['Can I customize the sightseeing itinerary?','Yes. The itinerary is flexible — tell the driver your preferred stops at pickup and they will plan the fastest loop within your booked hours and kilometres.'],
['Is a Tempo Traveller available for group sightseeing in Dehradun?','Yes, 12-17 seater Tempo Travellers and Force Urbania are available for family, school and corporate group tours — see the group section below or the Tempo Traveller page.'],
['Are entry tickets and parking included in the fare?','The fare covers the cab and driver only. Attraction entry tickets, parking and any tolls are extra at actuals and are shared upfront before you book.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__attr_actions = [];
$__spot_geo = [
'Robber\'s Cave'=>['30.3455','78.0889'],'Sahastradhara'=>['30.3636','78.0833'],'Tapkeshwar Temple'=>['30.3679','78.0713'],
'Mindrolling Monastery'=>['30.2849','78.0008'],'Forest Research Institute'=>['30.3180','78.0080'],'Malsi Deer Park'=>['30.3830','78.0560'],
];
foreach ($__spots as $s) {
    $node = ['@type'=>'TouristAttraction','name'=>$s[0],'description'=>$s[2]];
    if (isset($__spot_geo[$s[0]])) { $node['geo'] = ['@type'=>'GeoCoordinates','latitude'=>$__spot_geo[$s[0]][0],'longitude'=>$__spot_geo[$s[0]][1]]; }
    $__attr_actions[] = $node;
}
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun Local Sightseeing Taxi Packages','serviceType'=>'Local sightseeing taxi tours',
 'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun']],'url'=>$page_url,
 'offers'=>[
  ['@type'=>'Offer','priceCurrency'=>'INR','price'=>'900','description'=>'Half-day 4 hour / 40 km sightseeing taxi, hatchback, from Rs 900.'],
  ['@type'=>'Offer','priceCurrency'=>'INR','price'=>'1600','description'=>'Full-day 8 hour / 80 km sightseeing taxi, hatchback, from Rs 1600.'],
 ]],
['@type'=>'ItemList','@id'=>$page_url.'#attractions','name'=>'Popular Dehradun sightseeing stops','numberOfItems'=>count($__attr_actions),'itemListElement'=>array_values($__attr_actions)],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';

require_once __DIR__ . '/includes/header.php';
?>
<main id="main">
<style>
.sg{--blue:#0057ff;--cyan:#00c2ff;--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--cloud:#f5f8ff;--green:#16a34a;--gold:#c9821a;--r:20px;--rs:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef4fc 0%,#fff 480px)}
.sg *{box-sizing:border-box}
.sg .sg-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.sg .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.sg .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.sg .rv.in{opacity:1;transform:none}
.sg .sg-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.sg .sg-crumb a{color:var(--slate);text-decoration:none}.sg .sg-crumb a:hover{color:var(--blue)}.sg .sg-crumb i{font-size:.6rem;color:#94a3b8}.sg .sg-crumb .cur{color:var(--ink);font-weight:600}
.sg .sg-hero{display:grid;grid-template-columns:1.15fr .95fr;gap:36px;align-items:start;padding:24px 0 12px}
.sg .sg-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.sg .sg-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.4vw,3rem);font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:14px 0 14px}.sg .sg-hero h1 em{font-style:normal;color:var(--blue)}
.sg .sg-qa{background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:18px 20px;box-shadow:0 18px 40px -26px rgba(9,32,84,.25);margin:0 0 20px}
.sg .sg-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.sg .sg-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.96rem}.sg .sg-qa strong{color:var(--ink)}
.sg .sg-cta{display:flex;gap:12px;flex-wrap:wrap}
.sg .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rs);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.sg .btn-b{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.sg .btn-b:hover{transform:translateY(-2px);filter:brightness(1.06)}
.sg .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.sg .btn-g:hover{transform:translateY(-2px)}
.sg .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.sg .btn-o:hover{border-color:var(--blue);color:var(--blue)}
/* tour line card */
.sg .tour{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(3,16,46,.6);overflow:hidden}
.sg .tour::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(0,194,255,.3),transparent 70%)}
.sg .tour .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#9fe0ff;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.sg .tour h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 16px;position:relative}
.sg .tour .line{position:relative;padding-left:26px}
.sg .tour .line::before{content:"";position:absolute;left:8px;top:6px;bottom:6px;width:2px;background:repeating-linear-gradient(180deg,rgba(255,255,255,.5) 0 8px,transparent 8px 16px)}
.sg .tour .stop{position:relative;padding:0 0 16px}
.sg .tour .stop:last-child{padding-bottom:0}
.sg .tour .stop::before{content:"";position:absolute;left:-22px;top:6px;width:10px;height:10px;border-radius:50%;background:#fff;box-shadow:0 0 0 4px rgba(255,255,255,.2)}
.sg .tour .stop b{display:block;font-size:.92rem}
.sg .tour .stop span{font-size:.76rem;color:rgba(255,255,255,.72)}
.sg .tour .cab{position:absolute;left:1px;top:0;color:#ffd34d;font-size:.95rem;animation:sgcab 7s ease-in-out infinite}
@keyframes sgcab{0%{top:0}50%{top:calc(100% - 20px)}100%{top:0}}
.sg .sec{padding:50px 0}
.sg .sh{text-align:center;max-width:720px;margin:0 auto 30px}.sg .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}.sg .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.sg .sh p{color:var(--slate);margin:0}
.sg .pkgrid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.sg .pk{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:26px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.sg .pk::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--blue),var(--cyan));transform:scaleX(0);transform-origin:left;transition:transform .4s}
.sg .pk:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3);border-color:#cfe0ff}.sg .pk:hover::after{transform:scaleX(1)}
.sg .pk .hd{display:flex;align-items:center;gap:14px;margin-bottom:6px}
.sg .pk .ic{flex:none;width:50px;height:50px;border-radius:14px;background:rgba(0,87,255,.08);color:var(--blue);display:grid;place-items:center;font-size:1.15rem}
.sg .pk h3{font-family:'Sora','Poppins',sans-serif;font-size:1.15rem;font-weight:800;margin:0}
.sg .pk .dur{font-size:.78rem;color:var(--blue);font-weight:700}
.sg .pk p{color:var(--slate);font-size:.9rem;line-height:1.6;margin:6px 0 16px}
.sg .pk table{width:100%;border-collapse:collapse}
.sg .pk td{padding:9px 10px;border-top:1px solid var(--line);font-size:.9rem}
.sg .pk td:last-child{text-align:right;font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}
.sg .pk .note{font-size:.74rem;color:#94a3b8;margin-top:12px}
.sg .cgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.sg .cc{background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:24px;transition:transform .35s,box-shadow .35s,border-color .35s}
.sg .cc:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3);border-color:#cfe0ff}
.sg .cc .ic{width:48px;height:48px;border-radius:13px;background:rgba(0,87,255,.08);color:var(--blue);display:grid;place-items:center;font-size:1.1rem;margin-bottom:14px}
.sg .cc h3{font-family:'Sora','Poppins',sans-serif;font-size:1.05rem;font-weight:800;margin:0 0 2px}
.sg .cc .dur{font-size:.76rem;color:var(--blue);font-weight:700}
.sg .cc p{color:var(--slate);font-size:.88rem;line-height:1.6;margin:8px 0 12px}
.sg .cc ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}
.sg .cc li{display:flex;gap:9px;font-size:.86rem;color:var(--slate)}.sg .cc li i{color:var(--green);margin-top:3px}
.sg .sgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.sg .sc{background:#fff;border:1px solid var(--line);border-radius:var(--rs);padding:20px;transition:transform .3s,box-shadow .3s}
.sg .sc:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28)}
.sg .sc .tp{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.sg .sc .ic{width:42px;height:42px;border-radius:12px;background:rgba(0,87,255,.08);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.sg .sc .bt{font-size:.68rem;font-weight:800;color:var(--gold);background:rgba(201,130,26,.1);padding:5px 10px;border-radius:999px}
.sg .sc h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:800;margin:0 0 2px}
.sg .sc .alt{font-size:.74rem;color:#94a3b8;margin:0 0 8px}
.sg .sc p{color:var(--slate);font-size:.86rem;line-height:1.6;margin:0}
.sg .grp{background:linear-gradient(135deg,#03102e,#0a2a63);border-radius:26px;padding:36px;color:#fff;display:grid;grid-template-columns:1.1fr .9fr;gap:30px;align-items:center;position:relative;overflow:hidden}
.sg .grp::before{content:"";position:absolute;top:-80px;right:-60px;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(37,211,102,.25),transparent 70%)}
.sg .grp h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.4rem,2.8vw,1.9rem);font-weight:800;margin:0 0 10px;position:relative}
.sg .grp p{color:rgba(255,255,255,.82);line-height:1.7;margin:0 0 18px;position:relative}
.sg .grp .row{display:flex;gap:12px;flex-wrap:wrap;position:relative}
.sg .grp .bus{font-size:5rem;color:rgba(255,255,255,.25);text-align:center}
.sg .fbox{max-width:820px;margin:0 auto}
.sg .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rs);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.sg .fi:hover{border-color:#cfe0ff}
.sg .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.sg .ft{flex:none;width:26px;height:26px;border-radius:8px;background:rgba(0,87,255,.08);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.sg .fi.open .ft{transform:rotate(45deg)}
.sg .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.sg .fi.open .fb{max-height:400px;padding:0 20px 18px}
.sg .chips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.sg .chip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1.5px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:700;font-size:.9rem;color:var(--ink);text-decoration:none;transition:.25s}
.sg .chip i{color:var(--blue)}.sg .chip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-3px);box-shadow:0 14px 30px -12px rgba(0,87,255,.35)}
.sg .cta2{padding:0 0 70px}
.sg .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--cyan),transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.sg .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.sg .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}
.sg .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.sg .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}
.sg .cta2 .w{background:#fff;color:#0057ff}.sg .cta2 .g{background:#25d366;color:#04260f}.sg .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.sg .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:960px){.sg .sg-hero{grid-template-columns:1fr}.sg .tour{position:static}.sg .pkgrid{grid-template-columns:1fr}.sg .cgrid{grid-template-columns:1fr}.sg .sgrid{grid-template-columns:1fr 1fr}.sg .grp{grid-template-columns:1fr}}
@media(max-width:560px){.sg .sgrid{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.sg *{transition:none!important;animation:none!important}.sg .rv{opacity:1!important;transform:none!important}}
</style>
<div class="sg"><div class="sg-in">
<nav class="sg-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Local Sightseeing Taxi</span></nav>

<section class="sg-hero">
<div class="rv">
<span class="sg-ey"><i class="fa-solid fa-map-location-dot"></i> Doon Valley day tours</span>
<h1 class="disp">Dehradun Local Sightseeing <em>Taxi Packages</em> — one day, every highlight</h1>
<div class="sg-qa"><div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p>A Dehradun local sightseeing taxi starts at <strong>₹900 for a 4-hour/40 km half-day tour</strong> and <strong>₹1,600 for a full 8-hour/80 km day</strong> in a hatchback; sedans start at ₹1,100 and ₹1,900. Tours cover <strong>Robber's Cave, Sahastradhara, Tapkeshwar Temple, Mindrolling Monastery and FRI</strong> with a verified driver and a fixed fare.</p></div>
<div class="sg-cta">
<a class="btn btn-b" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a day tour</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun local sightseeing taxi package.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-indian-rupee-sign"></i> See all fares</a>
</div>
</div>
<aside class="tour rv" aria-label="Sample full-day sightseeing route">
<span class="tag"><i class="fa-solid fa-route"></i> Sample full-day loop</span>
<h3 class="disp">8 hr / 80 km — the classic</h3>
<div class="line">
<i class="fa-solid fa-taxi cab" aria-hidden="true"></i>
<div class="stop"><b>Robber's Cave</b><span>River cave walk · 90 min</span></div>
<div class="stop"><b>Sahastradhara</b><span>Springs & rope-way · 60 min</span></div>
<div class="stop"><b>Tapkeshwar Temple</b><span>Cave shrine darshan · 45 min</span></div>
<div class="stop"><b>Mindrolling Monastery</b><span>Buddha statue & gardens · 60 min</span></div>
<div class="stop"><b>FRI Campus</b><span>Colonial boulevards · 60 min</span></div>
<div class="stop"><b>Malsi Deer Park</b><span>Family stop · 45 min</span></div>
</div>
</aside>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-tags"></i> Packages</span><h2 class="disp">Half-day or full-day — pick your pace</h2><p>Fixed package rates by vehicle. Extra km at standard per-km rates; extra hours ₹150/hr.</p></div>
<div class="pkgrid">
<?php foreach ($__pkgs as $pk): ?>
<div class="pk rv">
<div class="hd"><span class="ic"><i class="fa-solid <?php echo $pk[2]; ?>"></i></span><div><h3><?php echo $pk[0]; ?></h3><span class="dur"><?php echo $pk[1]; ?></span></div></div>
<p><?php echo $pk[3]; ?></p>
<table><?php foreach ($pk[4] as $row): ?><tr><td><?php echo $row[0]; ?></td><td><?php echo $row[1]; ?></td></tr><?php endforeach; ?></table>
<div class="note">Fare covers cab + driver. Entry tickets, parking & tolls extra at actuals.</div>
</div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-compass"></i> Themed circuits</span><h2 class="disp">Three ready-made itineraries</h2><p>Or mix your own — the driver plans the fastest loop within your hours.</p></div>
<div class="cgrid">
<?php foreach ($__circuits as $c): ?>
<div class="cc rv">
<span class="ic"><i class="fa-solid <?php echo $c[2]; ?>"></i></span>
<h3><?php echo $c[0]; ?></h3><span class="dur"><?php echo $c[1]; ?></span>
<p><?php echo $c[3]; ?></p>
<ul><?php foreach ($c[4] as $st): ?><li><i class="fa-solid fa-circle-check"></i> <?php echo $st; ?></li><?php endforeach; ?></ul>
</div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-star"></i> The highlights</span><h2 class="disp">Six stops Dehradun is known for</h2></div>
<div class="sgrid">
<?php foreach ($__spots as $s): ?>
<div class="sc rv">
<div class="tp"><span class="ic"><i class="fa-solid <?php echo $s[4]; ?>"></i></span><span class="bt">Best: <?php echo $s[3]; ?></span></div>
<h3><?php echo $s[0]; ?></h3><p class="alt"><?php echo $s[1]; ?></p>
<p><?php echo $s[2]; ?></p>
</div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="grp">
<div>
<h2 class="disp">Group sightseeing? Take a Tempo Traveller.</h2>
<p>For family functions, school trips and corporate outings, a 12-17 seater Tempo Traveller or Force Urbania keeps the whole group in one cab — with the same fixed package rates and a verified driver.</p>
<div class="row">
<a class="btn btn-b" href="/tempo-traveller-in-dehradun"><i class="fa-solid fa-bus-simple"></i> Tempo Traveller page</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need a Tempo Traveller for group sightseeing in Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Group quote</a>
</div>
</div>
<div class="bus"><i class="fa-solid fa-bus-simple"></i></div>
</div></section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Sightseeing taxi — quick answers</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Keep exploring</span><h2 class="disp">Pair your day tour with</h2></div>
<div class="chips">
<a class="chip" href="/local-taxi-in-dehradun"><i class="fa-solid fa-taxi"></i> Hourly city taxi</a>
<a class="chip" href="/dehradun-to-mussoorie-taxi"><i class="fa-solid fa-mountain-sun"></i> Mussoorie day trip</a>
<a class="chip" href="/dehradun-airport-taxi-service"><i class="fa-solid fa-plane-departure"></i> Airport transfer</a>
<a class="chip" href="/char-dham-yatra-taxi"><i class="fa-solid fa-om"></i> Char Dham Yatra</a>
</div>
</section>

<section class="cta2 rv"><div class="ctain">
<h2 class="disp">Ready for a full day in the Doon Valley?</h2>
<p>Share your date and group size — we confirm a fixed package fare in minutes.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a day tour</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun local sightseeing taxi package.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></section>
</div></div>
</main>
<script>
(function(){var r=document.querySelectorAll('.sg .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.sg .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>