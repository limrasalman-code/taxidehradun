﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title       = "Photo Gallery | Fleet & Tour Highlights - Anaya Cab";
$page_description = "Explore Anaya Cab Service photo gallery: modern sanitized fleet, Dzire, Ertiga, Innova Crysta, Tempo Traveller, Mussoorie & Char Dham tours. Call " .";
$page_url         = $domain . "/gallery";

$gallery_items = [
    [
        'title' => 'Maruti Suzuki Dzire AC Sedan',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-dzire-pro-v4.png',
        'caption' => 'Comfortable 4-passenger AC sedan for Dehradun city rides, airport drops and outstation travel.'
    ],
    [
        'title' => 'Maruti Suzuki Ertiga 6-Seater SUV',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-ertiga-pro-v4.png',
        'caption' => 'Spacious family 6-seater SUV with ample luggage space and rear AC blowers.'
    ],
    [
        'title' => 'Toyota Innova Crysta Luxury MPV',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-innova-crysta-pro-v4.png',
        'caption' => 'Premium luxury MPV with plush captain seats, ideal for long outstation journeys and Char Dham Yatra.'
    ],
    [
        'title' => 'Force Tempo Traveller (12–17 Seater)',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-tempo-pro-v4.png',
        'caption' => 'Luxury push-back reclining seats for large family groups, corporate outings and pilgrimage tours.'
    ],
    [
        'title' => 'Force Urbania Premium 13-Seater',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-urbania-pro-v4.png',
        'caption' => 'Ultra-luxury executive traveller van for weddings, VIP airport transfers and hill tours.'
    ],
    [
        'title' => 'Toyota Glanza Compact Hatchback',
        'category' => 'fleet',
        'img' => '/assets/images/fleet/slider-glanza-pro-v4.png',
        'caption' => 'Economical, nimble hatchback for quick city errands, railway station transfers and airport rides.'
    ],
    [
        'title' => 'Scenic Mountain Roads to Mussoorie',
        'category' => 'tours',
        'img' => '/assets/images/routes/dehradun-to-mussoorie-taxi.webp',
        'caption' => 'Scenic ghat highway connecting Dehradun to Mussoorie Mall Road and Kempty Falls.'
    ],
    [
        'title' => 'Char Dham Himalayan Pilgrimage Route',
        'category' => 'yatra',
        'img' => '/assets/images/routes/char-dham-yatra-taxi.webp',
        'caption' => 'Divine mountain circuit covering Yamunotri, Gangotri, Kedarnath, and Badrinath.'
    ],
    [
        'title' => 'Jolly Grant Airport Terminal Transfers',
        'category' => 'airport',
        'img' => '/assets/images/routes/dehradun-airport-taxi-guide.webp',
        'caption' => 'Punctual arrivals and departure pickups with real-time flight delay tracking.'
    ],
    [
        'title' => 'Rishikesh Ganga River Valley Drive',
        'category' => 'tours',
        'img' => '/assets/images/routes/dehradun-to-rishikesh-taxi.webp',
        'caption' => 'Smooth transit to Tapovan, Ram Jhula, yoga ashrams, and adventure rafting camps.'
    ],
    [
        'title' => 'Nainital & Kumaon Lake Tour',
        'category' => 'tours',
        'img' => '/assets/images/routes/dehradun-to-nainital-taxi.webp',
        'caption' => 'Long-distance scenic tour to Naini Lake, Bhimtal, and Kainchi Dham ashram.'
    ],
    [
        'title' => 'Auli Himalayan Snow Peaks Trip',
        'category' => 'tours',
        'img' => '/assets/images/routes/dehradun-to-auli-taxi.webp',
        'caption' => 'High-altitude mountain cab service for Joshimath, Auli skiing slopes, and ropeway.'
    ]
];

$__image_schema = [];
foreach ($gallery_items as $item) {
    $__image_schema[] = [
        '@type' => 'ImageObject',
        'contentUrl' => $domain . $item['img'],
        'name' => $item['title'],
        'description' => $item['caption']
    ];
}

$page_schema = '<script type="application/ld+json">'
. json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'ImageGallery',
            '@id' => $page_url . '#gallery',
            'name' => 'Anaya Cab Service Fleet & Tour Photo Gallery',
            'description' => 'Photo gallery showcasing Anaya Cab Service modern vehicle fleet, sanitized cabs, and scenic Uttarakhand tour destinations.',
            'url' => $page_url,
            'image' => $__image_schema
        ],
        [
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $domain . '/'],
                ['@type' => 'ListItem', 'position' => 2, 'name' => 'Photo Gallery', 'item' => $page_url]
            ]
        ]
    ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<style>
.gal-pg{--ink:#0b1220;--slate:#4b5874;--line:#e2eaf8;--blue:#0057ff;--blue-tint:#eef5ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#f0f6ff 0%,#ffffff 480px);padding:36px 0 60px}
.gal-pg *{box-sizing:border-box}
.gal-in{max-width:1240px;margin:0 auto;padding:0 24px}
.gal-head{text-align:center;max-width:760px;margin:0 auto 36px}
.gal-badge{display:inline-flex;align-items:center;gap:8px;font-size:0.76rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);border:1px solid rgba(0,87,255,0.18);padding:7px 16px;border-radius:999px;margin-bottom:14px}
.gal-head h1{font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:clamp(2.1rem,4.4vw,3.2rem);font-weight:800;letter-spacing:-0.035em;line-height:1.1;margin:0 0 14px;color:#07142f}
.gal-head h1 em{font-style:normal;color:var(--blue)}
.gal-head p{color:var(--slate);font-size:1.05rem;line-height:1.68;margin:0}
.gal-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:24px;margin-top:28px}
.gal-card{background:#ffffff;border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:0 6px 20px rgba(11,18,32,0.04);transition:transform 0.25s cubic-bezier(0.16,1,0.3,1),box-shadow 0.25s;display:flex;flex-direction:column}
.gal-card:hover{transform:translateY(-4px);box-shadow:0 14px 36px -10px rgba(0,87,255,0.2);border-color:rgba(0,87,255,0.3)}
.gal-img-wrap{position:relative;width:100%;height:220px;background:#f8fafc;overflow:hidden;display:flex;align-items:center;justify-content:center}
.gal-img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform 0.4s ease}
.gal-card:hover .gal-img-wrap img{transform:scale(1.05)}
.gal-body{padding:20px 22px;flex:1;display:flex;flex-direction:column;justify-content:space-between}
.gal-body h3{font-family:'Sora',sans-serif;font-size:1.15rem;font-weight:800;color:#07142f;margin:0 0 8px}
.gal-body p{color:var(--slate);font-size:0.92rem;line-height:1.55;margin:0}
.gal-cta-bar{background:linear-gradient(135deg,#07142f 0%,#0a2a63 100%);border-radius:24px;padding:36px 40px;color:#ffffff;margin-top:54px;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap;box-shadow:0 24px 60px -20px rgba(7,20,47,0.4)}
.gal-cta-bar h2{font-family:'Sora',sans-serif;font-size:1.8rem;font-weight:800;margin:0 0 8px}
.gal-cta-bar p{color:rgba(255,255,255,0.85);font-size:1rem;margin:0}
.gal-btns{display:flex;gap:12px;flex-wrap:wrap}
.gal-btn-p{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;border-radius:14px;background:linear-gradient(135deg,#0057ff,#00c2ff);color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none;box-shadow:0 12px 30px -8px rgba(0,87,255,0.5)}
.gal-btn-w{display:inline-flex;align-items:center;gap:8px;padding:14px 24px;border-radius:14px;background:#25d366;color:#fff;font-family:'Sora',sans-serif;font-weight:700;text-decoration:none}
@media (max-width:768px){.gal-grid{grid-template-columns:1fr}.gal-cta-bar{padding:24px;text-align:center;justify-content:center}}
</style>

<div class="gal-pg">
    <div class="gal-in">
        <div class="gal-head">
            <span class="gal-badge"><i class="fa-solid fa-camera"></i> Verified Fleet & Tours</span>
            <h1>Anaya Cab <em>Photo Gallery</em></h1>
            <p>Take a look inside our clean, air-conditioned cabs and explore the scenic routes across Dehradun, Mussoorie, Rishikesh, and the sacred Char Dham Himalayas.</p>
        </div>

        <div class="gal-grid">
            <?php foreach ($gallery_items as $item): ?>
            <article class="gal-card">
                <div class="gal-img-wrap">
                    <img 
                        src="<?php echo htmlspecialchars($item['img']); ?>" 
                        alt="<?php echo htmlspecialchars($item['title']); ?>" 
                        loading="lazy" 
                        decoding="async"
                        onerror="this.src='/assets/images/fleet/slider-dzire-pro-v4.png'"
                    >
                </div>
                <div class="gal-body">
                    <div>
                        <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                        <p><?php echo htmlspecialchars($item['caption']); ?></p>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>

        <div class="gal-cta-bar">
            <div>
                <h2>Ready to Travel in Comfort?</h2>
                <p>Book your preferred vehicle with verified drivers and upfront fixed pricing.</p>
            </div>
            <div class="gal-btns">
                <a class="gal-btn-p" href="/#booking"><i class="fa-solid fa-car-side"></i> Book Taxi Online</a>
                <a class="gal-btn-w" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I saw your photo gallery and want to book a cab.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp Us</a>
            </div>
        </div>
    </div>
</div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
