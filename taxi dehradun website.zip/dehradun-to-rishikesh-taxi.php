<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Rishikesh Taxi Fare | Cab from ₹1,150';
$page_description = 'Dehradun to Rishikesh taxi from ₹1,150 (45 km, 1 hr). Drops at Tapovan, Ram Jhula, Laxman Jhula & rafting camps. Fixed fares, 24x7 pickup.';
$page_url         = $domain . "/dehradun-to-rishikesh-taxi";

$__faqs = [
["How far is Rishikesh from Dehradun by taxi?", "Rishikesh is approximately 45 km from Dehradun city center and about 20 km from Jolly Grant Airport. The taxi drive takes around 1 to 1.25 hours."],
["What is the taxi fare from Dehradun to Rishikesh?", "One-way sedan taxi fare from Dehradun to Rishikesh starts at ₹1,000 for a Dzire, ₹1,400 for an Ertiga (SUV), and ₹1,800 for an Innova Crysta. Fares are fixed with no hidden costs."],
["Can I get a direct taxi from Jolly Grant Airport to Rishikesh?", "Yes. Jolly Grant Airport is located on the Dehradun-Rishikesh route (~20 km from Rishikesh). A direct airport taxi takes just 30 to 40 minutes."],
["Do you drop at Tapovan, Laxman Jhula, and Triveni Ghat?", "Yes. We provide direct door-to-door drops to hotels, yoga ashrams, and camps across Tapovan, Laxman Jhula, Ram Jhula, Triveni Ghat, and Shivpuri."],
["Is 24/7 taxi booking available for Rishikesh Ganga Aarti?", "Yes. We offer round-the-clock taxi bookings so you can attend the evening Ganga Aarti at Triveni Ghat or Parmarth Niketan and return comfortably."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Rishikesh Taxi Service','serviceType'=>'Intercity & pilgrimage taxi transfer','description'=>'One-way and round-trip taxi from Dehradun & Jolly Grant Airport to Rishikesh over 45 km with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Rishikesh'],['@type'=>'City','name'=>'Tapovan']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'1000','description'=>'One way sedan taxi fare from Dehradun to Rishikesh starts from 1,000 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun City → Rishikesh / Tapovan','~45 km','1,000','1,400','1,800','/dehradun-to-rishikesh-taxi'],
['Jolly Grant Airport → Rishikesh','~20 km','1,100','1,500','1,800','/dehradun-airport-taxi-service'],
['Dehradun → Shivpuri Rafting Camps','~60 km','1,400','1,900','2,300','/dehradun-to-rishikesh-taxi'],
];

$__sights = [
['Ram Jhula & Laxman Jhula','fa-bridge','Iconic suspension bridges, markets, and cafes along the Ganga.'],
['Tapovan & Badrinath Road','fa-hotel','Primary hub for yoga ashrams, boutique hotels, and stays.'],
['Triveni Ghat','fa-water','Famous riverbank ghat for spiritual bathing and evening Ganga Aarti.'],
['Shivpuri & Marine Drive','fa-campground','Adventure sports hub for river rafting, camping, and cliff jumping.'],
];

$__related = [
['Dehradun → Haridwar','/dehradun-to-haridwar-taxi','fa-om'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],
['Dehradun → Delhi','/dehradun-to-delhi-taxi','fa-road'],['Dehradun → Kedarnath','/dehradun-to-kedarnath-taxi','fa-om'],
];
?>
<main id="main">
<style>
.rk{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--teal:#0891b2;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef8fa 0%,#ffffff 440px)}
.rk *{box-sizing:border-box}
.rk .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rk .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.rk .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.rk .rv.in{opacity:1;transform:none}
.rk .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.rk .crumb a{color:var(--slate);text-decoration:none}.rk .crumb a:hover{color:var(--teal)}.rk .crumb i{font-size:.6rem;color:var(--mute)}.rk .crumb .cur{color:var(--ink);font-weight:600}
.rk .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.rk .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:#e0f2fe;padding:7px 13px;border-radius:999px}
.rk .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.rk .hero h1 em{font-style:normal;color:var(--teal)}
.rk .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.rk .lead strong{color:var(--ink)}
.rk .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.rk .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.rk .m i{color:var(--teal)}.rk .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.rk .m span{font-size:.8rem;color:var(--slate)}
.rk .herocta{display:flex;gap:12px;flex-wrap:wrap}
.rk .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.rk .btn-p{background:var(--teal);color:#fff;box-shadow:0 16px 34px -14px rgba(8,145,178,.55)}.rk .btn-p:hover{transform:translateY(-2px)}
.rk .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.rk .btn-g:hover{transform:translateY(-2px)}
.rk .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.rk .btn-o:hover{border-color:var(--teal);color:var(--teal)}
.rk .card{position:sticky;top:88px;background:linear-gradient(160deg,#031f28,#0891b2);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(8,145,178,.5);overflow:hidden}
.rk .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c7f0f8;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.rk .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.rk .fares{display:grid;gap:8px;margin:14px 0 0}
.rk .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.rk .fr .v{font-weight:700;font-size:.9rem}.rk .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.rk .card .cta{display:grid;gap:10px;margin-top:16px}
.rk .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.rk .card .cta .w{background:#fff;color:var(--teal)}.rk .card .cta .g{background:#25d366;color:#04260f}
.rk .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--teal);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.rk .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);margin-bottom:8px}
.rk .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.rk .qa strong{color:var(--ink)}
.rk .sec{padding:48px 0}
.rk .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.rk .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--teal);background:#e0f2fe;padding:7px 13px;border-radius:999px}
.rk .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.rk .sh p{color:var(--slate);margin:0}
.rk .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.rk .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.rk .sico{flex:none;width:44px;height:44px;border-radius:12px;background:#e0f2fe;color:var(--teal);display:grid;place-items:center;font-size:1rem}
.rk .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.rk .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.rk .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.rk .tscroll{overflow-x:auto}
.rk table{width:100%;border-collapse:collapse;min-width:560px}
.rk th,.rk td{padding:15px 18px;text-align:left;font-size:.92rem}
.rk thead th{background:var(--soft);color:var(--teal);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.rk tbody tr{border-top:1px solid var(--line)}
.rk .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.rk .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.rk .rchip i{color:var(--teal)}.rk .rchip:hover{border-color:var(--teal);color:var(--teal);transform:translateY(-2px)}
.rk .fbox{max-width:820px;margin:0 auto}
.rk .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.rk .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.rk .ft{flex:none;width:26px;height:26px;border-radius:8px;background:#e0f2fe;color:var(--teal);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.rk .fi.open .ft{transform:rotate(45deg)}
.rk .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.rk .fi.open .fb{max-height:380px;padding:0 20px 18px}
.rk .soft{background:linear-gradient(180deg,#eef8fa,#f6fbfa)}
.rk .cta{padding:0 0 70px}
.rk .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0891b2,transparent 55%),linear-gradient(120deg,#031f28,#0891b2);color:#fff;text-align:center;padding:50px 24px}
.rk .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.rk .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.rk .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.rk .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.rk .cta .w{background:#fff;color:var(--teal)}.rk .cta .g{background:#25d366;color:#04260f}.rk .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.rk .hero{grid-template-columns:1fr;gap:24px}.rk .card{position:static}}
</style>

<div class="rk">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Rishikesh Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-water"></i> Yoga Capital · 45 km</span>
<h1 class="disp">Dehradun to Rishikesh Taxi Service <em>(Tapovan, Rafting &amp; Ashrams)</em></h1>
<p class="lead"><strong>Dehradun to Rishikesh taxi fare starts from ₹1,000 for a sedan.</strong> Anaya Cab Service offers direct transfers to Tapovan, Laxman Jhula, Triveni Ghat, and Shivpuri rafting camps with verified drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>45 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>1 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-om"></i> <b>Ganga Aarti</b> <span>direct drop</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹1,000+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Rishikesh cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Rishikesh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Rishikesh fare">
<span class="tag"><i class="fa-solid fa-water"></i> Route fare</span>
<h3 class="disp">Dehradun → Rishikesh</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹1,000</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹1,400</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹1,800</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Rishikesh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Dehradun to Rishikesh Taxi Fare &amp; Route</div>
<p itemprop="text"><strong>Dehradun to Rishikesh distance is 45 km via Haridwar Road / NH 7, taking approximately 1 hour of smooth drive.</strong> One-way taxi fare starts at <strong>₹1,000 for Sedan (Dzire)</strong>, <strong>₹1,400 for SUV (Ertiga)</strong>, and <strong>₹1,800 for Innova Crysta</strong>. Pickups available from Dehradun Railway Station, ISBT, and Jolly Grant Airport (~20 km, ₹1,100), with door-to-door drops to Tapovan, Laxman Jhula, Ram Jhula, and Shivpuri rafting camps.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Rishikesh taxi fares by drop location</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Rishikesh taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Rishikesh</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Rishikesh taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Rishikesh or Tapovan? Book your cab now</h2>
<p>Fixed fare, verified driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Rishikesh cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Rishikesh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.rk .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rk .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

