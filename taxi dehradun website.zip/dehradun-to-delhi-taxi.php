<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
/* Rate Manager wiring — admin se change hote hi page update */
$sedan = anaya_rate('r_delhi');
if ($sedan <= 0) { $sedan = 3500; }
$ertiga = anaya_rate('delhi_ertiga');      if ($ertiga <= 0) { $ertiga = (int)round($sedan * 1.3 / 50) * 50; }
$crysta = anaya_rate('delhi_crysta');      if ($crysta <= 0) { $crysta = (int)round($sedan * 1.5 / 50) * 50; }
$airport = anaya_rate('delhi_airport_sedan'); if ($airport <= 0) { $airport = $sedan + 300; }
$gurgaon = anaya_rate('r_gurgaon');        if ($gurgaon <= 0) { $gurgaon = 3800; }
$noida = anaya_rate('r_noida');            if ($noida <= 0) { $noida = 3600; }
$roundt = anaya_rate('rt_delhi');          if ($roundt <= 0) { $roundt = 5000; }
$airport_e = (int)round($airport * 1.3 / 50) * 50;
$airport_c = (int)round($airport * 1.5 / 50) * 50;
$gurgaon_e = (int)round($gurgaon * 1.3 / 50) * 50;
$gurgaon_c = (int)round($gurgaon * 1.5 / 50) * 50;
$noida_e = (int)round($noida * 1.3 / 50) * 50;
$noida_c = (int)round($noida * 1.5 / 50) * 50;
$fs = number_format($sedan); $fe = number_format($ertiga); $fc = number_format($crysta);
$fas = number_format($airport); $fae = number_format($airport_e); $fac = number_format($airport_c);
$fgs = number_format($gurgaon); $fge = number_format($gurgaon_e); $fgc = number_format($gurgaon_c);
$fns = number_format($noida); $fne = number_format($noida_e); $fnc = number_format($noida_c);
$frt = number_format($roundt);
$page_title = "Dehradun to Delhi Taxi | One Way ₹" . $fs . " | Anaya Cab";
$page_description = "Dehradun to Delhi one-way taxi ₹" . $fs . " sedan via Delhi–Dehradun Expressway (250 km, 5 hr). IGI T1/T2/T3, Gurgaon, Noida drops.";
$page_url         = $domain . "/dehradun-to-delhi-taxi";
$page_cover       = false; /* page ka apna .dl-cover hai — header auto-cover OFF (duplicate image fix) */
$__faqs = [
["How far is Delhi from Dehradun by taxi?", "The distance from Dehradun to Delhi is approximately 250 km via NH 334 / Delhi-Dehradun Expressway, taking around 4.5 to 5.5 hours depending on traffic and drop location in Delhi/NCR."],
["What is the one-way taxi fare from Dehradun to Delhi?", "One-way sedan taxi fare from Dehradun to Delhi starts at Rs " . $fs . " for a Dzire, Rs " . $fe . " for an Ertiga (SUV), and Rs " . $fc . " for an Innova Crysta. Round-trip starts at Rs " . $frt . ". All fares are fixed and confirmed before booking."],
["Can I book a Dehradun taxi to Delhi IGI Airport (T3/T1)?", "Yes. We offer direct door-to-door drops to Delhi IGI Airport Terminal 3, Terminal 1, and Terminal 2, as well as New Delhi Railway Station, Gurgaon, and Noida."],
["Are toll tax and MCD state taxes included in the fare?", "The quoted fare covers fuel, driver allowance, and vehicle rental. Toll taxes, FASTag charges, and Delhi MCD entry fees are charged extra as per actual receipts."],
["Is late-night or early-morning taxi available for Delhi?", "Yes, Anaya Cab Service operates 24x7. You can book an early morning 4 AM cab or late-night transfer to match your flight or train schedule."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Delhi Taxi Service','serviceType'=>'Outstation intercity cab transfer','description'=>'One-way and round-trip taxi from Dehradun to Delhi NCR over 250 km via Delhi-Dehradun Expressway with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Delhi'],['@type'=>'City','name'=>'Gurgaon'],['@type'=>'City','name'=>'Noida']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>(string)$sedan,'description'=>'One way sedan taxi fare from Dehradun to Delhi starts from ' . $fs . ' rupees. Round trip starts at ' . $frt . ' rupees.']],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__fares = [
['Dehradun → Delhi City / Connaught Place','~250 km',$fs,$fe,$fc,'/dehradun-to-delhi-taxi'],
['Dehradun → IGI Airport (T3 / T1)','~265 km',$fas,$fae,$fac,'/dehradun-to-delhi-taxi'],
['Dehradun → Gurgaon / Cyber City','~280 km',$fgs,$fge,$fgc,'/dehradun-to-gurgaon-taxi'],
['Dehradun → Noida / Greater Noida','~260 km',$fns,$fne,$fnc,'/dehradun-to-noida-taxi'],
];
$__sights = [
['IGI Airport (T3/T1/T2)','fa-plane-departure','Direct Terminal 3 drops for international and domestic flight connections.'],
['New Delhi Railway Station','fa-train','On-time drops at NDLS and Old Delhi railway stations.'],
['Gurgaon & Cyber City','fa-building-user','Corporate transfers to Gurgaon, Golf Course Road, and DLF Cyber City.'],
['Noida & Ghaziabad','fa-city','Smooth highway connectivity to Noida Sectors, Greater Noida, and Indirapuram.'],
];
$__related = [
['Dehradun → Haridwar','/dehradun-to-haridwar-taxi','fa-om'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],
['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],['Dehradun → Chandigarh','/dehradun-to-chandigarh-taxi','fa-road'],
['Delhi → Dehradun','/delhi-to-dehradun-taxi','fa-rotate'],['Dehradun → Jaipur','/dehradun-to-jaipur-taxi','fa-road'],
['Delhi taxi time guide','/blog/dehradun-to-delhi-taxi-time','fa-book-open'],['Airport taxi guide','/blog/dehradun-airport-taxi-guide','fa-book-open'],
];
?>
<main id="main">
<style>
.dl{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 440px)}
.dl *{box-sizing:border-box}
.dl::before{content:"";position:absolute;top:-180px;left:-120px;width:580px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.12),transparent 70%);pointer-events:none}
.dl .dl-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.dl .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.dl .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.dl .rv.in{opacity:1;transform:none}
.dl .dl-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.dl .dl-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.dl .dl-crumb a:hover{color:var(--blue)}
.dl .dl-crumb i{font-size:.6rem;color:var(--mute)}.dl .dl-crumb .cur{color:var(--ink);font-weight:600}
.dl .dl-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.dl .dl-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.dl .dl-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.dl .dl-hero h1 em{font-style:normal;color:var(--blue)}
.dl .dl-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.dl .dl-lead strong{color:var(--ink)}
.dl .dl-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.dl .dl-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.dl .dl-m i{color:var(--blue)}.dl .dl-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.dl .dl-m span{font-size:.8rem;color:var(--slate)}
.dl .dl-herocta{display:flex;gap:12px;flex-wrap:wrap}
.dl .dl-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.dl .dl-btn-p{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.dl .dl-btn-p:hover{transform:translateY(-2px);filter:brightness(1.08)}
.dl .dl-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.dl .dl-btn-g:hover{transform:translateY(-2px)}
.dl .dl-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.dl .dl-btn-o:hover{border-color:var(--blue);color:var(--blue)}
.dl .dl-card{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,87,255,.5);overflow:hidden}
.dl .dl-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.dl .dl-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px;position:relative;color:#fff}
.dl .dl-anim{position:relative;height:64px;margin:0 0 10px;overflow:hidden}
.dl .dl-anim .road{position:absolute;left:0;right:0;bottom:14px;height:3px;background:repeating-linear-gradient(90deg,#9fe0ff 0 12px,transparent 12px 24px);border-radius:3px;opacity:.85}
.dl .dl-anim .car{position:absolute;bottom:18px;left:6%;color:#fff;font-size:.95rem;animation:dlrun 4.6s ease-in-out infinite}
@keyframes dlrun{0%,100%{left:6%}50%{left:86%}}
.dl .dl-anim .gate{position:absolute;right:4%;top:50%;transform:translateY(-50%);color:#9fe0ff;font-size:1.2rem}
.dl .dl-anim .mile{position:absolute;bottom:26px;color:rgba(255,255,255,.6);font-size:.62rem;letter-spacing:.08em}
.dl .dl-anim .m1{left:22%}.dl .dl-anim .m2{left:52%}
.dl .dl-fares{display:grid;gap:8px;margin:14px 0 0;position:relative}
.dl .dl-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.dl .dl-fr .v{font-weight:700;font-size:.9rem}
.dl .dl-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.dl .dl-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.dl .dl-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.dl .dl-card .cta .w{background:#fff;color:var(--blue)}.dl .dl-card .cta .g{background:#25d366;color:#04260f}
.dl .dl-card .cta a:hover{transform:translateY(-2px)}
.dl .dl-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.dl .dl-cover{position:relative;margin:6px 0 0;border-radius:22px;overflow:hidden;box-shadow:0 24px 50px -28px rgba(9,32,84,.42);background:linear-gradient(135deg,#03102e,#0057ff);min-height:200px}
.dl .dl-cover img{width:100%;height:360px;object-fit:cover;display:block;transition:transform .6s ease}
.dl .dl-cover:hover img{transform:scale(1.03)}
.dl .dl-cover-fb{display:none;position:absolute;inset:0;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:rgba(255,255,255,.92);background:radial-gradient(120% 120% at 30% 0%,rgba(0,194,255,.4),#0a2a63)}
.dl .dl-cover-fb i{font-size:3rem;color:#9fe0ff;filter:drop-shadow(0 8px 16px rgba(0,0,0,.35))}
.dl .dl-cover-fb span{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.1rem;letter-spacing:-.01em}
@media(max-width:640px){.dl .dl-cover img{height:220px}.dl .dl-cover{min-height:160px}}
.dl .dl-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.dl .dl-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.dl .dl-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.dl .dl-qa strong{color:var(--ink)}
.dl .dl-sec{padding:48px 0}
.dl .dl-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.dl .dl-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.dl .dl-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.dl .dl-sh p{color:var(--slate);margin:0}
.dl .dl-sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.dl .dl-sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.dl .dl-sitem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.dl .dl-sico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.dl .dl-sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.dl .dl-sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.dl .dl-steps{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;max-width:960px;margin:0 auto}
.dl .dl-step{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:20px 16px 16px;text-align:center}
.dl .dl-step .n{position:absolute;top:-12px;left:50%;transform:translateX(-50%);width:24px;height:24px;border-radius:999px;background:var(--blue);color:#fff;font-family:'Sora','Poppins',sans-serif;font-size:.72rem;font-weight:800;display:grid;place-items:center}
.dl .dl-step i{font-size:1.3rem;color:var(--blue);margin:6px 0 8px}
.dl .dl-step h3{font-family:'Sora','Poppins',sans-serif;font-size:.92rem;font-weight:700;margin:0 0 4px}
.dl .dl-step p{margin:0;font-size:.8rem;color:var(--slate);line-height:1.5}
.dl .dl-inc{display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:860px;margin:0 auto}
.dl .dl-incc{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:22px}
.dl .dl-incc h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:800;margin:0 0 12px;display:flex;align-items:center;gap:9px}
.dl .dl-incc h3 i{color:var(--green)}
.dl .dl-incc.x h3 i{color:#dc2626}
.dl .dl-incc ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:9px}
.dl .dl-incc li{display:flex;gap:9px;font-size:.88rem;color:var(--slate)}
.dl .dl-incc li i{margin-top:3px;font-size:.72rem}
.dl .dl-incc li i.ok{color:var(--green)}.dl .dl-incc li i.no{color:#dc2626}
.dl .dl-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.dl .dl-tscroll{overflow-x:auto}
.dl table{width:100%;border-collapse:collapse;min-width:560px}
.dl th,.dl td{padding:15px 18px;text-align:left;font-size:.92rem}
.dl thead th{background:var(--soft);color:var(--blue-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.dl tbody tr{border-top:1px solid var(--line);transition:background .2s}.dl tbody tr:hover{background:var(--soft)}
.dl .dl-rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.dl .dl-rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.dl .dl-rchip i{color:var(--blue)}.dl .dl-rchip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}
.dl .dl-fbox{max-width:820px;margin:0 auto}
.dl .dl-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.dl .dl-fi:hover{border-color:#bfe6e0}
.dl .dl-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.dl .dl-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.dl .dl-fi.open .dl-ft{transform:rotate(45deg)}
.dl .dl-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.dl .dl-fi.open .dl-fb{max-height:380px;padding:0 20px 18px}
.dl .dl-soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.dl .dl-cta{padding:0 0 70px}
.dl .dl-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0057ff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.dl .dl-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.dl .dl-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.dl .dl-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.dl .dl-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.dl .dl-cta .w{background:#fff;color:var(--blue)}.dl .dl-cta .g{background:#25d366;color:#04260f}.dl .dl-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.dl .dl-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.dl .dl-hero{grid-template-columns:1fr;gap:24px}.dl .dl-card{position:static}.dl .dl-steps{grid-template-columns:1fr 1fr}.dl .dl-inc{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.dl *{transition:none!important;animation:none!important}.dl .rv{opacity:1!important;transform:none!important}}
</style>
<div class="dl">
<div class="dl-in">
<nav class="dl-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Delhi Taxi</span></nav>
<section class="dl-hero">
<div class="rv">
<span class="dl-eyebrow"><i class="fa-solid fa-road"></i> Delhi-Dehradun Expressway · 250 km</span>
<h1 class="disp">Dehradun to Delhi Taxi Service <em>(One Way &amp; Airport Drops)</em></h1>
<p class="dl-lead"><strong>Dehradun to Delhi taxi fare starts from ₹<?php echo $fs; ?> for a sedan (round-trip ₹<?php echo $frt; ?>).</strong> Anaya Cab Service offers direct door-to-door drops to Delhi NCR, IGI Airport (T3/T1/T2), Gurgaon, and Noida via the Delhi-Dehradun Expressway with verified drivers and transparent fares.</p>
<div class="dl-metrics">
<span class="dl-m"><i class="fa-solid fa-road"></i> <b>250 km</b> <span>distance</span></span>
<span class="dl-m"><i class="fa-regular fa-clock"></i> <b>4.5–5 hr</b> <span>drive time</span></span>
<span class="dl-m"><i class="fa-solid fa-plane"></i> <b>IGI Airport</b> <span>direct drop</span></span>
<span class="dl-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹<?php echo $fs; ?>+</b> <span>one-way</span></span>
</div>
<div class="dl-herocta">
<a class="dl-btn dl-btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Delhi cab</a>
<a class="dl-btn dl-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Delhi taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="dl-btn dl-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="dl-card rv" aria-label="Dehradun to Delhi fare">
<span class="tag"><i class="fa-solid fa-road"></i> Expressway fare</span>
<h3 class="disp">Dehradun → Delhi NCR</h3>
<div class="dl-anim" aria-hidden="true">
<div class="road"></div>
<span class="mile m1">ROORKEE</span><span class="mile m2">MEERUT</span>
<i class="fa-solid fa-car-side car"></i>
<i class="fa-solid fa-archway gate"></i>
</div>
<div class="dl-fares">
<div class="dl-fr"><span class="v">Sedan (Dzire)</span><span class="p">₹<?php echo $fs; ?></span></div>
<div class="dl-fr"><span class="v">SUV (Ertiga)</span><span class="p">₹<?php echo $fe; ?></span></div>
<div class="dl-fr"><span class="v">Innova Crysta</span><span class="p">₹<?php echo $fc; ?></span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Delhi taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way ₹<?php echo $fs; ?> · Round-trip ₹<?php echo $frt; ?> · 24×7</p>
</aside>
</section>
<figure class="dl-cover rv">
<img src="/assets/images/services/dehradun-to-delhi-taxi.webp" alt="Dehradun to Delhi taxi on the Delhi-Dehradun Expressway" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';var f=this.nextElementSibling;if(f)f.style.display='flex'">
<figcaption class="dl-cover-fb"><i class="fa-solid fa-road"></i><span>Dehradun to Delhi Taxi</span></figcaption>
</figure>
<div class="dl-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer · Dehradun to Delhi Taxi Overview</div>
<p itemprop="text"><strong>Dehradun to Delhi distance is approximately 250 km (213 km on the new Expressway) taking 4 to 5 hours by cab.</strong> One-way taxi fare starts at <strong>₹<?php echo $fs; ?> for Sedan (Dzire)</strong>, <strong>₹<?php echo $fe; ?> for SUV (Ertiga)</strong>, and <strong>₹<?php echo $fc; ?> for Innova Crysta</strong>. Round-trip starts at ₹<?php echo $frt; ?>. Anaya Cab Service provides 24x7 door-to-door drops to Connaught Place, Delhi IGI Airport (T1/T2/T3), Gurgaon, and Noida with verified highway drivers and FASTag toll billing.</p>
</div>
</div>
<section class="dl-sec rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Delhi taxi fares by destination</h2></div>
<div class="dl-twrap"><div class="dl-tscroll">
<table aria-label="Dehradun to Delhi taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</div></section>
<section class="dl-sec dl-soft rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-route"></i> The run</span><h2 class="disp">Dehradun to Delhi, step by step</h2></div>
<div class="dl-steps">
<div class="dl-step rv"><span class="n">1</span><i class="fa-solid fa-circle-dot"></i><h3>Pickup in Dehradun</h3><p>Home, hotel, station or airport — at your time, 24x7.</p></div>
<div class="dl-step rv"><span class="n">2</span><i class="fa-solid fa-road"></i><h3>Delhi-Dehradun Expressway</h3><p>NH-334 towards Roorkee-Meerut side, one comfort stop.</p></div>
<div class="dl-step rv"><span class="n">3</span><i class="fa-solid fa-tower-broadcast"></i><h3>Modinagar-Meerut bypass</h3><p>Skips city traffic for a smooth final stretch.</p></div>
<div class="dl-step rv"><span class="n">4</span><i class="fa-solid fa-location-dot"></i><h3>Drop anywhere in NCR</h3><p>IGI T1/T2/T3, CP, Gurgaon, Noida — door to door.</p></div>
</div>
</div></section>
<section class="dl-sec rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Transparency</span><h2 class="disp">What your fare covers — and what it does not</h2></div>
<div class="dl-inc">
<div class="dl-incc rv"><h3><i class="fa-solid fa-circle-check"></i> Included in the fare</h3><ul>
<li><i class="fa-solid fa-check ok"></i> Fuel, vehicle and verified driver</li>
<li><i class="fa-solid fa-check ok"></i> Driver allowance and inter-state permit</li>
<li><i class="fa-solid fa-check ok"></i> Reasonable airport waiting (flight-tracked)</li>
<li><i class="fa-solid fa-check ok"></i> Door-to-door NCR drop, any terminal</li>
</ul></div>
<div class="dl-incc x rv"><h3><i class="fa-solid fa-circle-xmark"></i> Extra at actuals</h3><ul>
<li><i class="fa-solid fa-xmark no"></i> Expressway toll (FASTag receipt shared)</li>
<li><i class="fa-solid fa-xmark no"></i> Delhi MCD / state entry tax</li>
<li><i class="fa-solid fa-xmark no"></i> Parking at airport or monument</li>
<li><i class="fa-solid fa-xmark no"></i> Night halt on multi-day plans</li>
</ul></div>
</div>
</div></section>
<section class="dl-sec dl-soft rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Delhi NCR</h2></div>
<div class="dl-sgrid">
<?php foreach ($__sights as $s): ?>
<div class="dl-sitem rv"><span class="dl-sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="dl-sec rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular outstation routes</h2></div>
<div class="dl-rchips">
<?php foreach ($__related as $r): ?>
<a class="dl-rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</div></section>
<section class="dl-sec dl-soft rv" id="faq"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Delhi taxi — FAQs</h2></div>
<div class="dl-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="dl-fi<?php echo $i===0?' open':''; ?>"><div class="dl-fh"><?php echo htmlspecialchars($f[0]); ?><span class="dl-ft"><i class="fa-solid fa-plus"></i></span></div><div class="dl-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="dl-cta rv"><div class="dl-in">
<div class="dl-ctain">
<h2 class="disp">Need a cab to Delhi or IGI Airport?</h2>
<p>Fixed fare, express highway route and pickup from anywhere in Dehradun — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Delhi cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Delhi taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.dl .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.dl .dl-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>