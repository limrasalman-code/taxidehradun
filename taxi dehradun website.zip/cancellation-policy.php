<?php
require_once __DIR__ . '/includes/config.php';
$page_title       = "Cancellation & Refund Policy | Anaya Cab Service Dehradun";
$page_description = "Anaya Cab Service cancellation & refund policy for Dehradun taxi bookings — free cancellation window, charges table, no-show rules and refund process.";
$page_url         = SITE_DOMAIN . "/cancellation-policy";
$__faqs = [
['How do I cancel my taxi booking?', 'You can cancel by calling ' . BUSINESS_PHONE . ' or messaging us on WhatsApp with your booking details. Our team is available 24x7 and will confirm the cancellation and any applicable refund immediately.'],
['Is cancellation free if I cancel early?', 'Yes. Cancellations made within the free-cancellation window (at least 24 hours before a local or airport pickup, and at least 48 hours before an outstation or Char Dham trip) attract no charge. Cancellations closer to the trip time may incur the charges shown in the table on this page.'],
['What if the driver cancels or there is bad weather?', 'If we or the driver cancel, or if a trip cannot run due to severe weather, landslides or road closures, you receive a full refund or a free reschedule — whichever you prefer — with no penalty.'],
['How and when will I receive my refund?', 'Refunds, where applicable, are processed to the original payment method or as agreed with our team, typically within 3 to 7 working days after the cancellation is confirmed.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', '@id' => $page_url . '#faq', 'mainEntity' => $__faq_entities], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
?>
<main>
<style>
.lp{--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f6f9ff;--radius:18px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef3fb,#ffffff 240px)}
.lp *{box-sizing:border-box}
.lp .lp-in{max-width:1120px;margin:0 auto;padding:0 22px}
.lp .lp-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:18px 0 0;font-size:.82rem;color:var(--slate)}
.lp .lp-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}
.lp .lp-crumb a:hover{color:var(--blue)}
.lp .lp-crumb i{font-size:.62rem;color:#94a3b8}
.lp .lp-crumb .cur{color:var(--ink);font-weight:600}
.lp .lp-head{padding:26px 0 8px;max-width:760px}
.lp .lp-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.lp .lp-head h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.8rem,4vw,2.6rem);font-weight:800;letter-spacing:-.03em;line-height:1.08;margin:14px 0 10px}
.lp .lp-head p{color:var(--slate);font-size:1.02rem;line-height:1.6;margin:0}
.lp .lp-meta{display:flex;flex-wrap:wrap;gap:16px;margin-top:14px;font-size:.8rem;color:var(--slate)}
.lp .lp-meta span{display:inline-flex;align-items:center;gap:7px}
.lp .lp-meta i{color:var(--blue)}
.lp .lp-layout{display:grid;grid-template-columns:248px 1fr;gap:40px;padding:30px 0 60px;align-items:start}
.lp .lp-toc{position:sticky;top:88px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:18px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 12px 30px -16px rgba(9,32,84,.18)}
.lp .lp-toc h2{font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#94a3b8;margin:0 0 12px}
.lp .lp-toc a{display:block;padding:7px 10px;border-radius:10px;color:var(--slate);font-size:.86rem;font-weight:500;text-decoration:none;border-left:2px solid transparent;transition:.2s}
.lp .lp-toc a:hover{background:var(--soft);color:var(--blue);border-left-color:var(--blue)}
.lp .lp-body{background:#fff;border:1px solid var(--line);border-radius:22px;padding:34px 38px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -28px rgba(9,32,84,.22)}
.lp .lp-body section{scroll-margin-top:96px;padding:6px 0 4px}
.lp .lp-body section+section{border-top:1px solid var(--line);margin-top:18px;padding-top:24px}
.lp .lp-body h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:700;letter-spacing:-.02em;margin:0 0 10px}
.lp .lp-body h3{font-size:1.02rem;font-weight:700;margin:18px 0 6px}
.lp .lp-body p{color:#3b4456;line-height:1.72;margin:0 0 12px;font-size:.96rem}
.lp .lp-body ul{margin:0 0 12px;padding-left:2px;list-style:none;display:flex;flex-direction:column;gap:8px}
.lp .lp-body li{position:relative;padding-left:24px;color:#3b4456;line-height:1.6;font-size:.95rem}
.lp .lp-body li::before{content:"\f058";font-family:"Font Awesome 6 Free";font-weight:900;position:absolute;left:0;top:2px;color:var(--blue);font-size:.82rem}
.lp .lp-body a{color:var(--blue);font-weight:600;text-decoration:none}
.lp .lp-body a:hover{text-decoration:underline}
.lp .lp-table{width:100%;border-collapse:collapse;margin:6px 0 14px;border:1px solid var(--line);border-radius:14px;overflow:hidden;font-size:.92rem}
.lp .lp-table th,.lp .lp-table td{padding:13px 16px;text-align:left;border-bottom:1px solid var(--line)}
.lp .lp-table thead th{background:var(--soft);color:#0039ad;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.8rem;letter-spacing:.02em}
.lp .lp-table tbody tr:last-child td{border-bottom:0}
.lp .lp-table tbody tr:hover{background:var(--soft)}
.lp .lp-note{background:var(--soft);border:1px solid #d6e4ff;border-radius:14px;padding:14px 16px;font-size:.9rem;color:#33415c;margin:4px 0 12px}
.lp .lp-note i{color:var(--blue);margin-right:8px}
.lp .lp-faq{margin-top:26px}
.lp .lp-faq h2{margin-bottom:14px}
.lp .lp-faq-i{border:1px solid var(--line);border-radius:14px;margin-bottom:10px;overflow:hidden;background:#fff;transition:border-color .3s,box-shadow .3s}
.lp .lp-faq-i:hover{border-color:#cfe0ff}
.lp .lp-faq-h{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:15px 18px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:.98rem;cursor:pointer}
.lp .lp-faq-t{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.lp .lp-faq-i.open .lp-faq-t{transform:rotate(45deg)}
.lp .lp-faq-b{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.65;padding:0 18px;transition:max-height .35s,padding .35s}
.lp .lp-faq-i.open .lp-faq-b{max-height:340px;padding:0 18px 16px}
.lp .lp-cta{margin:8px 0 60px;border-radius:24px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;padding:40px 28px;text-align:center}
.lp .lp-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.4rem,3vw,1.9rem);letter-spacing:-.02em;color:#fff;margin:0 0 8px}
.lp .lp-cta p{color:rgba(255,255,255,.84);margin:0 0 20px}
.lp .lp-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.lp .lp-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:12px 20px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.lp .lp-cta .w{background:#fff;color:#0057ff}.lp .lp-cta .g{background:#25d366;color:#04260f}.lp .lp-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.lp .lp-cta a:hover{transform:translateY(-2px)}
@media(max-width:880px){.lp .lp-layout{grid-template-columns:1fr;gap:18px}.lp .lp-toc{position:static}.lp .lp-body{padding:24px 20px}}
@media(prefers-reduced-motion:reduce){.lp *{transition:none!important}}
</style>

<div class="lp"><div class="lp-in">
<nav class="lp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Cancellation &amp; Refund Policy</span></nav>

<header class="lp-head">
<span class="lp-eyebrow"><i class="fa-solid fa-rotate-left"></i> Cancellation &amp; refunds</span>
<h1>Cancellation &amp; Refund Policy</h1>
<p>Plans change &mdash; we get it. This policy explains how cancellations, modifications and refunds work for Anaya Cab Service taxi bookings in Dehradun, so you always know where you stand before you travel.</p>
<div class="lp-meta"><span><i class="fa-regular fa-calendar"></i> Last updated: 25 July 2026</span><span><i class="fa-solid fa-scale-balanced"></i> Jurisdiction: Uttarakhand, India</span><span><i class="fa-regular fa-clock"></i> 3 min read</span></div>
</header>

<div class="lp-layout">
<aside class="lp-toc" aria-label="On this page">
<h2>On this page</h2>
<a href="#free">Free cancellation window</a>
<a href="#charges">Cancellation charges</a>
<a href="#noshow">No-show policy</a>
<a href="#refund">Refund process</a>
<a href="#force">Driver / weather cancellations</a>
<a href="#howto">How to cancel</a>
<a href="#modify">Modifications &amp; rescheduling</a>
</aside>

<article class="lp-body">
<section id="free"><h2>1. Free cancellation window</h2>
<p>You may cancel your booking free of charge if you do so within the windows below, measured from the scheduled pickup time:</p>
<ul>
<li><strong>Local &amp; airport rides (Dehradun):</strong> at least 24 hours before pickup.</li>
<li><strong>Outstation &amp; Char Dham / multi-day trips:</strong> at least 48 hours before pickup.</li>
</ul>
<p>Cancellations inside these windows carry no fee, and any amount collected is refunded in full.</p></section>

<section id="charges"><h2>2. Cancellation charges</h2>
<p>If you cancel closer to the trip time, the following charges may apply to cover driver allocation and standby:</p>
<div class="lp-note"><i class="fa-solid fa-circle-info"></i> Charges are calculated on the agreed trip fare. Where no advance was collected, the charge (if any) is settled as advised by our team at the time of cancellation.</div>
<table class="lp-table">
<thead><tr><th>Trip type</th><th>Cancelled before pickup</th><th>Charge</th></tr></thead>
<tbody>
<tr><td>Local / Airport</td><td>More than 24 hours</td><td><strong>Free</strong></td></tr>
<tr><td>Local / Airport</td><td>4 &ndash; 24 hours</td><td>10% of fare</td></tr>
<tr><td>Local / Airport</td><td>Less than 4 hours</td><td>25% of fare</td></tr>
<tr><td>Outstation / Char Dham</td><td>More than 48 hours</td><td><strong>Free</strong></td></tr>
<tr><td>Outstation / Char Dham</td><td>24 &ndash; 48 hours</td><td>15% of fare</td></tr>
<tr><td>Outstation / Char Dham</td><td>Less than 24 hours</td><td>30% of fare</td></tr>
</tbody>
</table></section>

<section id="noshow"><h2>3. No-show policy</h2>
<p>If the assigned driver arrives at the pickup point and is unable to reach you after reasonable attempts, and the trip is not completed due to passenger no-show, the applicable late-cancellation charge (as per the table above) may apply. Please keep your phone reachable and inform us promptly of any change.</p></section>

<section id="refund"><h2>4. Refund process</h2>
<p>Approved refunds are processed to the original payment method, or by the method agreed with our support team, typically within <strong>3 to 7 working days</strong> of cancellation confirmation. For cash or pay-after-trip bookings where no advance was taken, no refund is required and the booking is simply closed.</p></section>

<section id="force"><h2>5. Driver or weather cancellations</h2>
<p>If Anaya Cab Service or the driver cancels, or if a trip cannot operate due to severe weather, landslides, road closures or any force-majeure event, you are entitled to a <strong>full refund or a free reschedule</strong> &mdash; your choice &mdash; with no penalty.</p></section>

<section id="howto"><h2>6. How to cancel</h2>
<p>Cancelling is simple &mdash; reach us through any channel with your name and trip details:</p>
<ul>
<li>Call our 24&times;7 line: <a href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><?php echo BUSINESS_PHONE; ?></a></li>
<li>WhatsApp: <a href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>" target="_blank" rel="noopener">message us here</a></li>
<li>Or use the <a href="/contact">contact page</a> / booking reference shared at confirmation.</li>
</ul></section>

<section id="modify"><h2>7. Modifications &amp; rescheduling</h2>
<p>Need to change the date, time or vehicle instead of cancelling? In most cases we can modify your booking free of charge, subject to availability. Just contact us as early as possible and we will do our best to accommodate the change.</p></section>

<div class="lp-faq" id="faq">
<h2>Cancellation &mdash; quick answers</h2>
<?php foreach ($__faqs as $i => $f): ?>
<div class="lp-faq-i<?php echo $i===0?' open':''; ?>"><div class="lp-faq-h"><?php echo $f[0]; ?><span class="lp-faq-t"><i class="fa-solid fa-plus"></i></span></div><div class="lp-faq-b"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div>
<?php endforeach; ?>
</div>
</article>
</div>

<div class="lp-cta">
<h2>Need to change or cancel a booking?</h2>
<p>Our Dehradun support team is one call or message away, 24&times;7.</p>
<div class="row">
<a class="w" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I need to cancel / modify my booking.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="/#booking"><i class="fa-solid fa-taxi"></i> New booking</a>
</div>
</div>
</div></div>
</main>
<script>
document.querySelectorAll('.lp .lp-faq-h').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>