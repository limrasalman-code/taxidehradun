<?php
require_once __DIR__ . '/includes/config.php';
// Smart fallbacks for statistics constants to avoid 0+ / 0% rendering issues
$stat_customers = (defined('STAT_CUSTOMERS') && !in_array(STAT_CUSTOMERS, ['0+', '0', '0%'], true)) ? STAT_CUSTOMERS : '500+';
$stat_drivers   = (defined('STAT_DRIVERS') && !in_array(STAT_DRIVERS, ['0+', '0', '0%'], true)) ? STAT_DRIVERS : '50+';
$stat_cities    = (defined('STAT_CITIES') && !in_array(STAT_CITIES, ['0+', '0', '0%'], true)) ? STAT_CITIES : '25+';
$stat_safety    = (defined('STAT_SAFETY') && !in_array(STAT_SAFETY, ['0%', '0', '0+'], true)) ? STAT_SAFETY : '100%';
$page_title = 'About Anaya Cab Service | Trusted Dehradun Taxi';
$page_description = 'Anaya Cab Service: Dehradun taxi provider since 2014 — local rides, airport transfers, outstation & Char Dham. Verified drivers, fixed fares, 24x7.';
$page_url         = (defined('SITE_DOMAIN') ? SITE_DOMAIN : '') . "/about";
/* AboutPage + FAQPage Schema */
$__faqs = [
["Is Anaya Cab Service available 24 hours a day?", "Yes, Anaya Cab Service takes bookings and runs taxis round the clock, every day of the week, for local, airport, outstation and Char Dham travel from Dehradun."],
["Are your taxi drivers verified and experienced?", "Yes, every driver is police-verified and trained on Dehradun city roads as well as Uttarakhand hill and pilgrimage routes, including Mussoorie and the Char Dham circuit."],
["Which areas and routes does Anaya Cab Service cover?", "We cover all of Dehradun plus outstation routes to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital, Chandigarh and the Char Dham Yatra, with local, airport and hourly options inside the city."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'AboutPage','@id'=>$page_url.'#about','name'=>$page_title,'description'=>$page_description,'url'=>$page_url,'mainEntity'=>['@id'=>(defined('SITE_DOMAIN') ? SITE_DOMAIN : '').'/#taxi-service']],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__story = [
['fa-seedling','The first promise','Anaya Cab Service began in Dehradun with a small fleet and one simple rule — every ride must feel safe, honest and on time, from the first call to the final drop.'],
['fa-arrows-up-to-line','Growing the routes','As travellers trusted us, we added Jolly Grant Airport transfers, one-way outstation drops and hill routes to Mussoorie, Haridwar and Rishikesh, all with verified drivers.'],
['fa-om','Pilgrimage & group travel','We built dedicated Char Dham Yatra packages and brought in Innova, Crysta, Tempo Traveller and Urbania for families, groups and wedding travel across Uttarakhand.'],
['fa-shield-halved','Where we stand today','Today we run 24x7 with fixed, transparent fares, police-verified hill drivers and a clean AC fleet — still answering every booking like it is our first.'],
];
$__values = [
['big','fa-shield-halved','Safety & trust, by design','Every driver is police-verified, every vehicle is inspected and sanitised before a trip, and every fare is fixed and shared before you travel. Trust is not a tagline for us — it is the operating system of every ride we run across Dehradun and the hills.'],
['fa-clock','Always on time','Punctual pickups for flights, trains and yatra departures.'],
['fa-tags','Transparent pricing','The fare we quote is the fare you pay — no hidden charges.'],
['fa-mountain-sun','Local expertise','Drivers who know every Dehradun street and hill turn.'],
['fa-spray-can-sparkles','Clean AC fleet','Sanitised sedans, SUVs, Innovas and travellers.'],
];
$__serve = ['Families','Pilgrims','Business travellers','Tourists','Airport arrivals','Groups & weddings','Students & parents','Hotel guests'];
?>
<main id="main">
<style>
.ab{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f6f9ff;--green:#16a34a;--gold:#c9821a;--gold-soft:#fbf2e2;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#f7f3ec 0%,#ffffff 460px)}
.ab *{box-sizing:border-box}
.ab::before{content:"";position:absolute;top:-200px;right:-140px;width:560px;height:460px;border-radius:50%;background:radial-gradient(circle,rgba(201,130,26,.12),transparent 70%);pointer-events:none}
.ab::after{content:"";position:absolute;top:380px;left:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.07),transparent 70%);pointer-events:none}
.ab .ab-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.ab .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ab .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.ab .rv.in{opacity:1;transform:none}
.ab .ab-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.ab .ab-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.ab .ab-crumb a:hover{color:var(--gold)}
.ab .ab-crumb i{font-size:.6rem;color:var(--mute)}.ab .ab-crumb .cur{color:var(--ink);font-weight:600}
/* hero editorial */
.ab .ab-hero{display:grid;grid-template-columns:1.25fr .95fr;gap:38px;align-items:start;padding:26px 0 12px}
.ab .ab-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--gold);background:var(--gold-soft);padding:7px 13px;border-radius:999px}
.ab .ab-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 16px}
.ab .ab-hero h1 em{font-style:normal;color:var(--gold)}
.ab .ab-lead{color:var(--slate);font-size:1.06rem;line-height:1.68;max-width:56ch;margin:0 0 22px}.ab .ab-lead strong{color:var(--ink)}
.ab .ab-quote{position:relative;border-left:3px solid var(--gold);padding:6px 0 6px 20px;margin:0 0 24px}
.ab .ab-quote p{font-family:'Sora','Poppins',sans-serif;font-size:1.18rem;font-weight:600;line-height:1.4;color:var(--ink);margin:0;letter-spacing:-.01em}
.ab .ab-quote cite{display:block;margin-top:8px;font-style:normal;font-size:.82rem;color:var(--slate);font-weight:600}
.ab .ab-herocta{display:flex;gap:12px;flex-wrap:wrap}
.ab .ab-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.ab .ab-btn-g{background:var(--gold);color:#fff;box-shadow:0 16px 34px -14px rgba(201,130,26,.55)}.ab .ab-btn-g:hover{transform:translateY(-2px);filter:brightness(1.06)}
.ab .ab-btn-w{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.ab .ab-btn-w:hover{transform:translateY(-2px)}
.ab .ab-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.ab .ab-btn-o:hover{border-color:var(--gold);color:var(--gold)}
/* numbers living panel */
.ab .ab-nums{position:sticky;top:88px;background:linear-gradient(160deg,#1a130a,#3a2a12);border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(58,42,18,.6);overflow:hidden}
.ab .ab-nums::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(255,206,92,.28),transparent 70%)}
.ab .ab-nums .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#ffe2a8;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.ab .ab-nums h3{font-family:'Sora','Poppins',sans-serif;font-size:1.15rem;font-weight:800;margin:14px 0 18px;position:relative}
.ab .ab-ngrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;position:relative}
.ab .ab-ncell{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.13);border-radius:16px;padding:16px 14px;text-align:center;transition:transform .3s,border-color .3s}
.ab .ab-ncell:hover{transform:translateY(-3px);border-color:rgba(255,206,92,.5)}
.ab .ab-num{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.7rem;letter-spacing:-.02em;display:block;color:#ffce5c}
.ab .ab-ncell span{font-size:.72rem;color:rgba(255,255,255,.74);font-weight:600}
.ab .ab-nums .foot{margin-top:16px;font-size:.8rem;color:rgba(255,255,255,.7);display:flex;align-items:center;gap:8px;position:relative}
.ab .ab-nums .foot i{color:#7fe3ac}
/* quick answer */
.ab .ab-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--gold);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ab .ab-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--gold);margin-bottom:8px}
.ab .ab-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ab .ab-qa strong{color:var(--ink)}
.ab .ab-sec{padding:50px 0}
.ab .ab-sh{text-align:center;max-width:700px;margin:0 auto 30px}
.ab .ab-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--gold);background:var(--gold-soft);padding:7px 13px;border-radius:999px}
.ab .ab-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.ab .ab-sh p{color:var(--slate);margin:0}
/* story timeline */
.ab .ab-tl{position:relative;max-width:820px;margin:0 auto;padding-left:8px}
.ab .ab-tl::before{content:"";position:absolute;left:23px;top:10px;bottom:10px;width:2px;background:linear-gradient(180deg,var(--gold),#e7c089,var(--blue))}
.ab .ab-row{position:relative;display:grid;grid-template-columns:48px 1fr;gap:18px;padding:0 0 22px}
.ab .ab-dot{position:relative;z-index:1;width:48px;height:48px;border-radius:14px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--gold);font-size:1.05rem;box-shadow:0 8px 18px -10px rgba(201,130,26,.4)}
.ab .ab-body{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px 18px;transition:transform .3s,box-shadow .3s}
.ab .ab-row:hover .ab-body{transform:translateX(4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.3)}
.ab .ab-body h3{font-family:'Sora','Poppins',sans-serif;font-size:1.04rem;font-weight:700;margin:0 0 4px}
.ab .ab-body p{margin:0;color:var(--slate);font-size:.9rem;line-height:1.62}
/* values bento (asymmetric) */
.ab .ab-bento{display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:16px;grid-auto-flow:row dense}
.ab .ab-v{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:24px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.ab .ab-v::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--gold),#e7c089);transform:scaleX(0);transform-origin:left;transition:transform .4s}
.ab .ab-v:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3);border-color:#ecd6b3}
.ab .ab-v:hover::after{transform:scaleX(1)}
.ab .ab-v.big{grid-row:span 2;background:linear-gradient(155deg,#1a130a,#3a2a12);color:#fff;border-color:transparent}
.ab .ab-v.big::after{background:linear-gradient(90deg,#ffce5c,#fff)}
.ab .ab-v.big:hover{border-color:transparent}
.ab .ab-vico{width:50px;height:50px;border-radius:14px;background:var(--gold-soft);color:var(--gold);display:grid;place-items:center;font-size:1.15rem;margin-bottom:14px;transition:transform .35s}
.ab .ab-v.big .ab-vico{background:rgba(255,255,255,.13);color:#ffce5c;width:56px;height:56px;font-size:1.3rem}
.ab .ab-v:hover .ab-vico{transform:scale(1.08) rotate(-5deg)}
.ab .ab-v h3{font-family:'Sora','Poppins',sans-serif;font-size:1.06rem;font-weight:700;margin:0 0 6px}
.ab .ab-v.big h3{font-size:1.4rem;color:#fff}
.ab .ab-v p{margin:0;color:var(--slate);font-size:.9rem;line-height:1.58}
.ab .ab-v.big p{color:rgba(255,255,255,.82);font-size:.98rem;line-height:1.66}
/* serve chips */
.ab .ab-chips{display:flex;flex-wrap:wrap;gap:11px;justify-content:center}
.ab .ab-chip{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:11px 17px;font-weight:600;font-size:.9rem;color:var(--ink);transition:.25s}
.ab .ab-chip i{color:var(--gold);font-size:.78rem}
.ab .ab-chip:hover{border-color:var(--gold);color:var(--gold);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(201,130,26,.4)}
/* faq */
.ab .ab-fbox{max-width:820px;margin:0 auto}
.ab .ab-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.ab .ab-fi:hover{border-color:#ecd6b3}
.ab .ab-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ab .ab-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--gold-soft);color:var(--gold);display:grid;place-items:center;font-size:.82rem;transition:transform .35s}
.ab .ab-fi.open .ab-ft{transform:rotate(45deg)}
.ab .ab-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ab .ab-fi.open .ab-fb{max-height:340px;padding:0 20px 18px}
.ab .ab-soft{background:linear-gradient(180deg,#f7f3ec,#fbf8f2)}
/* cta */
.ab .ab-cta{padding:0 0 70px}
.ab .ab-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#c9821a,transparent 55%),linear-gradient(120deg,#1a130a,#3a2a12);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.ab .ab-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ab .ab-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ab .ab-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ab .ab-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.ab .ab-cta .w{background:#fff;color:var(--gold)}.ab .ab-cta .g{background:#25d366;color:#04260f}.ab .ab-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.ab .ab-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.ab .ab-hero{grid-template-columns:1fr;gap:24px}.ab .ab-nums{position:static}.ab .ab-bento{grid-template-columns:1fr 1fr}.ab .ab-v.big{grid-row:auto;grid-column:span 2}}
@media(max-width:560px){.ab .ab-bento{grid-template-columns:1fr}.ab .ab-v.big{grid-column:auto}.ab .ab-ngrid{grid-template-columns:1fr 1fr}}
@media(prefers-reduced-motion:reduce){.ab *{transition:none!important;animation:none!important}.ab .rv{opacity:1!important;transform:none!important}}
</style>
<div class="ab">
<div class="ab-in">
<nav class="ab-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">About us</span></nav>
<section class="ab-hero">
<div class="rv">
<span class="ab-eyebrow"><i class="fa-solid fa-circle-info"></i> Who we are</span>
<h1 class="disp">Trusted Dehradun Taxi Service built on <em>one promise</em></h1>
<p class="ab-lead"><strong>Anaya Cab Service</strong> is a Dehradun-based cab operator for local rides, Jolly Grant Airport transfers, outstation trips and the Char Dham Yatra. We started with a small fleet and a simple belief — that a taxi ride should feel safe, honest and stress-free from the first call to the final drop — and we still run every booking that way.</p>
<blockquote class="ab-quote">
<p>&ldquo;We don&rsquo;t just move people across Dehradun — we take responsibility for how they feel on the way.&rdquo;</p>
<cite>— The Anaya Cab Service team</cite>
</blockquote>
<div class="ab-herocta">
<a class="ab-btn ab-btn-g" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="ab-btn ab-btn-w" href="https://wa.me/<?php echo defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : ''; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="ab-btn ab-btn-o" href="/services"><i class="fa-solid fa-route"></i> View services</a>
</div>
</div>
<aside class="ab-nums rv" aria-label="Anaya Cab Service by the numbers">
<span class="tag"><i class="fa-solid fa-mountain-sun"></i> By the numbers</span>
<h3 class="disp">The trust we have earned</h3>
<div class="ab-ngrid">
<div class="ab-ncell"><span class="ab-num"><?php echo $stat_customers; ?></span><span>Happy customers</span></div>
<div class="ab-ncell"><span class="ab-num"><?php echo $stat_drivers; ?></span><span>Verified drivers</span></div>
<div class="ab-ncell"><span class="ab-num"><?php echo $stat_cities; ?></span><span>Cities covered</span></div>
<div class="ab-ncell"><span class="ab-num"><?php echo $stat_safety; ?></span><span>Safe-ride promise</span></div>
</div>
<div class="foot"><i class="fa-solid fa-circle-check"></i> Fixed fares &amp; 24×7 support on every booking.</div>
</aside>
</section>
<div class="ab-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> is a Dehradun taxi provider running verified, air-conditioned cabs for local rides, Jolly Grant Airport pickup and drop, outstation trips to Haridwar, Rishikesh, Mussoorie, Delhi and Nainital, and full Char Dham Yatra packages — available 24×7 with fixed, transparent fares and no advance on most bookings.</p>
</div>
</div>
<!-- STORY -->
<section class="ab-sec rv"><div class="ab-in">
<div class="ab-sh"><span class="ey"><i class="fa-solid fa-road"></i> Our story</span><h2 class="disp">From one promise to every route in Uttarakhand</h2><p>How a small Dehradun cab service grew into a trusted name for city, hill and pilgrimage travel.</p></div>
<div class="ab-tl">
<?php foreach ($__story as $s): ?>
<div class="ab-row rv"><div class="ab-dot"><i class="fa-solid <?php echo $s[0]; ?>"></i></div><div class="ab-body"><h3><?php echo $s[1]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- VALUES BENTO -->
<section class="ab-sec ab-soft rv"><div class="ab-in">
<div class="ab-sh"><span class="ey"><i class="fa-solid fa-medal"></i> What we stand for</span><h2 class="disp">The values behind every ride</h2></div>
<div class="ab-bento">
<?php foreach ($__values as $i => $v):
$big = ($v[0] === 'big');
if ($big) { $ic = $v[1]; $ti = $v[2]; $de = $v[3]; } else { $ic = $v[0]; $ti = $v[1]; $de = $v[2]; }
?>
<div class="ab-v rv<?php echo $big ? ' big' : ''; ?>">
<div class="ab-vico"><i class="fa-solid <?php echo $ic; ?>"></i></div>
<h3><?php echo $ti; ?></h3>
<p><?php echo $de; ?></p>
</div>
<?php endforeach; ?>
</div>
</div></section>
<!-- 5-STEP DRIVER VERIFICATION & SAFETY PROTOCOL -->
<section class="ab-sec rv"><div class="ab-in">
<div class="ab-sh"><span class="ey"><i class="fa-solid fa-shield-check"></i> EEAT Trust Framework</span><h2 class="disp">Our 5-Step Driver Verification &amp; Safety Protocol</h2><p>How we ensure every journey across Dehradun and Himalayan highways is 100% safe, disciplined, and reliable.</p></div>
<div class="ab-bento" style="grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));">
<div class="ab-v rv">
<div class="ab-vico"><i class="fa-solid fa-id-card-clip"></i></div>
<h3>1. Background &amp; Police Verification</h3>
<p>Every chauffeur undergoes thorough local police verification, residential background screening, and commercial license authenticity checks.</p>
</div>
<div class="ab-v rv">
<div class="ab-vico"><i class="fa-solid fa-mountain-sun"></i></div>
<h3>2. 5+ Years Hill Road Experience</h3>
<p>Drivers assigned to Mussoorie, Nainital, and Char Dham routes must possess a minimum of 5 years proven mountain driving experience.</p>
</div>
<div class="ab-v rv">
<div class="ab-vico"><i class="fa-solid fa-car-on"></i></div>
<h3>3. 24-Point Vehicle Inspection</h3>
<p>Braking systems, mountain tire treads, suspension, dual AC units, and emergency medical kits are inspected prior to every outstation departure.</p>
</div>
<div class="ab-v rv">
<div class="ab-vico"><i class="fa-solid fa-user-shield"></i></div>
<h3>4. Passenger Hospitality &amp; Ethics</h3>
<p>Strict zero-tolerance policy against rash driving, route detours, or unannounced stopovers. Courteous, non-intrusive, family-friendly service.</p>
</div>
<div class="ab-v rv">
<div class="ab-vico"><i class="fa-solid fa-satellite-dish"></i></div>
<h3>5. 24×7 GPS &amp; Dispatch Monitoring</h3>
<p>Continuous route tracking via GPS telemetry and round-the-clock telephone and WhatsApp control room support for instant assistance.</p>
</div>
</div>
</div></section>
<!-- WHO WE SERVE -->
<section class="ab-sec ab-soft rv"><div class="ab-in">
<div class="ab-sh"><span class="ey"><i class="fa-solid fa-people-group"></i> Who travels with us</span><h2 class="disp">Built for every kind of traveller</h2></div>
<div class="ab-chips">
<?php foreach ($__serve as $s): ?><span class="ab-chip"><i class="fa-solid fa-user-check"></i> <?php echo $s; ?></span><?php endforeach; ?>
</div>
</div></section>
<!-- FAQ -->
<section class="ab-sec ab-soft rv" id="faq"><div class="ab-in">
<div class="ab-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">About Anaya Cab Service — FAQs</h2></div>
<div class="ab-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="ab-fi<?php echo $i===0?' open':''; ?>"><div class="ab-fh"><?php echo $f[0]; ?><span class="ab-ft"><i class="fa-solid fa-plus"></i></span></div><div class="ab-fb"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- CTA -->
<section class="ab-cta rv"><div class="ab-in">
<div class="ab-ctain">
<h2 class="disp">Ready to travel with a team that cares?</h2>
<p>Book your next Dehradun ride — local, airport, outstation or Char Dham — in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book a cab</a>
<a class="g" href="https://wa.me/<?php echo defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : ''; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : ''; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo defined('BUSINESS_PHONE') ? BUSINESS_PHONE : ''; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ab .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ab .ab-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
/* Count-up stats: parse leading number and animate from 0 to target */
var nums=document.querySelectorAll('.ab .ab-num');
function run(el){
var t=el.textContent.trim(),m=t.match(/^(\d+)(.*)$/);
if(!m)return;
var target=parseInt(m[1],10),suf=m[2]||'',start=null,dur=1100;
if(target===0) return;
function step(ts){
if(!start)start=ts;
var p=Math.min((ts-start)/dur,1),val=Math.floor(p*target);
el.textContent=val+suf;
if(p<1)requestAnimationFrame(step);
else el.textContent=target+suf;
}
requestAnimationFrame(step);
}
if('IntersectionObserver' in window){
var co=new IntersectionObserver(function(es){
es.forEach(function(e){
if(e.isIntersecting){run(e.target);co.unobserve(e.target);}
});
},{threshold:.5});
nums.forEach(function(e){co.observe(e);});
}
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>