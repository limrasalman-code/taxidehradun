﻿<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Dhanaulti Taxi | From ₹2,200';
$page_description = 'Dehradun to Dhanaulti taxi from ₹2,200 (60 km, 2.5 hr). Eco Park & Surkanda Devi drops. Sedan, Ertiga, Innova. Fixed fares.';
$page_url         = $domain . "/dehradun-to-dhanaulti-taxi";

$__faqs = [
["How far is Dhanaulti from Dehradun by taxi?", "Dhanaulti is about 60 km from Dehradun via Mussoorie or Suwakholi route, taking around 2 to 2.5 hours of mountain drive."],
["What is the one-way taxi fare from Dehradun to Dhanaulti?", "One-way sedan taxi fare from Dehradun to Dhanaulti starts at ₹2,200 for a Dzire, ₹3,000 for an Ertiga (SUV), and ₹3,800 for an Innova Crysta."],
["Can I visit Dhanaulti and Eco Park on a same-day return trip from Dehradun?", "Yes. You can book an 8-hour or full-day package covering Mussoorie, Suwakholi, Dhanaulti Eco Park, and Surkanda Devi Temple."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Dhanaulti Taxi Service','serviceType'=>'Outstation hill taxi transfer','description'=>'One-way and round-trip taxi from Dehradun to Dhanaulti over 60 km with verified hill drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Dhanaulti']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'2200','description'=>'One way sedan taxi fare from Dehradun to Dhanaulti starts from 2,200 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Dhanaulti Eco Park','~60 km','2,200','3,000','3,800','/dehradun-to-dhanaulti-taxi'],
['Dehradun → Surkanda Devi Temple','~67 km','2,500','3,300','4,200','/dehradun-to-dhanaulti-taxi'],
['Dehradun → Kanatal Hill Resorts','~78 km','2,800','3,600','4,500','/dehradun-to-kanatal-taxi-service'],
];

$__sights = [
['Dhanaulti Eco Park','fa-tree','Pine and deodar forest park with walking trails and mountain air.'],
['Surkanda Devi Temple','fa-place-of-worship','Reachable by road and ropeway cable car, offering 360-degree Himalayan views.'],
['Potato Farm & Apple Orchards','fa-leaf','Quiet viewpoints and terrace farming scenes.'],
['Kanatal & Chamba','fa-mountain','Quiet hill resort hamlets along the Tehri road.'],
];

$__related = [
['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],['Dehradun → Tehri','/dehradun-to-tehri-taxi-service','fa-water'],
['Dehradun → Chakrata','/dehradun-to-chakrata-taxi','fa-mountain'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],
];
?>
<main id="main">
<style>
.dh{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--pine:#0f766e;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eaf4f1 0%,#ffffff 440px)}
.dh *{box-sizing:border-box}
.dh .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.dh .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.dh .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.dh .rv.in{opacity:1;transform:none}
.dh .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.dh .crumb a{color:var(--slate);text-decoration:none}.dh .crumb a:hover{color:var(--pine)}.dh .crumb i{font-size:.6rem;color:var(--mute)}.dh .crumb .cur{color:var(--ink);font-weight:600}
.dh .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.dh .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.dh .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.dh .hero h1 em{font-style:normal;color:var(--pine)}
.dh .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.dh .lead strong{color:var(--ink)}
.dh .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.dh .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.dh .m i{color:var(--pine)}.dh .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.dh .m span{font-size:.8rem;color:var(--slate)}
.dh .herocta{display:flex;gap:12px;flex-wrap:wrap}
.dh .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.dh .btn-p{background:var(--pine);color:#fff;box-shadow:0 16px 34px -14px rgba(15,118,110,.55)}.dh .btn-p:hover{transform:translateY(-2px)}
.dh .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.dh .btn-g:hover{transform:translateY(-2px)}
.dh .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.dh .btn-o:hover{border-color:var(--pine);color:var(--pine)}
.dh .card{position:sticky;top:88px;background:linear-gradient(160deg,#06231f,#0f766e);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(6,35,31,.6);overflow:hidden}
.dh .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#bdf3ea;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.dh .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.dh .fares{display:grid;gap:8px;margin:14px 0 0}
.dh .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.dh .fr .v{font-weight:700;font-size:.9rem}.dh .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.dh .card .cta{display:grid;gap:10px;margin-top:16px}
.dh .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.dh .card .cta .w{background:#fff;color:var(--pine)}.dh .card .cta .g{background:#25d366;color:#04260f}
.dh .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--pine);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.dh .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);margin-bottom:8px}
.dh .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.dh .qa strong{color:var(--ink)}
.dh .sec{padding:48px 0}
.dh .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.dh .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);background:#e1f1ee;padding:7px 13px;border-radius:999px}
.dh .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.dh .sh p{color:var(--slate);margin:0}
.dh .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.dh .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.dh .sico{flex:none;width:44px;height:44px;border-radius:12px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:1rem}
.dh .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.dh .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.dh .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.dh .tscroll{overflow-x:auto}
.dh table{width:100%;border-collapse:collapse;min-width:560px}
.dh th,.dh td{padding:15px 18px;text-align:left;font-size:.92rem}
.dh thead th{background:var(--soft);color:var(--pine);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.dh tbody tr{border-top:1px solid var(--line)}
.dh .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.dh .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.dh .rchip i{color:var(--pine)}.dh .rchip:hover{border-color:var(--pine);color:var(--pine);transform:translateY(-2px)}
.dh .fbox{max-width:820px;margin:0 auto}
.dh .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.dh .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.dh .ft{flex:none;width:26px;height:26px;border-radius:8px;background:#e1f1ee;color:var(--pine);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.dh .fi.open .ft{transform:rotate(45deg)}
.dh .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.dh .fi.open .fb{max-height:380px;padding:0 20px 18px}
.dh .soft{background:linear-gradient(180deg,#eaf4f1,#f6fbfa)}
.dh .cta{padding:0 0 70px}
.dh .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0f766e,transparent 55%),linear-gradient(120deg,#06231f,#0f766e);color:#fff;text-align:center;padding:50px 24px}
.dh .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.dh .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.dh .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.dh .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.dh .cta .w{background:#fff;color:var(--pine)}.dh .cta .g{background:#25d366;color:#04260f}.dh .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.dh .hero{grid-template-columns:1fr;gap:24px}.dh .card{position:static}}
</style>

<div class="dh">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Dhanaulti Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-tree"></i> Eco Park &amp; Pines · 60 km</span>
<h1 class="disp">Dehradun to Dhanaulti Taxi Fare <em>&amp; Distance (Eco Park Cab)</em></h1>
<p class="lead"><strong>Dehradun to Dhanaulti taxi fare starts from ₹2,200 for a sedan.</strong> Anaya Cab Service offers scenic hill transfers to Eco Park, Surkanda Devi Temple, and Kanatal with verified hill drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>60 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>2–2.5 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-mountain"></i> <b>~2,280 m</b> <span>altitude</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹2,200+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Dhanaulti cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Dhanaulti taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Dhanaulti fare">
<span class="tag"><i class="fa-solid fa-tree"></i> Hill fare</span>
<h3 class="disp">Dehradun → Dhanaulti</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹2,200</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹3,000</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹3,800</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Dhanaulti taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Dehradun to Dhanaulti Distance &amp; Taxi Fare</div>
<p itemprop="text"><strong>The road distance from Dehradun to Dhanaulti is 60 km via Mussoorie/Suwakholi route, taking 2 to 2.5 hours of mountain drive.</strong> One-way taxi fare starts at <strong>₹2,200 for Sedan (Dzire)</strong>, <strong>₹3,000 for SUV (Ertiga)</strong>, and <strong>₹3,800 for Innova Crysta</strong>. Full-day return packages are available covering Dhanaulti Eco Park, Surkanda Devi Temple (Ropeway), Apple Orchards, and Kanatal.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Dhanaulti taxi fares by destination</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Dhanaulti taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Dhanaulti</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Dhanaulti taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Dhanaulti or Surkanda Devi? Book your cab now</h2>
<p>Fixed fare, verified hill driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Dhanaulti cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Dhanaulti taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.dh .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.dh .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

