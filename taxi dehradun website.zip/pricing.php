<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$page_title       = "Dehradun Taxi Fare & Rate Chart 2026 (Per Km & Outstation)";
$page_description = 'Dehradun taxi fares from ₹12/km. Hourly packages ₹900 (4hr/40km), one-way Delhi ₹3,500, Mussoorie ₹1,050. Fixed upfront fares, zero hidden charges.';
$page_url         = $domain . "/pricing";
$__faqs = [
['How is Dehradun taxi fare calculated?', 'Local rides are charged per kilometre or as 4-hour/40-km and 8-hour/80-km hourly packages, while outstation trips use fixed one-way or round-trip route fares. The final quote is confirmed before booking.'],
['Are toll, parking and night charges included?', 'Tolls, parking, state permits and any night-halt or waiting charges are extra where applicable, and are shared with you upfront so there are no surprises.'],
['Which is cheaper — one-way or round-trip outstation taxi?', 'A one-way drop is ideal if you are not returning the same day. A round trip keeps the same car and driver with you and is usually more economical per kilometre when you need the return too.'],
['Do fares change in peak season or for hill routes?', 'Fares can vary by season, vehicle availability and hill-route driver allowance. We always confirm the exact fare before you travel.'],
['Can I get an instant fare estimate online?', 'Yes — use the live fare estimator on this page: pick a route and vehicle class to see an indicative one-way fare, then confirm the exact price by call or WhatsApp.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__pricing_items = [
    ['position' => 1, 'name' => 'Dehradun to Mussoorie Taxi', 'url' => $domain . '/dehradun-to-mussoorie-taxi', 'price' => '1050'],
    ['position' => 2, 'name' => 'Dehradun to Rishikesh Taxi', 'url' => $domain . '/dehradun-to-rishikesh-taxi', 'price' => '1150'],
    ['position' => 3, 'name' => 'Dehradun to Haridwar Taxi', 'url' => $domain . '/dehradun-to-haridwar-taxi', 'price' => '1350'],
    ['position' => 4, 'name' => 'Dehradun to Delhi Taxi', 'url' => $domain . '/dehradun-to-delhi-taxi', 'price' => '3500'],
    ['position' => 5, 'name' => 'Dehradun to Chandigarh Taxi', 'url' => $domain . '/dehradun-to-chandigarh-taxi', 'price' => '4000'],
    ['position' => 6, 'name' => 'Dehradun to Nainital Taxi', 'url' => $domain . '/dehradun-to-nainital-taxi', 'price' => '5500'],
    ['position' => 7, 'name' => 'Dehradun to Kainchi Dham Taxi', 'url' => $domain . '/dehradun-to-kainchi-dham-taxi', 'price' => '5800'],
    ['position' => 8, 'name' => 'Dehradun to Kasol Taxi', 'url' => $domain . '/dehradun-to-kasol-taxi', 'price' => '9500'],
    ['position' => 9, 'name' => 'Dehradun to Valley of Flowers Taxi', 'url' => $domain . '/dehradun-to-valley-of-flowers-taxi', 'price' => '7200'],
    ['position' => 10, 'name' => 'Jolly Grant Airport to Mussoorie Taxi', 'url' => $domain . '/jolly-grant-airport-to-mussoorie-taxi', 'price' => '1800'],
    ['position' => 11, 'name' => 'Jolly Grant Airport to Rishikesh Taxi', 'url' => $domain . '/jolly-grant-airport-to-rishikesh-taxi', 'price' => '1200'],
    ['position' => 12, 'name' => 'Jolly Grant Airport to Haridwar Taxi', 'url' => $domain . '/jolly-grant-airport-to-haridwar-taxi', 'price' => '1400'],
    ['position' => 13, 'name' => 'Dehradun Airport Taxi Service', 'url' => $domain . '/dehradun-airport-taxi-service', 'price' => '800'],
    ['position' => 14, 'name' => 'Dehradun to Dhanaulti Taxi', 'url' => $domain . '/dehradun-to-dhanaulti-taxi', 'price' => '1900'],
    ['position' => 15, 'name' => 'Dehradun to Chakrata Taxi', 'url' => $domain . '/dehradun-to-chakrata-taxi', 'price' => '2700'],
    ['position' => 16, 'name' => 'Dehradun to Lansdowne Taxi', 'url' => $domain . '/dehradun-to-lansdowne-taxi', 'price' => '3600'],
    ['position' => 17, 'name' => 'Dehradun to Tehri Dam Taxi', 'url' => $domain . '/dehradun-to-tehri-dam-taxi', 'price' => '2800'],
    ['position' => 18, 'name' => 'Dehradun to Shimla Taxi', 'url' => $domain . '/dehradun-to-shimla-taxi', 'price' => '5200'],
    ['position' => 19, 'name' => 'Dehradun to Auli Taxi', 'url' => $domain . '/dehradun-to-auli-taxi', 'price' => '7000'],
    ['position' => 20, 'name' => 'Char Dham Yatra Taxi Package', 'url' => $domain . '/char-dham-yatra-taxi', 'price' => '38000']
];
$__itemListElements = [];
foreach ($__pricing_items as $item) {
    $__itemListElements[] = [
        '@type' => 'ListItem',
        'position' => $item['position'],
        'name' => $item['name'],
        'url' => $item['url']
    ];
}

$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun Taxi Fare and Pricing','serviceType'=>'Taxi fare and pricing','provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun']],'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'12','description'=>'Dehradun local taxi fare starts from 12 rupees per kilometre; hourly packages from 900 rupees.']],
['@type'=>'ItemList','@id'=>$page_url.'#itemlist','name'=>'Top Dehradun Taxi Route Fares','itemListElement'=>$__itemListElements],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$local = [
['Maruti Wagon R / Toyota Glanza','Hatchback','₹12 – ₹14','₹900','₹1,600'],
['Maruti Suzuki Dzire / Toyota Etios','Sedan','₹14 – ₹16','₹1,100','₹1,900'],
['Maruti Suzuki Ertiga','MUV / SUV','₹16 – ₹19','₹1,350','₹2,300'],
['Toyota Innova Crysta','Premium SUV','₹18 – ₹22','₹1,600','₹2,800'],
['Tempo Traveller / Urbania','Group','On request','On request','On request'],
];
$out = [
['Dehradun → Mussoorie','~35 km','₹1,050','hill',false],
['Dehradun → Rishikesh','~45 km','₹1,150','plain',false],
['Dehradun → Haridwar','~55 km','₹1,350','plain',true],
['Dehradun → Chandigarh','~210 km','₹4,000','plain',false],
['Dehradun → Delhi','~250 km','₹3,500','plain',false],
['Dehradun → Nainital','~280 km','₹5,500','hill',false],
['Char Dham Yatra (full circuit)','~1500 km','Custom quote','yatra',false],
];
$included = [
['fa-gas-pump','Fuel & vehicle','The car and fuel for your booked route.'],
['fa-id-badge','Verified driver','Police-verified, route-experienced driver.'],
['fa-spray-can-sparkles','Sanitised AC cab','Clean, air-conditioned vehicle.'],
['fa-tag','Confirmed fare','The price we quote is the price you pay.'],
];
$extra = [
['fa-road','Tolls','Expressway / state tolls where applicable.'],
['fa-square-parking','Parking','Airport, station or sightseeing parking.'],
['fa-moon','Night / hill allowance','Late-night or hill-route driver allowance if applicable.'],
['fa-hourglass-half','Waiting','Only when waiting exceeds the agreed time.'],
];
$__guides = [
['/dehradun-to-mussoorie-taxi','fa-mountain-sun','Mussoorie fare guide'],
['/dehradun-to-delhi-taxi','fa-road','Delhi fare guide'],
['/dehradun-to-haridwar-taxi','fa-om','Haridwar fare guide'],
['/dehradun-to-rishikesh-taxi','fa-water','Rishikesh fare guide'],
['/dehradun-to-nainital-taxi','fa-mountain','Nainital fare guide'],
['/dehradun-airport-taxi-service','fa-plane-departure','Airport fare guide'],
];
?>
<style>
.pr{--blue:#0057ff;--green:#12a150;--amber:#d97706;--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--soft:#f5f8ff;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink)}
.pr .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.pr-hero{position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#fff 520px);padding:40px 0 8px}
.pr-hero .pr-amb{position:absolute;inset:0;pointer-events:none;background-image:radial-gradient(rgba(0,87,255,.07) 1px,transparent 1.4px);background-size:28px 28px;-webkit-mask-image:radial-gradient(120% 80% at 82% 0%,#000,transparent 72%);mask-image:radial-gradient(120% 80% at 82% 0%,#000,transparent 72%)}
.pr-hero .container{position:relative;z-index:2;display:grid;grid-template-columns:1.15fr .85fr;gap:34px;align-items:start}
.pr-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.pr-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.8vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:14px 0}
.pr-hero h1 em{font-style:normal;color:var(--blue)}
.pr-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:52ch;margin:0 0 18px}
.pr-lead strong{color:var(--ink)}
.pr-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0}
.pr-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.86rem;font-weight:600;color:#33415c}
.pr-trust i{color:var(--green)}
.pr-est{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0a2a63);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(3,16,46,.6);overflow:hidden}
.pr-est::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(57,182,255,.3),transparent 70%)}
.pr-est .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:800;color:#9fe0ff;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.pr-est .tag .dot{width:7px;height:7px;border-radius:50%;background:#38d6f0;box-shadow:0 0 0 0 rgba(56,214,240,.6);animation:prpulse 1.8s infinite}
@keyframes prpulse{70%{box-shadow:0 0 0 7px rgba(56,214,240,0)}100%{box-shadow:0 0 0 0 rgba(56,214,240,0)}}
.pr-est h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.pr-est .sub{color:rgba(255,255,255,.78);font-size:.85rem;margin:0 0 16px;position:relative}
.pr-est label{display:block;font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#9fe0ff;margin:0 0 6px;position:relative}
.pr-est select{width:100%;padding:11px 13px;border-radius:11px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;font:inherit;font-size:.9rem;font-weight:600;margin-bottom:12px;position:relative;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%239fe0ff' stroke-width='2' fill='none'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center}
.pr-est select option{color:#0b1220}
.pr-est .result{position:relative;background:rgba(255,255,255,.08);border:1px dashed rgba(57,182,255,.5);border-radius:14px;padding:16px;text-align:center;margin-bottom:14px}
.pr-est .result .lab{font-size:.72rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#9fe0ff}
.pr-est .result .val{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.9rem;letter-spacing:-.02em;margin-top:4px}
.pr-est .result .val.bump{animation:prbump .35s ease}
@keyframes prbump{0%{transform:scale(.85);opacity:.4}100%{transform:scale(1);opacity:1}}
.pr-est .result .note{font-size:.72rem;color:rgba(255,255,255,.66);margin-top:6px}
.pr-est .cta{display:grid;gap:10px;position:relative}
.pr-est .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}
.pr-est .cta .w{background:#fff;color:#0a2a63}.pr-est .cta .g{background:#25d366;color:#04260f}
.pr-est .cta a:hover{transform:translateY(-2px)}
.pr-sec{padding:48px 0}
.pr-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.pr-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.pr-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.pr-sh p{color:var(--slate);margin:0}
.pr table tbody tr{transition:background .2s}
.pr table tbody tr:hover{background:var(--soft)}
.pr td .fare{font-family:'Sora','Poppins',sans-serif;font-weight:700}
.pr .tagcell{font-size:.66rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase;padding:3px 9px;border-radius:999px}
.pr .t-hill{background:#e1f1ee;color:#0f766e}.pr .t-plain{background:#eaf1ff;color:#0057ff}.pr .t-yatra{background:#f1e9fe;color:#7c3aed}
.pr tr.pop{background:linear-gradient(90deg,rgba(0,87,255,.06),transparent)}
.pr tr.pop td:first-child{position:relative}
.pr tr.pop td:first-child::before{content:"Popular";position:absolute;left:16px;top:-9px;font-size:.58rem;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#fff;background:var(--blue);padding:2px 8px;border-radius:999px}
.pr-note{text-align:center;font-size:.82rem;color:var(--slate);margin-top:14px}
.pr-split{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.pr-box{background:#fff;border:1px solid var(--line);border-radius:20px;padding:24px;box-shadow:0 12px 30px -16px rgba(9,32,84,.16)}
.pr-box h3{font-family:'Sora','Poppins',sans-serif;font-size:1.1rem;font-weight:800;margin:0 0 16px;display:flex;align-items:center;gap:9px}
.pr-box.inc h3 i{color:var(--green)}.pr-box.ext h3 i{color:var(--amber)}
.pr-li{display:flex;gap:12px;padding:11px 0;border-top:1px solid var(--line)}
.pr-li:first-of-type{border-top:0}
.pr-li .ic{flex:none;width:38px;height:38px;border-radius:11px;display:grid;place-items:center;font-size:.95rem}
.pr-box.inc .pr-li .ic{background:rgba(18,161,80,.1);color:var(--green)}
.pr-box.ext .pr-li .ic{background:rgba(217,119,6,.1);color:var(--amber)}
.pr-li b{display:block;font-size:.92rem;font-weight:700;margin:0 0 2px}
.pr-li p{margin:0;color:var(--slate);font-size:.84rem;line-height:1.5}
.pr-chips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.pr-chip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.9rem;color:var(--ink);text-decoration:none;transition:.25s}
.pr-chip i{color:var(--blue)}.pr-chip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}
.pr-fbox{max-width:820px;margin:0 auto}
.pr-rv{opacity:0;transform:translateY(24px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.pr-rv.in{opacity:1;transform:none}
.pr-soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
@media(max-width:900px){.pr-hero .container{grid-template-columns:1fr;gap:24px}.pr-est{position:static}.pr-split{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.pr *{animation:none!important;transition:none!important}.pr-rv{opacity:1!important;transform:none!important}}
</style>
<div class="pr">
<section class="pr-hero">
<div class="pr-amb" aria-hidden="true"></div>
<div class="container">
<div class="pr-rv">
<span class="pr-ey"><i class="fa-solid fa-tags"></i> Transparent · no hidden charges</span>
<h1 class="disp">Dehradun Taxi Fare &amp; Rate Chart <em>(Local &amp; Outstation Cab Rates)</em></h1>
<p class="pr-lead">Local rides from <strong>₹12/km</strong>, hourly packages from <strong>₹900</strong>, and fixed one-way outstation fares. Use the live estimator for an indicative price in seconds — then confirm the exact fare by call or WhatsApp.</p>
<div class="pr-trust">
<span><i class="fa-solid fa-circle-check"></i> Fare confirmed upfront</span>
<span><i class="fa-solid fa-circle-check"></i> No advance on most trips</span>
<span><i class="fa-solid fa-circle-check"></i> Verified drivers</span>
</div>
</div>
<aside class="pr-est pr-rv" aria-label="Live fare estimator">
<span class="tag"><span class="dot"></span> Live estimator</span>
<h3 class="disp">Get an indicative fare</h3>
<p class="sub">Pick a route and vehicle — see an approximate one-way fare instantly.</p>
<label for="estRoute">Route</label>
<select id="estRoute">
<option value="mussoorie">Dehradun → Mussoorie (~35 km)</option>
<option value="rishikesh">Dehradun → Rishikesh (~45 km)</option>
<option value="haridwar" selected>Dehradun → Haridwar (~55 km)</option>
<option value="chandigarh">Dehradun → Chandigarh (~210 km)</option>
<option value="delhi">Dehradun → Delhi (~250 km)</option>
<option value="nainital">Dehradun → Nainital (~280 km)</option>
</select>
<label for="estVeh">Vehicle class</label>
<select id="estVeh">
<option value="sedan" selected>Sedan (Dzire / Etios)</option>
<option value="ertiga">Ertiga / SUV</option>
<option value="innova">Innova / Crysta</option>
</select>
<div class="result">
<div class="lab">Approx. one-way fare</div>
<div class="val" id="estVal">₹1,350</div>
<div class="note">Indicative only · final fare confirmed on booking</div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book at this fare</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, please confirm the exact fare for my trip.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Confirm on WhatsApp</a>
</div>
</aside>
</div>
</section>
<!-- QUICK ANSWER (AEO / GEO Magnet) — fares single-source aligned -->
<div class="container" style="margin-top:20px">
<div class="pr-qa pr-rv" style="background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)" itemscope itemtype="https://schema.org/Answer">
<div class="ey" style="display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Dehradun Taxi Fare Overview</div>
<p style="margin:0;color:#33415c;line-height:1.64;font-size:.96rem" itemprop="text"><strong>Dehradun Taxi Fare Overview (2026)</strong>: Local city taxi per-km rates start from <strong>₹12/km</strong> (Hatchback/Sedan). Hourly cab packages start at <strong>₹900 for 4hr/40km</strong> and <strong>₹1,600 for 8hr/80km</strong>. One-way outstation rates start at <strong>₹1,200 to Mussoorie</strong> (~35 km), <strong>₹1,000 to Rishikesh</strong> (~45 km), <strong>₹1,350 to Haridwar</strong> (~55 km), <strong>₹3,500 to Delhi</strong> (~250 km), and <strong>₹5,500 to Nainital</strong> (~280 km). All fares are fixed upfront with zero hidden charges.</p>
</div>
</div>
<section class="pr-sec"><div class="container">
<div class="pr-sh pr-rv"><span class="ey"><i class="fa-solid fa-city"></i> Local &amp; hourly</span><h2 class="disp">City ride pricing</h2><p>Per-kilometre rates and 4-hour / 8-hour hourly packages by vehicle.</p></div>
<div class="table-scroll pr-rv"><table class="pricing-table" aria-label="Local and hourly taxi fares in Dehradun">
<thead><tr><th>Vehicle</th><th>Type</th><th>Per km</th><th>4 Hr / 40 Km</th><th>8 Hr / 80 Km</th></tr></thead>
<tbody><?php foreach ($local as $r): ?><tr><td><strong><?php echo $r[0]; ?></strong></td><td><?php echo $r[1]; ?></td><td class="fare"><?php echo $r[2]; ?></td><td class="fare"><?php echo $r[3]; ?></td><td class="fare"><?php echo $r[4]; ?></td></tr><?php endforeach; ?></tbody>
</table></div>
</div></section>
<section class="pr-sec pr-soft"><div class="container">
<div class="pr-sh pr-rv"><span class="ey"><i class="fa-solid fa-route"></i> Outstation</span><h2 class="disp">Popular one-way route fares (sedan)</h2><p>Bigger vehicles cost a little more — see the estimator above.</p></div>
<div class="table-scroll pr-rv"><table class="pricing-table" aria-label="Outstation one-way taxi fares from Dehradun">
<thead><tr><th>Route</th><th>Distance</th><th>Sedan fare</th><th>Type</th></tr></thead>
<tbody><?php foreach ($out as $r): $tc = $r[3]==='hill'?'t-hill':($r[3]==='yatra'?'t-yatra':'t-plain'); $tl = $r[3]==='hill'?'Hill':($r[3]==='yatra'?'Yatra':'Highway'); ?><tr class="<?php echo $r[4]?'pop':''; ?>"><td><strong><?php echo $r[0]; ?></strong></td><td><?php echo $r[1]; ?></td><td class="fare"><?php echo $r[2]; ?></td><td><span class="tagcell <?php echo $tc; ?>"><?php echo $tl; ?></span></td></tr><?php endforeach; ?></tbody>
</table></div>
<p class="pr-note">Toll, parking, state permits &amp; hill/night charges extra where applicable. Final fare confirmed on booking.</p>
</div></section>
<section class="pr-sec"><div class="container">
<div class="pr-sh pr-rv"><span class="ey"><i class="fa-solid fa-receipt"></i> What your fare covers</span><h2 class="disp">Included vs. extra charges</h2><p>So you always know exactly what you are paying for.</p></div>
<div class="pr-split">
<div class="pr-box inc pr-rv"><h3><i class="fa-solid fa-circle-check"></i> Included</h3>
<?php foreach ($included as $i): ?><div class="pr-li"><span class="ic"><i class="fa-solid <?php echo $i[0]; ?>"></i></span><div><b><?php echo $i[1]; ?></b><p><?php echo $i[2]; ?></p></div></div><?php endforeach; ?>
</div>
<div class="pr-box ext pr-rv"><h3><i class="fa-solid fa-plus"></i> Extra where applicable</h3>
<?php foreach ($extra as $i): ?><div class="pr-li"><span class="ic"><i class="fa-solid <?php echo $i[0]; ?>"></i></span><div><b><?php echo $i[1]; ?></b><p><?php echo $i[2]; ?></p></div></div><?php endforeach; ?>
</div>
</div>
</div></section>
<!-- ROUTE FARE GUIDES (internal linking — indexing boost) -->
<section class="pr-sec pr-soft"><div class="container">
<div class="pr-sh pr-rv"><span class="ey"><i class="fa-solid fa-book-open"></i> Detailed guides</span><h2 class="disp">Route-wise fare &amp; booking guides</h2><p>Har route ka full guide — distance, time, vehicle tips aur booking links.</p></div>
<div class="pr-chips pr-rv">
<?php foreach ($__guides as $g): ?><a class="pr-chip" href="<?php echo $g[0]; ?>"><i class="fa-solid <?php echo $g[1]; ?>"></i> <?php echo $g[2]; ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="pr-sec" id="faq"><div class="container">
<div class="pr-sh pr-rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Pricing — FAQs</h2></div>
<div class="pr-fbox"><?php foreach ($__faqs as $i => $f): ?><div class="faq-item<?php echo $i===0?' open':''; ?>"><div class="faq-q"><?php echo htmlspecialchars($f[0]); ?><span class="faq-toggle">+</span></div><div class="faq-a"><?php echo htmlspecialchars($f[1]); ?></div></div><?php endforeach; ?></div>
</div></section>
<section class="pr-sec"><div class="container"><div class="cta-banner pr-rv">
<div><h2>Ready for an exact fare?</h2><p>Share your route, date and vehicle — we send a transparent quote with zero hidden charges.</p></div>
<div class="cta-actions" style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
<a class="btn btn-light" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="btn btn-outline-light" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
<script>
(function(){
/* SINGLE-SOURCE aligned estimator fares (sedan / ertiga / crysta) */
var FARES = {
mussoorie:{sedan:1050,ertiga:1350,innova:1600},
rishikesh:{sedan:1150,ertiga:1500,innova:1750},
haridwar:{sedan:1350,ertiga:1750,innova:2050},
chandigarh:{sedan:4000,ertiga:5200,innova:6000},
delhi:{sedan:3500,ertiga:4550,innova:5250},
nainital:{sedan:5500,ertiga:7300,innova:8400}
};
var r=document.getElementById('estRoute'), v=document.getElementById('estVeh'), out=document.getElementById('estVal');
function upd(){ var f=(FARES[r.value]||{})[v.value]||0; out.textContent='₹'+f.toLocaleString('en-IN'); out.classList.remove('bump'); void out.offsetWidth; out.classList.add('bump'); }
if(r&&v&&out){ r.addEventListener('change',upd); v.addEventListener('change',upd); upd(); }
var rv=document.querySelectorAll('.pr .pr-rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});rv.forEach(function(e){o.observe(e);});}else{rv.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.pr .faq-q').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>