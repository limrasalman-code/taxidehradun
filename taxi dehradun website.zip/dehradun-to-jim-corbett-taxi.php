﻿<?php
require_once __DIR__ . '/includes/config.php';
$domain    = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone     = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp  = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = "Dehradun to Jim Corbett Taxi | Cabs ₹3,500 - Anaya Cab";
$page_description = 'Dehradun to Jim Corbett taxi from ₹3,500 (240 km, 6–7 hr) via Ramnagar. Bijrani, Jhirna, Dhela gypsy safaris ₹6,500–₹9,500 – cab + safari in…';
$page_url         = $domain . "/dehradun-to-jim-corbett-taxi";
$__route_schema_handled = true; /* bespoke page — own schema below */

$__faqs = [
['How much is a Dehradun to Jim Corbett taxi?','A one-way sedan taxi from Dehradun to Jim Corbett (Ramnagar) starts at Rs 3,500 for the 240 km drive (6-7 hours). SUV and Innova Crysta fares are Rs 4,700 and Rs 5,600 respectively, confirmed before you book.'],
['How much does a jeep safari cost in Jim Corbett?','A gypsy safari with park entry costs about Rs 6,500-7,500 per jeep in Bijrani, Jhirna and Dhela zones, and Rs 9,000-9,500 in Dhikala. A Dhikala canter seat costs Rs 1,500-2,000 per person.'],
['Which safari zones are open in monsoon?','Jhirna and Dhela remain open year-round, including monsoon. The core zones Bijrani and Dhikala close roughly July to mid-October and reopen around November.'],
['Can you book the safari along with the cab?','Yes. We bundle your cab, resort drop and jeep safari booking (gypsy + entry) so you arrive at the gate with everything arranged — one WhatsApp message confirms both.'],
['How many days should I plan for Jim Corbett from Dehradun?','Two days and one night is ideal: an afternoon safari on day one and a morning safari on day two. Add a third day for a full-day Dhikala excursion (permit required).'],
];
$__faq_ent = [];
foreach ($__faqs as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Jim Corbett Taxi with Safari Booking','serviceType'=>'Wildlife-gateway taxi transfer',
 'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Ramnagar']],
 'url'=>$page_url,
 'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'3500','description'=>'One-way sedan taxi Dehradun to Jim Corbett (Ramnagar) from Rs 3,500; 240 km, 6-7 hours.']],
['@type'=>'TouristAttraction','name'=>'Jim Corbett National Park','description'=>'India\'s oldest national park; tiger reserve with safari zones Bijrani, Jhirna, Dhela and Dhikala near Ramnagar.',
 'geo'=>['@type'=>'GeoCoordinates','latitude'=>'29.5583','longitude'=>'78.7747'],'isAccessibleForFree'=>false],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';

require_once __DIR__ . '/includes/header.php';

$__cab_fares = [
['Sedan (Dzire)','1-4 pax','₹3,500'],
['SUV (Ertiga)','4-6 pax','₹4,700'],
['Innova Crysta','5-7 pax','₹5,600'],
['Tempo Traveller','Groups','On request'],
];
$__zones = [
['Bijrani','fa-paw','₹6,500-7,500 / gypsy','Nov-Jun','The most-booked tiger zone; entry via Aamdanda gate, 90 min from Ramnagar.'],
['Jhirna','fa-tree','₹6,500-7,500 / gypsy','Open all year','The only core-side zone open in monsoon; great for sloth bear and birding.'],
['Dhela','fa-leaf','₹6,000-7,000 / gypsy','Open all year','Buffer zone with mixed forest and grassland; reliable sightings year-round.'],
['Dhikala','fa-binoculars','₹9,000-9,500 / gypsy','Nov-Jun','The iconic grassland; canter seats ₹1,500-2,000 per person, permit required.'],
];
$__itin = [
['Day 1','fa-sun','Dehradun → Ramnagar + afternoon safari','6 AM pickup, lunch at Ramnagar, Bijrani or Jhirna gypsy safari (3-4 hr), resort check-in and dinner.'],
['Day 2','fa-mountain-sun','Morning safari → return','Dawn Dhela or second gypsy safari, Corbett Falls or Kosi river-side lunch, back in Dehradun by evening.'],
['Day 3 (optional)','fa-flag','Full-day Dhikala or Garjiya temple','Permit-based Dhikala excursion with canter/gypsy, or Garjiya Devi temple + Kosi barrage, then drop.'],
];
$__wa_safari = rawurlencode('Hi Anaya Cab, I want a Dehradun to Jim Corbett taxi + jeep safari booking.');
?>
<main id="main">
<style>
.jc{--moss:#4d7c0f;--lime:#bef264;--pine:#1a2e05;--fern:#3f6212;--sand:#f1f8e6;--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;--amber:#b45309;--r:20px;--rs:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,var(--sand) 0%,#fff 480px)}
.jc *{box-sizing:border-box}
.jc .jc-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.jc .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.jc .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.jc .rv.in{opacity:1;transform:none}
.jc .jc-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.jc .jc-crumb a{color:var(--slate);text-decoration:none}.jc .jc-crumb a:hover{color:var(--moss)}.jc .jc-crumb i{font-size:.6rem;color:#94a3b8}.jc .jc-crumb .cur{color:var(--ink);font-weight:600}
.jc .jc-hero{display:grid;grid-template-columns:1.15fr .95fr;gap:36px;align-items:start;padding:24px 0 12px}
.jc .jc-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--moss);background:rgba(77,124,15,.1);padding:7px 13px;border-radius:999px}
.jc .jc-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.4vw,3rem);font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:14px 0 14px}.jc .jc-hero h1 em{font-style:normal;color:var(--moss)}
.jc .jc-qa{background:#fff;border:1px solid var(--line);border-left:4px solid var(--moss);border-radius:16px;padding:18px 20px;box-shadow:0 18px 40px -26px rgba(26,46,5,.3);margin:0 0 20px}
.jc .jc-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--moss);margin-bottom:8px}
.jc .jc-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.96rem}.jc .jc-qa strong{color:var(--ink)}
.jc .jc-cta{display:flex;gap:12px;flex-wrap:wrap}
.jc .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rs);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.jc .btn-m{background:var(--moss);color:#fff;box-shadow:0 16px 34px -14px rgba(77,124,15,.55)}.jc .btn-m:hover{transform:translateY(-2px);filter:brightness(1.06)}
.jc .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.jc .btn-g:hover{transform:translateY(-2px)}
.jc .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.jc .btn-o:hover{border-color:var(--moss);color:var(--moss)}
/* safari desk card */
.jc .desk{position:sticky;top:88px;background:linear-gradient(160deg,var(--pine),var(--fern));border-radius:24px;padding:26px;color:#fff;box-shadow:0 30px 60px -28px rgba(26,46,5,.6);overflow:hidden}
.jc .desk::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(190,242,102,.28),transparent 70%)}
.jc .desk .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:var(--lime);background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.jc .desk h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.jc .desk .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 14px;position:relative}
.jc .jeep{position:relative;height:70px;margin:0 0 10px;overflow:hidden}
.jc .jeep .trail{position:absolute;left:0;right:0;bottom:16px;height:3px;background:repeating-linear-gradient(90deg,var(--lime) 0 10px,transparent 10px 20px);border-radius:3px;opacity:.85}
.jc .jeep .g{position:absolute;bottom:20px;left:6%;color:#fff;font-size:1rem;animation:jcrun 5s ease-in-out infinite}
@keyframes jcrun{0%,100%{left:6%}50%{left:84%}}
.jc .jeep .paw{position:absolute;bottom:34px;color:var(--lime);font-size:.8rem;opacity:.8}
.jc .jeep .p1{left:30%}.jc .jeep .p2{left:62%}
.jc .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px;margin-bottom:8px;transition:background .25s;position:relative}.jc .fr:hover{background:rgba(255,255,255,.14)}
.jc .fr .v{font-weight:700;font-size:.9rem}.jc .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.jc .desk .cta{display:grid;gap:10px;margin-top:14px;position:relative}
.jc .desk .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}
.jc .desk .cta .w{background:#fff;color:var(--pine)}.jc .desk .cta .g{background:#25d366;color:#04260f}.jc .desk .cta a:hover{transform:translateY(-2px)}
.jc .desk .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.jc .sec{padding:50px 0}
.jc .sh{text-align:center;max-width:720px;margin:0 auto 30px}.jc .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--moss);background:rgba(77,124,15,.1);padding:7px 13px;border-radius:999px}.jc .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.jc .sh p{color:var(--slate);margin:0}
.jc .zgrid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.jc .zc{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:24px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.jc .zc::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--moss),var(--lime));transform:scaleX(0);transform-origin:left;transition:transform .4s}
.jc .zc:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(26,46,5,.3);border-color:#d3e8b8}.jc .zc:hover::after{transform:scaleX(1)}
.jc .zc .hd{display:flex;align-items:center;gap:14px;margin-bottom:8px}
.jc .zc .ic{flex:none;width:50px;height:50px;border-radius:14px;background:rgba(77,124,15,.1);color:var(--moss);display:grid;place-items:center;font-size:1.15rem}
.jc .zc h3{font-family:'Sora','Poppins',sans-serif;font-size:1.1rem;font-weight:800;margin:0}
.jc .zc .cost{font-size:.78rem;color:var(--amber);font-weight:800}
.jc .zc .season{display:inline-flex;align-items:center;gap:6px;font-size:.68rem;font-weight:800;color:var(--moss);background:rgba(77,124,15,.1);padding:5px 10px;border-radius:999px;margin-left:auto}
.jc .zc p{color:var(--slate);font-size:.9rem;line-height:1.6;margin:6px 0 0}
.jc .monsoon{background:linear-gradient(135deg,var(--pine),var(--fern));border-radius:22px;padding:26px 30px;color:#fff;display:flex;gap:18px;align-items:center;flex-wrap:wrap}
.jc .monsoon i{font-size:2rem;color:var(--lime)}
.jc .monsoon b{font-family:'Sora','Poppins',sans-serif;font-size:1.05rem}
.jc .monsoon p{margin:4px 0 0;color:rgba(255,255,255,.82);font-size:.9rem;line-height:1.6;flex:1;min-width:260px}
.jc .igrid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.jc .ic-card{background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:24px;transition:transform .35s,box-shadow .35s}
.jc .ic-card:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(26,46,5,.3)}
.jc .ic-card .day{display:inline-flex;align-items:center;gap:8px;font-size:.7rem;font-weight:800;color:#fff;background:var(--moss);padding:6px 12px;border-radius:999px;margin-bottom:12px}
.jc .ic-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.02rem;font-weight:800;margin:0 0 6px}
.jc .ic-card p{color:var(--slate);font-size:.88rem;line-height:1.6;margin:0}
.jc .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--r);overflow:hidden;box-shadow:0 24px 50px -30px rgba(26,46,5,.25)}
.jc .tscr{overflow-x:auto}
.jc table{width:100%;border-collapse:collapse;min-width:520px}
.jc th,.jc td{padding:14px 18px;text-align:left;font-size:.92rem}
.jc thead th{background:var(--sand);color:var(--fern);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.jc tbody tr{border-top:1px solid var(--line);transition:background .2s}
.jc tbody tr:hover{background:var(--sand)}
.jc td .fare{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.jc .fbox{max-width:820px;margin:0 auto}
.jc .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rs);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.jc .fi:hover{border-color:#d3e8b8}
.jc .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.jc .ft{flex:none;width:26px;height:26px;border-radius:8px;background:rgba(77,124,15,.1);color:var(--moss);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.jc .fi.open .ft{transform:rotate(45deg)}
.jc .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.jc .fi.open .fb{max-height:400px;padding:0 20px 18px}
.jc .chips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.jc .chip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1.5px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:700;font-size:.9rem;color:var(--ink);text-decoration:none;transition:.25s}
.jc .chip i{color:var(--moss)}.jc .chip:hover{border-color:var(--moss);color:var(--moss);transform:translateY(-3px);box-shadow:0 14px 30px -12px rgba(77,124,15,.35)}
.jc .cta2{padding:0 0 70px}
.jc .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--lime),transparent 55%),linear-gradient(120deg,var(--pine),var(--fern));color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.jc .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.jc .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}
.jc .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.jc .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}
.jc .cta2 .w{background:#fff;color:var(--pine)}.jc .cta2 .g{background:#25d366;color:#04260f}.jc .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.jc .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:960px){.jc .jc-hero{grid-template-columns:1fr}.jc .desk{position:static}.jc .zgrid{grid-template-columns:1fr}.jc .igrid{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.jc *{transition:none!important;animation:none!important}.jc .rv{opacity:1!important;transform:none!important}}
</style>
<div class="jc"><div class="jc-in">
<nav class="jc-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Jim Corbett Taxi</span></nav>

<section class="jc-hero">
<div class="rv">
<span class="jc-ey"><i class="fa-solid fa-paw"></i> Wildlife gateway · Ramnagar</span>
<h1 class="disp">Dehradun to Jim Corbett <em>Taxi + Safari</em> — cab, gate & gypsy in one booking</h1>
<div class="jc-qa"><div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p>A Dehradun to Jim Corbett taxi starts at <strong>₹3,500 for a sedan</strong> — 240 km in 6-7 hours via Ramnagar. Jeep safaris cost <strong>₹6,500-₹9,500 per gypsy</strong> depending on zone (Bijrani, Jhirna, Dhela, Dhikala). Anaya Cab bundles your cab, resort drop and safari booking with verified drivers.</p></div>
<div class="jc-cta">
<a class="btn btn-m" href="/#booking"><i class="fa-solid fa-taxi"></i> Book cab + safari</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo $__wa_safari; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-indian-rupee-sign"></i> All fares</a>
</div>
</div>
<aside class="desk rv" aria-label="Jim Corbett fare desk">
<span class="tag"><i class="fa-solid fa-binoculars"></i> Safari desk</span>
<h3 class="disp">Dehradun → Ramnagar</h3>
<p class="sub">Cab fares by vehicle — safari added on request.</p>
<div class="jeep" aria-hidden="true">
<div class="trail"></div>
<i class="fa-solid fa-paw paw p1"></i><i class="fa-solid fa-paw paw p2"></i>
<i class="fa-solid fa-truck-pickup g"></i>
</div>
<?php foreach ($__cab_fares as $r): ?><div class="fr"><span class="v"><?php echo $r[0]; ?> · <?php echo $r[1]; ?></span><span class="p"><?php echo $r[2]; ?></span></div><?php endforeach; ?>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo $__wa_safari; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Safari quote</a>
</div>
<p class="note">One-way or round-trip · 24×7 support</p>
</aside>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-map"></i> Safari zones</span><h2 class="disp">Four zones, four moods of the park</h2><p>Indicative per-gypsy costs including park entry; your driver times the gate arrival to your permit slot.</p></div>
<div class="zgrid">
<?php foreach ($__zones as $z): ?>
<div class="zc rv">
<div class="hd"><span class="ic"><i class="fa-solid <?php echo $z[1]; ?>"></i></span><div><h3><?php echo $z[0]; ?></h3><span class="cost"><?php echo $z[2]; ?></span></div><span class="season"><i class="fa-regular fa-calendar"></i> <?php echo $z[3]; ?></span></div>
<p><?php echo $z[4]; ?></p>
</div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="monsoon">
<i class="fa-solid fa-cloud-showers-heavy"></i>
<div style="flex:1;min-width:260px"><b>Monsoon (July - mid-October)</b>
<p>Core zones Bijrani and Dhikala close for the rains; <strong>Jhirna and Dhela stay open year-round</strong>, so a monsoon safari is still very much on. We plan the zone and gate timing for you before you leave Dehradun.</p></div>
</div></section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-route"></i> Suggested plan</span><h2 class="disp">The classic 2-day Corbett loop</h2></div>
<div class="igrid">
<?php foreach ($__itin as $it): ?>
<div class="ic-card rv">
<span class="day"><i class="fa-solid <?php echo $it[1]; ?>"></i> <?php echo $it[0]; ?></span>
<h3><?php echo $it[2]; ?></h3>
<p><?php echo $it[3]; ?></p>
</div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Cab fares</span><h2 class="disp">Dehradun → Jim Corbett cab rates</h2><p>Fare covers cab + driver; safari gypsy, entry and resort stay are added at actuals and shared upfront.</p></div>
<div class="twrap rv"><div class="tscr"><table aria-label="Dehradun to Jim Corbett cab fares">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>One-way fare</th></tr></thead>
<tbody><?php foreach ($__cab_fares as $r): ?><tr><td><strong><?php echo $r[0]; ?></strong></td><td><?php echo $r[1]; ?></td><td class="fare"><?php echo $r[2]; ?></td></tr><?php endforeach; ?></tbody>
</table></div></div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Corbett cab + safari — quick answers</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<section class="sec rv"><div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Pair it with</span><h2 class="disp">Travellers also book</h2></div>
<div class="chips">
<a class="chip" href="/dehradun-to-nainital-taxi"><i class="fa-solid fa-mountain"></i> Nainital</a>
<a class="chip" href="/dehradun-to-haldwani-taxi"><i class="fa-solid fa-road"></i> Haldwani</a>
<a class="chip" href="/dehradun-to-rishikesh-taxi"><i class="fa-solid fa-water"></i> Rishikesh</a>
<a class="chip" href="/tempo-traveller-in-dehradun"><i class="fa-solid fa-bus-simple"></i> Tempo Traveller</a>
</div>
</section>

<section class="cta2 rv"><div class="ctain">
<h2 class="disp">Tiger country, without the logistics headache</h2>
<p>One message books your cab, your resort drop and your gypsy — we handle the rest.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book cab + safari</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo $__wa_safari; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></section>
</div></div>
</main>
<script>
(function(){var r=document.querySelectorAll('.jc .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.jc .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>