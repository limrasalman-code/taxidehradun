<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$V = [
'slug'=>'innova-taxi-in-dehradun','name'=>'Innova Taxi in Dehradun','short'=>'Innova','cls'=>'Premium MPV · Innova / Crysta',
'char'=>'Premium MPV · Innova / Crysta','char_icon'=>'fa-van-shuttle','glyph'=>'fa-van-shuttle','img'=>'/assets/images/fleet/innova-crysta.webp',
'ac'=>'#f79009','ac2'=>'#ffc24d','d1'=>'#2a1602','d2'=>'#7a3d05','tint'=>'#fbf0db',
'headline'=>'Innova Taxi in Dehradun — Innova Crysta Cab on Rent with Driver',
'lead'=>'Book an Innova taxi in Dehradun for journeys where premium comfort and space matter most. Toyota Innova and Innova Crysta deliver exceptional torque for Uttarakhand hill roads, a quiet cabin for long highway hours, and luggage capacity for multi-day family tours, Char Dham Yatra, and Jolly Grant Airport transfers.',
'pax'=>'6–7','bags'=>'5','rate_range'=>'₹18 – ₹22 / km','pkg4'=>'₹1,600','pkg8'=>'₹2,800',
'service_type'=>'Innova / SUV taxi service','offers_price'=>'18','offer_desc'=>'Toyota Innova taxi in Dehradun available from approx. ₹18 per km depending on route and availability.',
'area'=>['Dehradun','Mussoorie','Nainital','Rishikesh','Haridwar','Char Dham'],
'best_for'=>[
['fa-om','Char Dham & Do Dham','The recommended cab for the yatra circuit — comfort, luggage space and stable hill-road performance over many hours.'],
['fa-mountain','Long hill routes','Torque and ground clearance for Mussoorie, Nainital, Auli and the high passes.'],
['fa-plane-departure','Premium airport transfer','Jolly Grant pickup and drop with room for the whole family and their bags.'],
['fa-road','Long-distance comfort','Delhi, Chandigarh, Jaipur and multi-day tours in a quiet, spacious cabin.'],
],
'compare_title'=>'Innova vs Innova Crysta vs Ertiga',
'compare'=>[['Toyota Innova Crysta','6–7 passengers','Premium comfort & yatra favourite'],['Toyota Innova','6–7 passengers','Reliable hill & long-route workhorse'],['Maruti Ertiga','6–7 passengers','Budget family alternative']],
'routes'=>[['Char Dham Yatra','/char-dham-yatra-taxi'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Dehradun → Nainital','/dehradun-to-nainital-taxi'],['Dehradun → Delhi','/dehradun-to-delhi-taxi'],['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Dehradun → Kedarnath','/dehradun-to-kedarnath-taxi']],
'use_cases'=>['Char Dham Yatra','Hill & long routes','Premium airport transfer','Multi-day family tours','Business long-distance'],
'faqs'=>[
['Is the Innova available for Char Dham Yatra from Dehradun?','Yes, the Innova and Innova Crysta are recommended for Char Dham Yatra because they offer comfort, luggage space and stable hill-road performance over long days.'],
['How many passengers can travel in an Innova?','The Toyota Innova and Innova Crysta usually seat six to seven passengers, depending on luggage and seating preference.'],
['Can I book an Innova for Dehradun airport pickup?','Yes, the Innova can be booked for Jolly Grant Airport pickup and drop and for outstation routes from Dehradun.'],
['What is the difference between Innova and Innova Crysta?','The Crysta is the newer, more premium variant — it has a more powerful engine, better suspension and a more refined cabin, which matters on long yatra and hill routes.'],
],
'title'=>'Innova Taxi in Dehradun | Innova Crysta Cab on Rent (2026)',
'desc'=>'Book Innova taxi in Dehradun & Innova Crysta cab with driver for Char Dham Yatra, airport transfers, Mussoorie, Nainital and outstation tours. Call '.$phone.'.',
];

$page_url = $domain . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];

require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<style>
.vp-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line,#e7edf6);border-left:4px solid var(--vp-ac,#f79009);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.vp-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--vp-ac,#f79009);margin-bottom:8px}
.vp-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.vp-qa strong{color:#0b1220}
</style>
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-user-group"></i><b><?php echo htmlspecialchars($V['pax']); ?></b><span>passengers</span></span>
<span class="vp-m"><i class="fa-solid fa-suitcase-rolling"></i><b><?php echo htmlspecialchars($V['bags']); ?></b><span>luggage</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>AC</b><span>sanitised</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b><?php echo htmlspecialchars($V['rate_range']); ?></b><span>base fare</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?> in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>

<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="vp-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Innova Taxi in Dehradun Rates</div>
<p itemprop="text"><strong>Innova Taxi in Dehradun</strong> (Toyota Innova &amp; Innova Crysta) offers premium 6 to 7 seater AC comfort, starting at <strong>₹18 – ₹22 / km</strong>. Anaya Cab Service provides Innova cabs with verified hill-expert drivers for local hourly packages (8 hr / 80 km at ₹2,800), Jolly Grant Airport transfers, Char Dham Yatra tours, and outstation trips to Mussoorie, Nainital, and Delhi NCR.</p>
</div>

</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where this cab shines</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['cls']); ?> fare at a glance</h2><p>Per-km and hourly packages — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Plan</th><th>What you get</th><th>Fare</th></tr></thead>
<tbody>
<tr><td>Per kilometre</td><td>Local &amp; outstation, metered by route</td><td class="fare"><?php echo htmlspecialchars($V['rate_range']); ?></td></tr>
<tr><td>4 Hr / 40 Km</td><td>City errands, airport + short sightseeing</td><td class="fare"><?php echo htmlspecialchars($V['pkg4']); ?></td></tr>
<tr><td>8 Hr / 80 Km</td><td>Full-day local or short outstation</td><td class="fare"><?php echo htmlspecialchars($V['pkg8']); ?></td></tr>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> comparison">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> Why Innova wins on long routes</span><h2 class="disp">The premium choice for hills and yatra</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">The Toyota Innova has been the default family and yatra cab across North India for nearly two decades, and there is a reason it still dominates Dehradun's hill and pilgrimage routes. It is built on a body-on-frame platform that gives it the strength to handle rough stretches near Sonprayag, Badrinath and Auli without the cabin feeling every bump. The diesel engine delivers torque low in the rev band, which is exactly what matters when you are climbing a loaded ghat road with six passengers and luggage.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">Inside, the second row has genuine legroom and the third row is usable for adults on long trips — something most MPVs cannot claim. The boot is deep enough for four medium suitcases plus a couple of duffels, which is the typical Char Dham packing. The air-conditioning is sized for a full load and holds temperature even when the vehicle is parked at a temple queue in Joshimath.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">The Innova Crysta is the newer, more refined variant — it has a more powerful engine, better suspension damping and a quieter cabin, which you notice on 8-hour highway runs to Delhi or Jaipur. For pilgrims and families who travel often, the Crysta is usually worth the small fare difference. Either way, you get the same Anaya Cab promise: a police-verified driver who knows the route, a fixed fare agreed before you travel, and 24x7 support.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Body-on-frame platform built for rough hill and yatra stretches.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Low-end diesel torque that makes loaded ghat climbs feel effortless.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Three usable rows and a deep boot for full-family pilgrimage packing.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Crysta variant available for a quieter, more powerful long-distance ride.</li>
</ul>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular routes</span><h2 class="disp">Routes travellers book</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This cab is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your route, date and luggage — we confirm a transparent fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
