﻿<?php
/**
 * Anaya Cab Service — Char Dham Yatra MASTER HUB (v2)
 * Upgrade: 4 dham pages ke internal links, indicative fare table,
 * winter-seat yatra section (zero-competition keyword), related yatra chips,
 * 7 FAQs (visible == schema), schema mein OfferCatalog (4 dham services).
 * Cover image: header v6.6 auto-cover (services/char-dham-yatra-taxi.webp upload karo).
 */
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$page_title = "Char Dham Yatra Taxi from Dehradun | 2026 Cabs";
$page_description = 'Char Dham Yatra taxi from Dehradun: 10–12 day Yamunotri, Gangotri, Kedarnath, Badrinath circuit.';
$page_url         = $domain . "/char-dham-yatra-taxi";
$__faqs = [
["How many days does the Char Dham Yatra take by taxi?", "A complete Char Dham Yatra by taxi from Dehradun usually takes 10 to 12 days, covering Yamunotri, Gangotri, Kedarnath and Badrinath, with buffer days recommended in peak and monsoon season."],
["Which vehicle is best for the Char Dham Yatra?", "An Innova Crysta or a similar SUV is ideal for families, while a Tempo Traveller suits groups, because both handle the hill terrain and carry the luggage needed for a multi day pilgrimage."],
["Are your Char Dham Yatra drivers experienced on hill roads?", "Yes. All Char Dham Yatra drivers are experienced with Uttarakhand hill roads, weather changes, roadheads and pilgrimage logistics, and support is available throughout the journey."],
["What is included in the Char Dham taxi package?", "The package includes the SUV or Tempo Traveller with an experienced hill driver, fuel, driver allowance and toll and parking charges, flexible daily planning and round the clock support. Registration and trek or helicopter costs are separate."],
["When is the best time to book a Char Dham Yatra taxi?", "The yatra season typically runs from late April to early November. Booking early in the season is advised, and keeping one or two buffer days helps manage weather and road closures during monsoon."],
["Can I do the Char Dham Yatra in winter?", "The four temples close roughly November to April, but worship continues at the winter seats - Kharsali (Yamunotri), Mukhba (Gangotri), Ukhimath (Kedarnath) and Joshimath (Badrinath). Our taxis run to all winter seats year-round, and Joshimath doubles as the base for Auli snow trips."],
["What does a Char Dham taxi package cost?", "Indicative per-day rates are Rs 3,500 to 4,000 for a sedan, Rs 5,000 to 6,000 for an Innova Crysta and Rs 6,000 to 7,500 for a Tempo Traveller. The full 10-12 day circuit is quoted per vehicle with fuel, driver allowance and tolls included. Call or WhatsApp for an exact package fare."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__graph = ['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Char Dham Yatra Taxi','serviceType'=>'Pilgrimage taxi package','description'=>'Full Char Dham Yatra taxi package from Dehradun covering Yamunotri, Gangotri, Kedarnath and Badrinath with hill-expert drivers and flexible itinerary.','provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Yamunotri'],['@type'=>'City','name'=>'Gangotri'],['@type'=>'City','name'=>'Kedarnath'],['@type'=>'City','name'=>'Badrinath'],['@type'=>'City','name'=>'Dehradun']],'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','description'=>'Char Dham Yatra taxi package price is quoted per vehicle and duration; call for a custom fare.'],'hasOfferCatalog'=>['@type'=>'OfferCatalog','name'=>'Char Dham taxi routes from Dehradun','itemListElement'=>[
['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Dehradun to Yamunotri Taxi','url'=>$domain.'/dehradun-to-yamunotri-taxi']],
['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Dehradun to Gangotri Taxi','url'=>$domain.'/dehradun-to-gangotri-taxi']],
['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Dehradun to Kedarnath Taxi','url'=>$domain.'/dehradun-to-kedarnath-taxi']],
['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Dehradun to Badrinath Taxi','url'=>$domain.'/dehradun-to-badrinath-taxi']],
]]],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]];
$page_schema = '<script type="application/ld+json">' . json_encode($__graph, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$__dhams = [
['Yamunotri','fa-mountain','Source of the Yamuna','Road to Janki Chatti, then a short trek or pony / palki to the temple.','~3,293 m','Day 1–3','/dehradun-to-yamunotri-taxi'],
['Gangotri','fa-water','Source of the Ganga','Accessible by road up to the temple town via Uttarkashi and Harsil.','~3,100 m','Day 3–5','/dehradun-to-gangotri-taxi'],
['Kedarnath','fa-om','Temple of Lord Shiva','Taxi to the roadhead at Sonprayag / Gaurikund; trek or helicopter to the temple.','~3,583 m','Day 5–8','/dehradun-to-kedarnath-taxi'],
['Badrinath','fa-place-of-worship','Temple of Lord Vishnu','Reachable directly by road via Joshimath; seasonal timing rules apply.','~3,133 m','Day 8–11','/dehradun-to-badrinath-taxi'],
];
$__itin = [
['Day 1','Dehradun → Barkot','Drive to the Yamunotri base side and overnight halt.'],
['Day 2','Yamunotri darshan','Road to Janki Chatti, then trek / pony / palki to the temple and back.'],
['Day 3','Barkot → Uttarkashi','Long scenic drive through the Garhwal valleys.'],
['Day 4','Gangotri darshan','Day trip to Gangotri temple from Uttarkashi and return.'],
['Day 5','Uttarkashi → Guptkashi','Drive toward the Kedarnath base via the Mandakini valley.'],
['Day 6','Kedarnath darshan','Taxi to Sonprayag / Gaurikund, then trek or helicopter to the temple.'],
['Day 7','Guptkashi → Joshimath','Drive toward the Badrinath route with an overnight halt.'],
['Day 8','Badrinath darshan','Morning temple visit plus optional Mana village and Tapt Kund.'],
['Day 9–11','Return via Rishikesh','Relaxed drive back to Dehradun with halts as needed.'],
];
$__veh = [
    ['Innova Crysta', 'fa-van-shuttle', '4–6 pax', 'Families · premium hill comfort', '/innova-crysta-for-char-dham-yatra'],
    ['Innova', 'fa-van-shuttle', '5–6 pax', 'Value SUV for yatra routes', '/innova-for-char-dham-yatra'],
    ['Maruti Ertiga', 'fa-car-rear', '5–6 pax', 'Budget family 6-seater SUV', '/ertiga-for-char-dham-yatra'],
    ['Swift Dzire', 'fa-car-side', '2–4 pax', 'Agile private sedan for couples', '/swift-dzire-for-char-dham-yatra'],
    ['Tempo Traveller', 'fa-bus-simple', '9–17 pax', 'Groups and joint families', '/tempo-traveller-for-char-dham-yatra'],
    ['Force Urbania', 'fa-bus-simple', '9–12 pax', 'Premium group travel', '/force-urbania-rental-dehradun'],
];
$__fares = [
    ['Swift Dzire', '4 pax', '₹3,200 – ₹3,500 / day'],
    ['Maruti Ertiga', '6 pax', '₹3,800 – ₹4,200 / day'],
    ['Toyota Innova', '6–7 pax', '₹4,200 – ₹4,800 / day'],
    ['Innova Crysta', '6–7 pax', '₹5,000 – ₹6,000 / day'],
    ['Tempo Traveller', '12–17 pax', '₹6,500 – ₹7,500 / day'],
    ['Force Urbania', '9–12 pax', '₹8,000 – ₹10,000 / day'],
];
$__winter = [
    ['Yamunotri', 'Kharsali', 'fa-mountain', 'Nov to Apr the Yamunotri deity rests at Kharsali village near Janki Chatti; taxi drops continue year-round.'],
    ['Gangotri', 'Mukhba', 'fa-water', 'The Gangotri winter seat is at Mukhba; the Harsil valley drive stays open and scenic all winter.'],
    ['Kedarnath', 'Ukhimath', 'fa-om', 'Kedarnath is worshipped at the Omkareshwar temple in Ukhimath; the Mandakini valley drive is calm and clear.'],
    ['Badrinath', 'Joshimath', 'fa-place-of-worship', 'The Badrinath deity sits at the Narsimha temple in Joshimath, which is also the base for Auli snow trips.'],
];
$__relchips = [
    ['Innova for Char Dham', '/innova-for-char-dham-yatra'],
    ['Innova Crysta for Char Dham', '/innova-crysta-for-char-dham-yatra'],
    ['Ertiga for Char Dham', '/ertiga-for-char-dham-yatra'],
    ['Swift Dzire for Char Dham', '/swift-dzire-for-char-dham-yatra'],
    ['Tempo Traveller for Char Dham', '/tempo-traveller-for-char-dham-yatra'],
    ['Do Dham Yatra Taxi', '/do-dham-yatra-taxi'],
    ['Jolly Grant Airport → Kedarnath', '/jolly-grant-airport-to-kedarnath-taxi'],
    ['Haridwar → Kedarnath', '/haridwar-to-kedarnath-taxi'],
    ['Haridwar → Badrinath', '/haridwar-to-badrinath-taxi'],
];
?>
<main id="main">
<style>
.cd{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--saffron:#e11d48;--gold:#f59e0b;--violet:#7c3aed;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#f3eefb 0%,#ffffff 440px)}
.cd *{box-sizing:border-box}
.cd::before{content:"";position:absolute;top:-200px;left:50%;transform:translateX(-50%);width:780px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(124,58,237,.12),transparent 70%);pointer-events:none}
.cd::after{content:"";position:absolute;top:360px;right:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(245,158,11,.08),transparent 70%);pointer-events:none}
.cd .cd-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.cd .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.cd .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.cd .rv.in{opacity:1;transform:none}
.cd .cd-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.cd .cd-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.cd .cd-crumb a:hover{color:var(--violet)}
.cd .cd-crumb i{font-size:.6rem;color:var(--mute)}.cd .cd-crumb .cur{color:var(--ink);font-weight:600}
.cd .cd-hero{display:grid;grid-template-columns:1.25fr .95fr;gap:34px;align-items:start;padding:24px 0 10px}
.cd .cd-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--violet);background:#f1e9fe;padding:7px 13px;border-radius:999px}
.cd .cd-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.cd .cd-hero h1 em{font-style:normal;color:var(--violet)}
.cd .cd-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.cd .cd-lead strong{color:var(--ink)}
.cd .cd-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}
.cd .cd-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.cd .cd-trust i{color:var(--green)}
.cd .cd-herocta{display:flex;gap:12px;flex-wrap:wrap}
.cd .cd-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.cd .cd-btn-v{background:var(--violet);color:#fff;box-shadow:0 16px 34px -14px rgba(124,58,237,.55)}.cd .cd-btn-v:hover{transform:translateY(-2px);filter:brightness(1.06)}
.cd .cd-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.cd .cd-btn-g:hover{transform:translateY(-2px)}
.cd .cd-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.cd .cd-btn-o:hover{border-color:var(--violet);color:var(--violet)}
.cd .cd-card{position:sticky;top:88px;background:linear-gradient(160deg,#1a1436,#33245e);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(51,36,94,.6);overflow:hidden}
.cd .cd-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(245,158,11,.32),transparent 70%)}
.cd .cd-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#ffe2a8;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.cd .cd-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.cd .cd-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 16px;position:relative}
.cd .cd-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;position:relative}
.cd .cd-st{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:14px;padding:12px;text-align:center}
.cd .cd-st b{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;display:block;color:#fff}
.cd .cd-st small{font-size:.66rem;color:rgba(255,255,255,.7);letter-spacing:.06em}
.cd .cd-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.cd .cd-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.cd .cd-card .cta .w{background:#fff;color:var(--violet)}.cd .cd-card .cta .g{background:#25d366;color:#04260f}.cd .cd-card .cta .c{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff}
.cd .cd-card .cta a:hover{transform:translateY(-2px)}
.cd .cd-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.cd .cd-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--violet);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.cd .cd-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--violet);margin-bottom:8px}
.cd .cd-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.cd .cd-qa strong{color:var(--ink)}
.cd .cd-sec{padding:48px 0}
.cd .cd-sh{text-align:center;max-width:700px;margin:0 auto 30px}
.cd .cd-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--violet);background:#f1e9fe;padding:7px 13px;border-radius:999px}
.cd .cd-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.cd .cd-sh p{color:var(--slate);margin:0}
.cd .cd-path{position:relative;max-width:900px;margin:0 auto;padding-left:8px}
.cd .cd-path::before{content:"";position:absolute;left:31px;top:14px;bottom:14px;width:3px;background:linear-gradient(180deg,var(--saffron),var(--gold),var(--violet),var(--blue));border-radius:3px}
.cd .cd-glow{position:absolute;left:32px;top:14px;width:9px;height:9px;margin-left:-3px;border-radius:50%;background:#fff;box-shadow:0 0 0 4px rgba(245,158,11,.5);animation:cdflow 8s linear infinite}
@keyframes cdflow{0%{top:14px}100%{top:calc(100% - 14px)}}
.cd .cd-drow{position:relative;display:grid;grid-template-columns:64px 1fr;gap:20px;padding:0 0 24px}
.cd .cd-ddot{position:relative;z-index:1;width:64px;height:64px;border-radius:18px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--violet);font-size:1.3rem;box-shadow:0 10px 22px -12px rgba(124,58,237,.4)}
.cd .cd-dbody{background:#fff;border:1px solid var(--line);border-radius:18px;padding:18px 20px;transition:transform .3s,box-shadow .3s}
.cd .cd-drow:hover .cd-dbody{transform:translateX(5px);box-shadow:0 18px 40px -24px rgba(9,32,84,.3)}
.cd .cd-dbody .top{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:6px}
.cd .cd-dbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1.18rem;font-weight:800;margin:0}
.cd .cd-dbody .alt{font-size:.72rem;font-weight:700;color:var(--gold);background:#fff7e8;border:1px solid #ffe6b8;padding:4px 10px;border-radius:999px}
.cd .cd-dbody .day{margin-left:auto;font-size:.74rem;font-weight:700;color:var(--violet)}
.cd .cd-dbody .role{color:var(--violet);font-weight:600;font-size:.84rem;margin:0 0 4px}
.cd .cd-dbody p{margin:0;color:var(--slate);font-size:.9rem;line-height:1.6}
.cd .cd-dlink{display:inline-flex;align-items:center;gap:7px;margin-top:12px;font-weight:700;font-size:.85rem;color:var(--violet);text-decoration:none;transition:gap .2s}
.cd .cd-dlink:hover{gap:11px}
.cd .cd-facts{margin:8px 0 30px}
.cd .cd-itl{position:relative;max-width:860px;margin:0 auto}
.cd .cd-irow{display:grid;grid-template-columns:96px 1fr;gap:18px;padding:0 0 14px}
.cd .cd-iday{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:.82rem;color:var(--violet);background:#f1e9fe;border-radius:12px;height:fit-content;padding:8px 12px;text-align:center}
.cd .cd-ibody{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px 18px}
.cd .cd-ibody h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}
.cd .cd-ibody p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
.cd .cd-vgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.cd .cd-vcard{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:22px 20px;text-decoration:none;color:var(--ink);overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.cd .cd-vcard:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.3);border-color:#dcc9f7}
.cd .cd-vico{width:50px;height:50px;border-radius:14px;background:#f1e9fe;color:var(--violet);display:grid;place-items:center;font-size:1.2rem;margin-bottom:14px;transition:transform .35s}
.cd .cd-vcard:hover .cd-vico{transform:scale(1.08) rotate(-5deg)}
.cd .cd-vcard h3{font-family:'Sora','Poppins',sans-serif;font-size:1.08rem;font-weight:700;margin:0 0 8px}
.cd .cd-vmeta{display:flex;gap:14px;margin-bottom:10px}
.cd .cd-vmeta span{display:inline-flex;align-items:center;gap:6px;font-size:.82rem;font-weight:600;color:#33415c}.cd .cd-vmeta i{color:var(--violet);font-size:.74rem}
.cd .cd-vbest{font-size:.84rem;color:var(--slate)}.cd .cd-vbest strong{color:var(--ink)}
.cd .cd-twrap{background:#fff;border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:0 24px 50px -30px rgba(9,32,84,.25)}
.cd .cd-ts{overflow-x:auto}
.cd .cd-tbl{width:100%;border-collapse:collapse;min-width:520px}
.cd .cd-tbl th{background:#f4f0fd;color:var(--violet);text-align:left;padding:13px 16px;font-weight:700;font-size:.78rem;letter-spacing:.02em;white-space:nowrap}
.cd .cd-tbl td{padding:13px 16px;border-top:1px solid var(--line);font-size:.9rem;color:var(--slate)}
.cd .cd-tbl td.fare{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink);white-space:nowrap}
.cd .cd-tbl tr:hover td{background:#faf7ff}
.cd .cd-tnote{margin:14px auto 0;max-width:700px;text-align:center;font-size:.82rem;color:var(--slate)}
.cd .cd-adv{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}
.cd .cd-aitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:20px}
.cd .cd-aico{flex:none;width:46px;height:46px;border-radius:13px;background:#fff7e8;color:var(--gold);display:grid;place-items:center;font-size:1.05rem}
.cd .cd-aitem h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}
.cd .cd-aitem p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
.cd .cd-chips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.cd .cd-chip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:11px 18px;font-weight:600;font-size:.9rem;color:var(--ink);text-decoration:none;transition:.25s}
.cd .cd-chip i{color:var(--violet)}
.cd .cd-chip:hover{border-color:var(--violet);color:var(--violet);transform:translateY(-2px)}
.cd .cd-fbox{max-width:820px;margin:0 auto}
.cd .cd-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.cd .cd-fi:hover{border-color:#dcc9f7}
.cd .cd-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.cd .cd-ft{flex:none;width:26px;height:26px;border-radius:8px;background:#f1e9fe;color:var(--violet);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.cd .cd-fi.open .cd-ft{transform:rotate(45deg)}
.cd .cd-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.cd .cd-fi.open .cd-fb{max-height:400px;padding:0 20px 18px}
.cd .cd-soft{background:linear-gradient(180deg,#f3eefb,#faf7ff)}
.cd .cd-cta{padding:0 0 70px}
.cd .cd-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#7c3aed,transparent 55%),linear-gradient(120deg,#1a1436,#33245e);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.cd .cd-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.cd .cd-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.cd .cd-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.cd .cd-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.cd .cd-cta .w{background:#fff;color:var(--violet)}.cd .cd-cta .g{background:#25d366;color:#04260f}.cd .cd-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.cd .cd-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.cd .cd-hero{grid-template-columns:1fr;gap:24px}.cd .cd-card{position:static}}
@media(max-width:520px){.cd .cd-drow{grid-template-columns:52px 1fr;gap:14px}.cd .cd-ddot{width:52px;height:52px}.cd .cd-path::before,.cd .cd-glow{left:25px}.cd .cd-irow{grid-template-columns:74px 1fr}}
@media(prefers-reduced-motion:reduce){.cd *{transition:none!important;animation:none!important}.cd .rv{opacity:1!important;transform:none!important}}
</style>
<div class="cd">
<div class="cd-in">
<nav class="cd-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Char Dham Yatra</span></nav>
<section class="cd-hero">
<div class="rv">
<span class="cd-eyebrow"><i class="fa-solid fa-om"></i> Sacred circuit · 10–12 days</span>
<h1 class="disp">Char Dham Yatra Taxi Package from Dehradun <em>(Yamunotri, Gangotri, Kedarnath, Badrinath)</em></h1>
<p class="cd-lead">The Char Dham Yatra — <strong>Yamunotri, Gangotri, Kedarnath and Badrinath</strong> — is one of India's most sacred pilgrimage circuits. Anaya Cab Service runs dedicated taxi packages from Dehradun with hill-expert drivers, comfortable Innova Crysta and Tempo Traveller options, and a flexible day-by-day itinerary built around your pace, with 24×7 support throughout.</p>
<div class="cd-trust">
<span><i class="fa-solid fa-circle-check"></i> Hill-expert drivers</span>
<span><i class="fa-solid fa-circle-check"></i> Innova &amp; Tempo Traveller</span>
<span><i class="fa-solid fa-circle-check"></i> Flexible itinerary</span>
<span><i class="fa-solid fa-circle-check"></i> 24×7 yatra support</span>
</div>
<div class="cd-herocta">
<a class="cd-btn cd-btn-v" href="/#booking"><i class="fa-solid fa-om"></i> Plan my yatra</a>
<a class="cd-btn cd-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo urlencode('Hi, I want a quote for Char Dham Yatra taxi package.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get quote on WhatsApp</a>
<a class="cd-btn cd-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="cd-card rv" aria-label="Plan your Char Dham Yatra">
<span class="tag"><i class="fa-solid fa-mountain-sun"></i> Yatra planning desk</span>
<h3 class="disp">Your Char Dham package</h3>
<p class="sub">Share dates, group size and vehicle — we build the itinerary and quote.</p>
<div class="cd-stats">
<div class="cd-st"><b>4</b><small>Sacred dhams</small></div>
<div class="cd-st"><b>10–12</b><small>Days typical</small></div>
<div class="cd-st"><b>24×7</b><small>On-trip support</small></div>
<div class="cd-st"><b>0</b><small>Hidden charges</small></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Plan now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo urlencode('Hi, I want a quote for Char Dham Yatra taxi package.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp quote</a>
<a class="c" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
<p class="note">Custom fare per vehicle &amp; duration · buffer days advised</p>
</aside>
</section>
<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="cd-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Char Dham Yatra Taxi Overview</div>
<p itemprop="text"><strong>Anaya Cab Service</strong> offers a complete <strong>Char Dham Yatra taxi package from Dehradun</strong> (10 to 12 days) covering <strong>Yamunotri, Gangotri, Kedarnath, and Badrinath</strong>. Indicative per-day rates start from <strong>₹3,500 – ₹4,000 for Sedan</strong>, <strong>₹5,000 – ₹6,000 for Innova Crysta</strong>, and <strong>₹6,000 – ₹7,500 for Tempo Traveller</strong>. Packages include an experienced hill driver, fuel, tolls, parking, and 24×7 on-trip pilgrimage support.</p>
</div>
</div>
<!-- SHARED YATRA FACTS -->
<div class="cd-in"><div class="cd-facts rv"><?php if (file_exists(__DIR__ . '/includes/yatra-facts.php')) { require_once __DIR__ . '/includes/yatra-facts.php'; if (function_exists('anaya_yatra_facts')) echo anaya_yatra_facts('char-dham'); } ?></div></div>
<!-- FOUR DHAMS PATH -->
<section class="cd-sec rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-solid fa-route"></i> The sacred circuit</span><h2 class="disp">The four dhams, in order of the yatra</h2><p>Our drivers follow the traditional sequence, with the taxi taking you to each roadhead.</p></div>
<div class="cd-path">
<span class="cd-glow" aria-hidden="true"></span>
<?php foreach ($__dhams as $d): ?>
<div class="cd-drow rv">
<div class="cd-ddot"><i class="fa-solid <?php echo $d[1]; ?>"></i></div>
<div class="cd-dbody">
<div class="top"><h3><?php echo $d[0]; ?></h3><span class="alt"><?php echo $d[4]; ?></span><span class="day"><?php echo $d[5]; ?></span></div>
<p class="role"><?php echo $d[2]; ?></p>
<p><?php echo $d[3]; ?></p>
<a class="cd-dlink" href="<?php echo $d[6]; ?>">Book <?php echo $d[0]; ?> taxi <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
<?php endforeach; ?>
</div>
</div></section>
<!-- ITINERARY -->
<section class="cd-sec cd-soft rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-regular fa-calendar-days"></i> Day-by-day plan</span><h2 class="disp">Typical Char Dham taxi itinerary from Dehradun</h2><p>A reference circuit — we adjust daily halts to your pace and the weather.</p></div>
<div class="cd-itl">
<?php foreach ($__itin as $it): ?>
<div class="cd-irow rv"><div class="cd-iday"><?php echo $it[0]; ?></div><div class="cd-ibody"><h3><?php echo $it[1]; ?></h3><p><?php echo $it[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- VEHICLES -->
<section class="cd-sec rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-solid fa-van-shuttle"></i> Recommended vehicles</span><h2 class="disp">Best cabs for the yatra terrain</h2><p>Power, ground clearance and luggage space for long mountain days.</p></div>
<div class="cd-vgrid">
<?php foreach ($__veh as $v): ?>
<a class="cd-vcard rv" href="<?php echo $v[4]; ?>">
<div class="cd-vico"><i class="fa-solid <?php echo $v[1]; ?>"></i></div>
<h3><?php echo $v[0]; ?></h3>
<div class="cd-vmeta"><span><i class="fa-solid fa-user-group"></i> <?php echo $v[2]; ?></span></div>
<p class="cd-vbest"><strong>Best for:</strong> <?php echo $v[3]; ?></p>
</a>
<?php endforeach; ?>
</div>
</div></section>
<!-- FARE GUIDE -->
<section class="cd-sec cd-soft rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp">Indicative per-day yatra rates</h2><p>Final package fare is quoted per vehicle before you book.</p></div>
<div class="cd-twrap rv"><div class="cd-ts"><table aria-label="Char Dham Yatra taxi fare guide">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Indicative rate</th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td><strong><?php echo $f[0]; ?></strong></td><td><?php echo $f[1]; ?></td><td class="fare"><?php echo $f[2]; ?></td></tr>
<?php endforeach; ?>
</tbody></table></div></div>
<p class="cd-tnote">The full 10–12 day circuit is quoted per vehicle and includes fuel, driver allowance, toll and parking. Yatra registration, trek and helicopter costs are separate.</p>
</div></section>
<!-- WINTER SEAT YATRA -->
<section class="cd-sec rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-regular fa-snowflake"></i> Nov – Apr</span><h2 class="disp">Winter seat yatra — the temples never close</h2><p>When the four shrines rest under snow, worship continues at the winter seats. Our taxis run there all year.</p></div>
<div class="cd-adv">
<?php foreach ($__winter as $w): ?>
<div class="cd-aitem rv"><span class="cd-aico"><i class="fa-solid <?php echo $w[2]; ?>"></i></span><div><h3><?php echo $w[0]; ?> → <?php echo $w[1]; ?></h3><p><?php echo $w[3]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- ADVISORY -->
<section class="cd-sec cd-soft rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-solid fa-triangle-exclamation"></i> Plan smart</span><h2 class="disp">Yatra travel advice from our hill drivers</h2></div>
<div class="cd-adv">
<div class="cd-aitem rv"><span class="cd-aico"><i class="fa-solid fa-clipboard-check"></i></span><div><h3>Register for the yatra</h3><p>Char Dham Yatra registration is required; keep your ID and confirmation handy for checkpoints.</p></div></div>
<div class="cd-aitem rv"><span class="cd-aico"><i class="fa-solid fa-cloud-sun-rain"></i></span><div><h3>Keep buffer days</h3><p>Monsoon and peak season bring landslides and road closures; one or two spare days prevent stress.</p></div></div>
<div class="cd-aitem rv"><span class="cd-aico"><i class="fa-solid fa-temperature-low"></i></span><div><h3>Carry warm layers</h3><p>Temple towns sit above 3,000 m and turn cold even in summer, especially at night and early morning.</p></div></div>
<div class="cd-aitem rv"><span class="cd-aico"><i class="fa-solid fa-kit-medical"></i></span><div><h3>Altitude &amp; health</h3><p>Pace yourself, stay hydrated and carry basic medicines; tell us of any health needs when booking.</p></div></div>
</div>
</div></section>
<!-- RELATED YATRA ROUTES -->
<section class="cd-sec rv"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Yatra routes</span><h2 class="disp">Other pilgrimage taxis travellers book</h2></div>
<div class="cd-chips rv">
<?php foreach ($__relchips as $r): ?>
<a class="cd-chip" href="<?php echo $r[1]; ?>"><i class="fa-solid fa-location-dot"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</div></section>
<!-- FAQ -->
<section class="cd-sec cd-soft rv" id="faq"><div class="cd-in">
<div class="cd-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Char Dham Yatra taxi — FAQs</h2></div>
<div class="cd-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="cd-fi<?php echo $i===0?' open':''; ?>"><div class="cd-fh"><?php echo htmlspecialchars($f[0]); ?><span class="cd-ft"><i class="fa-solid fa-plus"></i></span></div><div class="cd-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- CTA -->
<section class="cd-cta rv"><div class="cd-in">
<div class="cd-ctain">
<h2 class="disp">Ready to plan your Char Dham Yatra?</h2>
<p>Share dates, group size and vehicle — we build a custom itinerary and fare on WhatsApp.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-om"></i> Plan my yatra</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo urlencode('Hi, I want a quote for Char Dham Yatra taxi package.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.cd .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.cd .cd-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>