/* Anaya Cab Service — PWA Service Worker (CACHE KILL-SWITCH v2)
 * Ye SW activate hote hi:
 * 1) Saare purane caches DELETE kar deta hai
 * 2) Khud UNREGISTER ho jata hai
 * 3) Koi caching nahi karta — sab kuch network se aata hai
 * Result: deploy ke baad users ko purana cached page NAHI dikhega.
 */
self.addEventListener('install', function (e) {
  self.skipWaiting();
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) { return caches.delete(k); }));
    }).then(function () {
      return self.clients.claim();
    }).then(function () {
      return self.registration.unregister();
    })
  );
});

/* No caching at all — hamesha fresh network response */
self.addEventListener('fetch', function (e) {
  /* intentionally empty */
});