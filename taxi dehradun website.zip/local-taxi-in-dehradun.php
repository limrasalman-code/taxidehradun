﻿<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/rates.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
/* Rate Manager wiring — local package fares admin se live */
$h4 = anaya_rate('local_hatch_4');  if ($h4 <= 0) { $h4 = 900; }
$h8 = anaya_rate('local_hatch_8');  if ($h8 <= 0) { $h8 = 1600; }
$s4 = anaya_rate('local_sedan_4');  if ($s4 <= 0) { $s4 = 1100; }
$s8 = anaya_rate('local_sedan_8');  if ($s8 <= 0) { $s8 = 1900; }
$m4 = anaya_rate('local_mpv_4');    if ($m4 <= 0) { $m4 = 1350; }
$m8 = anaya_rate('local_mpv_8');    if ($m8 <= 0) { $m8 = 2300; }
$p4 = anaya_rate('local_prem_4');   if ($p4 <= 0) { $p4 = 1600; }
$p8 = anaya_rate('local_prem_8');   if ($p8 <= 0) { $p8 = 2800; }
$fh4 = number_format($h4); $fh8 = number_format($h8);
$fs4 = number_format($s4); $fs8 = number_format($s8);
$fm4 = number_format($m4); $fm8 = number_format($m8);
$fp4 = number_format($p4); $fp8 = number_format($p8);
$page_title = "Local Taxi in Dehradun | Hourly Cabs - Anaya Cab";
$page_description = 'Local taxi in Dehradun from ₹12/km – hourly packages ₹900 (4hr/40km) & ₹1,600 (8hr/80km). Doorstep pickup in 5–15 min across all localities.';
$page_url         = $domain . "/local-taxi-in-dehradun";
$__faqs = [
["Do you offer hourly taxi packages in Dehradun?", "Yes. Anaya Cab Service offers a 4 hour 40 km package and an 8 hour 80 km package for Dehradun city rides, errands, meetings and sightseeing, with the fare fixed before you book."],
["Can I book a local cab for Dehradun sightseeing?", "Yes. You can book a local taxi for Robbers Cave, FRI, Tapkeshwar Temple, Buddha Temple, Sahastradhara and other Dehradun sightseeing points, with flexible stops on an hourly package."],
["Is point to point taxi available in Dehradun city?", "Yes. Point to point taxi is available for Dehradun Railway Station, ISBT, Jolly Grant Airport, hotels, offices, hospitals and home transfers across the city."],
["Which areas of Dehradun do you cover for local rides?", "We cover Rajpur Road, Sahastradhara Road, Prem Nagar, Clement Town, Paltan Bazaar, ISBT, the railway station and Jolly Grant Airport, plus nearby colonies for hourly and point to point local taxi."],
["What is the starting fare for a local taxi in Dehradun?", "Local taxi in Dehradun starts from around " . $fh4 . " rupees for a 4 hour 40 km hatchback or sedan package, with per kilometre rates for point to point rides confirmed before booking and no hidden charges."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Local Taxi in Dehradun','serviceType'=>'Local taxi and hourly cab rental','description'=>'Hourly and point-to-point local taxi in Dehradun for city rides, sightseeing, railway station, ISBT and airport transfers with fixed fares and verified drivers.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>['Dehradun','Rajpur Road','Sahastradhara Road','Prem Nagar','Clement Town','Paltan Bazaar','ISBT Dehradun','Dehradun Railway Station','Jolly Grant Airport'],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>(string)$h4,'description'=>'4 hour 40 km local taxi package in Dehradun starts from ' . $fh4 . ' rupees.']],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__pkgs = [
['Hatchback','fa-car','Wagon R / Glanza',$fh4,$fh8,'1–3 pax · light bags','/fleet'],
['Sedan','fa-car-side','Dzire / Etios',$fs4,$fs8,'Most popular · AC comfort','/sedan-taxi-in-dehradun'],
['MPV','fa-car-rear','Ertiga',$fm4,$fm8,'Family · extra luggage','/suv-taxi-in-dehradun'],
['Premium','fa-van-shuttle','Innova Crysta',$fp4,$fp8,'Premium · hill-ready','/innova-taxi-in-dehradun'],
];
$__areas = ['Rajpur Road','Sahastradhara Road','Prem Nagar','Clement Town','Paltan Bazaar','ISBT Dehradun','Railway Station','Jolly Grant Airport','Robbers Cave','FRI','Tapkeshwar Temple','Buddha Temple'];
$__drops = [
['Railway Station / ISBT','fa-train','Arrivals, departures and bus connections across the city.'],
['Jolly Grant Airport','fa-plane-departure','Local leg of an airport transfer, on time.'],
['Hotels & hospitals','fa-hotel','Check-in, check-out, appointments and visits.'],
['Offices & schools','fa-building','Daily commute, meetings and drop-offs.'],
['Sightseeing points','fa-camera','Robbers Cave, FRI, Sahastradhara and more.'],
['Local markets','fa-bag-shopping','Paltan Bazaar, Rajpur Road and shopping runs.'],
];
$__plans = [
['fa-children','Family Fun Day','8 hr / 80 km','Robbers Cave → Sahastradhara → Maldevta picnic point','Hatchback or Sedan','/sedan-taxi-in-dehradun'],
['fa-om','Spiritual Circuit','4 hr / 40 km','Tapkeshwar Temple → Mindrolling Monastery → Buddha Temple','Sedan or Ertiga','/suv-taxi-in-dehradun'],
['fa-leaf','Nature & Forest','8 hr / 80 km','FRI Botanical Garden → Malsi Deer Park → Lachhiwala','Ertiga or Crysta','/innova-taxi-in-dehradun'],
];
?>
<main id="main">
<style>
.lt{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--amber:#f59e0b;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 420px)}
.lt *{box-sizing:border-box}
.lt::before{content:"";position:absolute;top:-180px;left:-120px;width:560px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.10),transparent 70%);pointer-events:none}
.lt::after{content:"";position:absolute;top:300px;right:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(245,158,11,.08),transparent 70%);pointer-events:none}
.lt .lt-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.lt .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.lt .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.lt .rv.in{opacity:1;transform:none}
.lt .lt-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.lt .lt-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.lt .lt-crumb a:hover{color:var(--blue)}
.lt .lt-crumb i{font-size:.6rem;color:var(--mute)}.lt .lt-crumb .cur{color:var(--ink);font-weight:600}
.lt .lt-hero{display:grid;grid-template-columns:1.25fr .95fr;gap:34px;align-items:start;padding:24px 0 10px}
.lt .lt-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.lt .lt-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.lt .lt-hero h1 em{font-style:normal;color:var(--blue)}
.lt .lt-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}
.lt .lt-lead strong{color:var(--ink)}
.lt .lt-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}
.lt .lt-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}
.lt .lt-trust i{color:var(--green)}
.lt .lt-herocta{display:flex;gap:12px;flex-wrap:wrap}
.lt .lt-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.lt .lt-btn-b{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.lt .lt-btn-b:hover{transform:translateY(-2px);filter:brightness(1.05)}
.lt .lt-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.lt .lt-btn-g:hover{transform:translateY(-2px)}
.lt .lt-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.lt .lt-btn-o:hover{border-color:var(--blue);color:var(--blue)}
.lt .lt-card{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0a2a63);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(9,32,84,.5);overflow:hidden}
.lt .lt-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,rgba(245,158,11,.3),transparent 70%)}
.lt .lt-live{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#ffe2a8;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.lt .lt-live::before{content:"";width:7px;height:7px;border-radius:50%;background:#ffce5c;box-shadow:0 0 0 0 rgba(255,206,92,.6);animation:ltpl 1.8s infinite}
@keyframes ltpl{70%{box-shadow:0 0 0 7px rgba(255,206,92,0)}100%{box-shadow:0 0 0 0 rgba(255,206,92,0)}}
.lt .lt-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.lt .lt-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 18px;position:relative}
.lt .lt-route{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:14px 16px;position:relative}
.lt .lt-route .end{text-align:center;flex:none}
.lt .lt-route .end b{font-family:'Sora','Poppins',sans-serif;font-size:1.1rem;display:block}
.lt .lt-route .end small{font-size:.64rem;color:rgba(255,255,255,.7);letter-spacing:.1em}
.lt .lt-route .mid{flex:1;height:2px;background:repeating-linear-gradient(90deg,#ffce5c 0 8px,transparent 8px 16px);position:relative}
.lt .lt-route .mid i{position:absolute;top:50%;left:10%;transform:translate(-50%,-50%);color:#fff;font-size:.85rem;animation:ltdrv 3.6s ease-in-out infinite}
@keyframes ltdrv{0%,100%{left:12%}50%{left:88%}}
.lt .lt-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.lt .lt-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.lt .lt-card .cta .w{background:#fff;color:#0057ff}.lt .lt-card .cta .g{background:#25d366;color:#04260f}.lt .lt-card .cta .c{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff}
.lt .lt-card .cta a:hover{transform:translateY(-2px)}
.lt .lt-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.lt .lt-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.lt .lt-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.lt .lt-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.lt .lt-qa strong{color:var(--ink)}
.lt .lt-sec{padding:48px 0}
.lt .lt-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.lt .lt-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.lt .lt-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.lt .lt-sh p{color:var(--slate);margin:0}
.lt .lt-pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.lt .lt-pcard{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:24px 22px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s;text-decoration:none;color:var(--ink)}
.lt .lt-pcard::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--blue),#22c9e8);transform:scaleX(0);transform-origin:left;transition:transform .4s}
.lt .lt-pcard:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.3);border-color:#cfe0ff}
.lt .lt-pcard:hover::after{transform:scaleX(1)}
.lt .lt-pico{width:50px;height:50px;border-radius:14px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1.2rem;margin-bottom:14px;transition:transform .35s}
.lt .lt-pcard:hover .lt-pico{transform:scale(1.08) rotate(-5deg)}
.lt .lt-pcard .pt{font-family:'Sora','Poppins',sans-serif;font-size:.74rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--blue)}
.lt .lt-pcard h3{font-family:'Sora','Poppins',sans-serif;font-size:1.12rem;font-weight:700;margin:4px 0 12px}
.lt .lt-prices{display:flex;gap:10px;margin-bottom:12px}
.lt .lt-pr{flex:1;background:var(--soft);border:1px solid var(--line);border-radius:12px;padding:10px;text-align:center}
.lt .lt-pr b{font-family:'Sora','Poppins',sans-serif;font-size:1.15rem;font-weight:800;color:var(--ink);display:block}
.lt .lt-pr small{font-size:.66rem;color:var(--mute);font-weight:600;letter-spacing:.04em;text-transform:uppercase}
.lt .lt-pbest{font-size:.84rem;color:var(--slate)}.lt .lt-pbest strong{color:var(--ink)}
.lt .lt-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;max-width:900px;margin:0 auto}
.lt .lt-step{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:20px 16px 16px;text-align:center}
.lt .lt-step .n{position:absolute;top:-12px;left:50%;transform:translateX(-50%);width:24px;height:24px;border-radius:999px;background:var(--blue);color:#fff;font-family:'Sora','Poppins',sans-serif;font-size:.72rem;font-weight:800;display:grid;place-items:center}
.lt .lt-step i{font-size:1.3rem;color:var(--blue);margin:6px 0 8px}
.lt .lt-step h3{font-family:'Sora','Poppins',sans-serif;font-size:.95rem;font-weight:700;margin:0 0 4px}
.lt .lt-step p{margin:0;font-size:.82rem;color:var(--slate);line-height:1.5}
.lt .lt-hub{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;background:radial-gradient(120% 140% at 90% 0%,#22c9e8,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;border-radius:24px;padding:30px;box-shadow:0 30px 60px -28px rgba(0,40,120,.5)}
.lt .lt-hub h3{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:8px 0 6px}
.lt .lt-hub p{margin:0;color:rgba(255,255,255,.82);max-width:52ch}
.lt .lt-hub .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:#bfe0ff;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.lt .lt-plangrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.lt .lt-plan{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:24px 22px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.lt .lt-plan::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:linear-gradient(180deg,var(--amber),var(--blue));opacity:0;transition:opacity .3s}
.lt .lt-plan:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.3);border-color:#ffe0b3}
.lt .lt-plan:hover::before{opacity:1}
.lt .lt-plan .ph{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.lt .lt-plan .pico{width:46px;height:46px;border-radius:13px;background:#fff7e8;color:var(--amber);display:grid;place-items:center;font-size:1.1rem;flex:none}
.lt .lt-plan h3{font-family:'Sora','Poppins',sans-serif;font-size:1.08rem;font-weight:700;margin:0}
.lt .lt-plan .hrs{font-size:.7rem;font-weight:800;color:var(--blue);background:var(--blue-tint);border-radius:999px;padding:4px 10px;white-space:nowrap}
.lt .lt-plan .stops{font-size:.88rem;color:var(--slate);line-height:1.6;margin:0 0 12px}
.lt .lt-plan .veh{font-size:.8rem;font-weight:700;color:var(--ink)}
.lt .lt-plan .veh i{color:var(--blue);margin-right:6px}
.lt .lt-chips{display:flex;flex-wrap:wrap;gap:11px;justify-content:center}
.lt .lt-chip{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:11px 17px;font-weight:600;font-size:.9rem;color:var(--ink);transition:.25s}
.lt .lt-chip i{color:var(--blue);font-size:.78rem}
.lt .lt-chip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}
.lt .lt-dgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
.lt .lt-ditem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.lt .lt-ditem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#cfe0ff}
.lt .lt-dico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.lt .lt-ditem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.lt .lt-ditem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.lt .lt-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25);max-width:760px;margin:0 auto}
.lt .lt-tscroll{overflow-x:auto}
.lt table{width:100%;border-collapse:collapse;min-width:480px}
.lt th,.lt td{padding:15px 18px;text-align:left;font-size:.92rem}
.lt thead th{background:var(--soft);color:var(--blue-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.lt tbody tr{border-top:1px solid var(--line);transition:background .2s}.lt tbody tr:hover{background:var(--soft)}
.lt td .pr{font-family:'Sora','Poppins',sans-serif;font-weight:700;color:var(--ink)}
.lt .lt-wgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.lt .lt-witem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:20px;transition:transform .3s,box-shadow .3s,border-color .3s}
.lt .lt-witem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#cfe0ff}
.lt .lt-wico{flex:none;width:46px;height:46px;border-radius:13px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1.05rem}
.lt .lt-witem h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}
.lt .lt-witem p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
.lt .lt-fbox{max-width:820px;margin:0 auto}
.lt .lt-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}
.lt .lt-fi:hover{border-color:#cfe0ff}
.lt .lt-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.lt .lt-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.lt .lt-fi.open .lt-ft{transform:rotate(45deg)}
.lt .lt-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.lt .lt-fi.open .lt-fb{max-height:380px;padding:0 20px 18px}
.lt .lt-soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.lt .lt-cta{padding:0 0 70px}
.lt .lt-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.lt .lt-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.lt .lt-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.lt .lt-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.lt .lt-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.lt .lt-cta .w{background:#fff;color:#0057ff}.lt .lt-cta .g{background:#25d366;color:#04260f}.lt .lt-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.lt .lt-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.lt .lt-hero{grid-template-columns:1fr;gap:24px}.lt .lt-card{position:static}.lt .lt-steps{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.lt *{transition:none!important;animation:none!important}.lt .rv{opacity:1!important;transform:none!important}}
</style>
<div class="lt">
<div class="lt-in">
<nav class="lt-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Local Taxi</span></nav>
<section class="lt-hero">
<div class="rv">
<span class="lt-eyebrow"><i class="fa-solid fa-taxi"></i> City rides · hourly · sightseeing</span>
<h1 class="disp">Local taxi in <em>Dehradun</em> — City Rides &amp; Hourly Cab Packages</h1>
<p class="lt-lead"><strong>Local taxi in Dehradun starts from ₹<?php echo $fh4; ?> for a 4 hour / 40 km package.</strong> Anaya Cab Service runs clean AC hatchbacks, sedans, Ertigas and Innovas for city rides, railway station and ISBT transfers, Dehradun sightseeing and hourly errands — with verified drivers and fares fixed before you book.</p>
<div class="lt-trust">
<span><i class="fa-solid fa-circle-check"></i> 4hr &amp; 8hr packages</span>
<span><i class="fa-solid fa-circle-check"></i> Fixed fare upfront</span>
<span><i class="fa-solid fa-circle-check"></i> Verified drivers</span>
<span><i class="fa-solid fa-circle-check"></i> No advance</span>
</div>
<div class="lt-herocta">
<a class="lt-btn lt-btn-b" href="/#booking"><i class="fa-solid fa-taxi"></i> Book local cab</a>
<a class="lt-btn lt-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a local taxi in Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get fare on WhatsApp</a>
<a class="lt-btn lt-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="lt-card rv" aria-label="Book your local taxi">
<span class="lt-live">Live city desk</span>
<h3 class="disp">Your Dehradun city ride</h3>
<p class="sub">Tell us pickup, drop and hours — fare confirmed on WhatsApp.</p>
<div class="lt-route" aria-hidden="true">
<div class="end"><b>PICKUP</b><small>ANYWHERE</small></div>
<div class="mid"><i class="fa-solid fa-car-side"></i></div>
<div class="end"><b>DROP</b><small>CITY-WIDE</small></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a local taxi in Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="c" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
<p class="note">Hourly or point to point · 24×7</p>
</aside>
</section>
<div class="lt-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> offers local taxi service in Dehradun as fixed-fare <strong>hourly cab packages (4hr/40km from ₹<?php echo $fh4; ?>, 8hr/80km from ₹<?php echo $fh8; ?>)</strong> or point-to-point city drops across Rajpur Road, Sahastradhara Road, ISBT, Dehradun Railway Station, Jolly Grant Airport, and local sightseeing spots (Robbers Cave, FRI, Tapkeshwar Temple).</p>
</div>
</div>
<section class="lt-sec rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-regular fa-clock"></i> Hourly packages</span><h2 class="disp">Local taxi packages by vehicle</h2><p>Pick a vehicle — the 4 hour and 8 hour package fares are fixed before you book.</p></div>
<div class="lt-pgrid">
<?php foreach ($__pkgs as $p): ?>
<a class="lt-pcard rv" href="<?php echo $p[6]; ?>">
<div class="lt-pico"><i class="fa-solid <?php echo $p[1]; ?>"></i></div>
<div class="pt"><?php echo $p[0]; ?></div>
<h3><?php echo $p[2]; ?></h3>
<div class="lt-prices">
<div class="lt-pr"><b>₹<?php echo $p[3]; ?></b><small>4 hr / 40 km</small></div>
<div class="lt-pr"><b>₹<?php echo $p[4]; ?></b><small>8 hr / 80 km</small></div>
</div>
<p class="lt-pbest"><strong>Best for:</strong> <?php echo $p[5]; ?></p>
</a>
<?php endforeach; ?>
</div>
</div></section>
<section class="lt-sec lt-soft rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-list-check"></i> Simple by design</span><h2 class="disp">How an hourly package works</h2></div>
<div class="lt-steps">
<div class="lt-step rv"><span class="n">1</span><i class="fa-solid fa-comment-dots"></i><h3>Fix the fare</h3><p>Tell pickup + hours on WhatsApp; fare locked before the ride.</p></div>
<div class="lt-step rv"><span class="n">2</span><i class="fa-solid fa-route"></i><h3>Ride with stops</h3><p>Errands, meetings, sightseeing — add stops freely within the package.</p></div>
<div class="lt-step rv"><span class="n">3</span><i class="fa-solid fa-clock"></i><h3>Extend if needed</h3><p>Running late? Extend at ₹150/hr or per-km, told upfront.</p></div>
</div>
</div></section>
<section class="lt-sec rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Themed day plans</span><h2 class="disp">Ready-made Dehradun day trips</h2><p>Tell us the mood — we plan the stops and the cab on an 8hr or 4hr package.</p></div>
<div class="lt-plangrid">
<?php foreach ($__plans as $pl): ?>
<div class="lt-plan rv">
<div class="ph"><span class="pico"><i class="fa-solid <?php echo $pl[0]; ?>"></i></span><h3><?php echo $pl[1]; ?></h3><span class="hrs"><?php echo $pl[2]; ?></span></div>
<p class="stops"><?php echo $pl[3]; ?></p>
<p class="veh"><i class="fa-solid fa-car-side"></i> Suggested: <?php echo $pl[4]; ?></p>
</div>
<?php endforeach; ?>
</div>
</div></section>
<section class="lt-sec lt-soft rv"><div class="lt-in">
<div class="lt-hub rv">
<div>
<span class="ey"><i class="fa-solid fa-map-location-dot"></i> Full-day sightseeing</span>
<h3>Planning a Doon Valley sightseeing day?</h3>
<p>Our dedicated sightseeing hub bundles Robbers Cave, Sahastradhara, FRI, Tapkeshwar and Mindrolling into ready 4hr and 8hr tours with a fixed package fare.</p>
</div>
<div class="lt-herocta"><a class="lt-btn lt-btn-b" href="/dehradun-local-sightseeing-taxi">View sightseeing packages <i class="fa-solid fa-arrow-right"></i></a></div>
</div>
</div></section>
<section class="lt-sec rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-map-location-dot"></i> Coverage</span><h2 class="disp">Areas we cover in &amp; around Dehradun</h2><p>Hourly and point-to-point local taxi across the city and nearby colonies.</p></div>
<div class="lt-chips">
<?php foreach ($__areas as $a): ?><span class="lt-chip"><i class="fa-solid fa-location-dot"></i> <?php echo $a; ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="lt-sec lt-soft rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-route"></i> Popular local drops</span><h2 class="disp">Where locals book us every day</h2></div>
<div class="lt-dgrid">
<?php foreach ($__drops as $d): ?>
<div class="lt-ditem rv"><span class="lt-dico"><i class="fa-solid <?php echo $d[1]; ?>"></i></span><div><h3><?php echo $d[0]; ?></h3><p><?php echo $d[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="lt-sec rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Package fares</span><h2 class="disp">Local taxi package rates</h2><p>Excess kilometre or hour charges, if any, are shared upfront.</p></div>
<div class="lt-twrap"><div class="lt-tscroll">
<table aria-label="Local taxi package fares in Dehradun">
<thead><tr><th>Vehicle</th><th>4 Hr / 40 Km</th><th>8 Hr / 80 Km</th></tr></thead>
<tbody>
<?php foreach ($__pkgs as $p): ?>
<tr><td><strong><?php echo $p[2]; ?></strong></td><td class="pr">₹<?php echo $p[3]; ?></td><td class="pr">₹<?php echo $p[4]; ?></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
<p style="text-align:center;margin-top:14px;font-size:.82rem;color:var(--slate)">Package fares include specified hours and kilometres. Extra kilometres are charged at standard vehicle rates (e.g. ₹13–18/km) and extra hours at ₹150/hr.</p>
</div></section>
<section class="lt-sec lt-soft rv"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-solid fa-medal"></i> Why book local with us</span><h2 class="disp">City travel, handled with care</h2></div>
<div class="lt-wgrid">
<?php $why=[['fa-spray-can-sparkles','Clean AC fleet','Sanitised hatchback, sedan, Ertiga and Innova options.'],['fa-id-badge','Verified drivers','Police-verified and courteous city drivers.'],['fa-tags','Transparent fare','Package or per-km fare fixed before the trip.'],['fa-headset','24×7 booking','Call or WhatsApp any time, day or night.'],['fa-bolt','Quick pickup','Fast dispatch across Dehradun city.'],['fa-clock','Flexible hours','Add stops and extend on an hourly package.'],]; foreach($why as $w): ?>
<div class="lt-witem rv"><span class="lt-wico"><i class="fa-solid <?php echo $w[0]; ?>"></i></span><div><h3><?php echo $w[1]; ?></h3><p><?php echo $w[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="lt-sec rv" id="faq"><div class="lt-in">
<div class="lt-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Local taxi in Dehradun — FAQs</h2></div>
<div class="lt-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="lt-fi<?php echo $i===0?' open':''; ?>"><div class="lt-fh"><?php echo htmlspecialchars($f[0]); ?><span class="lt-ft"><i class="fa-solid fa-plus"></i></span></div><div class="lt-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="lt-cta rv"><div class="lt-in">
<div class="lt-ctain">
<h2 class="disp">Need a cab in Dehradun right now?</h2>
<p>Book an hourly package or a quick point-to-point ride — confirmed in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book local cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a local taxi in Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.lt .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.lt .lt-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>