<?php
/**
 * =====================================================================
 * Anaya Cab Service — Production Sitemap INDEX Engine
 * taxidehradun.com
 * Version: 4.0 (index + split children + refresh mode)
 *
 * Behavior:
 * - Default (/sitemap.xml internal serve): <sitemapindex> output
 *   (3 static children: pages / routes / blog)
 * - ?refresh=sitemap2026 → children rebuild (DB blog preferred,
 *   filesystem fallback, dedupe, valid lastmod) — v3.0 intelligence preserved
 * - Child missing ho to index request pe auto-rebuild (self-healing)
 *
 * SEO rules preserved: canonical host enforcement, duplicate protection,
 * slug validation, excluded utilities, XML-safe output.
 * =====================================================================
 */
require_once __DIR__ . '/includes/config.php';

$domain = 'https://www.taxidehradun.com';
$REFRESH_KEY = 'sitemap2026';
$today = date('Y-m-d');

/* ---------------- Helpers ---------------- */
function anaya_file_date(string $file): string {
    if (is_file($file)) {
        $m = @filemtime($file);
        if ($m !== false && $m > 0) return date('Y-m-d', (int)$m);
    }
    return date('Y-m-d');
}

function anaya_valid_slug(string $slug): bool {
    return (bool) preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug);
}

function anaya_add(array &$urls, array &$seen, string $loc, string $lastmod, string $changefreq = 'weekly', string $priority = '0.7'): void {
    $path = parse_url($loc, PHP_URL_PATH);
    if ($path !== '/' && $path !== '/blog/' && substr($loc, -1) === '/') $loc = rtrim($loc, '/');
    $loc = preg_replace('#^https?://[^/]+#i', 'https://www.taxidehradun.com', $loc);
    $key = rtrim($loc, '/');
    if ($path === '/blog/' || $path === '/blog') { $key = 'https://www.taxidehradun.com/blog/'; $loc = 'https://www.taxidehradun.com/blog/'; }
    if (isset($seen[$key])) return;
    $seen[$key] = true;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $lastmod)) $lastmod = date('Y-m-d');
    $allowed = ['always','hourly','daily','weekly','monthly','yearly','never'];
    if (!in_array($changefreq, $allowed, true)) $changefreq = 'weekly';
    $p = (float)$priority; $p = max(0.0, min(1.0, $p));
    $urls[] = ['loc' => $loc, 'lastmod' => $lastmod, 'changefreq' => $changefreq, 'priority' => number_format($p, 1, '.', '')];
}

function anaya_xml_urlset(array $urls): string {
    $x = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach ($urls as $u) {
        $x .= "  <url>\n    <loc>" . htmlspecialchars($u['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</loc>\n    <lastmod>" . htmlspecialchars($u['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</lastmod>\n    <changefreq>{$u['changefreq']}</changefreq>\n    <priority>{$u['priority']}</priority>\n  </url>\n";
    }
    return $x . "</urlset>\n";
}

/* ---------------- Exclusions (v3.0 preserved) ---------------- */
$EXCLUDE = [
    'index','sitemap','robots','404',
    'clear-opcache','clear-cache','debug','image-doctor','indexnow-bulk','auto-fix-seo','purge','blog-dedupe',
    'track','booking',
    'delhi-to-haridwar-taxi','dehradun-to-gurugram-taxi','dehradun-to-dehradun-taxi',
    'hero-slider-injector','sitemap-fixer','meta-fixer',
];

$CORE = [
    'services','pricing','fleet','about','reviews','faq','contact',
    'dehradun-airport-taxi-service','local-taxi-in-dehradun','dehradun-local-sightseeing-taxi',
    'char-dham-yatra-taxi','do-dham-yatra-taxi','outstation-taxi-from-dehradun','one-way-taxi-service-in-dehradun',
    'wedding-car-rental-dehradun','luxury-car-rental-dehradun','tempo-traveller-in-dehradun',
    'force-urbania-rental-dehradun','sedan-taxi-in-dehradun','suv-taxi-in-dehradun',
    'innova-taxi-in-dehradun','car-rental-in-dehradun','dehradun-railway-station-taxi','isbt-dehradun-taxi',
    'dehradun-to-delhi-taxi','dehradun-to-mussoorie-taxi','dehradun-to-haridwar-taxi',
    'dehradun-to-rishikesh-taxi','dehradun-to-kedarnath-taxi','dehradun-to-badrinath-taxi','dehradun-to-jim-corbett-taxi',
];

$LEGAL = ['privacy-policy','terms-conditions','cancellation-policy','privacy','terms','cancellation'];

/* ---------------- Children Builder (v3.0 intelligence) ---------------- */
function anaya_build_children(): array {
    global $domain, $EXCLUDE, $CORE, $LEGAL;
    $pages = []; $routes = []; $blog = [];
    $seenP = []; $seenR = []; $seenB = [];

    anaya_add($pages, $seenP, $domain . '/', anaya_file_date(__DIR__ . '/index.php'), 'daily', '1.0');
    anaya_add($pages, $seenP, $domain . '/blog/', anaya_file_date(__DIR__ . '/blog/index.php'), 'daily', '0.9');

    $root_files = glob(__DIR__ . '/*.php');
    if (is_array($root_files)) {
        foreach ($root_files as $file) {
            if (!is_file($file)) continue;
            $slug = basename($file, '.php');
            if (in_array($slug, $EXCLUDE, true)) continue;
            if (!anaya_valid_slug($slug)) continue;
            if (in_array($slug, ['index','sitemap','blog'], true)) continue;

            $prio = '0.7'; $freq = 'weekly';
            if (in_array($slug, $CORE, true)) { $prio = '0.9'; }
            elseif (in_array($slug, $LEGAL, true)) { $prio = '0.3'; $freq = 'yearly'; }
            elseif (strpos($slug, '-to-') !== false) { $prio = '0.8'; }
            elseif (strpos($slug,'taxi') !== false || strpos($slug,'cab') !== false || strpos($slug,'rental') !== false) { $prio = '0.8'; }

            if (strpos($slug, '-to-') !== false) {
                anaya_add($routes, $seenR, $domain . '/' . $slug, anaya_file_date($file), $freq, $prio);
            } else {
                anaya_add($pages, $seenP, $domain . '/' . $slug, anaya_file_date($file), $freq, $prio);
            }
        }
    }

    // Blog posts: DB preferred, filesystem fallback (v3.0 logic)
    $blog_slugs = [];
    if (function_exists('db')) {
        try {
            $stmt = db()->query("SELECT slug, updated_at, published_at FROM blogs WHERE status = 'published' ORDER BY COALESCE(updated_at, published_at) DESC");
            $rows = $stmt ? $stmt->fetchAll() : [];
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    $s = isset($row['slug']) ? trim((string)$row['slug']) : '';
                    if ($s === '' || !anaya_valid_slug($s) || isset($blog_slugs[$s])) continue;
                    $blog_slugs[$s] = ['updated_at' => (string)($row['updated_at'] ?? ''), 'published_at' => (string)($row['published_at'] ?? '')];
                }
            }
        } catch (Throwable $e) { $blog_slugs = []; }
    }
    if (empty($blog_slugs)) {
        $bf = glob(__DIR__ . '/blog/*.php');
        if (is_array($bf)) {
            foreach ($bf as $file) {
                if (!is_file($file)) continue;
                $s = basename($file, '.php');
                if ($s === 'index' || !anaya_valid_slug($s)) continue;
                if (!isset($blog_slugs[$s])) $blog_slugs[$s] = ['updated_at' => '', 'published_at' => ''];
            }
        }
    }
    foreach ($blog_slugs as $slug => $meta) {
        $file = __DIR__ . '/blog/' . $slug . '.php';
        if (is_file($file)) { $lastmod = anaya_file_date($file); }
        else {
            $raw = $meta['updated_at'] !== '' ? $meta['updated_at'] : $meta['published_at'];
            $ts = $raw !== '' ? strtotime($raw) : false;
            $lastmod = ($ts !== false) ? date('Y-m-d', $ts) : date('Y-m-d');
        }
        anaya_add($blog, $seenB, $domain . '/blog/' . $slug, $lastmod, 'monthly', '0.6');
    }

    return ['pages' => $pages, 'routes' => $routes, 'blog' => $blog];
}

function anaya_write_children(): array {
    $c = anaya_build_children();
    file_put_contents(__DIR__ . '/sitemap-pages.xml', anaya_xml_urlset($c['pages']));
    file_put_contents(__DIR__ . '/sitemap-routes.xml', anaya_xml_urlset($c['routes']));
    file_put_contents(__DIR__ . '/sitemap-blog.xml', anaya_xml_urlset($c['blog']));
    return $c;
}

/* ---------------- Refresh Mode ---------------- */
if (isset($_GET['refresh']) && $_GET['refresh'] === $REFRESH_KEY) {
    $c = anaya_write_children();
    header('Content-Type: text/plain; charset=UTF-8');
    echo "Children rebuilt @ $today\npages: " . count($c['pages']) . " URLs\nroutes: " . count($c['routes']) . " URLs\nblog: " . count($c['blog']) . " URLs\n";
    exit;
}

/* ---------------- Self-heal: missing child auto-rebuild ---------------- */
foreach (['sitemap-pages.xml','sitemap-routes.xml','sitemap-blog.xml'] as $f) {
    if (!is_file(__DIR__ . '/' . $f)) { anaya_write_children(); break; }
}

/* ---------------- Default: SITEMAP INDEX ---------------- */
header('Content-Type: application/xml; charset=UTF-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach (['sitemap-pages.xml','sitemap-routes.xml','sitemap-blog.xml'] as $f) {
    echo "  <sitemap>\n    <loc>$domain/$f</loc>\n    <lastmod>" . anaya_file_date(__DIR__ . '/' . $f) . "</lastmod>\n  </sitemap>\n";
}
echo "</sitemapindex>\n";