<?php
$__route_slug = 'dehradun-to-faridabad-taxi';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/route-head.php';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/route-template.php';
require_once __DIR__ . '/includes/footer.php';
