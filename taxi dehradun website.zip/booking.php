<?php
/**
 * Anaya Cab Service — Booking Compatibility Wrapper
 *
 * Canonical booking endpoint:
 * /api/booking.php
 *
 * /booking is internally rewritten to this file by .htaccess.
 * This file intentionally contains NO database or fare logic.
 */

declare(strict_types=1);

require_once __DIR__ . '/api/booking.php';