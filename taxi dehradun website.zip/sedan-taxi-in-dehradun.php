<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$V = [
'slug'=>'sedan-taxi-in-dehradun','name'=>'Sedan Taxi in Dehradun','short'=>'Sedan','cls'=>'Sedan · Dzire / Etios',
'char'=>'Sedan · Dzire / Etios','char_icon'=>'fa-car','glyph'=>'fa-car','img'=>'/assets/images/fleet/dzire.webp',
'ac'=>'#0057ff','ac2'=>'#39b6ff','d1'=>'#03102e','d2'=>'#0a2a63','tint'=>'#eaf1ff',
'headline'=>'Sedan Taxi in Dehradun — Dzire & Etios AC Cab Booking',
'lead'=>'Book a sedan taxi in Dehradun for the rides you take most — Jolly Grant Airport transfers, hourly city errands and short outstation drops to Mussoorie, Rishikesh and Haridwar. The Dzire / Etios class is our most-booked cab: smooth, fuel-efficient and easy on the budget, with a verified driver and a fare fixed before you travel.',
'pax'=>'4','bags'=>'2','rate_range'=>'₹14 – ₹16 / km','pkg4'=>'₹1,100','pkg8'=>'₹1,900',
'service_type'=>'Sedan cab booking','offers_price'=>'14','offer_desc'=>'Sedan taxi in Dehradun available from approx. ₹14 per km depending on route and vehicle.',
'area'=>['Dehradun','Jolly Grant Airport','Mussoorie','Rishikesh','Haridwar','Delhi'],
'best_for'=>[
['fa-plane-departure','Airport transfers','The go-to cab for Jolly Grant pickup and drop — quick, light and punctual, with flight-time tracking built in.'],
['fa-city','Local & hourly rides','Point-to-point city trips and 4 / 8-hour packages across Dehradun.'],
['fa-route','Short outstation','Mussoorie, Rishikesh and Haridwar one-way drops at a transparent fare.'],
['fa-briefcase','Business & corporate','Quiet, reliable rides for meetings, clients and city transfers.'],
],
'compare_title'=>'Sedan options compared',
'compare'=>[['Maruti Suzuki Dzire','4 passengers','Most popular — airport & outstation'],['Toyota Etios','4 passengers','Roomy boot for longer trips'],['Toyota Glanza','4 passengers','Budget hatchback alternative']],
'routes'=>[['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Local taxi','/local-taxi-in-dehradun'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi'],['Dehradun → Delhi','/dehradun-to-delhi-taxi']],
'use_cases'=>['Solo & couple travel','Airport pickup / drop','Local hourly rides','One-way outstation','Business transfers'],
'faqs'=>[
['Which sedan taxis are available in Dehradun?','Common sedan options include the Maruti Suzuki Dzire, Toyota Etios and similar AC sedans, assigned by availability and route.'],
['Is a sedan taxi suitable for airport transfer?','Yes, sedans are our most popular choice for Jolly Grant Airport pickup and drop, railway station transfers and small-family trips with light luggage.'],
['Can I book a sedan for outstation travel?','Yes, sedans can be booked for Haridwar, Rishikesh, Mussoorie, Delhi, Nainital and other outstation routes at a fixed one-way or round-trip fare.'],
['How many passengers fit comfortably in a sedan cab?','A sedan comfortably seats up to 4 passengers with light to medium luggage. For heavier luggage or 5 passengers, an Ertiga or SUV is recommended.'],
],
'title'=>'Sedan Taxi in Dehradun | Dzire & Etios Cab on Rent (2026)',
'desc'=>'Book sedan taxi in Dehradun — Maruti Dzire & Toyota Etios for Jolly Grant Airport transfers, local city hourly rides and outstation drops to Mussoorie, Rishikesh, Haridwar & Delhi. Call '.$phone.'.',
];

$page_url = $domain . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>$domain.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];

require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<style>
.vp-qa{margin:24px 0 10px;background:#fff;border:1px solid var(--line,#e7edf6);border-left:4px solid var(--vp-ac,#0057ff);border-radius:16px;padding:18px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.vp-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--vp-ac,#0057ff);margin-bottom:8px}
.vp-qa p{margin:0;color:#33415c;line-height:1.64;font-size:.96rem}.vp-qa strong{color:#0b1220}
</style>
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-user-group"></i><b><?php echo htmlspecialchars($V['pax']); ?></b><span>passengers</span></span>
<span class="vp-m"><i class="fa-solid fa-suitcase-rolling"></i><b><?php echo htmlspecialchars($V['bags']); ?></b><span>luggage</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>AC</b><span>sanitised</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b><?php echo htmlspecialchars($V['rate_range']); ?></b><span>base fare</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?> in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>

<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="vp-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Sedan Taxi in Dehradun Rates</div>
<p itemprop="text"><strong>Sedan Taxi in Dehradun</strong> (Maruti Dzire / Toyota Etios) is ideal for 1 to 4 passengers with luggage, starting at <strong>₹14 – ₹16 / km</strong>. Anaya Cab Service offers verified sedan cabs for Jolly Grant Airport transfers (₹800), 4 hr / 40 km local packages (₹1,100), 8 hr / 80 km packages (₹1,900), and one-way drops to Mussoorie (₹1,200), Rishikesh (₹1,000), Haridwar (₹1,200), and Delhi (₹3,500).</p>
</div>

</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where this cab shines</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['cls']); ?> fare at a glance</h2><p>Per-km and hourly packages — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Plan</th><th>What you get</th><th>Fare</th></tr></thead>
<tbody>
<tr><td>Per kilometre</td><td>Local &amp; outstation, metered by route</td><td class="fare"><?php echo htmlspecialchars($V['rate_range']); ?></td></tr>
<tr><td>4 Hr / 40 Km</td><td>City errands, airport + short sightseeing</td><td class="fare"><?php echo htmlspecialchars($V['pkg4']); ?></td></tr>
<tr><td>8 Hr / 80 Km</td><td>Full-day local or short outstation</td><td class="fare"><?php echo htmlspecialchars($V['pkg8']); ?></td></tr>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> comparison">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-gem"></i> The Sedan Advantage</span><h2 class="disp">Why a sedan is the smartest daily cab</h2></div>
<div class="rv" style="max-width:780px">
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">For the majority of trips in and around Dehradun — airport transfers, hourly city errands, railway station pickups and short outstation drops to Mussoorie, Rishikesh and Haridwar — a sedan is the smartest choice. It is light enough to navigate narrow city streets and tight parking spots, fuel-efficient enough to keep the per-km fare at the lowest slab, and comfortable enough for 2 to 4 passengers with light to medium luggage.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:1.02rem">The Maruti Suzuki Dzire is the most popular sedan in our fleet because it is reliable, easy to maintain and has a decent boot for two suitcases plus a cabin bag. The Toyota Etios is the alternative when you need a slightly roomier boot for longer outstation runs.</p>
<p style="color:#475569;line-height:1.8;margin:0 0 18px;font-size:1.02rem">A sedan is not the right cab for a full Char Dham Yatra or a 12-person wedding group — for those, look at the Innova or Tempo Traveller pages. But for the daily, frequent, budget-conscious trips that make up most of Dehradun's taxi demand, the sedan is the workhorse that keeps the fare honest and the ride smooth.</p>
<ul style="list-style:none;padding:0;margin:0;display:grid;gap:10px">
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Lowest per-km fare slab — the most budget-friendly option for daily trips.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Light, nimble size for Dehradun's narrow streets and tight parking.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Dzire and Etios — reliable, easy to maintain, decent boot for 2 suitcases.</li>
<li style="position:relative;padding-left:26px;color:#334155;line-height:1.6"><span style="position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:3px;background:<?php echo $V['ac']; ?>"></span>Ideal for 2-4 passengers with light to medium luggage.</li>
</ul>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular routes</span><h2 class="disp">Routes travellers book</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This cab is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your route, date and luggage — we confirm a transparent fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

