<?php
/**
 * Anaya Cab Service — Gemini Agent Functions
 * Safe MVP multi-agent layer for custom PHP admin.
 */
if (!defined('ADMIN_PASSWORD') && php_sapi_name() !== 'cli') exit;

function agent_db(): ?PDO {
    return function_exists('db') ? db() : null;
}

function agent_tables_install(?PDO $pdo): void {
    if (!$pdo) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS agent_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL UNIQUE,
        setting_value LONGTEXT NULL,
        updated_at TIMESTAMP NULL DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS agent_tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        agent_name VARCHAR(80) NOT NULL,
        task_type VARCHAR(80) NOT NULL,
        input_json LONGTEXT NULL,
        output_json LONGTEXT NULL,
        status ENUM('pending','running','completed','failed','approved','rejected') DEFAULT 'pending',
        priority TINYINT DEFAULT 5,
        error_text TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        completed_at TIMESTAMP NULL DEFAULT NULL,
        KEY idx_status(status),
        KEY idx_agent(agent_name),
        KEY idx_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS agent_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        agent_name VARCHAR(80) NOT NULL,
        level VARCHAR(20) DEFAULT 'info',
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_agent(agent_name),
        KEY idx_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS agent_drafts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        draft_type VARCHAR(60) DEFAULT 'blog',
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NULL,
        content LONGTEXT NULL,
        meta_title VARCHAR(255) NULL,
        meta_description VARCHAR(255) NULL,
        focus_keyword VARCHAR(255) NULL,
        schema_json LONGTEXT NULL,
        status ENUM('draft','needs_review','approved','published','rejected') DEFAULT 'needs_review',
        source_task_id INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        KEY idx_status(status),
        KEY idx_type(draft_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function agent_log(string $agent, string $message, string $level='info'): void {
    $pdo = agent_db();
    if (!$pdo) return;
    try {
        $stmt = $pdo->prepare("INSERT INTO agent_logs (agent_name, level, message) VALUES (?, ?, ?)");
        $stmt->execute([$agent, $level, $message]);
    } catch (Throwable $e) {}
}

function agent_get_setting(string $key, $default='') {
    $pdo = agent_db();
    if (!$pdo) return $default;
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM agent_settings WHERE setting_key=?");
        $stmt->execute([$key]);
        $v = $stmt->fetchColumn();
        return $v === false ? $default : $v;
    } catch (Throwable $e) { return $default; }
}

function agent_set_setting(string $key, string $value): void {
    $pdo = agent_db();
    if (!$pdo) return;
    $stmt = $pdo->prepare("INSERT INTO agent_settings (setting_key, setting_value, updated_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_at=NOW()");
    $stmt->execute([$key, $value]);
}

function agent_create_task(string $agent, string $type, array $input=[], int $priority=5): int {
    $pdo = agent_db();
    if (!$pdo) return 0;
    $stmt = $pdo->prepare("INSERT INTO agent_tasks (agent_name, task_type, input_json, status, priority, created_at) VALUES (?, ?, ?, 'pending', ?, NOW())");
    $stmt->execute([$agent, $type, json_encode($input, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), $priority]);
    return (int)$pdo->lastInsertId();
}

function agent_gemini_list_models(string $apiKey): array {
    $url = "https://generativelanguage.googleapis.com/v1beta/models?key=" . rawurlencode($apiKey);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $err || $code < 200 || $code >= 300) return [];
    $json = json_decode($body, true);
    $models = [];
    foreach (($json['models'] ?? []) as $m) {
        $name = $m['name'] ?? '';
        $methods = $m['supportedGenerationMethods'] ?? [];
        if ($name && in_array('generateContent', $methods, true)) {
            $models[] = str_replace('models/', '', $name);
        }
    }
    return $models;
}

function agent_gemini_call(string $prompt, string $system=''): array {
    $apiKey = trim((string)agent_get_setting('gemini_api_key', ''));
    $selectedModel = trim((string)agent_get_setting('gemini_model', 'gemini-2.0-flash')) ?: 'gemini-2.0-flash';
    if ($apiKey === '') return ['ok'=>false, 'error'=>'Gemini API key missing. Add it in AI Agents settings.'];

    $available = agent_gemini_list_models($apiKey);
    $preferred = [
        $selectedModel,
        'gemini-2.5-flash',
        'gemini-2.5-flash-lite',
        'gemini-2.0-flash',
        'gemini-2.0-flash-lite',
        'gemini-1.5-flash-latest',
        'gemini-1.5-flash',
        'gemini-1.5-pro-latest',
        'gemini-1.5-pro'
    ];
    if ($available) {
        $models = [];
        foreach ($preferred as $m) if (in_array($m, $available, true)) $models[] = $m;
        foreach ($available as $m) if (!in_array($m, $models, true)) $models[] = $m;
    } else {
        $models = $preferred;
    }
    $models = array_values(array_unique(array_filter($models)));

    $parts = [];
    if ($system !== '') $parts[] = ['text' => "System instructions:\n" . $system];
    $parts[] = ['text' => $prompt];
    $payload = [
        'contents' => [['role'=>'user', 'parts'=>$parts]],
        'generationConfig' => [
            'temperature' => 0.35,
            'topP' => 0.9,
            'maxOutputTokens' => 4096
        ]
    ];

    $attempts = [];
    foreach ($models as $model) {
        $url = "https://generativelanguage.googleapis.com/v1beta/models/" . rawurlencode($model) . ":generateContent?key=" . rawurlencode($apiKey);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 60
        ]);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $err) {
            $attempts[] = $model . ': curl ' . $err;
            continue;
        }
        $json = json_decode($body, true);
        if ($code >= 200 && $code < 300) {
            $text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
            if ($text !== '') return ['ok'=>true, 'text'=>$text, 'model'=>$model, 'available_models'=>$available, 'raw'=>$json];
            $attempts[] = $model . ': empty response';
            continue;
        }
        $msg = $json['error']['message'] ?? substr($body, 0, 300);
        $attempts[] = $model . ': HTTP ' . $code . ' ' . $msg;
        // 401/403 means key/billing/access issue; other models won't help much.
        if (in_array($code, [401,403], true)) break;
        // 404 model not found: continue trying.
    }

    $hint = $available ? ('Available generateContent models: ' . implode(', ', array_slice($available, 0, 12))) : 'Could not list models. Check API key and whether Generative Language API is enabled.';
    return ['ok'=>false, 'error'=>'Gemini failed. ' . $hint . ' Attempts: ' . implode(' | ', $attempts), 'available_models'=>$available];
}

function agent_fetch_url(string $url): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_USERAGENT => 'AnayaSEOAgent/1.0 (+https://www.taxidehradun.com)'
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $final = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    return ['ok'=>($body!==false && !$err), 'status'=>$code, 'url'=>$final, 'body'=>(string)$body, 'error'=>$err];
}

function agent_extract_sitemap_urls(string $sitemapUrl): array {
    $res = agent_fetch_url($sitemapUrl);
    if (!$res['ok'] || $res['status'] >= 400) return [];
    preg_match_all('#<loc>(.*?)</loc>#i', $res['body'], $m);
    return array_values(array_unique(array_map('trim', $m[1] ?? [])));
}

function agent_analyze_html_basic(string $html): array {
    $title = '';
    if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $title = trim(html_entity_decode(strip_tags($m[1])));
    $desc = '';
    if (preg_match('#<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)#is', $html, $m)) $desc = trim(html_entity_decode($m[1]));
    preg_match_all('#<h1\b[^>]*>(.*?)</h1>#is', $html, $h1m);
    preg_match_all('#<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $jm);
    $jsonErrors = 0;
    foreach ($jm[1] ?? [] as $block) { json_decode(html_entity_decode(trim($block)), true); if (json_last_error() !== JSON_ERROR_NONE) $jsonErrors++; }
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
    $words = $text === '' ? 0 : str_word_count($text);
    return ['title'=>$title, 'title_len'=>mb_strlen($title), 'description'=>$desc, 'desc_len'=>mb_strlen($desc), 'h1_count'=>count($h1m[1] ?? []), 'jsonld_blocks'=>count($jm[1] ?? []), 'jsonld_errors'=>$jsonErrors, 'words'=>$words];
}

function agent_run_seo_audit(array $input=[]): array {
    $domain = rtrim($input['domain'] ?? SITE_DOMAIN, '/');
    $limit = max(5, min(120, (int)($input['limit'] ?? 40)));
    $urls = agent_extract_sitemap_urls($domain . '/sitemap.xml');
    $urls = array_slice($urls, 0, $limit);
    $findings = [];
    foreach ($urls as $url) {
        $res = agent_fetch_url($url);
        $item = ['url'=>$url, 'status'=>$res['status']];
        if ($res['ok'] && $res['status'] < 400) $item += agent_analyze_html_basic($res['body']);
        else $item['error'] = $res['error'] ?: 'HTTP '.$res['status'];
        $issues = [];
        if (($item['status'] ?? 0) >= 400) $issues[] = 'HTTP error';
        if (($item['title_len'] ?? 0) > 65) $issues[] = 'Title too long';
        if (($item['desc_len'] ?? 0) > 170) $issues[] = 'Meta description too long';
        if (($item['h1_count'] ?? 0) !== 1) $issues[] = 'H1 count '.$item['h1_count'];
        if (($item['jsonld_errors'] ?? 0) > 0) $issues[] = 'Invalid JSON-LD';
        if (($item['words'] ?? 999) < 300) $issues[] = 'Thin content';
        $item['issues'] = $issues;
        $findings[] = $item;
    }
    return ['summary'=>['checked'=>count($findings), 'issue_pages'=>count(array_filter($findings, fn($f)=>!empty($f['issues'])))], 'pages'=>$findings];
}

function agent_run_image_audit(array $input=[]): array {
    $base = realpath(__DIR__ . '/..');
    $folders = ['assets/images', 'assets/images/fleet', 'assets/images/services', 'assets/images/routes', 'assets/images/blog'];
    $rows = [];
    foreach ($folders as $folder) {
        $dir = $base . '/' . $folder;
        if (!is_dir($dir)) continue;
        foreach (glob($dir.'/*.{jpg,jpeg,png,webp,gif}', GLOB_BRACE) ?: [] as $file) {
            $size = round(filesize($file)/1024, 2);
            $dim = @getimagesize($file);
            $warn = [];
            if (str_contains($folder, 'fleet') && $size > 25) $warn[] = 'Fleet image >25KB';
            if (basename($file) === 'logo-icon.png' && $size > 10) $warn[] = 'Logo >10KB';
            if ($size > 160) $warn[] = 'Large image';
            $rows[] = ['path'=>'/'.$folder.'/'.basename($file), 'kb'=>$size, 'width'=>$dim[0] ?? null, 'height'=>$dim[1] ?? null, 'issues'=>$warn];
        }
    }
    return ['count'=>count($rows), 'images'=>$rows, 'issue_count'=>count(array_filter($rows, fn($r)=>!empty($r['issues'])))];
}

function agent_run_booking_summary(array $input=[]): array {
    $pdo = agent_db();
    if (!$pdo) return ['error'=>'DB unavailable'];
    $summary = [];
    foreach (['new','confirmed','completed','cancelled'] as $s) {
        try { $st=$pdo->prepare('SELECT COUNT(*) FROM bookings WHERE status=?'); $st->execute([$s]); $summary[$s]=(int)$st->fetchColumn(); } catch(Throwable $e) { $summary[$s]=0; }
    }
    try { $recent=$pdo->query('SELECT id, customer_name, phone, pickup, drop_location, trip_date, trip_time, vehicle, status, created_at FROM bookings ORDER BY id DESC LIMIT 10')->fetchAll(); } catch(Throwable $e) { $recent=[]; }
    return ['summary'=>$summary, 'recent'=>$recent];
}

function agent_run_content_draft(array $input=[]): array {
    $topic = trim($input['topic'] ?? 'Dehradun taxi guide');
    $keyword = trim($input['keyword'] ?? $topic);
    $type = trim($input['draft_type'] ?? 'blog');
    $system = 'You are an expert SEO, GEO and AEO content strategist for Anaya Cab Service, a taxi service in Dehradun. Write accurate, helpful, non-fake content. Do not claim exact fares unless approximate. Use Hinglish-light but professional English.';
    $prompt = "Create a {$type} draft for topic: {$topic}\nFocus keyword: {$keyword}\nReturn in this exact structure:\nTITLE:\nMETA_TITLE:\nMETA_DESCRIPTION:\nSLUG:\nFOCUS_KEYWORD:\nGEO_QUICK_ANSWER:\nCONTENT:\nFAQS:\nUse 700-1000 words if blog, include practical taxi booking tips, local route details, FAQs.";
    $res = agent_gemini_call($prompt, $system);
    if (!$res['ok']) return $res;
    return ['draft_text'=>$res['text']];
}

function agent_execute_task(int $taskId): array {
    $pdo = agent_db();
    if (!$pdo) return ['ok'=>false, 'error'=>'DB unavailable'];
    $stmt = $pdo->prepare('SELECT * FROM agent_tasks WHERE id=?');
    $stmt->execute([$taskId]);
    $task = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$task) return ['ok'=>false, 'error'=>'Task not found'];
    $pdo->prepare("UPDATE agent_tasks SET status='running', updated_at=NOW() WHERE id=?")->execute([$taskId]);
    $input = json_decode($task['input_json'] ?: '{}', true) ?: [];
    try {
        if ($task['task_type'] === 'seo_audit') $output = agent_run_seo_audit($input);
        elseif ($task['task_type'] === 'image_audit') $output = agent_run_image_audit($input);
        elseif ($task['task_type'] === 'booking_summary') $output = agent_run_booking_summary($input);
        elseif ($task['task_type'] === 'content_draft') $output = agent_run_content_draft($input);
        else $output = ['error'=>'Unknown task type: '.$task['task_type']];
        $status = isset($output['error']) && !isset($output['draft_text']) ? 'failed' : 'completed';
        $pdo->prepare("UPDATE agent_tasks SET output_json=?, status=?, completed_at=NOW(), updated_at=NOW(), error_text=? WHERE id=?")
            ->execute([json_encode($output, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), $status, $output['error'] ?? null, $taskId]);
        agent_log($task['agent_name'], 'Task #'.$taskId.' '.$status, $status==='completed'?'info':'error');
        return ['ok'=>$status==='completed', 'output'=>$output];
    } catch (Throwable $e) {
        $pdo->prepare("UPDATE agent_tasks SET status='failed', error_text=?, updated_at=NOW() WHERE id=?")->execute([$e->getMessage(), $taskId]);
        agent_log($task['agent_name'], 'Task #'.$taskId.' failed: '.$e->getMessage(), 'error');
        return ['ok'=>false, 'error'=>$e->getMessage()];
    }
}
?>