<?php
/**
* Anaya Cab Service — Shared Footer
* Production Footer — SEO / UX / Accessibility / Performance safe
* v25: Google Preferred Source include + button band added (footer ke upar, har page)
*/
if (!defined('SITE_NAME')) {
require_once __DIR__ . '/config.php';
}
/* Google Preferred Source helpers (script + button) */
require_once __DIR__ . '/google-preferred-source.php';

/*
|--------------------------------------------------------------------------
| Safe helpers
|--------------------------------------------------------------------------
*/
$__footer_escape = static function ($value): string {
return htmlspecialchars(
(string)$value,
ENT_QUOTES | ENT_SUBSTITUTE,
'UTF-8'
);
};

/*
|--------------------------------------------------------------------------
| Social icons
|--------------------------------------------------------------------------
*/
$__iconmap = [
'fb'       => 'fa-brands fa-facebook-f',
'ig'       => 'fa-brands fa-instagram',
'google'   => 'fa-brands fa-google',
'whatsapp' => 'fa-brands fa-whatsapp',
];
$__socials = [];
if (
defined('SOCIAL_FACEBOOK') &&
trim((string)SOCIAL_FACEBOOK) !== ''
) {
$__socials[] = [
'fb',
(string)SOCIAL_FACEBOOK,
'Anaya Cab on Facebook'
];
}
if (
defined('SOCIAL_INSTAGRAM') &&
trim((string)SOCIAL_INSTAGRAM) !== ''
) {
$__socials[] = [
'ig',
(string)SOCIAL_INSTAGRAM,
'Anaya Cab on Instagram'
];
}
$__gbp = defined('GOOGLE_BUSINESS_PROFILE_URL')
? trim((string)GOOGLE_BUSINESS_PROFILE_URL)
: '';
if ($__gbp !== '') {
$__socials[] = [
'google',
$__gbp,
'Anaya Cab on Google'
];
}
$__socials[] = [
'whatsapp',
'https://wa.me/' . rawurlencode((string)BUSINESS_WHATSAPP) .
'?text=' . rawurlencode('Hi Anaya Cab, I want to book a taxi.'),
'Chat on WhatsApp'
];

/*
|--------------------------------------------------------------------------
| Trust points
|--------------------------------------------------------------------------
*/
$__trust = [
['fa-id-badge',           'Verified drivers'],
['fa-headset',            '24×7 booking'],
['fa-tags',               'Fixed fares'],
['fa-spray-can-sparkles', 'Sanitised AC fleet'],
];

/*
|--------------------------------------------------------------------------
| Coverage cities / destinations
|--------------------------------------------------------------------------
*/
$__cities = [
['Dehradun',            'fa-location-dot'],
['Mussoorie',           'fa-mountain-sun'],
['Rishikesh',           'fa-water'],
['Haridwar',            'fa-om'],
['Jolly Grant Airport', 'fa-plane-departure'],
['Delhi',               'fa-road'],
['Nainital',            'fa-mountain'],
['Chandigarh',          'fa-road'],
['Kedarnath',           'fa-om'],
['Badrinath',           'fa-om'],
['Auli',                'fa-snowflake'],
['Chakrata',            'fa-mountain-sun'],
['Kanatal',             'fa-campground'],
['Jim Corbett',         'fa-tree'],
];

/*
|--------------------------------------------------------------------------
| Quick links
|--------------------------------------------------------------------------
*/
$__quick = [
['About us',        '/about'],
['All services',    '/services'],
['Airport taxi',    '/dehradun-airport-taxi-service'],
['Local taxi',      '/local-taxi-in-dehradun'],
['Outstation taxi', '/outstation-taxi-from-dehradun'],
['Our fleet',       '/fleet'],
['Pricing',         '/pricing'],
['Travel blog',     '/blog/'],
['FAQ',             '/faq'],
['Reviews',         '/reviews'],
['Contact',         '/contact'],
];

/*
|--------------------------------------------------------------------------
| Popular routes
|--------------------------------------------------------------------------
*/
$__routes = [
['Dehradun to Haridwar taxi',  '/dehradun-to-haridwar-taxi'],
['Dehradun to Rishikesh taxi', '/dehradun-to-rishikesh-taxi'],
['Dehradun to Mussoorie taxi', '/dehradun-to-mussoorie-taxi'],
['Dehradun to Delhi taxi',     '/dehradun-to-delhi-taxi'],
['Dehradun to Nainital taxi',  '/dehradun-to-nainital-taxi'],
['Char Dham Yatra taxi',       '/char-dham-yatra-taxi'],
];

/*
|--------------------------------------------------------------------------
| Hyperlocal Areas We Serve in Dehradun
|--------------------------------------------------------------------------
*/
$__localities = [
['Ballupur', '/taxi-service-in-ballupur'],
['Clement Town', '/taxi-service-in-clement-town'],
['Rajpur Road', '/taxi-service-in-rajpur-road'],
['Prem Nagar', '/taxi-service-in-prem-nagar'],
['Jakhan', '/taxi-service-in-jakhan-dehradun'],
['Karanpur', '/taxi-service-in-karanpur-dehradun'],
['Dalanwala', '/taxi-service-in-dalanwala-dehradun'],
['Dharampur', '/taxi-service-in-dharampur-dehradun'],
['GMS Road', '/taxi-service-in-gms-road-dehradun'],
['Hathibarkala', '/taxi-service-in-hathibarkala-dehradun'],
['Indra Nagar', '/taxi-service-in-indra-nagar-dehradun'],
['Kaulagarh', '/taxi-service-in-kaulagarh-dehradun'],
['Patel Nagar', '/taxi-service-in-patel-nagar-dehradun'],
['Race Course', '/taxi-service-in-race-course-dehradun'],
['Sahastradhara', '/taxi-service-in-sahastradhara'],
['Subhash Nagar', '/taxi-service-in-subhash-nagar-dehradun'],
['Vasant Vihar', '/taxi-service-in-vasant-vihar-dehradun'],
['Bajawala', '/taxi-service-in-bajawala-dehradun'],
];

/*
|--------------------------------------------------------------------------
| Legal links
|--------------------------------------------------------------------------
*/
$__legal = [
['Privacy Policy',       '/privacy-policy'],
['Terms & Conditions',   '/terms-conditions'],
['Cancellation Policy',  '/cancellation-policy'],
['Sitemap',              '/sitemap.xml'],
];

/*
|--------------------------------------------------------------------------
| Contact URLs
|--------------------------------------------------------------------------
*/
$__phone_tel = defined('BUSINESS_PHONE_TEL')
? (string)BUSINESS_PHONE_TEL
: '';
$__whatsapp_number = defined('BUSINESS_WHATSAPP')
? (string)BUSINESS_WHATSAPP
: '';
$__whatsapp_url = 'https://wa.me/' .
rawurlencode($__whatsapp_number) .
'?text=' .
rawurlencode('Hi Anaya Cab, I want to book a taxi.');
?>
<?php gps_render_button(); ?>
<footer class="ft" role="contentinfo">
<span class="ft-topline" aria-hidden="true"></span>
<div class="ft-amb" aria-hidden="true">
<svg
viewBox="0 0 1200 460"
preserveAspectRatio="xMidYMid slice"
fill="none"
role="presentation"
>
<path
class="ft-route"
d="M-50 360 C 220 360, 300 150, 520 150 S 940 360, 1260 210"
/>
<path
class="ft-route"
d="M-50 430 C 260 430, 380 280, 660 300 S 1020 430, 1260 350"
/>
<path
class="ft-comet"
pathLength="1000"
d="M-50 360 C 220 360, 300 150, 520 150 S 940 360, 1260 210"
/>
<path
class="ft-comet b"
pathLength="1000"
d="M-50 430 C 260 430, 380 280, 660 300 S 1020 430, 1260 350"
/>
</svg>
</div>
<div class="ft-in">
<div
class="ft-trust"
aria-label="Why travellers choose Anaya Cab"
>
<?php foreach ($__trust as $__t): ?>
<div class="ft-ti ft-reveal">
<i
class="fa-solid <?php echo $__footer_escape($__t[0]); ?>"
aria-hidden="true"
></i>
<span><?php echo $__footer_escape($__t[1]); ?></span>
</div>
<?php endforeach; ?>
</div>
<div
class="ft-ticker"
aria-label="Cities and routes we cover"
>
<div class="ft-track">
<?php for ($__r = 0; $__r < 2; $__r++): ?>
<?php foreach ($__cities as $__c): ?>
<span class="ft-city">
<i
class="fa-solid <?php echo $__footer_escape($__c[1]); ?>"
aria-hidden="true"
></i>
<span><?php echo $__footer_escape($__c[0]); ?></span>
</span>
<?php endforeach; ?>
<?php endfor; ?>
</div>
</div>
<div class="ft-grid">
<div class="ft-reveal">
<a
class="ft-brand"
href="/"
aria-label="<?php echo $__footer_escape(SITE_NAME); ?> home"
>
<img
src="/assets/images/logo-icon.png"
alt="<?php echo $__footer_escape(SITE_NAME); ?> logo"
width="38"
height="44"
loading="lazy"
decoding="async"
onerror="this.style.display='none'"
>
<span class="ft-bname">
<b>Anaya</b>
<small>Cab Service</small>
</span>
</a>
<p class="ft-blurb">
<strong>Anaya Cab Service</strong> runs verified,
air-conditioned taxis across Dehradun &amp; Uttarakhand —
local rides, Jolly Grant Airport transfers, outstation
cabs and the Char Dham Yatra, with fixed fares and
24×7 booking.
</p>
<div class="ft-soc" aria-label="Social media">
<?php foreach ($__socials as $__s): ?>
<?php
$__k  = $__s[0];
$__ic = $__iconmap[$__k] ?? 'fa-solid fa-link';
?>
<a
data-k="<?php echo $__footer_escape($__k); ?>"
href="<?php echo $__footer_escape($__s[1]); ?>"
target="_blank"
rel="noopener noreferrer"
aria-label="<?php echo $__footer_escape($__s[2]); ?>"
>
<i
class="<?php echo $__footer_escape($__ic); ?>"
aria-hidden="true"
></i>
</a>
<?php endforeach; ?>
</div>
</div>
<div class="ft-reveal">
<h4>Quick links</h4>
<nav
class="ft-links"
aria-label="Footer quick links"
>
<?php foreach ($__quick as $__l): ?>
<a
class="ft-link"
href="<?php echo $__footer_escape($__l[1]); ?>"
>
<span><?php echo $__footer_escape($__l[0]); ?></span>
<i
class="fa-solid fa-arrow-right ft-arr"
aria-hidden="true"
></i>
</a>
<?php endforeach; ?>
<a
class="ft-link"
href="https://www.lulu.com/shop/anaya-cab-service/the-essential-dehradun-taxi-travel-guide-2026/ebook/product-84mvyrr.html"
target="_blank"
rel="noopener"
style="color:#00c2ff;font-weight:600;"
>
<span>📚 FREE Travel Guide</span>
<i
class="fa-solid fa-arrow-up-right-from-square ft-arr"
style="opacity:1;transform:none;"
aria-hidden="true"
></i>
</a>
</nav>
</div>
<div class="ft-reveal">
<h4>Popular routes</h4>
<nav
class="ft-links"
aria-label="Footer popular routes"
>
<?php foreach ($__routes as $__l): ?>
<a
class="ft-link"
href="<?php echo $__footer_escape($__l[1]); ?>"
>
<span><?php echo $__footer_escape($__l[0]); ?></span>
<i
class="fa-solid fa-arrow-right ft-arr"
aria-hidden="true"
></i>
</a>
<?php endforeach; ?>
</nav>
</div>
<div class="ft-reveal">
<h4>Get in touch</h4>
<div class="ft-cbtns">
<a
class="ft-cbtn ft-call"
href="tel:<?php echo $__footer_escape($__phone_tel); ?>"
style="color:#fff !important;-webkit-text-fill-color:#fff !important"
>
<i
class="fa-solid fa-phone"
aria-hidden="true"
style="color:#fff !important;-webkit-text-fill-color:#fff !important"
></i>
<span>
<?php echo $__footer_escape(BUSINESS_PHONE); ?>
</span>
</a>
<a
class="ft-cbtn ft-wa"
href="<?php echo $__footer_escape($__whatsapp_url); ?>"
target="_blank"
rel="noopener noreferrer"
style="color:#04260f !important;-webkit-text-fill-color:#04260f !important"
>
<i
class="fa-brands fa-whatsapp"
aria-hidden="true"
style="color:#04260f !important;-webkit-text-fill-color:#04260f !important"
></i>
<span>WhatsApp us</span>
</a>
</div>
<div class="ft-cline">
<i
class="fa-regular fa-envelope"
aria-hidden="true"
></i>
<a
href="mailto:<?php echo $__footer_escape(BUSINESS_EMAIL); ?>"
>
<?php echo $__footer_escape(BUSINESS_EMAIL); ?>
</a>
</div>
<div class="ft-cline">
<i
class="fa-solid fa-location-dot"
aria-hidden="true"
></i>
<address
style="margin:0;font-style:normal"
>
<?php echo $__footer_escape(BUSINESS_FULL_ADDRESS); ?>
</address>
</div>
<div class="ft-cline">
<i
class="fa-regular fa-clock"
aria-hidden="true"
></i>
<span class="ft-hours">
Open 24 hours · 7 days a week
</span>
</div>
</div>
</div>
<div class="ft-areas" style="padding: 24px 0 16px; border-top: 1px solid rgba(255,255,255,0.08); margin-top: 24px;">
<div style="font-size: 0.85rem; font-weight: 700; color: rgba(255,255,255,0.9); margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
<i class="fa-solid fa-location-dot" style="color: #00c2ff;"></i> Areas We Serve in Dehradun:
</div>
<div style="display: flex; flex-wrap: wrap; gap: 8px 14px; font-size: 0.78rem;">
<?php foreach ($__localities as $__loc): ?>
<a href="<?php echo $__footer_escape($__loc[1]); ?>" style="color: rgba(255,255,255,0.65); text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#00c2ff'" onmouseout="this.style.color='rgba(255,255,255,0.65)'">
Taxi in <?php echo $__footer_escape($__loc[0]); ?>
</a>
<?php endforeach; ?>
</div>
</div>
<nav
class="ft-legal"
aria-label="Legal and policies"
>
<?php foreach ($__legal as $__i => $__l): ?>
<?php if ($__i > 0): ?>
<span aria-hidden="true">·</span>
<?php endif; ?>
<a
href="<?php echo $__footer_escape($__l[1]); ?>"
>
<?php echo $__footer_escape($__l[0]); ?>
</a>
<?php endforeach; ?>
<span aria-hidden="true">·</span>
<a
href="https://www.lulu.com/shop/anaya-cab-service/the-essential-dehradun-taxi-travel-guide-2026/ebook/product-84mvyrr.html"
target="_blank"
rel="noopener"
style="color:#00c2ff;"
>
📚 FREE Dehradun Taxi &amp; Travel Guide
</a>
</nav>
</div>
<div class="ft-bar">
<div class="ft-in">
<div class="ft-copy">
© <?php echo $__footer_escape(CURRENT_YEAR); ?>
<b><?php echo $__footer_escape(SITE_NAME); ?></b>
· www.taxidehradun.com · All rights reserved.
</div>
<div class="ft-made">
<i
class="fa-solid fa-mountain-sun"
aria-hidden="true"
></i>
<span>
Trusted taxi service in Dehradun, Uttarakhand
</span>
</div>
</div>
</div>
</footer>
<button
class="ft-top"
id="ftTop"
type="button"
aria-label="Back to top"
>
<i
class="fa-solid fa-arrow-up"
aria-hidden="true"
></i>
</button>
<nav
class="action-bar"
aria-label="Quick actions"
>
<span
class="ab-sheen"
aria-hidden="true"
></span>
<a
href="tel:<?php echo $__footer_escape($__phone_tel); ?>"
aria-label="Call Anaya Cab"
>
<i
class="fa-solid fa-phone"
aria-hidden="true"
></i>
<span>Call</span>
</a>
<a
href="/#booking"
class="action-book"
aria-label="Book a taxi"
>
<i
class="fa-solid fa-taxi"
aria-hidden="true"
></i>
<span>Book now</span>
</a>
<a
href="<?php echo $__footer_escape($__whatsapp_url); ?>"
target="_blank"
rel="noopener noreferrer"
aria-label="Chat on WhatsApp"
>
<i
class="fa-brands fa-whatsapp"
aria-hidden="true"
></i>
<span>WhatsApp</span>
</a>
</nav>
<div
class="toast-msg"
id="toast"
role="status"
aria-live="polite"
></div>
<style>
.ft{position:relative;overflow:hidden;background:radial-gradient(120% 90% at 12% -10%,#13294f 0%,transparent 46%),linear-gradient(180deg,#0a1430 0%,#0a1228 60%,#070d1f 100%);color:#c4d2e8;font-family:'Plus Jakarta Sans',system-ui,sans-serif;padding:0;margin-top:0}
.ft::before{content:"";position:absolute;top:-120px;left:-80px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.32),transparent 68%);filter:blur(8px);opacity:.55;pointer-events:none;animation:ftpulse 9s ease-in-out infinite}
.ft::after{content:"";position:absolute;bottom:-140px;right:-60px;width:360px;height:360px;border-radius:50%;background:radial-gradient(circle,rgba(37,211,102,.16),transparent 70%);pointer-events:none;animation:ftpulse 11s ease-in-out infinite reverse}
@keyframes ftpulse{0%,100%{transform:scale(1);opacity:.5}50%{transform:scale(1.12);opacity:.7}}
.ft-topline{position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#0057ff,#25d366,#7fe3ff,#0057ff);background-size:240% 100%;animation:ftslide 7s linear infinite;z-index:2}
@keyframes ftslide{0%{background-position:0 0}100%{background-position:240% 0}}
.ft .ft-amb{position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:0}
.ft .ft-amb svg{position:absolute;inset:0;width:100%;height:100%}
.ft-route{stroke:rgba(120,160,255,.13);stroke-width:2;fill:none;stroke-dasharray:5 9}
.ft-comet{stroke:#38d6f0;stroke-width:2.6;fill:none;stroke-linecap:round;stroke-dasharray:90 1000;opacity:.55;filter:drop-shadow(0 0 6px rgba(56,214,240,.6));animation:ftcomet 7s linear infinite}
.ft-comet.b{stroke:#25d366;opacity:.38;animation-duration:9.5s;animation-delay:-3s}
@keyframes ftcomet{from{stroke-dashoffset:1090}to{stroke-dashoffset:0}}
.ft .ft-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.ft .ft-trust{display:flex;flex-wrap:wrap;justify-content:center;gap:8px 0;padding:22px 0;border-bottom:1px solid rgba(255,255,255,.08)}
.ft .ft-ti{flex:1 1 180px;display:flex;align-items:center;justify-content:center;gap:10px;padding:8px 18px;color:#dbe6f7;font-weight:600;font-size:.9rem;position:relative;transition:color .25s}
.ft .ft-ti:not(:last-child)::after{content:"";position:absolute;right:0;top:50%;transform:translateY(-50%);width:1px;height:22px;background:rgba(255,255,255,.12)}
.ft .ft-ti i{color:#5b9bff;font-size:1.05rem;transition:transform .3s,color .3s}
.ft .ft-ti:hover{color:#fff}
.ft .ft-ti:hover i{color:#25d366;transform:scale(1.18) rotate(-6deg)}
.ft .ft-ticker{position:relative;overflow:hidden;border-bottom:1px solid rgba(255,255,255,.08);padding:13px 0;-webkit-mask-image:linear-gradient(90deg,transparent,#000 7%,#000 93%,transparent);mask-image:linear-gradient(90deg,transparent,#000 7%,#000 93%,transparent)}
.ft .ft-track{display:flex;gap:36px;width:max-content;white-space:nowrap;animation:fttick 32s linear infinite}
.ft .ft-ticker:hover .ft-track{animation-play-state:paused}
.ft .ft-city{display:inline-flex;align-items:center;gap:8px;font-size:.82rem;font-weight:600;color:#8aa0c2}
.ft .ft-city i{color:#5b9bff;font-size:.72rem}
@keyframes fttick{from{transform:translateX(0)}to{transform:translateX(-50%)}}
.ft .ft-grid{display:grid;grid-template-columns:1.5fr 1fr 1fr 1.15fr;gap:38px;padding:48px 0 36px}
.ft .ft-reveal{opacity:0;transform:translateY(22px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.ft .ft-reveal.in{opacity:1;transform:none}
.ft .ft-brand{display:flex;align-items:center;gap:10px;text-decoration:none;margin-bottom:16px}
.ft .ft-brand img{height:42px;width:auto;display:block;object-fit:contain;filter:drop-shadow(0 6px 14px rgba(0,87,255,.4));animation:ftfloat 5s ease-in-out infinite}
@keyframes ftfloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
.ft .ft-bname{display:flex;flex-direction:column;line-height:1}
.ft .ft-bname b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:#fff;font-size:1.2rem;letter-spacing:.04em;text-transform:uppercase}
.ft .ft-bname small{font-size:.52rem;letter-spacing:.18em;color:#5b9bff;font-weight:700;text-transform:uppercase;margin-top:3px}
.ft .ft-blurb{color:#9fb2d0;font-size:.9rem;line-height:1.65;max-width:34ch;margin:0 0 18px}
.ft .ft-blurb strong{color:#dbe6f7;font-weight:700}
.ft .ft-soc{display:flex;flex-wrap:wrap;gap:10px}
.ft .ft-soc a{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#cfe0ff;font-size:.95rem;transition:transform .25s,background .25s,color .25s,box-shadow .25s;text-decoration:none}
.ft .ft-soc a:hover{transform:translateY(-4px);color:#fff;box-shadow:0 12px 24px -10px rgba(0,87,255,.7)}
.ft .ft-soc a[data-k="fb"]:hover{background:#1877f2;border-color:#1877f2}
.ft .ft-soc a[data-k="ig"]:hover{background:linear-gradient(135deg,#f58529,#dd2a7b,#8134af);border-color:transparent}
.ft .ft-soc a[data-k="google"]:hover{background:#ea4335;border-color:#ea4335}
.ft .ft-soc a[data-k="whatsapp"]:hover{background:#25d366;border-color:#25d366}
.ft h4{font-family:'Sora','Poppins',sans-serif;font-size:.72rem;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#fff;margin:0 0 16px;display:flex;align-items:center;gap:8px}
.ft h4::before{content:"";width:18px;height:2px;border-radius:2px;background:linear-gradient(90deg,#0057ff,#25d366)}
.ft .ft-links{display:flex;flex-direction:column;gap:2px}
.ft .ft-link{display:flex;align-items:center;gap:8px;padding:7px 0;color:#a9bcdb;font-size:.9rem;font-weight:500;text-decoration:none;transition:color .2s}
.ft .ft-link span{transition:transform .25s}
.ft .ft-arr{font-size:.62rem;color:#5b9bff;opacity:0;transform:translateX(-6px);transition:opacity .25s,transform .25s}
.ft .ft-link:hover{color:#fff}
.ft .ft-link:hover span{transform:translateX(4px)}
.ft .ft-link:hover .ft-arr{opacity:1;transform:translateX(0)}
.ft .ft-cbtns{display:grid;gap:10px;margin-bottom:16px}
.ft .ft-cbtn{display:flex;align-items:center;gap:10px;justify-content:center;padding:11px 14px;border-radius:12px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.88rem;text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.ft .ft-cbtn i{font-size:1rem}
.ft .ft-call{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);color:#fff !important;-webkit-text-fill-color:#fff !important}
.ft .ft-call:hover{transform:translateY(-2px);border-color:#5b9bff;box-shadow:0 12px 24px -12px rgba(0,87,255,.6)}
.ft .ft-wa{position:relative;overflow:hidden;background:linear-gradient(135deg,#12b76a,#25d366);color:#04260f !important;-webkit-text-fill-color:#04260f !important;box-shadow:0 10px 22px -10px rgba(37,211,102,.7)}
.ft .ft-wa::after{content:"";position:absolute;top:0;left:-60%;width:38%;height:100%;background:linear-gradient(115deg,transparent,rgba(255,255,255,.5),transparent);transform:skewX(-20deg);animation:ftshine 3.6s ease-in-out infinite;pointer-events:none}
@keyframes ftshine{0%{left:-60%}55%,100%{left:130%}}
.ft .ft-wa:hover{transform:translateY(-2px);filter:brightness(1.06)}
.ft .ft-cline{display:flex;gap:10px;align-items:flex-start;color:#9fb2d0;font-size:.86rem;line-height:1.5;margin-bottom:10px}
.ft .ft-cline i{color:#5b9bff;margin-top:3px;width:16px;text-align:center;flex:none}
.ft .ft-cline a{color:#cfe0ff;text-decoration:none;font-weight:600;overflow-wrap:anywhere}
.ft .ft-cline a:hover{color:#fff}
.ft .ft-hours{color:#7fe3ac;font-weight:600;display:inline-flex;align-items:center;gap:7px}
.ft .ft-hours::before{content:"";width:7px;height:7px;border-radius:50%;background:#25d366;box-shadow:0 0 0 0 rgba(37,211,102,.6);animation:ftlive 1.8s infinite;flex:none}
@keyframes ftlive{70%{box-shadow:0 0 0 7px rgba(37,211,102,0)}100%{box-shadow:0 0 0 0 rgba(37,211,102,0)}}
.ft .ft-legal{display:flex;flex-wrap:wrap;gap:8px 22px;justify-content:center;padding:20px 0;border-top:1px solid rgba(255,255,255,.08)}
.ft .ft-legal a{color:#8aa0c2;font-size:.8rem;text-decoration:none;transition:color .2s}
.ft .ft-legal a:hover{color:#fff}
.ft .ft-legal span{color:rgba(255,255,255,.18)}
.ft .ft-bar{border-top:1px solid rgba(255,255,255,.06);padding:18px 0}
.ft .ft-bar .ft-in{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.ft .ft-copy{color:#7e93b6;font-size:.8rem}
.ft .ft-copy b{color:#aebfdc;font-weight:700}
.ft .ft-made{color:#5d7299;font-size:.78rem;display:flex;align-items:center;gap:6px}
.ft .ft-made i{color:#25d366}
.ft-top{position:fixed;right:16px;bottom:82px;z-index:1200;width:46px;height:46px;border-radius:14px;border:1px solid rgba(255,255,255,.16);background:linear-gradient(135deg,#0057ff,#3b82f6);color:#fff;display:grid;place-items:center;font-size:1rem;cursor:pointer;box-shadow:0 14px 30px -10px rgba(0,87,255,.7);opacity:0;visibility:hidden;transform:translateY(12px);transition:opacity .3s,transform .3s,visibility .3s,filter .2s}
.ft-top.show{opacity:1;visibility:visible;transform:none}
.ft-top:hover{filter:brightness(1.1);transform:translateY(-3px)}
.action-bar{position:fixed !important;left:50% !important;right:auto !important;transform:translateX(-50%);bottom:calc(12px + env(safe-area-inset-bottom,0px)) !important;width:min(94vw,460px) !important;max-width:460px !important;display:flex !important;align-items:center;gap:6px;padding:7px !important;border-radius:999px !important;background:linear-gradient(180deg,rgba(255,255,255,.82),rgba(255,255,255,.55)) !important;-webkit-backdrop-filter:blur(30px) saturate(200%) !important;backdrop-filter:blur(30px) saturate(200%) !important;border:1px solid rgba(255,255,255,.6) !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.92),inset 0 -1px 1px rgba(255,255,255,.3),0 18px 44px -16px rgba(9,32,84,.5),0 4px 14px rgba(9,32,84,.18) !important;isolation:isolate}
.action-bar .ab-sheen{position:absolute;inset:0;border-radius:999px;overflow:hidden;pointer-events:none;z-index:0}
.action-bar .ab-sheen::after{content:"";position:absolute;top:-60%;left:-60%;width:42%;height:220%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.6),transparent);transform:skewX(-18deg);animation:abdock 6.5s ease-in-out infinite}
@keyframes abdock{0%,16%{left:-60%}52%,100%{left:135%}}
.action-bar a{position:relative;z-index:1;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:9px 4px;min-height:46px;border-radius:999px !important;background:transparent !important;border:0 !important;box-shadow:none !important;color:#475569 !important;font-family:'Sora','Poppins',sans-serif;font-weight:700;text-decoration:none;transition:color .2s,transform .15s}
.action-bar a i{font-size:1.12rem;transition:transform .25s}
.action-bar a span{font-size:.62rem;letter-spacing:.02em}
.action-bar a:first-of-type i{color:#0057ff !important}
.action-bar a[href*="wa.me"] i{color:#25d366 !important}
.action-bar a:not(.action-book):active{transform:scale(.93)}
.action-bar .action-book{flex:1.25;flex-direction:row;gap:8px;padding:11px 12px;transform:none !important;background:linear-gradient(135deg,#12b76a,#25d366) !important;color:#fff !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 10px 22px -8px rgba(18,183,106,.65) !important;overflow:hidden}
.action-bar .action-book i,.action-bar .action-book span{color:#fff !important}
.action-bar .action-book i{font-size:1.05rem}
.action-bar .action-book span{font-size:.82rem}
.action-bar .action-book:active{transform:scale(.96) !important}
.action-bar .action-book::after{content:"";position:absolute;top:0;left:-60%;width:38%;height:100%;background:linear-gradient(115deg,transparent,rgba(255,255,255,.5),transparent);transform:skewX(-20deg);animation:abshine 3.4s ease-in-out infinite;pointer-events:none}
@keyframes abshine{0%{left:-60%}55%,100%{left:130%}}
@media(min-width:981px){.action-bar{display:none !important}.ft-top{right:26px !important;bottom:26px !important;width:50px !important;height:50px !important;border-radius:16px !important}}
body{padding-bottom:calc(92px + env(safe-area-inset-bottom,0px))}
@media(min-width:981px){body{padding-bottom:0}}
@media(max-width:900px){.ft .ft-grid{grid-template-columns:1fr 1fr;gap:30px 26px}.ft .ft-ti:not(:last-child)::after{display:none}.ft .ft-ti{flex:1 1 50%}}
@media(max-width:560px){.ft .ft-grid{grid-template-columns:1fr;gap:28px;padding:38px 0 30px}.ft .ft-blurb{max-width:none}.ft .ft-bar .ft-in{justify-content:center;text-align:center}.ft .ft-legal{gap:8px 14px}.ft .ft-copy{line-height:1.6}.ft .ft-made{justify-content:center;width:100%;text-align:center}}
@media(prefers-reduced-motion:reduce){.ft::before,.ft::after,.ft-topline,.ft .ft-amb svg,.ft .ft-track,.ft .ft-wa::after,.ft .ft-hours::before,.ft .ft-brand img,.action-bar .ab-sheen::after,.action-bar .action-book::after{animation:none !important}.ft .ft-reveal{opacity:1 !important;transform:none !important;transition:none !important}}
</style>
<script>
(function () {
'use strict';
var reveals = document.querySelectorAll('.ft .ft-reveal');
if ('IntersectionObserver' in window) {
var observer = new IntersectionObserver(
function (entries) {
entries.forEach(function (entry) {
if (entry.isIntersecting) {
entry.target.classList.add('in');
observer.unobserve(entry.target);
}
});
},
{
threshold: 0.12,
rootMargin: '0px 0px -6% 0px'
}
);
reveals.forEach(function (element) {
observer.observe(element);
});
} else {
reveals.forEach(function (element) {
element.classList.add('in');
});
}
var topButton = document.getElementById('ftTop');
if (topButton) {
var updateTopButton = function () {
topButton.classList.toggle(
'show',
window.scrollY > 500
);
};
updateTopButton();
window.addEventListener(
'scroll',
updateTopButton,
{
passive:true
}
);
topButton.addEventListener(
'click',
function () {
if (
window.matchMedia &&
window.matchMedia(
'(prefers-reduced-motion: reduce)'
).matches
) {
window.scrollTo(0, 0);
} else {
window.scrollTo({
top:0,
behavior:'smooth'
});
}
}
);
}
})();
</script>
<script>
(function () {
'use strict';
try {
var KEY = 'anaya_sid';
function getSessionId() {
var stored =
localStorage.getItem(KEY);
var storedTime =
parseInt(
localStorage.getItem(KEY + '_t') || '0',
10
);
var now = Date.now();
if (
!stored ||
now - storedTime > 1800000
) {
stored =
's' +
Math.random()
.toString(36)
.slice(2) +
now.toString(36);
localStorage.setItem(
KEY,
stored
);
}
localStorage.setItem(
KEY + '_t',
String(now)
);
return stored;
}
var sessionId = getSessionId();
function sendTracking(data) {
data.s = sessionId;
data.u =
navigator.userAgent || '';
data.l =
navigator.language || '';
data.sw =
screen.width;
data.sh =
screen.height;
try {
var body =
JSON.stringify(data);
var blob =
new Blob(
[body],
{
type:'text/plain'
}
);
if (
navigator.sendBeacon &&
typeof navigator.sendBeacon === 'function'
) {
navigator.sendBeacon(
'/track',
blob
);
} else {
var xhr =
new XMLHttpRequest();
xhr.open(
'POST',
'/track',
true
);
xhr.setRequestHeader(
'Content-Type',
'text/plain;charset=UTF-8'
);
xhr.send(body);
}
} catch (error) {
}
}
sendTracking({
t:'view',
p:
location.pathname +
location.search,
r:
document.referrer || ''
});
function category(anchor) {
var href =
anchor.getAttribute('href') || '';
if (
href.indexOf('tel:') === 0
) {
return 'phone';
}
if (
href.indexOf('wa.me') > -1 ||
href.indexOf('whatsapp') > -1
) {
return 'whatsapp';
}
if (
href.indexOf('#booking') > -1
) {
return 'book';
}
if (
anchor.hasAttribute('data-track')
) {
return anchor.getAttribute(
'data-track'
);
}
if (
/^https?:/i.test(href) &&
href.indexOf(location.host) === -1
) {
return 'external';
}
if (
href.indexOf('-taxi') > -1
) {
return 'route';
}
return 'link';
}
document.addEventListener(
'click',
function (event) {
var anchor =
event.target.closest(
'a,button[data-track]'
);
if (!anchor) {
return;
}
var href =
anchor.getAttribute('href') || '';
if (
!href ||
href === '#'
) {
return;
}
var label =
(
anchor.getAttribute(
'data-track-label'
) ||
anchor.textContent ||
anchor.getAttribute(
'aria-label'
) ||
href
)
.trim()
.slice(0, 80);
sendTracking({
t:'click',
cat:category(anchor),
label:label,
href:href.slice(0, 300),
p:location.pathname
});
},
true
);
} catch (error) {
}
})();
</script>
<script
src="/assets/js/theme.js?v=<?php echo $__footer_escape((string)SITE_VERSION); ?>-perf2"
defer
></script>
<script
src="/assets/js/hero-slider.js?v=<?php echo $__footer_escape((string)SITE_VERSION); ?>-hero2"
defer
></script>
<!-- OFX4-START -->
<style>.ofx4{max-width:1200px;margin:30px auto 10px;padding:0 20px}.ofx4 summary{cursor:pointer;font-family:Sora,sans-serif;font-weight:700;color:#0057FF;font-size:.95rem;padding:10px 0}.ofx4 h4{font-size:.78rem;color:#5B6B8C;margin:14px 0 8px;text-transform:uppercase;letter-spacing:.06em}.ofx4 .g{display:flex;flex-wrap:wrap;gap:7px}.ofx4 a{border:1px solid #E3EAF8;background:#F5F8FF;color:#0A1633;border-radius:999px;padding:5px 12px;font-size:.75rem;text-decoration:none;font-weight:600}.ofx4 a:hover{border-color:#0057FF;color:#0057FF}</style>
<details class="ofx4"><summary>🗺️ Browse All 153 Routes & Services — Fixed Fares, 24x7</summary><h4>🛫 Jolly Grant Airport Routes</h4><div class="g"><a href="/dehradun-airport-taxi-service">Dehradun Airport Taxi Service</a><a href="/jolly-grant-airport-to-badrinath-taxi">Jolly Grant Airport To Badrinath Taxi</a><a href="/jolly-grant-airport-to-chandigarh-taxi">Jolly Grant Airport To Chandigarh Taxi</a><a href="/jolly-grant-airport-to-delhi-taxi">Jolly Grant Airport To Delhi Taxi</a><a href="/jolly-grant-airport-to-haridwar-taxi">Jolly Grant Airport To Haridwar Taxi</a><a href="/jolly-grant-airport-to-jim-corbett-taxi">Jolly Grant Airport To Jim Corbett Taxi</a><a href="/jolly-grant-airport-to-kedarnath-taxi">Jolly Grant Airport To Kedarnath Taxi</a><a href="/jolly-grant-airport-to-mussoorie-taxi">Jolly Grant Airport To Mussoorie Taxi</a><a href="/jolly-grant-airport-to-nainital-taxi">Jolly Grant Airport To Nainital Taxi</a><a href="/jolly-grant-airport-to-rishikesh-taxi">Jolly Grant Airport To Rishikesh Taxi</a><a href="/jolly-grant-airport-to-shimla-taxi">Jolly Grant Airport To Shimla Taxi</a></div><h4>📍 Dehradun Locality Services</h4><div class="g"><a href="/taxi-service-in-bajawala-dehradun">Taxi Service In Bajawala Dehradun</a><a href="/taxi-service-in-ballupur">Taxi Service In Ballupur</a><a href="/taxi-service-in-clement-town">Taxi Service In Clement Town</a><a href="/taxi-service-in-dalanwala-dehradun">Taxi Service In Dalanwala Dehradun</a><a href="/taxi-service-in-dharampur-dehradun">Taxi Service In Dharampur Dehradun</a><a href="/taxi-service-in-gms-road-dehradun">Taxi Service In Gms Road Dehradun</a><a href="/taxi-service-in-hathibarkala-dehradun">Taxi Service In Hathibarkala Dehradun</a><a href="/taxi-service-in-indra-nagar-dehradun">Taxi Service In Indra Nagar Dehradun</a><a href="/taxi-service-in-jakhan-dehradun">Taxi Service In Jakhan Dehradun</a><a href="/taxi-service-in-karanpur-dehradun">Taxi Service In Karanpur Dehradun</a><a href="/taxi-service-in-kaulagarh-dehradun">Taxi Service In Kaulagarh Dehradun</a><a href="/taxi-service-in-patel-nagar-dehradun">Taxi Service In Patel Nagar Dehradun</a><a href="/taxi-service-in-prem-nagar">Taxi Service In Prem Nagar</a><a href="/taxi-service-in-race-course-dehradun">Taxi Service In Race Course Dehradun</a><a href="/taxi-service-in-rajpur-road">Taxi Service In Rajpur Road</a><a href="/taxi-service-in-sahastradhara">Taxi Service In Sahastradhara</a><a href="/taxi-service-in-subhash-nagar">Taxi Service In Subhash Nagar</a><a href="/taxi-service-in-vasant-vihar-dehradun">Taxi Service In Vasant Vihar Dehradun</a></div><h4>🛣️ Outstation & Yatra Routes</h4><div class="g"><a href="/dehradun-to-agra-taxi">Dehradun To Agra Taxi</a><a href="/dehradun-to-almora-taxi">Dehradun To Almora Taxi</a><a href="/dehradun-to-amritsar-taxi">Dehradun To Amritsar Taxi</a><a href="/dehradun-to-auli-taxi">Dehradun To Auli Taxi</a><a href="/dehradun-to-badrinath-taxi">Dehradun To Badrinath Taxi</a><a href="/dehradun-to-bareilly-taxi">Dehradun To Bareilly Taxi</a><a href="/dehradun-to-bhimtal-taxi">Dehradun To Bhimtal Taxi</a><a href="/dehradun-to-binsar-taxi">Dehradun To Binsar Taxi</a><a href="/dehradun-to-chail-taxi">Dehradun To Chail Taxi</a><a href="/dehradun-to-chakrata-taxi">Dehradun To Chakrata Taxi</a><a href="/dehradun-to-chandigarh-taxi">Dehradun To Chandigarh Taxi</a><a href="/dehradun-to-chopta-taxi">Dehradun To Chopta Taxi</a><a href="/dehradun-to-dalhousie-taxi">Dehradun To Dalhousie Taxi</a><a href="/dehradun-to-delhi-taxi">Dehradun To Delhi Taxi</a><a href="/dehradun-to-devprayag-taxi">Dehradun To Devprayag Taxi</a><a href="/dehradun-to-dhanaulti-taxi">Dehradun To Dhanaulti Taxi</a><a href="/dehradun-to-dharamshala-taxi">Dehradun To Dharamshala Taxi</a><a href="/dehradun-to-faridabad-taxi">Dehradun To Faridabad Taxi</a><a href="/dehradun-to-gangotri-taxi">Dehradun To Gangotri Taxi</a><a href="/dehradun-to-ghaziabad-taxi">Dehradun To Ghaziabad Taxi</a><a href="/dehradun-to-govindghat-taxi">Dehradun To Govindghat Taxi</a><a href="/dehradun-to-guptkashi-taxi">Dehradun To Guptkashi Taxi</a><a href="/dehradun-to-gurgaon-taxi">Dehradun To Gurgaon Taxi</a><a href="/dehradun-to-haldwani-taxi">Dehradun To Haldwani Taxi</a><a href="/dehradun-to-haridwar-taxi">Dehradun To Haridwar Taxi</a><a href="/dehradun-to-hemkund-sahib-taxi">Dehradun To Hemkund Sahib Taxi</a><a href="/dehradun-to-jaipur-taxi">Dehradun To Jaipur Taxi</a><a href="/dehradun-to-jalandhar-taxi">Dehradun To Jalandhar Taxi</a><a href="/dehradun-to-jim-corbett-taxi">Dehradun To Jim Corbett Taxi</a><a href="/dehradun-to-kainchi-dham-taxi">Dehradun To Kainchi Dham Taxi</a><a href="/dehradun-to-kalka-taxi">Dehradun To Kalka Taxi</a><a href="/dehradun-to-kanatal-taxi">Dehradun To Kanatal Taxi</a><a href="/dehradun-to-karnaprayag-taxi">Dehradun To Karnaprayag Taxi</a><a href="/dehradun-to-kasauli-taxi">Dehradun To Kasauli Taxi</a><a href="/dehradun-to-kasol-taxi">Dehradun To Kasol Taxi</a><a href="/dehradun-to-kausani-taxi">Dehradun To Kausani Taxi</a><a href="/dehradun-to-kedarnath-taxi">Dehradun To Kedarnath Taxi</a><a href="/dehradun-to-kufri-taxi">Dehradun To Kufri Taxi</a><a href="/dehradun-to-kullu-taxi">Dehradun To Kullu Taxi</a><a href="/dehradun-to-lansdowne-taxi">Dehradun To Lansdowne Taxi</a><a href="/dehradun-to-ludhiana-taxi">Dehradun To Ludhiana Taxi</a><a href="/dehradun-to-manali-taxi">Dehradun To Manali Taxi</a><a href="/dehradun-to-mandi-taxi">Dehradun To Mandi Taxi</a><a href="/dehradun-to-mathura-taxi">Dehradun To Mathura Taxi</a><a href="/dehradun-to-meerut-taxi">Dehradun To Meerut Taxi</a><a href="/dehradun-to-mohali-taxi">Dehradun To Mohali Taxi</a><a href="/dehradun-to-mukteshwar-taxi">Dehradun To Mukteshwar Taxi</a><a href="/dehradun-to-munsiyari-taxi">Dehradun To Munsiyari Taxi</a><a href="/dehradun-to-mussoorie-taxi">Dehradun To Mussoorie Taxi</a><a href="/dehradun-to-nainital-taxi">Dehradun To Nainital Taxi</a><a href="/dehradun-to-naukuchiatal-taxi">Dehradun To Naukuchiatal Taxi</a><a href="/dehradun-to-noida-taxi">Dehradun To Noida Taxi</a><a href="/dehradun-to-panchkula-taxi">Dehradun To Panchkula Taxi</a><a href="/dehradun-to-patiala-taxi">Dehradun To Patiala Taxi</a><a href="/dehradun-to-pauri-taxi">Dehradun To Pauri Taxi</a><a href="/dehradun-to-phata-taxi">Dehradun To Phata Taxi</a><a href="/dehradun-to-pithoragarh-taxi">Dehradun To Pithoragarh Taxi</a><a href="/dehradun-to-ramnagar-taxi">Dehradun To Ramnagar Taxi</a><a href="/dehradun-to-ranikhet-taxi">Dehradun To Ranikhet Taxi</a><a href="/dehradun-to-rishikesh-taxi">Dehradun To Rishikesh Taxi</a><a href="/dehradun-to-roorkee-taxi">Dehradun To Roorkee Taxi</a><a href="/dehradun-to-rudraprayag-taxi">Dehradun To Rudraprayag Taxi</a><a href="/dehradun-to-saharanpur-taxi">Dehradun To Saharanpur Taxi</a><a href="/dehradun-to-shimla-taxi">Dehradun To Shimla Taxi</a><a href="/dehradun-to-sitapur-taxi">Dehradun To Sitapur Taxi</a><a href="/dehradun-to-solan-taxi">Dehradun To Solan Taxi</a><a href="/dehradun-to-sonprayag-taxi">Dehradun To Sonprayag Taxi</a><a href="/dehradun-to-srinagar-garhwal-taxi">Dehradun To Srinagar Garhwal Taxi</a><a href="/dehradun-to-tehri-taxi">Dehradun To Tehri Taxi</a><a href="/dehradun-to-ukhimath-taxi">Dehradun To Ukhimath Taxi</a><a href="/dehradun-to-uttarkashi-taxi">Dehradun To Uttarkashi Taxi</a><a href="/dehradun-to-valley-of-flowers-taxi">Dehradun To Valley Of Flowers Taxi</a><a href="/dehradun-to-yamunotri-taxi">Dehradun To Yamunotri Taxi</a><a href="/delhi-to-dehradun-taxi">Delhi To Dehradun Taxi</a><a href="/delhi-to-jim-corbett-taxi">Delhi To Jim Corbett Taxi</a><a href="/delhi-to-lansdowne-taxi">Delhi To Lansdowne Taxi</a><a href="/delhi-to-mussoorie-taxi">Delhi To Mussoorie Taxi</a><a href="/delhi-to-nainital-taxi">Delhi To Nainital Taxi</a><a href="/delhi-to-rishikesh-taxi">Delhi To Rishikesh Taxi</a><a href="/haridwar-to-badrinath-taxi">Haridwar To Badrinath Taxi</a><a href="/haridwar-to-chandigarh-taxi">Haridwar To Chandigarh Taxi</a><a href="/haridwar-to-dehradun-taxi">Haridwar To Dehradun Taxi</a><a href="/haridwar-to-delhi-taxi">Haridwar To Delhi Taxi</a><a href="/haridwar-to-kedarnath-taxi">Haridwar To Kedarnath Taxi</a><a href="/haridwar-to-mussoorie-taxi">Haridwar To Mussoorie Taxi</a><a href="/haridwar-to-rishikesh-taxi">Haridwar To Rishikesh Taxi</a><a href="/mussoorie-to-dehradun-taxi">Mussoorie To Dehradun Taxi</a><a href="/mussoorie-to-haridwar-taxi">Mussoorie To Haridwar Taxi</a><a href="/mussoorie-to-rishikesh-taxi">Mussoorie To Rishikesh Taxi</a><a href="/rishikesh-to-badrinath-taxi">Rishikesh To Badrinath Taxi</a><a href="/rishikesh-to-chandigarh-taxi">Rishikesh To Chandigarh Taxi</a><a href="/rishikesh-to-dehradun-taxi">Rishikesh To Dehradun Taxi</a><a href="/rishikesh-to-delhi-taxi">Rishikesh To Delhi Taxi</a><a href="/rishikesh-to-haridwar-taxi">Rishikesh To Haridwar Taxi</a><a href="/rishikesh-to-kedarnath-taxi">Rishikesh To Kedarnath Taxi</a><a href="/rishikesh-to-mussoorie-taxi">Rishikesh To Mussoorie Taxi</a></div><h4>🚕 More Services</h4><div class="g"><a href="/ai-trip-planner">Ai Trip Planner</a><a href="/best-taxi-service-in-dehradun">Best Taxi Service In Dehradun</a><a href="/cancellation-policy">Cancellation Policy</a><a href="/car-rental-in-dehradun">Car Rental In Dehradun</a><a href="/char-dham-yatra-taxi">Char Dham Yatra Taxi</a><a href="/cheap-cab-in-dehradun">Cheap Cab In Dehradun</a><a href="/dehradun-local-sightseeing-taxi">Dehradun Local Sightseeing Taxi</a><a href="/dehradun-railway-station-taxi">Dehradun Railway Station Taxi</a><a href="/do-dham-yatra-taxi">Do Dham Yatra Taxi</a><a href="/ertiga-for-char-dham-yatra">Ertiga For Char Dham Yatra</a><a href="/force-urbania-rental-dehradun">Force Urbania Rental Dehradun</a><a href="/gallery">Gallery</a><a href="/innova-crysta-for-char-dham-yatra">Innova Crysta For Char Dham Yatra</a><a href="/innova-for-char-dham-yatra">Innova For Char Dham Yatra</a><a href="/innova-taxi-in-dehradun">Innova Taxi In Dehradun</a><a href="/isbt-dehradun-taxi">Isbt Dehradun Taxi</a><a href="/local-taxi-in-dehradun">Local Taxi In Dehradun</a><a href="/luxury-car-rental-dehradun">Luxury Car Rental Dehradun</a><a href="/one-way-taxi-service-in-dehradun">One Way Taxi Service In Dehradun</a><a href="/outstation-taxi-from-dehradun">Outstation Taxi From Dehradun</a><a href="/privacy-policy">Privacy Policy</a><a href="/sedan-taxi-in-dehradun">Sedan Taxi In Dehradun</a><a href="/suv-taxi-in-dehradun">Suv Taxi In Dehradun</a><a href="/swift-dzire-for-char-dham-yatra">Swift Dzire For Char Dham Yatra</a><a href="/tempo-traveller-for-char-dham-yatra">Tempo Traveller For Char Dham Yatra</a><a href="/tempo-traveller-in-dehradun">Tempo Traveller In Dehradun</a><a href="/terms-conditions">Terms Conditions</a><a href="/wedding-car-rental-dehradun">Wedding Car Rental Dehradun</a></div></details>
<!-- OFX4-END -->
<?php if (function_exists('gps_render_script')) { gps_render_script(); } ?>
</body>
</html>