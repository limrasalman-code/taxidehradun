<?php
/**
 * route-head.php v2 — Anaya Cab Service
 * Sets $page_title / $page_description / $page_url / schema-guard for a route page,
 * BEFORE header.php is included, so the <head> is correct and CMS-aware.
 * Expects $__route_slug to be set by the stub.
 *
 * v2 change: SEO LENGTH GUARD — title ≤ 60 chars, meta description ≤ 160 chars
 * (Ahrefs "Title too long 22" + "Meta description too long 26" fix).
 * Koi bhi route data entry ab lamba title/desc leak nahi kar sakti.
 */
if (!defined('SITE_NAME')) { require_once __DIR__ . '/config.php'; }
require_once __DIR__ . '/route-data.php';
$__route_slug = $__route_slug ?? '';
$__e = anaya_route_entry($__route_slug);

/* ---------------------------------------------------------------------
 * SEO LENGTH GUARD
 * ------------------------------------------------------------------- */
function anaya_trim_title(string $t, int $max = 60): string {
    $t = trim($t);
    if (mb_strlen($t) <= $max) return $t;

    /* 1) trailing brand suffix hatao (aksar yahi lamba karta hai) */
    $t = preg_replace('/\s*[|\-–]\s*Anaya Cab(?: Service)?$/u', '', $t);
    if ($t === null) $t = trim((string)$t);
    if (mb_strlen($t) <= $max) return $t;

    /* 2) "(From ₹3,500)" / "(From Rs 3500)" → "– ₹3,500" (chhota format) */
    $t2 = preg_replace('/\s*\(From\s+(?:₹|Rs\.?\s?)([\d,]+)\)\s*/u', ' – ₹$1 ', $t);
    if ($t2 !== null && trim($t2) !== '') $t = trim($t2);
    if (mb_strlen($t) <= $max) return $t;

    /* 3) pipe ho to first segment + short brand */
    if (strpos($t, '|') !== false) {
        $first = trim(explode('|', $t)[0]);
        $cand = $first . ' | Anaya Cab';
        if (mb_strlen($cand) <= $max) return $cand;
        if (mb_strlen($first) <= $max) return $first;
        $t = $first;
    }

    /* 4) word-safe hard cut */
    $cut = mb_substr($t, 0, $max - 1);
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp > 20) $cut = mb_substr($cut, 0, $sp);
    return rtrim($cut, ' ,–-') . '…';
}

function anaya_trim_desc(string $d, int $max = 160): string {
    $d = trim(preg_replace('/\s+/u', ' ', $d));
    if ($d === null) $d = '';
    if (mb_strlen($d) <= $max) return $d;

    /* sentence boundary ke paas cut karo (≥80 chars pe) */
    $cut = mb_substr($d, 0, $max);
    $pos = mb_strrpos($cut, '. ');
    if ($pos !== false && $pos >= 80) return mb_substr($cut, 0, $pos + 1);

    /* warna word-safe cut */
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp > 60) $cut = mb_substr($cut, 0, $sp);
    return rtrim($cut, ' ,–-') . '…';
}

/* ---------------------------------------------------------------------
 * OUTPUT (v1 jaisa hi, bas length-guarded)
 * ------------------------------------------------------------------- */
$page_title       = anaya_trim_title((string)($__e['title'] ?? ''));
$page_description = anaya_trim_desc((string)($__e['desc'] ?? ''));
$page_url         = SITE_DOMAIN . '/' . $__route_slug;
$__route_schema_handled = true;   /* tells header.php NOT to also emit route-schema.php (avoids duplicate Service node) */
$preload_image    = null;