<?php
/**
 * Anaya Cab Service — Dynamic Homepage Hero Slider
 * Premium rebuild
 *
 * Frontend file.
 * Slider content is managed from admin panel and saved in:
 * /includes/slider-data.json
 *
 * v6.2:
 * - Decorative hero/background images converted to CSS background layers.
 * - Prevents empty-alt image audit warnings for decorative backgrounds.
 * - Main vehicle images retain descriptive SEO ALT text.
 * - Per-slide clean bg:
 *   /assets/images/slider/{key}-bg.webp|.jpg
 *   fallback global hero_bg.
 */

if (!defined('SITE_NAME')) {
    if (file_exists(__DIR__ . '/config.php')) {
        require_once __DIR__ . '/config.php';
    } elseif (file_exists(__DIR__ . '/includes/config.php')) {
        require_once __DIR__ . '/includes/config.php';
    }
}

if (!isset($FLEET)) {
    if (file_exists(__DIR__ . '/fleet-config.php')) {
        @require_once __DIR__ . '/fleet-config.php';
    } elseif (file_exists(__DIR__ . '/includes/fleet-config.php')) {
        @require_once __DIR__ . '/includes/fleet-config.php';
    }
}

$slider_data_file = file_exists(__DIR__ . '/slider-data.json') ? (__DIR__ . '/slider-data.json') : (__DIR__ . '/includes/slider-data.json');

$slider_default = [
    'delay' => 3300,

    'hero_bg' => '/assets/images/hero-bg.webp',

    'show_trust' => true,

    'trust' => [
        [
            'icon' => 'fa-star',
            'title' => 'Google',
            'subtitle' => 'Business Profile'
        ],
        [
            'icon' => 'fa-users',
            'title' => '500+',
            'subtitle' => 'Happy customers'
        ],
        [
            'icon' => 'fa-headset',
            'title' => '24×7',
            'subtitle' => 'Booking support'
        ],
        [
            'icon' => 'fa-route',
            'title' => '25+',
            'subtitle' => 'Routes covered'
        ],
        [
            'icon' => 'fa-tags',
            'title' => 'No hidden',
            'subtitle' => 'Fare surprises'
        ],
    ],

    'slides' => [
        [
            'active' => true,
            'key' => 'dzire',
            'title' => 'Your Ride, Our Priority.',
            'sub' => 'Local rides, airport transfers, outstation trips and Char Dham Yatra — travel with comfort, care and verified drivers.',
            'badge' => 'Dehradun · Uttarakhand · 24×7',
            'image' => '/assets/images/fleet/dzire.webp',
            'label' => 'Maruti Suzuki Dzire',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],

        [
            'active' => true,
            'key' => 'ertiga',
            'title' => 'Family Trips Made Comfortable.',
            'sub' => 'Spacious cabs for Mussoorie, Rishikesh, Haridwar, airport pickup and weekend getaways from Dehradun.',
            'badge' => 'Family taxi · Extra luggage · AC',
            'image' => '/assets/images/fleet/ertiga.webp',
            'label' => 'Maruti Suzuki Ertiga',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],

        [
            'active' => true,
            'key' => 'innova-crysta',
            'title' => 'Premium Taxi for Long Journeys.',
            'sub' => 'Comfort-focused Innova Crysta for Delhi, Chandigarh, Nainital, Char Dham and multi-day trips.',
            'badge' => 'Premium comfort',
            'image' => '/assets/images/fleet/innova-crysta.webp',
            'label' => 'Toyota Innova Crysta',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],

        [
            'active' => true,
            'key' => 'tempo',
            'title' => 'Group Travel Without Hassle.',
            'sub' => 'Tempo Traveller for family groups, airport pickups, pilgrimage tours and outstation journeys.',
            'badge' => '12–17 seater options',
            'image' => '/assets/images/fleet/tempo.webp',
            'label' => 'Tempo Traveller',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],

        [
            'active' => true,
            'key' => 'urbania',
            'title' => 'Urbania for Premium Groups',
            'sub' => 'Force Urbania rental for corporate travel, weddings, family tours and premium group transfers.',
            'badge' => 'Premium 13-seater · Corporate & weddings',
            'image' => '/assets/images/fleet/urbania.webp',
            'label' => 'Force Urbania',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],

        [
            'active' => true,
            'key' => 'glanza',
            'title' => 'Smart City Rides, Made Easy.',
            'sub' => 'Toyota Glanza for local rides, Jolly Grant Airport transfers and short outstation trips — economical, comfortable and easy to book.',
            'badge' => 'Compact hatchback · City & airport · AC',
            'image' => '/assets/images/fleet/glanza.webp',
            'label' => 'Toyota Glanza',
            'primary_text' => 'Book Your Ride',
            'primary_url' => '#booking',
            'secondary_text' => 'Call Now',
            'secondary_url' => 'tel:' . BUSINESS_PHONE_TEL
        ],
    ]
];

$slider_data = $slider_default;

if (is_file($slider_data_file)) {

    $json = json_decode(
        (string) file_get_contents($slider_data_file),
        true
    );

    if (is_array($json)) {
        $slider_data = array_replace_recursive(
            $slider_default,
            $json
        );
    }
}

$heroSlides = array_values(
    array_filter(
        $slider_data['slides'] ?? [],
        fn($s) => !empty($s['active'])
    )
);

if (!$heroSlides) {
    $heroSlides = $slider_default['slides'];
}

$slider_delay_ms = (int) (
    $slider_data['delay'] ?? 3300
);

$trust_items = $slider_data['trust']
    ?? $slider_default['trust'];

$show_trust = !empty(
    $slider_data['show_trust']
);

$slide_count = count($heroSlides);

$hero_bg = (string) (
    $slider_data['hero_bg']
    ?? '/assets/images/hero-bg.webp'
);

$accent_map = [
    'dzire' => [
        '#0057ff',
        '#39b6ff'
    ],

    'zest' => [
        '#12a150',
        '#5fe0a0'
    ],

    'ertiga' => [
        '#12a150',
        '#5fe0a0'
    ],

    'innova' => [
        '#e08a00',
        '#ffc24d'
    ],

    'innova-crysta' => [
        '#0891b2',
        '#5fe3f0'
    ],

    'tempo' => [
        '#7c3aed',
        '#b69bff'
    ],

    'urbania' => [
        '#e11d48',
        '#ff8aa6'
    ],

    'glanza' => [
        '#12a150',
        '#5fe0a0'
    ],
];

$car_shift = [
    'dzire' => '8%',
    'zest' => '8%',
    'ertiga' => '6%',
    'innova' => '6%',
    'innova-crysta' => '0%',
    'tempo' => '6%',
    'urbania' => '6%',
    'glanza' => '8%',
];

/*
|--------------------------------------------------------------------------
| Safe CSS background URL
|--------------------------------------------------------------------------
| Background layers are decorative, so they are rendered through CSS
| instead of <img>. This prevents empty-alt image audit warnings.
|--------------------------------------------------------------------------
*/

$hero_bg_safe = htmlspecialchars(
    $hero_bg,
    ENT_QUOTES,
    'UTF-8'
);
?>

<style>

.td-hero{
    --td-ac1:#0057ff;
    --td-ac2:#39b6ff;
    position:relative;
    overflow:hidden;
    background:linear-gradient(
        180deg,
        #fbfdff 0%,
        #eef4fb 100%
    );
    padding:18px 0 0
}

.td-hero *{
    box-sizing:border-box
}

.td-primary-h1{
    position:absolute!important;
    width:1px;
    height:1px;
    padding:0;
    margin:-1px;
    overflow:hidden;
    clip:rect(0,0,0,0);
    white-space:nowrap;
    border:0
}

/*
|--------------------------------------------------------------------------
| GLOBAL HERO BACKGROUND
|--------------------------------------------------------------------------
*/

.td-hero-bg{
    position:absolute;
    inset:0;
    z-index:0;
    overflow:hidden;
    pointer-events:none;
}

.td-hero-bg-layer{
    position:absolute;
    inset:0;
    background-repeat:no-repeat;
    background-size:cover;
    background-position:center 62%;
    filter:saturate(1.08);
    transform:translateZ(0);
}

.td-hero-veil{
    position:absolute;
    inset:0;
    background:linear-gradient(
        90deg,
        rgba(247,250,255,.95) 0%,
        rgba(247,250,255,.84) 38%,
        rgba(247,250,255,.38) 62%,
        rgba(247,250,255,.06) 100%
    )
}

/*
|--------------------------------------------------------------------------
| AMBIENT
|--------------------------------------------------------------------------
*/

.td-ambient{
    position:absolute;
    inset:0;
    pointer-events:none;
    overflow:hidden;
    z-index:1
}

.td-ambient .td-grid{
    position:absolute;
    inset:0;
    background-image:
        radial-gradient(
            rgba(0,87,255,.10) 1px,
            transparent 1.4px
        );
    background-size:26px 26px;
    -webkit-mask-image:
        radial-gradient(
            120% 90% at 70% 20%,
            #000 0%,
            transparent 72%
        );
    mask-image:
        radial-gradient(
            120% 90% at 70% 20%,
            #000 0%,
            transparent 72%
        );
    opacity:.6
}

.td-cloud{
    position:absolute;
    top:7%;
    left:-22%;
    width:230px;
    height:62px;
    background:rgba(255,255,255,.6);
    border-radius:999px;
    filter:blur(16px);
    animation:td-drift 30s linear infinite
}

.td-cloud.c2{
    top:15%;
    width:160px;
    height:46px;
    animation-duration:38s;
    animation-delay:-14s;
    opacity:.5
}

.td-cloud.c3{
    top:3%;
    width:280px;
    height:72px;
    animation-duration:46s;
    animation-delay:-24s;
    opacity:.4
}

@keyframes td-drift{

    from{
        transform:translateX(0)
    }

    to{
        transform:translateX(145vw)
    }

}

.td-sun{
    position:absolute;
    top:-50px;
    right:5%;
    width:200px;
    height:200px;
    border-radius:50%;
    background:
        radial-gradient(
            circle,
            rgba(255,214,120,.55),
            rgba(255,214,120,0) 70%
        );
    animation:td-glow 6s ease-in-out infinite
}

@keyframes td-glow{

    0%,
    100%{
        opacity:.5;
        transform:scale(1)
    }

    50%{
        opacity:.95;
        transform:scale(1.18)
    }

}

.td-routes{
    position:absolute;
    inset:0;
    width:100%;
    height:100%
}

.td-route{
    stroke:rgba(0,87,255,.14);
    stroke-width:2;
    fill:none;
    stroke-dasharray:5 9
}

.td-route--2{
    stroke:rgba(0,87,255,.09)
}

.td-flow{
    stroke:var(--td-ac2);
    stroke-width:3;
    fill:none;
    stroke-linecap:round;
    stroke-dasharray:120 1000;
    opacity:.85;
    filter:
        drop-shadow(
            0 0 6px
            color-mix(
                in srgb,
                var(--td-ac2) 60%,
                transparent
            )
        );
    animation:td-flow 5.5s linear infinite
}

.td-flow--2{
    stroke:var(--td-ac1);
    stroke-width:2.4;
    opacity:.5;
    animation-duration:7.5s;
    animation-delay:-2s
}

@keyframes td-flow{

    from{
        stroke-dashoffset:1120
    }

    to{
        stroke-dashoffset:0
    }

}

.td-node{
    fill:var(--td-ac1);
    opacity:.5;
    animation:td-node 2.6s ease-in-out infinite
}

.td-node--2{
    fill:var(--td-ac2);
    animation-delay:-.9s
}

.td-node--3{
    animation-delay:-1.7s
}

@keyframes td-node{

    0%,
    100%{
        r:4;
        opacity:.35
    }

    50%{
        r:6.5;
        opacity:.8
    }

}

/*
|--------------------------------------------------------------------------
| PROGRESS
|--------------------------------------------------------------------------
*/

.td-progress{
    position:absolute;
    top:0;
    left:0;
    right:0;
    height:3px;
    z-index:8;
    background:rgba(7,20,47,.07)
}

.td-progress-bar{
    height:100%;
    width:0;
    border-radius:0 3px 3px 0;
    background:
        linear-gradient(
            90deg,
            var(--td-ac1),
            var(--td-ac2)
        );
    box-shadow:
        0 0 10px
        color-mix(
            in srgb,
            var(--td-ac2) 55%,
            transparent
        )
}

.td-playing .td-progress-bar{
    animation:
        td-fill
        var(--td-delay,5000ms)
        linear
        forwards
}

.td-paused .td-progress-bar{
    animation-play-state:paused
}

@keyframes td-fill{

    from{
        width:0
    }

    to{
        width:100%
    }

}

/*
|--------------------------------------------------------------------------
| SLIDER
|--------------------------------------------------------------------------
*/

.td-slider{
    position:relative;
    z-index:2
}

.td-topbar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:14px;
    padding:6px 0 2px
}

.td-kicker{
    display:inline-flex;
    align-items:center;
    gap:9px;
    font-family:
        ui-monospace,
        SFMono-Regular,
        Menlo,
        Consolas,
        monospace;
    font-size:.7rem;
    font-weight:600;
    letter-spacing:.16em;
    text-transform:uppercase;
    color:#5b6b8c
}

.td-kicker-dot{
    width:7px;
    height:7px;
    border-radius:50%;
    background:var(--td-ac1);
    box-shadow:
        0 0 0 0
        color-mix(
            in srgb,
            var(--td-ac1) 60%,
            transparent
        );
    animation:td-ping 2s infinite
}

@keyframes td-ping{

    0%{
        box-shadow:
            0 0 0 0
            color-mix(
                in srgb,
                var(--td-ac1) 55%,
                transparent
            )
    }

    70%{
        box-shadow:
            0 0 0 8px
            color-mix(
                in srgb,
                var(--td-ac1) 0%,
                transparent
            )
    }

    100%{
        box-shadow:
            0 0 0 0
            color-mix(
                in srgb,
                var(--td-ac1) 0%,
                transparent
            )
    }

}

.td-topright{
    display:flex;
    align-items:center;
    gap:14px
}

.td-counter{
    display:flex;
    align-items:baseline;
    gap:3px;
    font-family:'Sora','Poppins',sans-serif;
    color:#07142f
}

.td-counter .td-cur{
    font-size:1.5rem;
    font-weight:800;
    letter-spacing:-.02em;
    font-variant-numeric:tabular-nums;
    line-height:1
}

.td-counter .td-cur.td-flip{
    animation:td-flip .35s ease
}

@keyframes td-flip{

    from{
        opacity:.2;
        transform:translateY(-5px)
    }

    to{
        opacity:1;
        transform:none
    }

}

.td-counter .td-sep{
    color:#9fb0c9;
    font-weight:700;
    margin:0 1px
}

.td-counter .td-total{
    font-size:.95rem;
    font-weight:700;
    color:#9fb0c9;
    font-variant-numeric:tabular-nums
}

.td-navs{
    display:flex;
    gap:8px
}

.td-nav{
    width:42px;
    height:42px;
    border-radius:50%;
    border:1px solid #d8e2f0;
    background:rgba(255,255,255,.7);
    backdrop-filter:blur(6px);
    color:#07142f;
    display:grid;
    place-items:center;
    cursor:pointer;
    font-size:.9rem;
    transition:
        transform .2s,
        background .2s,
        color .2s,
        border-color .2s,
        box-shadow .2s
}

.td-nav:hover{
    background:var(--td-ac1);
    color:#fff;
    border-color:var(--td-ac1);
    transform:translateY(-2px);
    box-shadow:
        0 10px 22px -8px
        color-mix(
            in srgb,
            var(--td-ac1) 60%,
            transparent
        )
}

.td-nav:focus-visible{
    outline:
        3px solid
        color-mix(
            in srgb,
            var(--td-ac1) 45%,
            transparent
        );
    outline-offset:2px
}

.td-stage{
    position:relative;
    min-height:540px
}

.td-slide{
    position:absolute;
    inset:0;
    display:none;
    grid-template-columns:1.04fr .96fr;
    align-items:center;
    gap:30px
}

.td-slide.active{
    display:grid;
    animation:td-fade .55s ease both
}

@keyframes td-fade{

    from{
        opacity:0
    }

    to{
        opacity:1
    }

}

/*
|--------------------------------------------------------------------------
| PER-SLIDE BACKGROUND
|--------------------------------------------------------------------------
| Converted from <img> to decorative CSS layer.
|--------------------------------------------------------------------------
*/

.td-slidebg{
    position:absolute;
    inset:0;
    z-index:0;
    overflow:hidden;
    pointer-events:none
}

.td-slidebg-layer{
    position:absolute;
    inset:0;
    background-repeat:no-repeat;
    background-size:cover;
    background-position:center 62%;
    filter:saturate(1.06);
    transform:translateZ(0)
}

.td-slidebg::after{
    content:"";
    position:absolute;
    inset:0;
    background:
        linear-gradient(
            180deg,
            rgba(247,250,255,.93) 0%,
            rgba(247,250,255,.78) 36%,
            rgba(247,250,255,.18) 60%,
            rgba(247,250,255,0) 85%
        )
}

.td-slide.active .td-slidebg{
    animation:tdBg .9s ease both
}

@keyframes tdBg{

    from{
        opacity:0;
        transform:scale(1.04)
    }

    to{
        opacity:1;
        transform:none
    }

}

/*
|--------------------------------------------------------------------------
| COPY
|--------------------------------------------------------------------------
*/

.td-copy{
    padding:18px 0 30px;
    max-width:640px;
    position:relative;
    z-index:2
}

.td-badge{
    display:inline-flex;
    align-items:center;
    gap:9px;
    background:
        color-mix(
            in srgb,
            var(--td-ac1) 10%,
            #fff
        );
    color:var(--td-ac1);
    border:
        1px solid
        color-mix(
            in srgb,
            var(--td-ac1) 22%,
            #fff
        );
    border-radius:999px;
    padding:9px 16px;
    font-size:.82rem;
    font-weight:800;
    letter-spacing:.02em;
    margin-bottom:20px;
    box-shadow:
        0 8px 22px
        color-mix(
            in srgb,
            var(--td-ac1) 12%,
            transparent
        )
}

.td-badge i{
    font-size:.78rem
}

.td-slide.active .td-badge{
    animation:tdTextUp .5s ease both
}

.td-title{
    font-family:'Sora','Poppins',sans-serif;
    font-size:clamp(2.3rem,5.4vw,4.4rem);
    line-height:1.02;
    letter-spacing:-.05em;
    margin:0 0 18px;
    color:#07142f;
    font-weight:800
}

.td-slide.active .td-title{
    animation:tdTextUp .62s ease both
}

.td-sub{
    font-size:clamp(1rem,1.7vw,1.22rem);
    line-height:1.62;
    color:#51617d;
    margin:0 0 24px;
    max-width:54ch
}

.td-slide.active .td-sub{
    animation:tdTextUp .72s .05s ease both
}

.td-actions{
    display:flex;
    gap:14px;
    flex-wrap:wrap;
    margin-bottom:20px
}

.td-slide.active .td-actions{
    animation:tdTextUp .8s .1s ease both
}

.td-btn-p,
.td-btn-s{
    position:relative;
    overflow:hidden;
    display:inline-flex;
    align-items:center;
    gap:10px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:700;
    font-size:.95rem;
    padding:14px 24px;
    border-radius:14px;
    text-decoration:none;
    transition:
        transform .2s,
        box-shadow .3s,
        filter .2s,
        gap .25s
}

.td-btn-p{
    background:
        linear-gradient(
            135deg,
            var(--td-ac1),
            color-mix(
                in srgb,
                var(--td-ac1) 60%,
                var(--td-ac2)
            )
        );
    color:#fff;
    box-shadow:
        0 14px 30px -10px
        color-mix(
            in srgb,
            var(--td-ac1) 60%,
            transparent
        )
}

.td-btn-p:hover{
    transform:translateY(-2px);
    gap:13px;
    filter:brightness(1.05)
}

.td-btn-p::after{
    content:"";
    position:absolute;
    top:0;
    left:-60%;
    width:38%;
    height:100%;
    background:
        linear-gradient(
            115deg,
            transparent,
            rgba(255,255,255,.5),
            transparent
        );
    transform:skewX(-20deg);
    animation:td-sheen 3.6s ease-in-out infinite
}

@keyframes td-sheen{

    0%{
        left:-60%
    }

    55%,
    100%{
        left:130%
    }

}

.td-btn-s{
    background:rgba(255,255,255,.85);
    backdrop-filter:blur(6px);
    color:#07142f;
    border:1px solid #d8e2f0;
    box-shadow:0 8px 24px rgba(10,22,51,.06)
}

.td-btn-s:hover{
    transform:translateY(-2px);
    border-color:var(--td-ac1);
    color:var(--td-ac1)
}

.td-chips{
    display:flex;
    flex-wrap:wrap;
    gap:9px
}

.td-chips span{
    display:inline-flex;
    align-items:center;
    gap:7px;
    font-size:.78rem;
    font-weight:700;
    color:#51617d;
    background:rgba(255,255,255,.7);
    border:1px solid #e3ebf6;
    border-radius:999px;
    padding:7px 13px
}

.td-chips i{
    color:var(--td-ac1);
    font-size:.74rem
}

/*
|--------------------------------------------------------------------------
| VISUAL
|--------------------------------------------------------------------------
*/

.td-visual{
    position:relative;
    min-height:440px;
    display:grid;
    place-items:end center;
    align-self:end;
    z-index:1
}

.td-road{
    position:absolute;
    left:50%;
    bottom:4%;
    transform:translateX(-50%);
    width:92%;
    height:40px;
    border-radius:50%;
    background:
        radial-gradient(
            60% 100% at 50% 0%,
            rgba(0,0,0,.24),
            transparent 70%
        );
    filter:blur(2px)
}

.td-visual img.td-car{
    position:relative;
    z-index:2;
    width:min(720px,100%);
    height:auto;
    object-fit:contain;
    filter:
        drop-shadow(
            0 22px 26px
            rgba(10,22,51,.35)
        );
    transform:
        translate(
            var(--car-x,0%),
            10px
        )
}

.td-slide.active img.td-car{
    animation:tdCarEnter .8s ease both
}

@keyframes tdCarEnter{

    from{
        opacity:0;
        transform:
            translate(
                calc(
                    var(--car-x,0%) + 44px
                ),
                34px
            )
            scale(.93)
    }

    to{
        opacity:1;
        transform:
            translate(
                var(--car-x,0%),
                10px
            )
            scale(1)
    }

}

.td-car-label{
    position:absolute;
    z-index:3;
    top:64px;
    right:18px;
    display:inline-flex;
    align-items:center;
    gap:8px;
    background:rgba(255,255,255,.9);
    backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,.9);
    border-radius:999px;
    padding:9px 16px;
    font-family:'Sora','Poppins',sans-serif;
    font-weight:800;
    color:#07142f;
    font-size:.9rem;
    box-shadow:0 12px 30px rgba(10,22,51,.1)
}

.td-cl-dot{
    width:8px;
    height:8px;
    border-radius:50%;
    background:var(--td-ac2);
    box-shadow:
        0 0 0 0
        color-mix(
            in srgb,
            var(--td-ac2) 60%,
            transparent
        );
    animation:td-ping 2s infinite
}

.td-streak{
    position:absolute;
    top:32%;
    right:-12%;
    width:55%;
    height:2px;
    background:
        linear-gradient(
            90deg,
            transparent,
            var(--td-ac2)
        );
    opacity:0;
    z-index:1;
    border-radius:2px
}

.td-streak--2{
    top:46%;
    width:40%
}

.td-slide.active .td-streak{
    animation:
        td-streak
        .9s
        .15s
        ease-out
}

.td-slide.active .td-streak--2{
    animation-delay:.3s
}

@keyframes td-streak{

    0%{
        opacity:0;
        transform:translateX(40px)
    }

    30%{
        opacity:.85
    }

    100%{
        opacity:0;
        transform:translateX(-240px)
    }

}

/*
|--------------------------------------------------------------------------
| DOTS
|--------------------------------------------------------------------------
*/

.td-dots{
    position:absolute;
    left:0;
    right:0;
    bottom:6px;
    z-index:5;
    display:flex;
    justify-content:center;
    gap:10px
}

.td-dot{
    width:11px;
    height:11px;
    border:0;
    border-radius:999px;
    background:rgba(7,20,47,.18);
    cursor:pointer;
    padding:0;
    transition:
        width .3s,
        background .3s,
        box-shadow .3s
}

.td-dot:hover{
    background:rgba(7,20,47,.4)
}

.td-dot.active{
    width:32px;
    background:
        linear-gradient(
            90deg,
            var(--td-ac1),
            var(--td-ac2)
        );
    box-shadow:
        0 4px 12px
        color-mix(
            in srgb,
            var(--td-ac1) 45%,
            transparent
        )
}

.td-dot:focus-visible{
    outline:
        3px solid
        color-mix(
            in srgb,
            var(--td-ac1) 45%,
            transparent
        );
    outline-offset:2px
}

/*
|--------------------------------------------------------------------------
| TRUST
|--------------------------------------------------------------------------
*/

.td-trust{
    position:relative;
    z-index:6;
    margin:18px auto 0;
    background:rgba(255,255,255,.92);
    backdrop-filter:blur(16px);
    border:1px solid #e3ebf6;
    border-radius:22px;
    box-shadow:0 20px 50px rgba(10,22,51,.08);
    display:grid;
    grid-template-columns:repeat(5,1fr);
    overflow:hidden
}

.td-trust::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    height:2px;
    width:40%;
    background:
        linear-gradient(
            90deg,
            transparent,
            var(--td-ac2),
            transparent
        );
    animation:td-scan 4.5s linear infinite
}

@keyframes td-scan{

    0%{
        left:-40%
    }

    100%{
        left:100%
    }

}

.td-trust div{
    position:relative;
    padding:18px 12px;
    text-align:center;
    border-right:1px solid #eef2f8;
    transition:background .25s
}

.td-trust div:last-child{
    border-right:0
}

.td-trust div:hover{
    background:
        color-mix(
            in srgb,
            var(--td-ac1) 5%,
            #fff
        )
}

.td-trust i{
    display:inline-grid;
    place-items:center;
    width:40px;
    height:40px;
    border-radius:999px;
    background:
        color-mix(
            in srgb,
            var(--td-ac1) 10%,
            #fff
        );
    color:var(--td-ac1);
    font-size:1rem;
    margin-bottom:8px;
    transition:transform .3s
}

.td-trust div:hover i{
    transform:
        translateY(-3px)
        scale(1.08)
}

.td-trust strong{
    display:block;
    font-family:'Sora','Poppins',sans-serif;
    font-size:1.05rem;
    color:#07142f;
    line-height:1.2
}

.td-trust span{
    display:block;
    color:#5b6b8c;
    font-size:.8rem;
    margin-top:4px
}

@keyframes tdTextUp{

    from{
        opacity:0;
        transform:translateY(22px)
    }

    to{
        opacity:1;
        transform:translateY(0)
    }

}

/*
|--------------------------------------------------------------------------
| TABLET / MOBILE
|--------------------------------------------------------------------------
*/

@media(max-width:991px){

    .td-hero{
        padding-top:8px
    }

    .td-hero-veil{
        background:
            linear-gradient(
                180deg,
                rgba(247,250,255,.95) 0%,
                rgba(247,250,255,.8) 40%,
                rgba(247,250,255,.28) 66%,
                rgba(247,250,255,0) 88%
            )
    }

    .td-slidebg::after{
        background:
            linear-gradient(
                180deg,
                rgba(247,250,255,.94) 0%,
                rgba(247,250,255,.8) 40%,
                rgba(247,250,255,.22) 64%,
                rgba(247,250,255,0) 86%
            )
    }

    .td-stage{
        min-height:0
    }

    .td-slide{
        position:relative;
        inset:auto;
        display:none;
        grid-template-columns:1fr;
        gap:8px
    }

    .td-slide.active{
        display:grid
    }

    .td-copy{
        width:100%;
        padding:10px 0 6px
    }

    .td-title{
        font-size:clamp(
            2rem,
            9.5vw,
            3.1rem
        );
        margin-bottom:12px
    }

    .td-sub{
        font-size:.98rem;
        margin-bottom:16px
    }

    .td-actions{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:12px
    }

    .td-btn-p,
    .td-btn-s{
        justify-content:center;
        padding:13px 10px;
        font-size:.9rem;
        min-height:48px
    }

    .td-visual{
        width:100%;
        min-height:0;
        height:300px;
        place-items:end center;
        margin-top:4px
    }

    .td-visual img.td-car{
        width:min(560px,100%);
        max-height:280px
    }

    .td-car-label{
        top:4px;
        right:6px;
        font-size:.82rem;
        padding:7px 12px
    }

    .td-dots{
        position:static;
        justify-content:center;
        margin:14px 0 4px
    }

    .td-trust{
        grid-template-columns:repeat(3,1fr);
        border-radius:18px
    }

    .td-trust div{
        padding:14px 8px
    }

    .td-trust div:nth-child(n+4){
        display:none
    }

    .td-trust i{
        width:34px;
        height:34px
    }

    .td-trust strong{
        font-size:.92rem
    }

    .td-trust span{
        font-size:.7rem
    }

    .td-navs{
        display:none
    }

}

@media(max-width:420px){

    .td-title{
        font-size:clamp(
            1.9rem,
            10vw,
            2.8rem
        )
    }

    .td-visual{
        height:260px
    }

    .td-visual img.td-car{
        max-height:240px
    }

}

@media(prefers-reduced-motion:reduce){

    .td-hero *{
        animation:none!important;
        transition:none!important
    }

    .td-slide.active{
        animation:none!important
    }

}

</style>

<section
    class="td-hero"
    id="home"
>

<!-- =========================================================
     GLOBAL DECORATIVE HERO BACKGROUND
========================================================= -->

<div
    class="td-hero-bg"
    aria-hidden="true"
>

    <div
        class="td-hero-bg-layer"
        style="background-image:url('<?php echo $hero_bg_safe; ?>');"
    ></div>

    <span class="td-hero-veil"></span>

</div>

<!-- =========================================================
     AMBIENT
========================================================= -->

<div
    class="td-ambient"
    aria-hidden="true"
>

    <div class="td-grid"></div>

    <span class="td-sun"></span>

    <span class="td-cloud"></span>

    <span class="td-cloud c2"></span>

    <span class="td-cloud c3"></span>

    <svg
        class="td-routes"
        viewBox="0 0 1200 640"
        preserveAspectRatio="xMidYMid slice"
        fill="none"
    >

        <path
            class="td-route"
            d="M-50 470 C 200 470, 260 250, 520 250 S 900 470, 1260 300"
        />

        <path
            class="td-route td-route--2"
            d="M-50 560 C 250 560, 360 380, 640 400 S 1000 560, 1260 470"
        />

        <path
            class="td-flow"
            pathLength="1000"
            d="M-50 470 C 200 470, 260 250, 520 250 S 900 470, 1260 300"
        />

        <path
            class="td-flow td-flow--2"
            pathLength="1000"
            d="M-50 560 C 250 560, 360 380, 640 400 S 1000 560, 1260 470"
        />

        <circle
            class="td-node"
            cx="520"
            cy="250"
            r="4"
        />

        <circle
            class="td-node td-node--2"
            cx="905"
            cy="432"
            r="4"
        />

        <circle
            class="td-node td-node--3"
            cx="250"
            cy="372"
            r="4"
        />

    </svg>

</div>

<!-- =========================================================
     PROGRESS
========================================================= -->

<div
    class="td-progress"
    aria-hidden="true"
>

    <div class="td-progress-bar"></div>

</div>

<div
    class="container td-slider"
    id="tdHeroSlider"
    data-delay="<?php echo (int)$slider_delay_ms; ?>"
>

<!-- =========================================================
     TOP BAR
========================================================= -->

<div class="td-topbar">

    <span class="td-kicker">

        <span class="td-kicker-dot"></span>

        Dehradun · Uttarakhand · 24×7

    </span>

    <div class="td-topright">

        <div
            class="td-counter"
            aria-hidden="true"
        >

            <span
                class="td-cur"
                data-td-cur
            >
                01
            </span>

            <span class="td-sep">
                /
            </span>

            <span class="td-total">
                <?php
                echo str_pad(
                    (string)$slide_count,
                    2,
                    '0',
                    STR_PAD_LEFT
                );
                ?>
            </span>

        </div>

        <div class="td-navs">

            <button
                type="button"
                class="td-nav"
                data-td-prev
                aria-label="Previous slide"
            >
                <i class="fa-solid fa-arrow-left"></i>
            </button>

            <button
                type="button"
                class="td-nav"
                data-td-next
                aria-label="Next slide"
            >
                <i class="fa-solid fa-arrow-right"></i>
            </button>

        </div>

    </div>

</div>

<!-- =========================================================
     SLIDES
========================================================= -->

<div class="td-stage">

<div
    class="td-slides"
    aria-live="polite"
>

<?php

foreach ($heroSlides as $i => $slide):

    $label =
        $slide['label']
        ?: (
            $FLEET[$slide['key']]['name']
            ?? ucwords(
                str_replace(
                    '-',
                    ' ',
                    $slide['key'] ?? 'cab'
                )
            )
        );

    $ac =
        $accent_map[$slide['key']]
        ?? [
            '#0057ff',
            '#39b6ff'
        ];

    $key =
        (string)($slide['key'] ?? '');

    $cx =
        isset($car_shift[$key])
            ? $car_shift[$key]
            : '6%';

    /*
    |--------------------------------------------------------------------------
    | Find slide background
    |--------------------------------------------------------------------------
    */

    $sbg = '';

    if ($key !== '') {

        foreach (
            ['.webp', '.jpg'] as $ext
        ) {

            $bp =
                '/assets/images/slider/'
                . $key
                . '-bg'
                . $ext;

            if (
                file_exists(
                    dirname(__DIR__) . $bp
                )
            ) {

                $sbg = $bp;

                break;

            }

        }

    }

    $sbg_safe =
        htmlspecialchars(
            $sbg,
            ENT_QUOTES,
            'UTF-8'
        );

?>

<article
    class="td-slide <?php echo $i === 0 ? 'active' : ''; ?>"
    data-td-slide="<?php echo $i; ?>"
    data-ac1="<?php echo htmlspecialchars($ac[0], ENT_QUOTES, 'UTF-8'); ?>"
    data-ac2="<?php echo htmlspecialchars($ac[1], ENT_QUOTES, 'UTF-8'); ?>"
    style="--car-x:<?php echo htmlspecialchars($cx, ENT_QUOTES, 'UTF-8'); ?>"
>

<?php if ($sbg !== ''): ?>

<!-- =========================================================
     DECORATIVE SLIDE BACKGROUND
     CSS background instead of empty-alt <img>
========================================================= -->

<div
    class="td-slidebg"
    aria-hidden="true"
>

    <div
        class="td-slidebg-layer"
        style="background-image:url('<?php echo $sbg_safe; ?>');"
    ></div>

</div>

<?php endif; ?>

<!-- =========================================================
     COPY
========================================================= -->

<div class="td-copy">

    <span class="td-badge">

        <i class="fa-solid fa-location-dot"></i>

        <?php
        echo htmlspecialchars(
            $slide['badge']
            ?? 'Dehradun · 24×7',
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </span>

    <?php $slide_htag = ($i === 0) ? 'h1' : 'h2'; ?>
    <<?php echo $slide_htag; ?> class="td-title">

        <?php
        echo htmlspecialchars(
            $slide['title']
            ?? 'Book Taxi in Dehradun',
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </<?php echo $slide_htag; ?>>

    <p class="td-sub">

        <?php
        echo htmlspecialchars(
            $slide['sub']
            ?? 'Reliable local, airport and outstation taxi service.',
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </p>

    <div class="td-actions">

        <a
            class="td-btn-p ripple"
            href="<?php
                echo htmlspecialchars(
                    $slide['primary_url']
                    ?? '#booking',
                    ENT_QUOTES,
                    'UTF-8'
                );
            ?>"
        >

            <i class="fa-solid fa-car"></i>

            <span>

                <?php
                echo htmlspecialchars(
                    $slide['primary_text']
                    ?? 'Book Your Ride',
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </span>

        </a>

        <a
            class="td-btn-s ripple"
            href="<?php
                echo htmlspecialchars(
                    $slide['secondary_url']
                    ?? ('tel:' . BUSINESS_PHONE_TEL),
                    ENT_QUOTES,
                    'UTF-8'
                );
            ?>"
        >

            <i class="fa-solid fa-phone"></i>

            <span>

                <?php
                echo htmlspecialchars(
                    $slide['secondary_text']
                    ?? 'Call Now',
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </span>

        </a>

    </div>

    <div class="td-chips">

        <span>
            <i class="fa-solid fa-snowflake"></i>
            AC cars
        </span>

        <span>
            <i class="fa-solid fa-id-badge"></i>
            Verified drivers
        </span>

        <span>
            <i class="fa-solid fa-tag"></i>
            Upfront fare
        </span>

    </div>

</div>

<!-- =========================================================
     VEHICLE
========================================================= -->

<div class="td-visual">

    <span class="td-streak"></span>

    <span class="td-streak td-streak--2"></span>

    <div class="td-road"></div>

    <span class="td-car-label">

        <span class="td-cl-dot"></span>

        <?php
        echo htmlspecialchars(
            $label,
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </span>

    <!--
    |--------------------------------------------------------------------------
    | IMPORTANT:
    | Main vehicle image keeps descriptive ALT.
    |--------------------------------------------------------------------------
    -->

    <img
        class="td-car"
        src="<?php
            echo htmlspecialchars(
                $slide['image']
                ?? '/assets/images/hero-car.webp',
                ENT_QUOTES,
                'UTF-8'
            );
        ?>"
        alt="<?php
            echo htmlspecialchars(
                $label
                . ' taxi on Himalayan mountain road',
                ENT_QUOTES,
                'UTF-8'
            );
        ?>"
        width="760"
        height="507"
        decoding="async"
        <?php
        echo $i === 0
            ? 'fetchpriority="high" loading="eager"'
            : 'loading="lazy"';
        ?>
        onerror="this.src='/assets/images/hero-car.webp'"
    >

</div>

</article>

<?php endforeach; ?>

</div>

<!-- =========================================================
     DOTS
========================================================= -->

<div
    class="td-dots"
    role="tablist"
    aria-label="Hero slides"
>

<?php foreach ($heroSlides as $i => $slide): ?>

<button
    type="button"
    class="td-dot <?php echo $i === 0 ? 'active' : ''; ?>"
    data-td-dot="<?php echo $i; ?>"
    role="tab"
    aria-label="Show slide <?php echo $i + 1; ?>"
></button>

<?php endforeach; ?>

</div>

</div>

<!-- =========================================================
     TRUST
========================================================= -->

<?php if ($show_trust): ?>

<div class="td-trust">

<?php foreach (
    array_slice($trust_items, 0, 5)
    as $item
): ?>

<div>

    <i
        class="fa-solid <?php
            echo htmlspecialchars(
                $item['icon']
                ?? 'fa-star',
                ENT_QUOTES,
                'UTF-8'
            );
        ?>"
    ></i>

    <strong>

        <?php
        echo htmlspecialchars(
            $item['title']
            ?? 'Trust',
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </strong>

    <span>

        <?php
        echo htmlspecialchars(
            $item['subtitle']
            ?? '',
            ENT_QUOTES,
            'UTF-8'
        );
        ?>

    </span>

</div>

<?php endforeach; ?>

</div>

<?php endif; ?>

</div>

</section>

<script>

(function(){

'use strict';

/*
|--------------------------------------------------------------------------
| Slider boot
|--------------------------------------------------------------------------
*/

function boot(){

    var root =
        document.getElementById(
            'tdHeroSlider'
        );

    if(!root){

        console.warn(
            '[Slider] Root element not found'
        );

        return;

    }

    var slides =
        Array.from(
            root.querySelectorAll(
                '[data-td-slide]'
            )
        );

    var dots =
        Array.from(
            root.querySelectorAll(
                '[data-td-dot]'
            )
        );

    var curEl =
        root.querySelector(
            '[data-td-cur]'
        );

    var bar =
        root.querySelector(
            '.td-progress-bar'
        );

    var prev =
        root.querySelector(
            '[data-td-prev]'
        );

    var next =
        root.querySelector(
            '[data-td-next]'
        );

    if(slides.length < 1){

        console.warn(
            '[Slider] No slides found'
        );

        return;

    }

    if(slides.length < 2){

        if(curEl){

            curEl.textContent =
                '01';

        }

        return;

    }

    var total =
        slides.length;

    var delay =
        Math.max(
            2200,
            Number(
                root.dataset.delay || 3300
            )
        );

    root.style.setProperty(
        '--td-delay',
        delay + 'ms'
    );

    var index = 0;

    var timer = null;

    var pad =
        function(n){

            return (
                n < 10
                    ? '0'
                    : ''
            ) + n;

        };

    /*
    |--------------------------------------------------------------------------
    | Accent
    |--------------------------------------------------------------------------
    */

    function accent(i){

        var s =
            slides[i];

        root.style.setProperty(
            '--td-ac1',
            s.getAttribute('data-ac1')
            || '#0057ff'
        );

        root.style.setProperty(
            '--td-ac2',
            s.getAttribute('data-ac2')
            || '#39b6ff'
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Progress bar
    |--------------------------------------------------------------------------
    */

    function restartBar(){

        if(!bar){
            return;
        }

        bar.style.animation =
            'none';

        void bar.offsetWidth;

        bar.style.animation =
            '';

    }

    /*
    |--------------------------------------------------------------------------
    | Playing state
    |--------------------------------------------------------------------------
    */

    function setPlaying(p){

        root.classList.toggle(
            'td-playing',
            p
        );

        root.classList.toggle(
            'td-paused',
            !p
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Show slide
    |--------------------------------------------------------------------------
    */

    function show(n){

        index =
            (n + total) % total;

        slides.forEach(
            function(s,i){

                s.classList.toggle(
                    'active',
                    i === index
                );

            }
        );

        dots.forEach(
            function(d,i){

                d.classList.toggle(
                    'active',
                    i === index
                );

                d.setAttribute(
                    'aria-selected',
                    i === index
                        ? 'true'
                        : 'false'
                );

            }
        );

        accent(index);

        if(curEl){

            curEl.textContent =
                pad(index + 1);

            curEl.classList.remove(
                'td-flip'
            );

            void curEl.offsetWidth;

            curEl.classList.add(
                'td-flip'
            );

        }

        restartBar();

    }

    /*
    |--------------------------------------------------------------------------
    | Stop
    |--------------------------------------------------------------------------
    */

    function stop(){

        if(timer){

            clearInterval(timer);

            timer = null;

        }

        setPlaying(false);

    }

    /*
    |--------------------------------------------------------------------------
    | Start
    |--------------------------------------------------------------------------
    */

    function start(){

        stop();

        setPlaying(true);

        restartBar();

        timer =
            setInterval(
                function(){

                    show(
                        index + 1
                    );

                },
                delay
            );

    }

    /*
    |--------------------------------------------------------------------------
    | Dots
    |--------------------------------------------------------------------------
    */

    dots.forEach(
        function(d,i){

            d.addEventListener(
                'click',
                function(){

                    show(i);

                    start();

                },
                {
                    passive:true
                }
            );

        }
    );

    /*
    |--------------------------------------------------------------------------
    | Previous
    |--------------------------------------------------------------------------
    */

    if(prev){

        prev.addEventListener(
            'click',
            function(){

                show(
                    index - 1
                );

                start();

            }
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Next
    |--------------------------------------------------------------------------
    */

    if(next){

        next.addEventListener(
            'click',
            function(){

                show(
                    index + 1
                );

                start();

            }
        );

    }

    /*
    |--------------------------------------------------------------------------
    | Touch / swipe
    |--------------------------------------------------------------------------
    */

    var sx = 0;

    var sy = 0;

    root.addEventListener(
        'touchstart',
        function(e){

            sx =
                e.touches[0].clientX;

            sy =
                e.touches[0].clientY;

        },
        {
            passive:true
        }
    );

    root.addEventListener(
        'touchend',
        function(e){

            var dx =
                e.changedTouches[0].clientX
                - sx;

            var dy =
                e.changedTouches[0].clientY
                - sy;

            if(
                Math.abs(dx) > 40 &&
                Math.abs(dx) > Math.abs(dy)
            ){

                show(
                    index
                    + (
                        dx < 0
                            ? 1
                            : -1
                    )
                );

                start();

            }

        },
        {
            passive:true
        }
    );

    /*
    |--------------------------------------------------------------------------
    | Mouse hover pause
    |--------------------------------------------------------------------------
    */

    root.addEventListener(
        'mouseenter',
        function(){

            if(timer){

                clearInterval(timer);

                timer = null;

            }

            root.classList.add(
                'td-paused'
            );

        }
    );

    root.addEventListener(
        'mouseleave',
        function(){

            start();

        }
    );

    /*
    |--------------------------------------------------------------------------
    | Visibility
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'visibilitychange',
        function(){

            if(document.hidden){

                if(timer){

                    clearInterval(timer);

                    timer = null;

                }

                root.classList.add(
                    'td-paused'
                );

            }else{

                start();

            }

        }
    );

    /*
    |--------------------------------------------------------------------------
    | Keyboard navigation
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        function(e){

            var a =
                document.activeElement;

            var t =
                a && a.tagName;

            if(
                t === 'INPUT' ||
                t === 'TEXTAREA' ||
                t === 'SELECT' ||
                (
                    a &&
                    a.isContentEditable
                )
            ){

                return;

            }

            if(
                e.key === 'ArrowLeft'
            ){

                show(
                    index - 1
                );

                start();

            }else if(
                e.key === 'ArrowRight'
            ){

                show(
                    index + 1
                );

                start();

            }

        }
    );

    /*
    |--------------------------------------------------------------------------
    | Initial state
    |--------------------------------------------------------------------------
    */

    show(0);

    start();

}

/*
|--------------------------------------------------------------------------
| DOM ready
|--------------------------------------------------------------------------
*/

if(
    document.readyState === 'loading'
){

    document.addEventListener(
        'DOMContentLoaded',
        boot
    );

}else{

    boot();

}

})();

</script>