<?php
/**
 * Anaya Cab Service — Legacy Booking Compatibility Wrapper
 *
 * PRIMARY BOOKING API:
 * /api/booking.php
 *
 * This file is kept only for backward compatibility.
 * It does not contain a separate booking implementation.
 */

declare(strict_types=1);

require_once __DIR__ . '/../api/booking.php';