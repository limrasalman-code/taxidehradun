<?php
/**
* Anaya Cab Service — Route render engine v3.0 (FULL FILE — no snippets).
* 50+ route stubs isko require karke anaya_v2_entry() + anaya_v2_render() call karte hain.
* v2.7: includes/rates.php se live fares (Admin Rate Manager wired).
* v3.0: TOP hero background image (route image, fallback hero-bg.webp) —
*       car/road visual page ke top pe, veil ke saath text readable.
* NOTE: Is engine ko update karna = saare route stubs auto-update (duplicate logic mat likho).
*/
if (!defined('SITE_DOMAIN')) { return; }
if (file_exists(__DIR__ . '/rates.php')) { require_once __DIR__ . '/rates.php'; }
function anaya_v2_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function anaya_v2_km($k) {
static $K = array('haridwar'=>55,'rishikesh'=>45,'mussoorie'=>35,'delhi'=>250,'nainital'=>280,'chandigarh'=>210,'agra'=>430,'auli'=>300,'chakrata'=>90,'chopta'=>200,'kanatal'=>80,'dhanaulti'=>60,'tehri'=>120,'uttarkashi'=>180,'srinagar-garhwal'=>230,'haldwani'=>250,'jim-corbett'=>240,'roorkee'=>170,'saharanpur'=>150,'noida'=>230,'gurgaon'=>240,'gurugram'=>240,'ghaziabad'=>225,'faridabad'=>250,'jaipur'=>530,'mathura'=>380,'shimla'=>220,'manali'=>480,'kedarnath'=>230,'badrinath'=>335,'gangotri'=>270,'yamunotri'=>220,'joshimath'=>290,'almora'=>360,'ranikhet'=>300,'kausani'=>350,'pithoragarh'=>410,'rudraprayag'=>150,'devprayag'=>70,'pauri'=>110,'lansdowne'=>150,'ramnagar'=>200,'meerut'=>220,'bareilly'=>250);
return isset($K[$k]) ? $K[$k] : null;
}
function anaya_v2_fare($k) {
/* 1. Pehle Admin Rate Manager (rates.json) se live rate check karo */
if (function_exists('anaya_rate')) {
$rate_key = 'r_' . str_replace('-', '_', $k);
$live_fare = anaya_rate($rate_key);
if ($live_fare > 0) { return $live_fare; }
}
/* 2. Fallback hardcoded defaults (safety net) — orphan pages par fare dikhega, "Quote" nahi */
static $F = array('haridwar'=>1350,'rishikesh'=>1150,'mussoorie'=>1050,'delhi'=>3500,'nainital'=>5600,'chandigarh'=>4000,'agra'=>9000,'auli'=>8500,'chakrata'=>3000,'chopta'=>3000,'kanatal'=>2200,'dhanaulti'=>1800,'tehri'=>3000,'uttarkashi'=>4000,'srinagar-garhwal'=>4500,'haldwani'=>5000,'jim-corbett'=>5000,'roorkee'=>2500,'saharanpur'=>2200,'noida'=>3600,'gurgaon'=>3800,'gurugram'=>3800,'ghaziabad'=>3600,'faridabad'=>4000,'jaipur'=>9000,'mathura'=>7000,'shimla'=>4500,'manali'=>9000,'kedarnath'=>0,'badrinath'=>0,'gangotri'=>0,'yamunotri'=>0,'joshimath'=>4200,'almora'=>7200,'ranikhet'=>6000,'kausani'=>7000,'pithoragarh'=>8500,'rudraprayag'=>3500,'devprayag'=>1800,'pauri'=>2500,'lansdowne'=>3200,'ramnagar'=>4200,'meerut'=>4500,'bareilly'=>5000);
$v = isset($F[$k]) ? $F[$k] : null;
return ($v && $v > 0) ? $v : null;
}
function anaya_v2_theme($k) {
if (in_array($k, array('kedarnath','badrinath','gangotri','yamunotri','rudraprayag','devprayag'), true)) return 'pilgrim';
if ($k === 'auli') return 'snow';
if (in_array($k, array('jim-corbett','ramnagar'), true)) return 'wildlife';
if (in_array($k, array('haridwar','rishikesh','mathura'), true)) return 'river';
if (in_array($k, array('delhi','chandigarh','noida','gurgaon','gurugram','ghaziabad','faridabad','jaipur','agra','roorkee','saharanpur','meerut','bareilly'), true)) return 'highway';
return 'hill';
}
function anaya_v2_theme_style($t) {
static $S = array(
'pilgrim'=>array('#7c3aed','#c4b5fd','#1a1436','#33245e','#f1e9fe','fa-om'),
'snow'=>array('#0369a1','#38bdf8','#06283d','#0c4a6e','#e0f2fe','fa-snowflake'),
'wildlife'=>array('#4d7c0f','#bef264','#1a2e05','#3f6212','#eef6df','fa-tree'),
'river'=>array('#0e7490','#67e8f9','#083344','#155e75','#e0f6fa','fa-water'),
'highway'=>array('#b45309','#fcd34d','#451a03','#92400e','#fbf0db','fa-road'),
'hill'=>array('#15803d','#4ade80','#052e16','#14532d','#e7f6ec','fa-mountain-sun'),
);
return isset($S[$t]) ? $S[$t] : $S['hill'];
}
function anaya_v2_time($km) {
if (!$km) return '';
$h = max(1, (int)ceil($km / 50));
return $h . ' to ' . ($h + 1) . ' hours';
}
function anaya_v2_fact($to_key) {
static $FACT = array(
'faridabad'=>'For Faridabad we usually take the Delhi to Faridabad road or route you via the Southern Peripheral Road to skip city traffic, depending on your sector.',
'ghaziabad'=>'Ghaziabad drops are fastest via the Eastern Peripheral Expressway or the UP Gate entry, which keeps you off the Delhi to Meerut bottleneck.',
'gurgaon'=>'The Gurugram run is quickest on the expressway, and we drop you at Cyber Hub, your hotel or residential sector without circling the city.',
'noida'=>'For Noida we choose between the DND Flyway and the Eastern Peripheral Expressway based on live traffic, then drop you at your sector or office.',
'jaipur'=>'The Jaipur highway is long but smooth; we plan a comfort stop near Behror and time the entry so you avoid the evening rush at the city tolls.',
'roorkee'=>'Roorkee is a straight plains drive on NH58; we can drop you at IIT Roorkee, the cantonment or the market with very little traffic en route.',
'saharanpur'=>'The Saharanpur road passes the Muzaffarnagar sugarcane belt; it is flat and quick, and we drop you at your address or the main bus stand.',
'haldwani'=>'Haldwani is the gateway to Kumaon; the highway is fast and we can continue you on to Nainital or Ranikhet on the same booking if needed.',
'shimla'=>'The Shimla route climbs via Solan; the last stretch is a winding ghat road, so we start early and drop you at the Mall Road taxi stand or your hotel.',
'manali'=>'Manali is a long scenic drive through Mandi and Kullu; for comfort we can plan an overnight halt at Mandi or Bilaspur on the way up.',
'tehri'=>'The Tehri road gives wide views of the Tehri Lake; we stop at the best viewpoints and drop you at your lakeside resort or the dam point.',
'uttarkashi'=>'Uttarkashi follows the Bhagirathi deep into Garhwal; the road is good but narrow at river bends, so our hill drivers take those stretches slow.',
'srinagar-garhwal'=>'Srinagar Garhwal sits on the Char Dham highway and is a common lunch halt; we can drop you in town or carry on to Kedarnath or Badrinath.',
'delhi'=>'Delhi drops are planned terminal by terminal for the airport and area by area for the city, using the ring road to dodge the worst junctions.',
'haridwar'=>'For Haridwar we time the drop around the Ganga Aarti and use the taxi stand near the bridge when the ghats are closed to vehicles.',
'rishikesh'=>'Rishikesh has vehicle limits at the jhulas; we drop you at the nearest permitted point and guide the short walk to your ashram or resort.',
'mussoorie'=>'The Mussoorie climb is short but busy on weekends; an early start from the plains saves time and we drop you near Picture Palace or your hotel.',
'nainital'=>'The final climb from Bhowali to Nainital is steep and narrow; our hill drivers take it carefully and drop you at Mall Road or Tallital.',
'auli'=>'The Auli road above Joshimath is steep and often snowy in winter; we use a chain-ready Innova and confirm the snow condition before the climb.',
'chakrata'=>'Chakrata is a quiet forested ridge via Tiger Falls; the last stretch has almost no traffic, making it a calm and scenic drive.',
'chopta'=>'Chopta is the base for the Tungnath trek; we drop you at the Chopta parking, from where the temple is a paved 3.5 km walk uphill.',
'kanatal'=>'Kanatal sits on a quiet ridge above the Mussoorie road; the drive is peaceful and we drop you right at your camp or resort.',
'dhanaulti'=>'Dhanaulti is a crowd-free deodar ridge; we drop you near Eco Park or the Surkanda Devi base and can return you via Mussoorie.',
'chandigarh'=>'The Chandigarh run is mostly open highway; we drop you at the sector, the ISBT or the railway station with a smooth and fast ride.',
'agra'=>'The Agra route uses the Yamuna Expressway for the Taj visit; we can hold the cab for a few hours at the monument on a round trip.',
'mathura'=>'For Mathura and Vrindavan we time the arrival to miss the evening temple traffic and drop you at your hotel or the temple lane.',
'jim-corbett'=>'Corbett drops go to your resort and the safari gate; we time the departure so you reach in time for the evening safari briefing.',
'kedarnath'=>'The road ends at Sonprayag and Gaurikund; from there it is trek or helicopter, and we handle the Sonprayag check and your luggage transfer.',
'badrinath'=>'The Badrinath drive passes the narrow Joshimath stretch; we leave early to beat the afternoon convoy rules and drop you at the temple parking.',
'gangotri'=>'Gangotri follows the Bhagirathi through the Harsil valley; the road is scenic and narrow near the temple, so we drop you at the main parking.',
'yamunotri'=>'The road ends at Janki Chatti; from there it is a 6 km trek or pony ride, and we drop you at the parking and help arrange a pony if needed.',
'joshimath'=>'Joshimath is the last road head for Auli; the climb is steep and we drop you at the market or your hotel, ready for the snow road next day.',
'almora'=>'Almora sits on a crescent shaped Kumaon ridge above the Kosi valley; after the plains run we climb the final ghat stretch via Bhowali and drop you near Mall Road, Bright End Corner or your hotel, with Kausani and Jageshwar detours easy to add on the same booking.',
'ranikhet'=>'Ranikhet is a quiet cantonment ridge with the Chaubatia orchards and golf links; we climb via the Khairna bridge turn and drop you near the Mall Road or your Kumaon resort.',
'kausani'=>'Kausani gives a straight-on sunrise view of Nanda Devi and Trishul; the last climb branches at Baijnath and we drop you at the viewpoint hotels above the Someshwar valley.',
'pithoragarh'=>'Pithoragarh sits in the Soar valley near the Nepal border; it is a long Kumaon run, so we plan an early start and a comfort halt at Chaukhutia on the way.',
'rudraprayag'=>'Rudraprayag is the confluence of the Alaknanda and Mandakini and the fork for Kedarnath and Badrinath; we drop you at the sangam ghat or your yatra-highway hotel.',
'devprayag'=>'Devprayag is the first sacred confluence above Rishikesh where the Bhagirathi meets the Alaknanda; the temple sits right on the highway, making it an easy half-day drop.',
'pauri'=>'Pauri overlooks the Garhwal hills from a high ridge above Kandolia; the climb leaves the highway at Shivpuri and we drop you near the Mall or your circuit house stay.',
'lansdowne'=>'Lansdowne is a peaceful Garhwal cantonment reached via the Kotdwar plains; the final climb is gentle and we drop you at the parade ground or your pine-view hotel.',
'ramnagar'=>'Ramnagar is the gate of Corbett National Park; we drop you at the Bijrani or Dhikala gate side hotels and can time the run for the afternoon safari briefing.',
'meerut'=>'Meerut is a fast plains run on the Delhi bypass side; we drop you at the cantonment, the university or your address without entering Delhi traffic.',
'bareilly'=>'Bareilly is a straight run east on NH9 through Rampur; we drop you at the city centre, the station or your address with a planned halt near Moradabad.',
);
return isset($FACT[$to_key]) ? $FACT[$to_key] : '';
}
function anaya_v2_highlights($t, $to) {
static $H = array(
'pilgrim'=>array(array('fa-place-of-worship','Temple-area drop','Door-to-temple-area drop with a calm, planned schedule.'),array('fa-mountain-sun','Scenic valley drive','Confluences and mountain views along the route.'),array('fa-bed','Overnight halt','A sensible break before the final climb.'),array('fa-clipboard-check','Yatra logistics','Registration, road-timing and buffer-day advice.')),
'snow'=>array(array('fa-snowflake','Snow-belt climb','Drivers trained for ice, fog and chain conditions.'),array('fa-mountain-sun','Himalayan views','Clear-weather panoramas of the high peaks.'),array('fa-van-shuttle','Innova advised','Ground clearance and stability on the snow road.'),array('fa-bed','Overnight halt','A comfortable break before the final climb.')),
'wildlife'=>array(array('fa-paw','Safari-gate drop','Direct to resort and safari-gate entrances.'),array('fa-tree','Forest corridor','A green, scenic approach to the park.'),array('fa-binoculars','Sightings en route','Watch for wildlife on the forest stretch.'),array('fa-bed','Resort check-in','Door-to-resort drop with luggage care.')),
'river'=>array(array('fa-water','Riverside route','Ghats, ashrams and the river along the way.'),array('fa-place-of-worship','Pilgrimage stops','Temples and aarti points on request.'),array('fa-person-swimming','Adventure add-ons','Rafting and yoga-camp drops available.'),array('fa-clock','Flexible timing','Plan around aarti and check-in times.')),
'highway'=>array(array('fa-road','Open highway','Mostly expressway for a fast, smooth drive.'),array('fa-plane-departure','Airport-side drops','Direct to IGI terminal or city hotels.'),array('fa-clock','Early-start advised','Beat the traffic for the best travel time.'),array('fa-van-shuttle','Long-drive comfort','Innova or Crysta for a relaxed long drive.')),
'hill'=>array(array('fa-mountain-sun','Scenic hill road','Winding ghat sections driven with extra care.'),array('fa-camera','Viewpoints and falls','Stops at the popular lookouts and waterfalls.'),array('fa-van-shuttle','Hill-ready vehicles','SUV and Innova options for the climb.'),array('fa-cloud-sun-rain','Weather-aware driving','Caution planned for monsoon and winter fog.')),
);
$out = isset($H[$t]) ? $H[$t] : $H['hill'];
$out[0][1] = $out[0][1] . ' to ' . $to;
return $out;
}
function anaya_v2_timeline($from, $to, $t) {
if ($t === 'pilgrim') return array(array('fa-circle-dot','Pickup in ' . $from,'We collect you from your ' . $from . ' hotel, home or station and begin the yatra route.'),array('fa-water','River valleys','The drive follows the river valleys with confluences and mountain views.'),array('fa-bed','Overnight halt','A sensible overnight stop is planned before the final climb.'),array('fa-place-of-worship','Temple area drop','We drop you at the temple area or permitted roadhead.'));
if ($t === 'hill' || $t === 'snow') return array(array('fa-circle-dot','Pickup in ' . $from,'Collected from your ' . $from . ' location at the agreed time.'),array('fa-road','Plains to hill approach','The gradient begins to rise as we leave the valley.'),array('fa-mountain','Ghat climb','Winding sections driven carefully by an experienced hill driver.'),array('fa-location-dot','Drop at ' . $to,'Dropped at your hotel or sightseeing point in ' . $to . '.'));
return array(array('fa-circle-dot','Pickup in ' . $from,'Door-to-door pickup from your ' . $from . ' location.'),array('fa-road','Highway stretch','A fast, smooth open-road run.'),array('fa-mug-hot','Comfort stop','A planned break on longer drives.'),array('fa-location-dot','Drop at ' . $to,'Dropped at your hotel or address in ' . $to . '.'));
}
function anaya_v2_related($slug, $t) {
static $P = array(
'pilgrim'=>array(array('dehradun-to-kedarnath-taxi','Dehradun to Kedarnath'),array('dehradun-to-badrinath-taxi','Dehradun to Badrinath'),array('dehradun-to-gangotri-taxi','Dehradun to Gangotri'),array('dehradun-to-yamunotri-taxi','Dehradun to Yamunotri'),array('char-dham-yatra-taxi','Char Dham Yatra'),array('dehradun-to-rishikesh-taxi','Dehradun to Rishikesh')),
'snow'=>array(array('dehradun-to-auli-taxi','Dehradun to Auli'),array('dehradun-to-chopta-taxi','Dehradun to Chopta'),array('dehradun-to-badrinath-taxi','Dehradun to Badrinath'),array('dehradun-to-kedarnath-taxi','Dehradun to Kedarnath'),array('dehradun-to-mussoorie-taxi','Dehradun to Mussoorie'),array('dehradun-to-joshimath-taxi','Dehradun to Joshimath')),
'wildlife'=>array(array('dehradun-to-jim-corbett-taxi','Dehradun to Jim Corbett'),array('dehradun-to-ramnagar-taxi','Dehradun to Ramnagar'),array('dehradun-to-nainital-taxi','Dehradun to Nainital'),array('dehradun-to-haldwani-taxi','Dehradun to Haldwani'),array('dehradun-to-rishikesh-taxi','Dehradun to Rishikesh'),array('dehradun-to-delhi-taxi','Dehradun to Delhi'),array('dehradun-to-mussoorie-taxi','Dehradun to Mussoorie')),
'river'=>array(array('dehradun-to-haridwar-taxi','Dehradun to Haridwar'),array('dehradun-to-rishikesh-taxi','Dehradun to Rishikesh'),array('dehradun-to-mathura-taxi','Dehradun to Mathura'),array('dehradun-to-kedarnath-taxi','Dehradun to Kedarnath'),array('dehradun-to-delhi-taxi','Dehradun to Delhi'),array('dehradun-to-mussoorie-taxi','Dehradun to Mussoorie')),
'highway'=>array(array('dehradun-to-delhi-taxi','Dehradun to Delhi'),array('dehradun-to-chandigarh-taxi','Dehradun to Chandigarh'),array('dehradun-to-noida-taxi','Dehradun to Noida'),array('dehradun-to-gurgaon-taxi','Dehradun to Gurgaon'),array('dehradun-to-agra-taxi','Dehradun to Agra'),array('dehradun-to-haridwar-taxi','Dehradun to Haridwar')),
'hill'=>array(array('dehradun-to-mussoorie-taxi','Dehradun to Mussoorie'),array('dehradun-to-dhanaulti-taxi','Dehradun to Dhanaulti'),array('dehradun-to-chakrata-taxi','Dehradun to Chakrata'),array('dehradun-to-kanatal-taxi','Dehradun to Kanatal'),array('dehradun-to-nainital-taxi','Dehradun to Nainital'),array('dehradun-to-auli-taxi','Dehradun to Auli'),array('dehradun-to-almora-taxi','Dehradun to Almora')),
);
$list = isset($P[$t]) ? $P[$t] : (isset($P['hill']) ? $P['hill'] : array());
$out = array();
foreach ($list as $r) { if ($r[0] !== $slug) { $out[] = $r; if (count($out) >= 7) break; } }
return $out;
}
function anaya_v2_prose($svc, $t, $to, $from, $to_key) {
if ($t === 'highway') $word = 'a comfortable, mostly open-highway run';
elseif ($t === 'pilgrim') $word = 'a sacred, well-planned mountain journey';
else $word = 'a scenic, carefully driven route';
$fact = anaya_v2_fact($to_key);
$fact_sentence = $fact !== '' ? ' ' . anaya_v2_h($fact) : '';
$p1 = '<h2 style="font-size:1.3rem;margin:0 0 12px;">Route overview</h2><p style="color:var(--slate);line-height:1.7;margin:0 0 14px;">The ' . $svc . ' from ' . anaya_v2_h($from) . ' to ' . anaya_v2_h($to) . ' is ' . $word . '.' . $fact_sentence . ' Anaya Cab Service assigns a police-verified driver who knows this exact road, the halts and the drop points, with the fare fixed and shared before you travel and tolls, parking and any night or hill charges explained upfront.</p>';
$p2 = '<p style="color:var(--slate);line-height:1.7;margin:0;">Travelling with family or extra luggage from ' . anaya_v2_h($from) . '? An Innova or Crysta makes the journey to ' . anaya_v2_h($to) . ' more comfortable, and a Tempo Traveller can be arranged with advance notice for groups. From the first call to the final drop, the same accountable team handles pickup timing, route planning and 24x7 support.</p>';
return array($p1, $p2);
}
function anaya_v2_notes($to, $from, $to_key, $km, $time, $fare) {
$fact = anaya_v2_fact($to_key);
if ($fact === '') { $fact = 'Our drivers run the ' . $to . ' road regularly and plan the ' . $from . ' pickup around traffic, so you leave on time and reach without surprises.'; }
$li_open = '<li style="position:relative;padding-left:24px;color:var(--slate);line-height:1.65;margin:0 0 8px;">';
$dot = '<span style="position:absolute;left:2px;top:.6em;width:7px;height:7px;border-radius:2px;background:var(--ac);"></span>';
$h  = '<h2 style="font-family:Sora,Poppins,sans-serif;font-size:1.3rem;font-weight:800;letter-spacing:-.02em;margin:34px 0 12px;">Route notes &mdash; ' . anaya_v2_h($from) . ' to ' . anaya_v2_h($to) . '</h2>';
$h .= '<p style="color:var(--slate);line-height:1.7;margin:0 0 14px;">' . anaya_v2_h($fact) . '</p>';
$h .= '<ul style="list-style:none;padding-left:0;margin:0;">';
if ($km) { $h .= $li_open . $dot . 'Roughly ' . (int)$km . ' km and about ' . anaya_v2_h($time) . ' door to door, depending on the exact pickup in ' . anaya_v2_h($from) . ' and the drop in ' . anaya_v2_h($to) . '.</li>'; }
else { $h .= $li_open . $dot . 'Travel time is confirmed when you book, based on the pickup in ' . anaya_v2_h($from) . ' and the drop in ' . anaya_v2_h($to) . '.</li>'; }
if ($fare) { $h .= $li_open . $dot . 'A sedan starts from around Rs ' . number_format($fare) . '; an Innova or SUV costs a little more and is agreed before you travel.</li>'; }
else { $h .= $li_open . $dot . 'Fare is quoted for your date and vehicle before you book, with no hidden charges.</li>'; }
$h .= $li_open . $dot . 'Pickup in ' . anaya_v2_h($from) . ' is from your home, hotel, station or airport, and the drop in ' . anaya_v2_h($to) . ' is at your exact address.</li>';
$h .= '</ul>';
return $h;
}
function anaya_v2_entry($slug) {
$labels = isset($GLOBALS['ROUTE_PLACE_LABELS']) && is_array($GLOBALS['ROUTE_PLACE_LABELS']) ? $GLOBALS['ROUTE_PLACE_LABELS'] : array();
$from = ''; $to = ''; $dir = 'pkg'; $from_raw = false; $to_raw = false; $to_key = '';
if (preg_match('/^(.+)-to-(.+)-taxi$/', $slug, $m)) {
$from_key = $m[1]; $to_key = $m[2];
$from = isset($labels[$from_key]) ? $labels[$from_key] : ucwords(str_replace('-', ' ', $from_key));
$to   = isset($labels[$to_key])   ? $labels[$to_key]   : ucwords(str_replace('-', ' ', $to_key));
$from_raw = true; $to_raw = true;
if ($to_key === 'dehradun') $dir = 'in'; elseif ($from_key === 'dehradun') $dir = 'out'; else $dir = 'cross';
} else {
$to_key = preg_replace('/-taxi$/', '', $slug);
$to = isset($labels[$to_key]) ? $labels[$to_key] : ucwords(str_replace('-', ' ', $to_key));
$to_raw = ($to !== '');
}
$from_disp = $from !== '' ? $from : 'Dehradun';
$theme = anaya_v2_theme($to_key);
$ts = anaya_v2_theme_style($theme);
$km = ($dir === 'in') ? null : anaya_v2_km($to_key);
$fare = anaya_v2_fare($to_key);
$time = anaya_v2_time($km);
if ($from !== '' && $to !== '') $svc = $from . ' to ' . $to . ' Taxi';
elseif ($to !== '') $svc = $to . ' Taxi';
else $svc = 'Taxi Service';
if ($fare) $fare_lead = 'One-way sedan fare starts from Rs ' . number_format($fare) . '.';
else $fare_lead = 'Fare is a custom quote based on vehicle, duration and season.';
if ($km) $km_time = ' Distance about ' . $km . ' km, travel time around ' . $time . '.';
else $km_time = '';
$lead = 'Book ' . $svc . ' with Anaya Cab Service. ' . $fare_lead . $km_time . ' Verified drivers, clean AC cars and 24x7 booking.';
if ($fare) $a1 = 'A one-way sedan fare usually starts from around Rs ' . number_format($fare) . ', with SUV and Innova fares a little higher and confirmed before you book.';
else $a1 = 'Pricing is shared as a custom quote because it depends on vehicle, duration and route conditions. Call or WhatsApp for a confirmed fare.';
if ($km) $a2 = 'The distance is about ' . $km . ' km and the drive usually takes ' . $time . ', depending on traffic, weather and pickup point.';
else $a2 = 'Travel time and distance depend on the chosen route and conditions, and our driver plans the best path when you book.';
if ($theme === 'pilgrim') { $q3 = 'Do I need to register for this yatra?'; $a3 = 'Yes, yatra registration is required and our drivers help plan around checkpoints, road timings and buffer days for a smooth darshan.'; }
elseif ($theme === 'hill' || $theme === 'snow') { $q3 = 'Is the ' . $to . ' road safe in monsoon and winter?'; $a3 = 'Our drivers know the ' . $to . ' hill road well and drive with extra caution in rain, fog and snow; we recommend an Innova or Crysta in winter.'; }
else { $q3 = 'Can I book a one-way or round-trip taxi?'; $a3 = 'Yes, one-way, round-trip and multi-day bookings are available with the same verified driver and vehicle, subject to availability.'; }
if ($theme === 'hill' || $theme === 'snow' || $theme === 'pilgrim') $a4 = 'An Innova or Crysta is recommended for the ' . $to . ' route, with an Ertiga or SUV for budget family travel and a Tempo Traveller for groups.';
else $a4 = 'A sedan is comfortable and economical for two to three travellers, while an Ertiga, Innova or Crysta suits families with luggage.';
$faqs = array(
array('What is the taxi fare for ' . $svc . '?', $a1),
array('How far is the route and how long does it take?', $a2),
array($q3, $a3),
array('Which vehicle is best for ' . $svc . '?', $a4),
);
return array('slug'=>$slug,'svc'=>$svc,'from'=>$from,'to'=>$to,'from_raw'=>$from_raw,'to_raw'=>$to_raw,'dir'=>$dir,'theme'=>$theme,'km'=>$km,'time'=>$time,'sedan_from'=>$fare,'lead'=>$lead,'faqs'=>$faqs,'ac'=>$ts[0],'ac2'=>$ts[1],'d1'=>$ts[2],'d2'=>$ts[3],'tint'=>$ts[4],'char_icon'=>$ts[5],'highlights'=>anaya_v2_highlights($theme,$to),'timeline'=>anaya_v2_timeline($from_disp,$to,$theme),'prose'=>anaya_v2_prose($svc,$theme,$to,$from_disp,$to_key),'notes'=>anaya_v2_notes($to,$from_disp,$to_key,$km,$time,$fare));
}
function anaya_v2_css() {
return '.rv2-wrap{--ac:#0057ff;--ac2:#00c2ff;--d1:#03102e;--d2:#0a2a63;--tint:#eaf1ff;--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;position:relative;overflow:hidden;font-family:Plus Jakarta Sans,system-ui,sans-serif;color:var(--ink);background:linear-gradient(180deg,#eef3fb,#fff 460px)}'
. '.rv2-wrap *{box-sizing:border-box}'
. '.rv2-top{position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--ac),var(--ac2),var(--ac));background-size:200% 100%;animation:rv2slide 6s linear infinite;z-index:3}'
. '@keyframes rv2slide{to{background-position:200% 0}}'
. '.rv2-glow{position:absolute;top:-120px;right:-80px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac) 16%,transparent),transparent 70%);pointer-events:none}'
. '.rv2-hero-bg{position:absolute;top:0;left:0;right:0;height:620px;z-index:0;overflow:hidden;pointer-events:none}'
. '.rv2-hero-bg img{width:100%;height:100%;object-fit:cover;object-position:center 42%;opacity:.9;filter:saturate(1.06)}'
. '.rv2-hero-veil{position:absolute;inset:0;background:linear-gradient(90deg,rgba(247,250,255,.88) 0%,rgba(247,250,255,.45) 52%,rgba(247,250,255,.12) 100%),linear-gradient(180deg,rgba(247,250,255,.3) 0%,rgba(247,250,255,.6) 55%,#fff 92%)}'
. '.rv2-in{position:relative;z-index:2;max-width:1180px;margin:0 auto;padding:0 22px}'
. '.rv2-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:30px 0 10px}'
. '.rv2-ey{display:inline-flex;align-items:center;gap:8px;background:var(--tint);color:var(--ac);border:1px solid color-mix(in srgb,var(--ac) 28%,#fff);border-radius:999px;padding:7px 14px;font-weight:800;font-size:.74rem;text-transform:uppercase;letter-spacing:.05em}'
. '.rv2-h1{font-family:Sora,Poppins,sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:14px 0}'
. '.rv2-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:54ch;margin:0 0 16px}.rv2-lead strong{color:var(--ink)}'
. '.rv2-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 6px}'
. '.rv2-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px;box-shadow:0 4px 14px rgba(10,22,51,.05);transition:transform .25s,box-shadow .25s}.rv2-m:hover{transform:translateY(-3px);box-shadow:0 12px 24px rgba(10,22,51,.12)}'
. '.rv2-m i{color:var(--ac)}.rv2-m b{font-family:Sora,Poppins,sans-serif;font-weight:800}.rv2-m span{font-size:.76rem;color:var(--slate)}'
. '.rv2-card{border-top:4px solid var(--ac);border-radius:24px;overflow:hidden;background:linear-gradient(160deg,var(--d1),var(--d2));color:#fff;padding:24px;box-shadow:0 30px 60px -28px rgba(3,16,46,.6);position:sticky;top:88px}'
. '.rv2-live{display:inline-flex;align-items:center;gap:7px;font-size:.72rem;font-weight:800;color:#9fe0ff;margin-bottom:10px}.rv2-live::before{content:"";width:7px;height:7px;border-radius:50%;background:#38d6f0;animation:rv2p 1.8s infinite}'
. '@keyframes rv2p{0%{box-shadow:0 0 0 0 rgba(56,214,240,.5)}70%{box-shadow:0 0 0 7px rgba(56,214,240,0)}100%{box-shadow:0 0 0 0 rgba(56,214,240,0)}}'
. '.rv2-card h3,.rv2-card-title{font-family:Sora,Poppins,sans-serif;font-size:1.2rem;font-weight:800;margin:0 0 12px}'
. '.rv2-fr{display:flex;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px;margin-bottom:8px}.rv2-fr .v{font-weight:700;font-size:.9rem}.rv2-fr .p{font-family:Sora,Poppins,sans-serif;font-weight:800}'
. '.rv2-card .btns{display:grid;gap:10px;margin-top:14px}.rv2-card .btns a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:Sora,Poppins,sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}.rv2-card .btns .w{background:#fff;color:#0a2a63}.rv2-card .btns .g{background:#25d366;color:#04260f}.rv2-card .btns a:hover{transform:translateY(-2px)}'
. '.rv2-cover{position:relative;margin:6px 0 0;border-radius:22px;overflow:hidden;box-shadow:0 24px 50px -28px rgba(9,32,84,.42);background:linear-gradient(135deg,var(--d1),var(--d2));min-height:200px}'
. '.rv2-cover img{width:100%;height:360px;object-fit:cover;display:block;transition:transform .6s ease}'
. '.rv2-cover:hover img{transform:scale(1.03)}'
. '.rv2-cover-fb{display:none;position:absolute;inset:0;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:rgba(255,255,255,.92);background:radial-gradient(120% 120% at 30% 0%,color-mix(in srgb,var(--ac) 40%,var(--d1)),var(--d2))}'
. '.rv2-cover-fb i{font-size:3rem;color:color-mix(in srgb,var(--ac2) 82%,#fff);filter:drop-shadow(0 8px 16px rgba(0,0,0,.35))}'
. '.rv2-cover-fb span{font-family:Sora,Poppins,sans-serif;font-weight:800;font-size:1.1rem;letter-spacing:-.01em}'
. '@media(max-width:640px){.rv2-cover img{height:220px}.rv2-cover{min-height:160px}}'
. '.rv2-sec{padding:46px 0}.rv2-sh{text-align:center;max-width:680px;margin:0 auto 26px}.rv2-sh .ey{display:inline-flex;align-items:center;gap:8px;background:var(--tint);color:var(--ac);border-radius:999px;padding:7px 13px;font-weight:700;font-size:.72rem;text-transform:uppercase;letter-spacing:.1em}.rv2-sh h2{font-family:Sora,Poppins,sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.rv2-sh p{color:var(--slate);margin:0}'
. '.rv2-tw{background:#fff;border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:0 24px 50px -30px rgba(9,32,84,.25)}.rv2-ts{overflow-x:auto}.rv2-tbl{width:100%;border-collapse:collapse;min-width:480px}.rv2-tbl th{background:var(--ink);color:#fff;text-align:left;padding:13px 16px;font-weight:700;white-space:nowrap}.rv2-tbl td{padding:13px 16px;border-top:1px solid var(--line)}.rv2-tbl tr:hover td{background:var(--tint)}'
. '.rv2-hl{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}.rv2-hc{background:#fff;border:1px solid var(--line);border-radius:20px;padding:22px;transition:transform .3s,box-shadow .3s}.rv2-hc:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3)}.rv2-hc .ic{width:48px;height:48px;border-radius:13px;background:var(--tint);color:var(--ac);display:grid;place-items:center;font-size:1.1rem;margin-bottom:12px}.rv2-hc h3{font-family:Sora,Poppins,sans-serif;font-size:1.02rem;font-weight:700;margin:0 0 5px}.rv2-hc p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}'
. '.rv2-tl{max-width:780px;margin:0 auto}.rv2-tr{display:grid;grid-template-columns:46px 1fr;gap:16px;padding:0 0 16px}.rv2-tr .d{width:46px;height:46px;border-radius:13px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--ac);box-shadow:0 8px 18px -10px rgba(0,87,255,.3)}.rv2-tr .b{background:#fff;border:1px solid var(--line);border-radius:15px;padding:14px 17px}.rv2-tr .b h3{font-family:Sora,Poppins,sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.rv2-tr .b p{margin:0;color:var(--slate);font-size:.87rem}'
. '.rv2-rel{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}.rv2-rc{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:11px 18px;font-weight:600;font-size:.9rem;color:var(--ink);text-decoration:none;transition:.25s}.rv2-rc i{color:var(--ac)}.rv2-rc:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-2px)}'
. '.rv2-faq{max-width:780px;margin:0 auto}.rv2-fi{background:#fff;border:1px solid var(--line);border-radius:14px;margin-bottom:11px;overflow:hidden}.rv2-fq{padding:15px 18px;font-weight:700;cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:12px}.rv2-ft{color:var(--ac);font-weight:800;transition:transform .25s}.rv2-fi.open .rv2-ft{transform:rotate(45deg)}.rv2-fa{display:none;padding:0 18px 16px;color:var(--slate);line-height:1.65}.rv2-fi.open .rv2-fa{display:block}'
. '.rv2-cta{padding:0 0 64px}.rv2-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--ac),transparent 55%),linear-gradient(120deg,var(--d1),var(--d2));color:#fff;text-align:center;padding:48px 24px}.rv2-cta h2{font-family:Sora,Poppins,sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);margin:0 0 8px}.rv2-cta p{color:rgba(255,255,255,.84);margin:0 0 20px}.rv2-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.rv2-cta a{display:inline-flex;align-items:center;gap:9px;font-family:Sora,Poppins,sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}.rv2-cta .w{background:#fff;color:var(--d1)}.rv2-cta .g{background:#25d366;color:#04260f}.rv2-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.rv2-cta a:hover{transform:translateY(-2px)}'
. '.rv2-rv{opacity:0;transform:translateY(22px);transition:opacity .7s ease,transform .7s ease}.rv2-rv.in{opacity:1;transform:none}'
. '@media(max-width:900px){.rv2-hero{grid-template-columns:1fr;gap:24px}.rv2-card{position:static}.rv2-hero-bg{height:480px}}'
. '@media(prefers-reduced-motion:reduce){.rv2-wrap *{animation:none!important;transition:none!important}.rv2-rv{opacity:1!important;transform:none!important}}';
}
function anaya_v2_render($e) {
$GLOBALS['__route_schema_handled'] = true;
$allow = isset($GLOBALS['ROUTE_SERVICE_ALLOW']) && is_array($GLOBALS['ROUTE_SERVICE_ALLOW']) ? $GLOBALS['ROUTE_SERVICE_ALLOW'] : array();
$emit_svc = !in_array($e['slug'], $allow, true);
$graph = array();
if ($emit_svc) {
$as = array();
if ($e['from_raw']) $as[] = array('@type'=>'City','name'=>$e['from']);
if ($e['to_raw'])   $as[] = array('@type'=>'City','name'=>$e['to']);
$svc_node = array('@type'=>'Service','@id'=>SITE_DOMAIN.'/'.$e['slug'].'#service','name'=>$e['svc'],'serviceType'=>'One-way and round-trip taxi service','provider'=>array('@id'=>SITE_DOMAIN.'/#taxi-service'),'areaServed'=>array_values($as),'url'=>SITE_DOMAIN.'/'.$e['slug']);
if ($e['sedan_from']) {
$svc_node['offers'] = array('@type'=>'Offer','url'=>SITE_DOMAIN.'/'.$e['slug'],'priceCurrency'=>'INR','price'=>(string)$e['sedan_from'],'availability'=>'https://schema.org/InStock','description'=>$e['svc'].' one-way sedan fare starts from Rs '.number_format($e['sedan_from']).'. Toll, parking and hill charges extra where applicable.');
}
$graph[] = $svc_node;
}
$faq_ent = array();
foreach ($e['faqs'] as $f) { $faq_ent[] = array('@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>array('@type'=>'Answer','text'=>$f[1])); }
$graph[] = array('@type'=>'FAQPage','@id'=>SITE_DOMAIN.'/'.$e['slug'].'#faq','mainEntity'=>$faq_ent);
echo '<script type="application/ld+json">' . json_encode(array('@context'=>'https://schema.org','@graph'=>$graph), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
echo '<style>' . anaya_v2_css() . '</style>';
$T_svc  = anaya_v2_h($e['svc']);
$T_to   = anaya_v2_h($e['to']);
$T_from = anaya_v2_h($e['from']);
$T_lead = anaya_v2_h($e['lead']);
$ac  = anaya_v2_h($e['ac']);  $ac2 = anaya_v2_h($e['ac2']);
$d1  = anaya_v2_h($e['d1']);  $d2  = anaya_v2_h($e['d2']);  $tint = anaya_v2_h($e['tint']);
$ci  = anaya_v2_h($e['char_icon']);
/* v3.0: top hero background — route image, fallback hero-bg.webp */
$bg_src = '/assets/images/routes/' . $e['slug'] . '.webp';
if (!file_exists(dirname(__DIR__) . $bg_src)) { $bg_src = '/assets/images/hero-bg.webp'; }
echo '<div class="rv2-wrap" style="--ac:' . $ac . ';--ac2:' . $ac2 . ';--d1:' . $d1 . ';--d2:' . $d2 . ';--tint:' . $tint . ';">';
echo '<span class="rv2-top" aria-hidden="true"></span><div class="rv2-glow" aria-hidden="true"></div>';
echo '<div class="rv2-hero-bg" aria-hidden="true"><img src="' . anaya_v2_h($bg_src) . '" alt="" decoding="async" onerror="this.onerror=null;this.src=\'/assets/images/hero-bg.webp\';"><span class="rv2-hero-veil"></span></div>';
echo '<div class="rv2-in">';
echo '<section class="rv2-hero">';
echo '<div class="rv2-rv"><span class="rv2-ey"><i class="fa-solid ' . $ci . '"></i> ' . $T_to . '</span>';
echo '<h1 class="rv2-h1">' . $T_svc . '</h1>';
echo '<p class="rv2-lead"><strong>' . $T_lead . '</strong></p>';
echo '<div class="rv2-metrics">';
if ($e['km'])   echo '<span class="rv2-m"><i class="fa-solid fa-road"></i><b>~' . (int)$e['km'] . ' km</b><span>distance</span></span>';
if ($e['time']) echo '<span class="rv2-m"><i class="fa-regular fa-clock"></i><b>' . anaya_v2_h($e['time']) . '</b><span>travel time</span></span>';
echo '<span class="rv2-m"><i class="fa-solid ' . $ci . '"></i><b>' . $T_to . '</b><span>destination</span></span>';
echo '<span class="rv2-m"><i class="fa-solid fa-indian-rupee-sign"></i><b>' . ($e['sedan_from'] ? ('Rs ' . number_format($e['sedan_from']) . '+') : 'Quote') . '</b><span>sedan</span></span>';
echo '</div></div>';
echo '<aside class="rv2-card rv2-rv"><span class="rv2-live">Live fare desk</span><div class="rv2-card-title">' . ($T_from ? ($T_from . ' to ' . $T_to) : $T_to) . '</div>';
echo '<div class="rv2-fr"><span class="v">Sedan</span><span class="p">' . ($e['sedan_from'] ? ('Rs ' . number_format($e['sedan_from']) . ' - ' . number_format((int)round($e['sedan_from']*1.3))) : 'On request') . '</span></div>';
echo '<div class="rv2-fr"><span class="v">SUV / Innova</span><span class="p">' . ($e['sedan_from'] ? ('Rs ' . number_format((int)round($e['sedan_from']*1.3)) . ' - ' . number_format((int)round($e['sedan_from']*1.5))) : 'On request') . '</span></div>';
echo '<div class="rv2-fr"><span class="v">Tempo Traveller</span><span class="p">On request</span></div>';
echo '<div class="btns"><a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>';
echo '<a class="g" href="https://wa.me/' . BUSINESS_WHATSAPP . '?text=' . rawurlencode('Hi Anaya Cab, I want to book ' . $e['svc'] . '.') . '" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a></div>';
echo '</aside></section>';
echo '<figure class="rv2-cover rv2-rv"><img src="/assets/images/routes/' . anaya_v2_h($e['slug']) . '.webp" alt="' . anaya_v2_h($e['svc'] . ' route taxi from Dehradun') . '" width="1180" height="440" loading="lazy" decoding="async" onerror="this.style.display=\'none\';var f=this.nextElementSibling;if(f)f.style.display=\'flex\'"><figcaption class="rv2-cover-fb"><i class="fa-solid ' . $ci . '"></i><span>' . $T_svc . '</span></figcaption></figure>';
echo '<section class="rv2-sec rv2-rv"><div class="rv2-sh"><span class="ey"><i class="fa-solid fa-star"></i> Highlights</span><h2>What makes this route worth the drive</h2></div><div class="rv2-hl">';
foreach ($e['highlights'] as $hl) {
echo '<div class="rv2-hc"><span class="ic"><i class="fa-solid ' . anaya_v2_h($hl[0]) . '"></i></span><h3>' . anaya_v2_h($hl[1]) . '</h3><p>' . anaya_v2_h($hl[2]) . '</p></div>';
}
echo '</div></section>';
echo '<section class="rv2-sec rv2-rv"><div class="rv2-sh"><span class="ey"><i class="fa-solid fa-route"></i> The journey</span><h2>How the ' . $T_svc . ' works</h2></div><div class="rv2-tl">';
foreach ($e['timeline'] as $tr) {
echo '<div class="rv2-tr"><span class="d"><i class="fa-solid ' . anaya_v2_h($tr[0]) . '"></i></span><div class="b"><h3>' . anaya_v2_h($tr[1]) . '</h3><p>' . anaya_v2_h($tr[2]) . '</p></div></div>';
}
echo '</div></section>';
echo '<section class="rv2-sec rv2-rv"><div class="rv2-in-prose" style="max-width:780px;margin:0 auto;">';
foreach ($e['prose'] as $p) { echo $p; }
echo $e['notes'];
echo '</div></section>';
$related = anaya_v2_related($e['slug'], $e['theme']);
if ($related) {
echo '<section class="rv2-sec rv2-rv"><div class="rv2-sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2>Other taxis travellers book with this</h2></div><div class="rv2-rel">';
foreach ($related as $rl) { echo '<a class="rv2-rc" href="/' . anaya_v2_h($rl[0]) . '"><i class="fa-solid fa-location-dot"></i> ' . anaya_v2_h($rl[1]) . '</a>'; }
echo '</div></section>';
}
echo '<section class="rv2-sec rv2-rv"><div class="rv2-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2>' . $T_svc . ' - FAQs</h2></div><div class="rv2-faq">';
foreach ($e['faqs'] as $i => $f) {
echo '<div class="rv2-fi' . ($i === 0 ? ' open' : '') . '"><div class="rv2-fq">' . anaya_v2_h($f[0]) . '<span class="rv2-ft">+</span></div><div class="rv2-fa">' . anaya_v2_h($f[1]) . '</div></div>';
}
echo '</div></section>';
echo '<section class="rv2-cta rv2-rv"><div class="rv2-ctain"><h2>Ready to book the ' . $T_svc . '?</h2><p>Share pickup, drop, date and vehicle - we confirm a transparent fare before the trip.</p><div class="row">';
echo '<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>';
echo '<a class="g" href="https://wa.me/' . BUSINESS_WHATSAPP . '?text=' . rawurlencode('Hi Anaya Cab, I want to book ' . $e['svc'] . '.') . '" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>';
echo '<a class="o" href="tel:' . BUSINESS_PHONE_TEL . '"><i class="fa-solid fa-phone"></i> Call ' . anaya_v2_h(BUSINESS_PHONE) . '</a>';
echo '</div></div></section>';
echo '</div></div>';
echo "<script>document.querySelectorAll('.rv2-fq').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});(function(){var els=document.querySelectorAll('.rv2-rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1});els.forEach(function(e){o.observe(e);});}else{els.forEach(function(e){e.classList.add('in');});}})();</script>";
}