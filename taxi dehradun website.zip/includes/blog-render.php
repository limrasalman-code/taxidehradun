<?php
/**
* Anaya Cab Service — includes/blog-render.php (v5.4 FULL — REVEAL THRESHOLD FIX)
* v5.4 fix: IntersectionObserver threshold .08 -> 0. Lambe posts (~19k chars) mein
*           .bp-body element itna ooncha tha ki 8% ratio kabhi cross nahi hota tha
*           -> .in class nahi lagti thi -> poora body opacity:0 (blank page).
*           Ab threshold:0 = 1 pixel dikhte hi reveal. + <noscript> fallback.
* v5.3: DB backfill (image_alt_N/images/content DB se) — alt wipe impossible.
* v5.2: parse-clean; {{img:N}} robust 1-indexed mapping; skip_qa figure-safe.
* CSS external (assets/css/blog-post.css). Tables + FAQ accordion + FAQPage +
* Quick Answer/Speakable (.bp-qa .aiBox) + og:image + in-article links.
*/
if (!defined('SITE_DOMAIN')) { require_once __DIR__ . '/config.php'; }
if (!function_exists('anaya_blog_dir')) { function anaya_blog_dir(){ return dirname(__DIR__) . '/blog'; } }
if (!function_exists('anaya_r_esc'))  { function anaya_r_esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); } }
if (!function_exists('anaya_r_abs'))  { function anaya_r_abs($u){ $u = trim((string)$u); return $u === '' ? '' : (strpos($u,'http')===0 ? $u : SITE_DOMAIN.$u); } }
if (!function_exists('anaya_r_inline')) {
function anaya_r_inline($t){
$t = anaya_r_esc($t);
$t = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $t);
$t = preg_replace('/\[(.+?)\]\((.+?)\)/', '<a href="$2">$1</a>', $t);
return $t;
} }
if (!function_exists('anaya_r_images')) {
function anaya_r_images(array $p){
$imgs = [];
for ($i = 1; $i <= 3; $i++) {
$src = trim((string)($p['image_'.$i] ?? ''));
if ($src !== '') { $imgs[$i] = ['src'=>anaya_r_abs($src), 'alt'=>trim((string)($p['image_alt_'.$i] ?? ''))]; }
}
return $imgs;
} }
if (!function_exists('anaya_r_figure')) {
function anaya_r_figure($img){
if (!$img || empty($img['src'])) return '';
return '<figure class="bp-fig"><img src="'.anaya_r_esc($img['src']).'" alt="'.anaya_r_esc($img['alt'] ?? '').'" loading="lazy" decoding="async"></figure>';
} }
if (!function_exists('anaya_r_only_figures')) {
function anaya_r_only_figures($text, $imgs){
$out = '';
if (preg_match_all('/\{\{img:\s*([1-3])\s*\}\}/', $text, $mm)) { foreach ($mm[1] as $nn) { $out .= anaya_r_figure($imgs[(int)$nn] ?? null); } }
return $out;
} }
if (!function_exists('anaya_r_tokens_to_figures')) {
function anaya_r_tokens_to_figures($text, $imgs){
$parts = preg_split('/(\{\{img:\s*[1-3]\s*\}\})/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
$out = '';
foreach ($parts as $part) {
if ($part === '') continue;
if (preg_match('/^\{\{img:\s*([1-3])\s*\}\}$/', $part, $mm)) { $out .= anaya_r_figure($imgs[(int)$mm[1]] ?? null); }
else { $out .= anaya_r_inline($part); }
}
return $out;
} }
if (!function_exists('anaya_r_strip_tokens')) { function anaya_r_strip_tokens($t){ return trim(preg_replace('/\{\{img:\s*[1-3]\s*\}\}/', '', $t)); } }
if (!function_exists('anaya_r_row')) {
function anaya_r_row($line){
$line = trim($line); $line = trim($line, '|'); $line = str_replace('\\|', "\x01", $line);
$cells = explode('|', $line);
return array_map(function($c){ $c = str_replace("\x01", '|', $c); return anaya_r_inline(trim($c)); }, $cells);
} }
/* ── v5.3: DB BACKFILL — missing/empty fields DB row se bharo (DB = source of truth) ── */
if (!function_exists('anaya_blog_merge_db')) {
function anaya_blog_merge_db(array $p){
if (!function_exists('db')) return $p;
$slug = (string)($p['slug'] ?? '');
if ($slug === '') return $p;
try {
$st = db()->prepare("SELECT * FROM blogs WHERE slug=? LIMIT 1");
$st->execute([$slug]);
$row = $st->fetch();
if (!$row) return $p;
$keys = ['title','content','excerpt','meta_title','meta_description','category','author',
'featured_image','og_image','og_image_alt','image_1','image_alt_1','image_2','image_alt_2','image_3','image_alt_3',
'ai_summary','geo_summary','aeo_faqs','faq_json','related_url','canonical_url','schema_type','read_min','created_at','updated_at'];
foreach ($keys as $k) {
if (!isset($row[$k])) continue;
$cur = $p[$k] ?? '';
if ($cur === '' || $cur === null) { $p[$k] = $row[$k]; }
}
} catch (Throwable $e) { /* DB fail → form data se continue */ }
return $p;
} }
if (!function_exists('anaya_r_content')) {
function anaya_r_content($raw, $imgs){
$lines = preg_split('/\R/', (string)$raw);
$html = ''; $toc = []; $inlist = false; $first_h = false; $skip_qa = false;
$hslug = function($t){ $t = strip_tags($t); $t = preg_replace('/[^a-z0-9]+/','-', strtolower(html_entity_decode($t, ENT_QUOTES,'UTF-8'))); $t = trim($t,'-'); return $t !== '' ? $t : 'sec'; };
$close_list = function() use (&$inlist, &$html){ if ($inlist) { $html .= '</ul>'; $inlist = false; } };
$n = count($lines); $i = 0;
while ($i < $n) {
$trimRaw = trim($lines[$i]);
if ($trimRaw === '') { $close_list(); $i++; continue; }
$struct = anaya_r_strip_tokens($trimRaw);
$figs = anaya_r_only_figures($trimRaw, $imgs);
/* pipe table */
if (strpos($struct, '|') === 0 && $i + 1 < $n && preg_match('/^\|[\s\-:|]+\|?$/', anaya_r_strip_tokens(trim($lines[$i+1])))) {
$close_list();
$hdr = anaya_r_row($struct); $i += 2; $rows = [];
while ($i < $n) { $sx = anaya_r_strip_tokens(trim($lines[$i])); if (strpos($sx,'|') !== 0) break; $rows[] = anaya_r_row($sx); $i++; }
$html .= '<div class="rTableWrap"><table class="rTable blogTable"><thead><tr>';
foreach ($hdr as $c) { $html .= '<th>'.$c.'</th>'; }
$html .= '</tr></thead><tbody>';
foreach ($rows as $r) { $html .= '<tr>'; foreach ($r as $c) { $html .= '<td>'.$c.'</td>'; } $html .= '</tr>'; }
$html .= '</tbody></table></div>'.$figs;
continue;
}
/* H2 */
if (preg_match('/^##\s+(.+)$/i', $struct, $m)) {
if (strtolower(trim($m[1])) === 'quick answer') { $skip_qa = true; $html .= $figs; $i++; continue; }
$close_list(); $id = $hslug($m[1]); $toc[] = ['id'=>$id,'text'=>trim($m[1])];
$html .= '<h2 id="'.anaya_r_esc($id).'">'.anaya_r_inline($m[1]).'</h2>'.$figs; $first_h = true; $i++; continue;
}
/* H3 */
if (preg_match('/^###\s+(.+)$/', $struct, $m)) {
$close_list();
if (!$first_h) { $id = $hslug($m[1]); $toc[] = ['id'=>$id,'text'=>trim($m[1])]; $html .= '<h2 id="'.anaya_r_esc($id).'">'.anaya_r_inline($m[1]).'</h2>'.$figs; $first_h = true; }
else { $html .= '<h3 id="'.anaya_r_esc($hslug($m[1])).'">'.anaya_r_inline($m[1]).'</h3>'.$figs; }
$i++; continue;
}
/* Quick Answer skip — figures NEVER dropped */
if ($skip_qa) {
if ($figs !== '') { $html .= $figs; }
if (!preg_match('/^[-*]\s+/',$struct) && !preg_match('/^#{1,3}\s+/',$struct)) { $i++; continue; }
$skip_qa = false;
}
/* lists */
if (preg_match('/^[-*]\s+(.+)$/', $struct, $m)) { if (!$inlist) { $html .= '<ul class="bp-ul">'; $inlist = true; } $html .= '<li>'.anaya_r_inline($m[1]).'</li>'.$figs; $i++; continue; }
$close_list();
/* token-only line -> figures only */
if ($struct === '') { $html .= $figs; $i++; continue; }
/* paragraph with inline/adjacent tokens */
$html .= '<p>'.anaya_r_tokens_to_figures($trimRaw, $imgs).'</p>';
$i++;
}
$close_list();
$html = preg_replace('/\{\{img:[^}]*\}\}/', '', $html);
return ['html'=>$html, 'toc'=>$toc];
} }
if (!function_exists('anaya_r_faqs')) {
function anaya_r_faqs(array $p){
$faqs = [];
$j = json_decode((string)($p['faq_json'] ?? ''), true);
if (is_array($j)) { foreach ($j as $f) { if (isset($f['q'],$f['a']) && trim((string)$f['q']) !== '') $faqs[] = [trim((string)$f['q']), trim((string)$f['a'])]; } }
if (!$faqs) { foreach (preg_split('/\R/', (string)($p['aeo_faqs'] ?? '')) as $ln) { $ln = trim($ln); if ($ln === '' || strpos($ln,'|') === false) continue; $pp = array_map('trim', explode('|',$ln,2)); if ($pp[0] !== '') $faqs[] = $pp; } }
return $faqs;
} }
if (!function_exists('anaya_r_related')) {
function anaya_r_related(array $p){
$s = strtolower((string)($p['slug'] ?? '')); $c = strtolower((string)($p['category'] ?? ''));
if (strpos($s,'rishikesh') !== false) return [['/dehradun-to-rishikesh-taxi','Dehradun → Rishikesh Taxi'],['/local-taxi-in-dehradun','Local Taxi Dehradun'],['/outstation-taxi-from-dehradun','Outstation Taxi']];
if (strpos($s,'mussoorie') !== false) return [['/dehradun-to-mussoorie-taxi','Dehradun → Mussoorie Taxi'],['/dehradun-local-sightseeing-taxi','Local Sightseeing'],['/outstation-taxi-from-dehradun','Outstation Taxi']];
if (strpos($s,'haridwar') !== false)  return [['/dehradun-to-haridwar-taxi','Dehradun → Haridwar Taxi'],['/char-dham-yatra-taxi','Char Dham Yatra'],['/outstation-taxi-from-dehradun','Outstation Taxi']];
if (strpos($s,'delhi') !== false)     return [['/dehradun-to-delhi-taxi','Dehradun → Delhi Taxi'],['/dehradun-airport-taxi-service','Airport Transfer'],['/outstation-taxi-from-dehradun','Outstation Taxi']];
if (strpos($s,'airport') !== false)   return [['/dehradun-airport-taxi-service','Airport Transfer'],['/dehradun-to-delhi-taxi','Dehradun → Delhi'],['/local-taxi-in-dehradun','Local Taxi']];
if (strpos($s,'kedarnath') !== false || strpos($s,'yatra') !== false || strpos($s,'char') !== false || $c === 'yatra guide') return [['/char-dham-yatra-taxi','Char Dham Yatra Taxi'],['/dehradun-to-kedarnath-taxi','Kedarnath Taxi'],['/dehradun-to-badrinath-taxi','Badrinath Taxi']];
if (strpos($s,'nainital') !== false)  return [['/dehradun-to-nainital-taxi','Dehradun → Nainital'],['/outstation-taxi-from-dehradun','Outstation Taxi'],['/fleet','Our Fleet']];
return [['/local-taxi-in-dehradun','Local Taxi Dehradun'],['/outstation-taxi-from-dehradun','Outstation Taxi'],['/char-dham-yatra-taxi','Char Dham Yatra']];
} }
if (!function_exists('anaya_blog_page_html')) {
function anaya_blog_page_html(array $p){
$esc = function($s){ return addcslashes((string)$s, "\\'"); };
$canon = trim((string)($p['canonical_url'] ?? '')) !== '' ? anaya_r_abs($p['canonical_url']) : SITE_DOMAIN.'/blog/'.$p['slug'];
$title = trim((string)($p['meta_title'] ?? '')) !== '' ? trim((string)$p['meta_title']) : (string)($p['title'] ?? '');
$desc  = trim((string)($p['meta_description'] ?? '')) !== '' ? trim((string)$p['meta_description']) : ((string)($p['excerpt'] ?? '') !== '' ? (string)$p['excerpt'] : $title);
$og    = trim((string)($p['og_image'] ?? '')) !== '' ? anaya_r_abs($p['og_image']) : (trim((string)($p['featured_image'] ?? '')) !== '' ? anaya_r_abs($p['featured_image']) : SITE_DOMAIN.'/assets/images/logo-source-original.png');
$stype = in_array((string)($p['schema_type'] ?? ''), ['BlogPosting','Article'], true) ? (string)$p['schema_type'] : 'BlogPosting';
$qa    = trim((string)($p['ai_summary'] ?? '')) !== '' ? trim((string)$p['ai_summary']) : trim((string)($p['geo_summary'] ?? ''));
$imgs  = anaya_r_images($p);
$md    = anaya_r_content($p['content'] ?? '', $imgs);
$faqs  = anaya_r_faqs($p);
$date_iso = !empty($p['created_at']) ? date('c', strtotime($p['created_at'])) : date('c');
$mod_iso  = !empty($p['updated_at']) ? date('c', strtotime($p['updated_at'])) : $date_iso;
$date_disp= !empty($p['created_at']) ? date('d M Y', strtotime($p['created_at'])) : date('d M Y');
$readmin  = (int)($p['read_min'] ?? 0) > 0 ? (int)$p['read_min'] : max(1, (int)round(str_word_count(strip_tags($md['html'])) / 200));
$graph = [];
$graph[] = ['@type'=>$stype,'headline'=>$title,'description'=>$desc,'image'=>[$og],'datePublished'=>$date_iso,'dateModified'=>$mod_iso,'author'=>['@type'=>'Organization','name'=>'Anaya Cab Service'],'publisher'=>['@type'=>'Organization','name'=>'Anaya Cab Service','logo'=>['@type'=>'ImageObject','url'=>SITE_DOMAIN.'/assets/images/logo-source-original.png']],'mainEntityOfPage'=>['@type'=>'WebPage','@id'=>$canon]];
if ($qa !== '') { $graph[] = ['@type'=>'WebPage','@id'=>$canon.'#page','speakable'=>['@type'=>'SpeakableSpecification','cssSelector'=>['.bp-qa','.aiBox']]]; }
if ($faqs) { $me = []; foreach ($faqs as $f) { $me[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; } $graph[] = ['@type'=>'FAQPage','@id'=>$canon.'#faq','mainEntity'=>$me]; }
$json = json_encode(['@context'=>'https://schema.org','@graph'=>$graph], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
if ($json === false) { $json = '{"@context":"https://schema.org","@graph":[]}'; }
$json = str_replace('</','<\/',$json);
$schema_html = addcslashes('<script type="application/ld+json">'.$json.'</script>', "\\'");
$php = "<?php\n"
. "\$page_title = '".$esc($title)." | Anaya Cab Service';\n"
. "\$page_description = '".$esc($desc)."';\n"
. "\$page_url = '".$esc($canon)."';\n"
. "\$page_image = '".$esc($og)."';\n"
. "\$preload_image = \$page_image;\n"
. "\$page_schema = '".$schema_html."';\n"
. "require_once __DIR__ . '/../includes/header.php';\n"
. "?>\n"
. "<link rel=\"stylesheet\" href=\"/assets/css/blog-post.css?v=5.4\">\n"
. "<noscript><style>.bp .rv{opacity:1!important;transform:none!important}</style></noscript>\n";
$h_title = anaya_r_esc($title); $h_cat = anaya_r_esc($p['category'] ?: 'Travel Guide');
$h_author = anaya_r_esc($p['author'] ?: 'Anaya Cab Service'); $h_img = anaya_r_esc($p['featured_image'] ?: '');
$catcol = ['Route Guide'=>'#0057ff','Travel Guide'=>'#16a34a','Yatra Guide'=>'#7c3aed','Airport Guide'=>'#0891b2','Fleet Guide'=>'#ea7317'];
$ac = $catcol[$p['category'] ?? ''] ?? '#0057ff';
$toc_html = '';
if (count($md['toc']) > 1) { $toc_html = '<nav class="bp-toc"><div class="bp-toc-h"><i class="fa-solid fa-list"></i> On this page</div><ol>'; foreach ($md['toc'] as $t) { $toc_html .= '<li><a href="#'.anaya_r_esc($t['id']).'">'.anaya_r_esc($t['text']).'</a></li>'; } $toc_html .= '</ol></nav>'; }
$faqs_html = '';
foreach ($faqs as $i => $f) { $faqs_html .= '<div class="bp-fq'.($i===0?' open':'').'"><button type="button" class="bp-fq-h">'.anaya_r_esc($f[0]).'<span class="bp-fq-t"><i class="fa-solid fa-plus"></i></span></button><div class="bp-fq-a"><p>'.anaya_r_esc($f[1]).'</p></div></div>'; }
$rel = anaya_r_related($p);
$inlinks = '<div class="bp-inlinks"><i class="fa-solid fa-link"></i> <strong>Plan your ride:</strong> ';
$parts = [];
foreach (array_slice($rel, 0, 3) as $rl) { $parts[] = '<a href="'.$rl[0].'">'.anaya_r_esc($rl[1]).'</a>'; }
$inlinks .= implode(' · ', $parts) . '</div>';
/* v5.4: reveal observer threshold 0 (lambe articles mein .08 kabhi cross nahi hota tha) */
$article = '<main id="main"><div class="bp" style="--bp-ac:'.$ac.'">'
. '<div class="bp-prog" id="bpProg"></div><div class="bp-amb" aria-hidden="true"></div><div class="bp-in">'
. '<nav class="bp-crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/blog">Blog</a><i class="fa-solid fa-chevron-right"></i><span class="cur">'.$h_cat.'</span></nav>'
. '<header class="bp-hero rv">'
. '<span class="bp-ey" style="--c:'.$ac.'"><i class="fa-solid fa-tag"></i> '.$h_cat.'</span>'
. '<h1 class="bp-h1">'.$h_title.'</h1>'
. '<div class="bp-meta"><span><i class="fa-regular fa-user"></i> '.$h_author.'</span><span><i class="fa-regular fa-calendar"></i> '.$date_disp.'</span><span><i class="fa-regular fa-clock"></i> '.$readmin.' min read</span></div>'
. '</header>'
. ($h_img ? '<figure class="bp-figure rv"><img src="'.$h_img.'" alt="'.$h_title.'" loading="eager" decoding="async" onerror="this.parentElement.style.display=\'none\'"></figure>' : '')
. '<div class="bp-layout">'
. ($toc_html ? '<aside class="bp-side rv">'.$toc_html.'</aside>' : '')
. '<article class="bp-body rv">'
. ($qa !== '' ? '<div class="bp-qa aiBox"><div class="bp-qa-ey"><i class="fa-solid fa-bolt"></i> Quick Answer</div><p>'.anaya_r_esc($qa).'</p></div>' : '')
. '<div class="bp-content">'.$md['html'].'</div>'
. $inlinks
. ($faqs_html ? '<section class="bp-faqsec"><h2 class="bp-h2">Frequently Asked Questions</h2>'.$faqs_html.'</section>' : '')
. '</article>'
. '</div>'
. '<section class="bp-related rv"><div class="bp-relcard"><div><span class="bp-ey" style="--c:'.$ac.'"><i class="fa-solid fa-arrow-right"></i> Keep reading</span><h3>Plan your trip with Anaya Cab</h3><p>Ready to book? Get a fixed fare in minutes.</p></div><div class="bp-relact"><a class="bp-btn bp-btna" href="'.anaya_r_esc($p['related_url'] ?: '/services').'">View service <i class="fa-solid fa-arrow-right"></i></a><a class="bp-btn bp-btng" href="https://wa.me/'.BUSINESS_WHATSAPP.'?text='.rawurlencode('Hi Anaya Cab, I read your blog and want to book a taxi.').'" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a></div></div></section>'
. '</div></div></main>'
. '<script>(function(){var p=document.getElementById("bpProg");if(p){var on=function(){var h=document.documentElement;var s=h.scrollTop||document.body.scrollTop;var m=(h.scrollHeight-h.clientHeight)||1;p.style.width=Math.min(100,s/m*100)+"%";};on();window.addEventListener("scroll",on,{passive:true});}var r=document.querySelectorAll(".bp .rv");if("IntersectionObserver" in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");o.unobserve(e.target);}});},{threshold:0,rootMargin:"0px 0px -40px 0px"});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add("in");});}document.querySelectorAll(".bp-fq-h").forEach(function(h){h.addEventListener("click",function(){h.parentElement.classList.toggle("open");});});var links=document.querySelectorAll(".bp-toc a");var heads=[].map.call(links,function(a){return document.getElementById(a.getAttribute("href").slice(1));}).filter(Boolean);if(heads.length){var on2=function(){var y=window.scrollY+120;var cur=heads[0];heads.forEach(function(hh){if(hh.offsetTop<=y)cur=hh;});links.forEach(function(a){a.classList.toggle("on",a.getAttribute("href")==="#"+cur.id);});};on2();window.addEventListener("scroll",on2,{passive:true});}})();</script>';
$foot = "<?php require_once __DIR__ . '/../includes/footer.php'; ?>\n";
return $php . $article . $foot;
} }
if (!function_exists('anaya_blog_write')) {
function anaya_blog_write(array $p){
$slug = (string)($p['slug'] ?? '');
if ($slug === '') return false;
$p = anaya_blog_merge_db($p); /* v5.3: DB backfill — alt/images/content kabhi nahi khilte */
$dir = anaya_blog_dir();
if (!is_dir($dir)) @mkdir($dir, 0755, true);
return (bool)@file_put_contents($dir . '/' . $slug . '.php', anaya_blog_page_html($p));
} }