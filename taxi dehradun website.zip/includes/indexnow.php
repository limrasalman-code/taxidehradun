<?php
/**
 * IndexNow submitter — instantly notify Bing / Yandex / IndexNow engines
 * when URLs are added or updated. Place in /includes/.
 *
 * Key file must be live at: https://www.taxidehradun.com/21ff024efc7de8452f39062cab7aca3c.txt
 *
 * Usage:
 *   require_once __DIR__ . '/indexnow.php';
 *   indexnow_submit('https://www.taxidehradun.com/blog/my-post');      // single
 *   indexnow_submit([ 'https://.../a', 'https://.../b' ]);              // many
 */

if (!defined('INDEXNOW_KEY')) define('INDEXNOW_KEY', '21ff024efc7de8452f39062cab7aca3c');

function indexnow_host(): string {
    if (defined('SITE_DOMAIN')) {
        $h = parse_url(SITE_DOMAIN, PHP_URL_HOST);
        if ($h) return $h;
    }
    return 'www.taxidehradun.com';
}

/**
 * Submit one or more URLs to IndexNow.
 * Returns ['ok'=>bool,'code'=>int,'resp'=>string,'error'=>string].
 */
function indexnow_submit($urls): array {
    $host = indexnow_host();
    $key  = INDEXNOW_KEY;
    $keyLocation = 'https://' . $host . '/' . $key . '.txt';

    // keep only valid same-host https URLs
    $urls = array_values(array_unique(array_filter(array_map('trim', (array)$urls), function ($u) use ($host) {
        return $u !== '' && stripos($u, 'https://' . $host) === 0;
    })));
    if (!$urls) return ['ok'=>false,'code'=>0,'resp'=>'','error'=>'no valid same-host urls'];

    $endpoint = 'https://api.indexnow.org/indexnow';
    $payload  = json_encode([
        'host' => $host,
        'key' => $key,
        'keyLocation' => $keyLocation,
        'urlList' => $urls,
    ], JSON_UNESCAPED_SLASHES);

    // Prefer cURL; fall back to stream context
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http'=>[
            'method'=>'POST',
            'header'=>"Content-Type: application/json; charset=utf-8\r\n",
            'content'=>$payload,
            'timeout'=>15,
            'ignore_errors'=>true,
        ]]);
        $resp = @file_get_contents($endpoint, false, $ctx);
        $code = 0; $err = '';
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $mm)) $code = (int)$mm[1];
        if ($resp === false) $err = 'request failed';
    }
    // IndexNow returns 200 or 202 on success
    return ['ok'=>($code===200 || $code===202), 'code'=>$code, 'resp'=>(string)$resp, 'error'=>$err];
}
