<?php
if (!defined('SITE_NAME')) { require_once __DIR__ . '/config.php'; }
require_once __DIR__ . '/route-data.php';
$__e = anaya_route_entry($__route_slug ?? '');
$__TH = [
'pilgrim'=>['ac'=>'#6d28d9','ac2'=>'#c4b5fd','d1'=>'#1e1240','d2'=>'#4c1d95','bg1'=>'#f1ecfb','v'=>'pilgrim','g'=>'fa-om'],
'snow'=>['ac'=>'#0369a1','ac2'=>'#7dd3fc','d1'=>'#06283d','d2'=>'#0c4a6e','bg1'=>'#e8f3fa','v'=>'snow','g'=>'fa-snowflake'],
'hill'=>['ac'=>'#15803d','ac2'=>'#86efac','d1'=>'#052e16','d2'=>'#14532d','bg1'=>'#e8f5ec','v'=>'climb','g'=>'fa-mountain-sun'],
'forest'=>['ac'=>'#166534','ac2'=>'#86efac','d1'=>'#062512','d2'=>'#14532d','bg1'=>'#e9f4ec','v'=>'forest','g'=>'fa-tree'],
'highway'=>['ac'=>'#b45309','ac2'=>'#fcd34d','d1'=>'#451a03','d2'=>'#92400e','bg1'=>'#fbf2e2','v'=>'highway','g'=>'fa-road'],
'river'=>['ac'=>'#0e7490','ac2'=>'#67e8f9','d1'=>'#083344','d2'=>'#155e75','bg1'=>'#e6f6f9','v'=>'highway','g'=>'fa-water'],
'plains'=>['ac'=>'#be123c','ac2'=>'#fda4af','d1'=>'#4c0519','d2'=>'#9f1239','bg1'=>'#fdeef1','v'=>'highway','g'=>'fa-city'],
'wildlife'=>['ac'=>'#4d7c0f','ac2'=>'#bef264','d1'=>'#1a2e05','d2'=>'#3f6212','bg1'=>'#f1f8e6','v'=>'forest','g'=>'fa-paw'],
];
$__t = $__TH[$__e['theme']] ?? $__TH['hill'];
$__sf = $__e['sedan_from'];
$__fare_rows = [
['Sedan', $__sf ? ('₹'.number_format($__sf).'+') : 'On request'],
['SUV / Innova', $__sf ? ('₹'.number_format((int)round($__sf*1.35)).'+') : 'On request'],
['Innova Crysta', $__sf ? ('₹'.number_format((int)round($__sf*1.6)).'+') : 'On request'],
['Tempo Traveller','On request'],
];
$__wa = rawurlencode('Hi Anaya Cab, I want a quote for '.$__e['service_name'].'.');
$__image_path = '/assets/images/routes/'.rawurlencode((string)$__e['slug']).'.webp';
$__image_url = SITE_DOMAIN.$__image_path;
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$__e['service_name'],'serviceType'=>'Taxi transfer service','provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>$__e['from']],['@type'=>'City','name'=>$__e['to']]],'url'=>$page_url,'image'=>$__image_url];
if ($__sf) { $__svc['offers'] = ['@type'=>'Offer','priceCurrency'=>'INR','price'=>(string)$__sf,'description'=>$__e['service_name'].' sedan fare starts from '.number_format($__sf).' rupees.','priceSpecification'=>['@type'=>'PriceSpecification','price'=>(string)$__sf,'priceCurrency'=>'INR','description'=>'One-way sedan fare. Toll, parking and hill charges extra where applicable.']]; }
else { $__svc['offers'] = ['@type'=>'Offer','priceCurrency'=>'INR','description'=>$__e['service_name'].' fare is confirmed on booking per vehicle and date.']; }
$__faq_ent = [];
foreach ($__e['faqs'] as $__f) { $__faq_ent[] = ['@type'=>'Question','name'=>$__f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$__f[1]]]; }
/* ── v2.1: ADVANCED SCHEMA — Trip + TouristAttraction (GEO/AI boost, verified geo constants only) ── */
$__GEO = [
'mussoorie'=>['30.4595','78.0667'],'haridwar'=>['29.9457','78.1642'],'rishikesh'=>['30.0869','78.2676'],
'delhi'=>['28.6139','77.2090'],'nainital'=>['29.3803','79.4636'],'kedarnath'=>['30.7346','79.0669'],
'badrinath'=>['30.7433','79.4938'],'gangotri'=>['30.9944','78.9377'],'yamunotri'=>['31.0218','78.4518'],
'jim corbett'=>['29.5228','78.9525'],'ramnagar'=>['29.3928','79.1254'],'chopta'=>['30.2747','79.0064'],
'dhanaulti'=>['30.5919','78.9162'],'auli'=>['30.5229','79.5616'],'chakrata'=>['30.6938','77.9103'],
'kanatal'=>['30.6169','78.9803'],'pauri'=>['30.1667','78.7833'],'rudraprayag'=>['30.2889','78.9803'],
'uttarkashi'=>['30.7333','78.4518'],'devprayag'=>['30.1417','78.5986'],
];
$__to_low = strtolower(trim((string)$__e['to']));
$__graph = [$__svc];
if (isset($__GEO[$__to_low])) {
$__graph[] = ['@type'=>'TouristAttraction','name'=>$__e['to'],'description'=>$__e['tagline'],
'geo'=>['@type'=>'GeoCoordinates','latitude'=>$__GEO[$__to_low][0],'longitude'=>$__GEO[$__to_low][1]],
'address'=>['@type'=>'PostalAddress','addressRegion'=>'Uttarakhand','addressCountry'=>'IN']];
}
$__trip = ['@type'=>'Trip','name'=>$__e['service_name'],'description'=>$__e['tagline'],
'provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],
'itinerary'=>[['@type'=>'Place','name'=>$__e['from']]]];
if (isset($__GEO[$__to_low])) {
$__trip['itinerary'][] = ['@type'=>'Place','name'=>$__e['to'],'geo'=>['@type'=>'GeoCoordinates','latitude'=>$__GEO[$__to_low][0],'longitude'=>$__GEO[$__to_low][1]]];
} else {
$__trip['itinerary'][] = ['@type'=>'Place','name'=>$__e['to']];
}
if ($__e['km']) { $__trip['distance'] = ['@type'=>'Distance','name'=>$__e['km'].' km']; }
$__graph[] = $__trip;
$__graph[] = ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent];
echo '<script type="application/ld+json">'.json_encode(['@context'=>'https://schema.org','@graph'=>$__graph], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>';
?>
<style>
.rt{--ac:<?php echo $__t['ac']; ?>;--ac2:<?php echo $__t['ac2']; ?>;--d1:<?php echo $__t['d1']; ?>;--d2:<?php echo $__t['d2']; ?>;--bg1:<?php echo $__t['bg1']; ?>;--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--soft:#f5f8ff;--green:#16a34a;--radius:20px;--rsm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,var(--bg1) 0%,#fff 460px)}
.rt *{box-sizing:border-box}
.rt::before{content:"";position:absolute;top:-220px;right:-140px;width:600px;height:480px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac) 16%,transparent),transparent 70%);pointer-events:none}
.rt::after{content:"";position:absolute;top:380px;left:-180px;width:460px;height:460px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac2) 22%,transparent),transparent 72%);pointer-events:none}
.rt .rt-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.rt .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rt .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.rt .rv.in{opacity:1;transform:none}
.rt .rv-stagger{transition-delay:calc(var(--stagger-i,0) * 80ms)}
.rt .rt-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.rt .rt-crumb a{color:var(--slate);text-decoration:none}.rt .rt-crumb a:hover{color:var(--ac)}.rt .rt-crumb i{font-size:.6rem;color:var(--mute)}.rt .rt-crumb .cur{color:var(--ink);font-weight:600}
.rt .rt-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.rt .rt-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:color-mix(in srgb,var(--ac) 12%,#fff);padding:7px 13px;border-radius:999px}
.rt .rt-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.rt .rt-hero h1 em{font-style:normal;color:var(--ac)}
.rt .rt-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.rt .rt-lead strong{color:var(--ink)}
.rt .rt-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}.rt .rt-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px;transition:transform .25s,box-shadow .25s}.rt .rt-m:hover{transform:translateY(-3px);box-shadow:0 8px 20px -6px color-mix(in srgb,var(--ac) 15%,transparent)}.rt .rt-m i{color:var(--ac)}.rt .rt-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800}.rt .rt-m span{font-size:.8rem;color:var(--slate)}
.rt .rt-herocta{display:flex;gap:12px;flex-wrap:wrap}
.rt .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rsm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.rt .btn-a{background:var(--ac);color:#fff;box-shadow:0 16px 34px -14px color-mix(in srgb,var(--ac) 60%,transparent)}.rt .btn-a:hover{transform:translateY(-2px)}
.rt .btn-g{background:#25d366;color:#04260f}.rt .btn-g:hover{transform:translateY(-2px)}
.rt .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.rt .btn-o:hover{border-color:var(--ac);color:var(--ac)}
.rt .rt-card{position:sticky;top:88px;background:linear-gradient(160deg,var(--d1),var(--d2));border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px color-mix(in srgb,var(--d1) 70%,transparent);overflow:hidden}
.rt .rt-card::before{content:"";position:absolute;top:0;left:-100%;width:60%;height:100%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.08),transparent);transform:skewX(-15deg);animation:rtCardShimmer 5s ease-in-out infinite;pointer-events:none}
@keyframes rtCardShimmer{0%{left:-100%}50%,100%{left:150%}}
.rt .rt-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:var(--ac2);background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.rt .rt-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.rt .rt-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 14px;position:relative}
.rt .rt-anim{position:relative;height:74px;margin:0 0 8px;overflow:hidden}
.rt .rt-anim .road{position:absolute;left:0;right:0;bottom:18px;height:3px;background:repeating-linear-gradient(90deg,var(--ac2) 0 12px,transparent 12px 24px);border-radius:3px;opacity:.85}
.rt .rt-anim .slope{position:absolute;left:0;right:0;bottom:18px;height:3px;background:repeating-linear-gradient(90deg,var(--ac2) 0 10px,transparent 10px 20px);transform:rotate(-7deg);transform-origin:left center;opacity:.85}
.rt .rt-anim .car{position:absolute;color:#fff;font-size:1rem}
.rt .rt-anim .car.flat{top:50%;left:6%;transform:translate(-50%,-50%);animation:rtflat 4.2s ease-in-out infinite}
.rt .rt-anim .car.climb{bottom:22px;left:6%;animation:rtclimb 4.6s ease-in-out infinite}
@keyframes rtflat{0%,100%{left:6%}50%{left:88%}}
@keyframes rtclimb{0%,100%{left:6%;bottom:22px}50%{left:84%;bottom:46px}}
.rt .rt-anim .glyph{position:absolute;right:5%;top:50%;transform:translateY(-50%);color:var(--ac2);font-size:1.3rem;opacity:.9}
.rt .rt-anim .tree{position:absolute;bottom:30px;color:var(--ac2);font-size:1.05rem;opacity:.85}.rt .rt-anim .t1{left:30%}.rt .rt-anim .t2{left:62%}
.rt .rt-anim .flake{position:absolute;top:-8px;color:#e0f2fe;font-size:.7rem;animation:rtfall linear infinite}.rt .rt-anim .f1{left:22%;animation-duration:3.2s}.rt .rt-anim .f2{left:52%;animation-duration:4.1s}.rt .rt-anim .f3{left:78%;animation-duration:3.6s}
@keyframes rtfall{0%{top:-8px;opacity:0}10%{opacity:1}100%{top:70px;opacity:0}}
.rt .rt-fares{display:grid;gap:8px;position:relative}.rt .rt-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px;transition:background .2s,transform .2s}.rt .rt-fr:hover{background:rgba(255,255,255,.14);transform:translateX(3px)}.rt .rt-fr .v{font-weight:700;font-size:.9rem}.rt .rt-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.rt .rt-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}.rt .rt-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}.rt .rt-card .cta a:hover{transform:translateY(-2px);filter:brightness(1.05)}.rt .rt-card .cta .w{background:#fff;color:var(--d1)}.rt .rt-card .cta .g{background:#25d366;color:#04260f}
.rt .rt-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.rt .rt-cover{position:relative;margin:18px 0 28px;border-radius:22px;overflow:hidden;aspect-ratio:1376/768;background:linear-gradient(135deg,var(--d1),var(--d2))}
.rt .rt-cover img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .3s ease-out}
.rt .rt-cover-fb{display:none;position:absolute;inset:0;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:#fff;text-align:center;padding:24px}.rt .rt-cover-fb i{font-size:3rem;color:var(--ac2)}.rt .rt-cover-fb strong{font-family:'Sora','Poppins',sans-serif;font-size:1.1rem}
.rt .rt-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--ac);border-radius:16px;padding:20px 22px;transition:box-shadow .3s}
.rt .rt-qa:hover{box-shadow:0 12px 30px -12px color-mix(in srgb,var(--ac) 20%,transparent)}
.rt .rt-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin-bottom:8px}
.rt .rt-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.rt .rt-qa strong{color:var(--ink)}
.rt .sec{padding:48px 0}
.rt .sh{text-align:center;max-width:700px;margin:0 auto 28px}.rt .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:color-mix(in srgb,var(--ac) 12%,#fff);padding:7px 13px;border-radius:999px}.rt .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.rt .sh p{color:var(--slate);margin:0}
.rt .tl{position:relative;max-width:800px;margin:0 auto;padding-left:8px}.rt .tl::before{content:"";position:absolute;left:23px;top:8px;bottom:8px;width:2px;background:linear-gradient(180deg,var(--ac),var(--ac2))}
.rt .trow{position:relative;display:grid;grid-template-columns:48px 1fr;gap:18px;padding:0 0 18px}.rt .tdot{position:relative;z-index:1;width:48px;height:48px;border-radius:14px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--ac);font-size:1.05rem;transition:transform .3s,box-shadow .3s}.rt .trow:hover .tdot{transform:scale(1.1);box-shadow:0 8px 20px -6px color-mix(in srgb,var(--ac) 30%,transparent)}.rt .tbody{background:#fff;border:1px solid var(--line);border-radius:16px;padding:15px 18px;transition:transform .3s,box-shadow .3s}.rt .trow:hover .tbody{transform:translateX(4px);box-shadow:0 8px 24px -8px rgba(0,0,0,.08)}.rt .tbody h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:700;margin:0 0 3px}.rt .tbody p{margin:0;color:var(--slate);font-size:.88rem}
.rt .bento{display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:16px;grid-auto-flow:row dense}.rt .bv{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:24px;overflow:hidden;transition:transform .3s,box-shadow .3s;transform-style:preserve-3d}.rt .bv:hover{box-shadow:0 20px 44px -16px rgba(0,0,0,.12)}.rt .bv.big{grid-row:span 2;background:linear-gradient(155deg,var(--d1),var(--d2));color:#fff;border-color:transparent}.rt .bv .vi{width:50px;height:50px;border-radius:14px;background:color-mix(in srgb,var(--ac) 12%,#fff);color:var(--ac);display:grid;place-items:center;font-size:1.15rem;margin-bottom:14px;transition:transform .3s}.rt .bv:hover .vi{transform:scale(1.1) rotate(-5deg)}.rt .bv.big .vi{background:rgba(255,255,255,.14);color:var(--ac2)}.rt .bv h3{font-family:'Sora','Poppins',sans-serif;font-size:1.06rem;font-weight:700;margin:0 0 6px}.rt .bv p{margin:0;color:var(--slate);font-size:.9rem}.rt .bv.big p{color:rgba(255,255,255,.84)}
.rt .vgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px}.rt .vitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--rsm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}.rt .vitem:hover{transform:translateY(-4px);box-shadow:0 12px 28px -10px color-mix(in srgb,var(--ac) 15%,transparent);border-color:color-mix(in srgb,var(--ac) 30%,var(--line))}.rt .vico{flex:none;width:44px;height:44px;border-radius:12px;background:color-mix(in srgb,var(--ac) 12%,#fff);color:var(--ac);display:grid;place-items:center;transition:transform .3s}.rt .vitem:hover .vico{transform:scale(1.1) rotate(-5deg)}.rt .vitem h3{font-size:.98rem;font-weight:700;margin:0 0 3px}.rt .vitem p{margin:0;color:var(--slate);font-size:.86rem}
.rt .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden}.rt .tscr{overflow-x:auto}.rt table{width:100%;border-collapse:collapse;min-width:520px}.rt th,.rt td{padding:14px 18px;text-align:left;font-size:.92rem}.rt thead th{background:var(--soft);color:var(--ac);font-weight:700;font-size:.78rem}.rt tbody tr{border-top:1px solid var(--line);transition:background .2s}.rt tbody tr:hover{background:color-mix(in srgb,var(--ac) 4%,#fff)}
.rt .prose{max-width:840px;margin:24px auto 0}.rt .prose h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 10px}.rt .prose p{color:var(--slate);line-height:1.72;margin:0 0 12px;font-size:.96rem}.rt .prose strong{color:var(--ink)}
.rt .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}.rt .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:all .3s}.rt .rchip i{color:var(--ac)}.rt .rchip:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-3px);box-shadow:0 10px 24px -8px color-mix(in srgb,var(--ac) 20%,transparent)}
.rt .fbox{max-width:820px;margin:0 auto}.rt .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:box-shadow .3s,border-color .3s}.rt .fi:hover{border-color:color-mix(in srgb,var(--ac) 30%,var(--line));box-shadow:0 8px 20px -8px color-mix(in srgb,var(--ac) 12%,transparent)}
.rt .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-weight:600;font-size:1rem;cursor:pointer}
.rt .ft{flex:none;width:26px;height:26px;border-radius:8px;background:color-mix(in srgb,var(--ac) 12%,#fff);color:var(--ac);display:grid;place-items:center;font-size:.82rem;transition:transform .4s cubic-bezier(.4,0,.2,1)}.rt .fi.open .ft{transform:rotate(45deg)}
.rt .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .45s cubic-bezier(.4,0,.2,1),padding .45s}.rt .fi.open .fb{max-height:400px;padding:0 20px 18px}
.rt .soft{background:linear-gradient(180deg,var(--bg1),#fff)}
.rt .cta2{padding:0 0 70px}.rt .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--ac),transparent 55%),linear-gradient(120deg,var(--d1),var(--d2));color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.rt .ctain::before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 50% 50%,rgba(255,255,255,.06),transparent 70%);animation:rtCtaPulse 3s ease-in-out infinite}
@keyframes rtCtaPulse{0%,100%{opacity:.3;transform:scale(1)}50%{opacity:.8;transform:scale(1.02)}}
.rt .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);margin:0 0 8px;position:relative}
.rt .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px;position:relative}
.rt .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;position:relative}
.rt .cta2 a{display:inline-flex;align-items:center;gap:9px;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,box-shadow .3s}
.rt .cta2 a:hover{transform:translateY(-2px)}
.rt .cta2 .w{background:#fff;color:var(--d1)}.rt .cta2 .g{background:#25d366;color:#04260f}.rt .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.rt .rt-hero{grid-template-columns:1fr}.rt .rt-card{position:static}.rt .bento{grid-template-columns:1fr 1fr}.rt .bv.big{grid-row:auto;grid-column:span 2}}
@media(max-width:560px){.rt .bento{grid-template-columns:1fr}.rt .bv.big{grid-column:auto}}
@media(prefers-reduced-motion:reduce){.rt *{transition:none!important;animation:none!important}.rt .rv{opacity:1!important;transform:none!important}}
</style>
<div class="rt"><div class="rt-in">
<nav class="rt-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($__e['service_name']); ?></span></nav>
<figure class="rt-cover rv">
<img src="<?php echo htmlspecialchars($__image_path, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($__e['service_name'].' route', ENT_QUOTES, 'UTF-8'); ?>" width="1376" height="768" loading="eager" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
<figcaption class="rt-cover-fb"><i class="fa-solid <?php echo $__t['g']; ?>"></i><strong><?php echo htmlspecialchars($__e['service_name']); ?></strong></figcaption>
</figure>
<section class="rt-hero">
<div class="rv">
<span class="rt-ey"><i class="fa-solid <?php echo $__t['g']; ?>"></i> <?php echo htmlspecialchars($__e['to']); ?> · verified drivers</span>
<h1 class="disp"><?php echo htmlspecialchars($__e['service_name']); ?> <em>(Cab Fare &amp; Booking)</em></h1>
<p class="rt-lead"><strong><?php echo htmlspecialchars($__e['tagline']); ?></strong></p>
<div class="rt-metrics">
<?php if ($__e['km']): ?><span class="rt-m"><i class="fa-solid fa-road"></i> <b>~<?php echo $__e['km']; ?> km</b> <span>distance</span></span><?php endif; ?>
<?php if ($__e['time']): ?><span class="rt-m"><i class="fa-regular fa-clock"></i> <b><?php echo htmlspecialchars($__e['time']); ?></b> <span>drive time</span></span><?php endif; ?>
<span class="rt-m"><i class="fa-solid <?php echo $__t['g']; ?>"></i> <b><?php echo htmlspecialchars($__e['to']); ?></b> <span>destination</span></span>
<span class="rt-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b><?php echo $__sf ? ('₹'.number_format($__sf).'+') : 'Quote'; ?></b> <span>sedan</span></span>
</div>
<div class="rt-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book this route</a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo $__wa; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get fare on WhatsApp</a>
<a class="btn btn-o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> <?php echo BUSINESS_PHONE; ?></a>
</div>
</div>
<aside class="rt-card rv" aria-label="<?php echo htmlspecialchars($__e['service_name']); ?> fare">
<span class="tag"><i class="fa-solid fa-route"></i> Live fare desk</span>
<h3 class="disp"><?php echo htmlspecialchars($__e['from']); ?> → <?php echo htmlspecialchars($__e['to']); ?></h3>
<p class="sub">Indicative fares by vehicle — confirmed before you book.</p>
<div class="rt-anim" aria-hidden="true">
<?php if ($__t['v']==='climb'): ?><div class="slope"></div><i class="fa-solid fa-car-side car climb"></i>
<?php elseif ($__t['v']==='snow'): ?><div class="slope"></div><i class="fa-solid fa-snowflake flake f1"></i><i class="fa-solid fa-snowflake flake f2"></i><i class="fa-solid fa-snowflake flake f3"></i><i class="fa-solid fa-car-side car climb"></i>
<?php elseif ($__t['v']==='forest'): ?><div class="road"></div><i class="fa-solid fa-tree tree t1"></i><i class="fa-solid fa-tree tree t2"></i><i class="fa-solid fa-car-side car flat"></i>
<?php elseif ($__t['v']==='pilgrim'): ?><div class="road"></div><i class="fa-solid fa-car-side car flat"></i><i class="fa-solid fa-om glyph"></i>
<?php else: ?><div class="road"></div><i class="fa-solid fa-car-side car flat"></i><i class="fa-solid <?php echo $__t['g']; ?> glyph"></i><?php endif; ?>
</div>
<div class="rt-fares"><?php foreach ($__fare_rows as $__fr): ?><div class="rt-fr"><span class="v"><?php echo $__fr[0]; ?></span><span class="p"><?php echo $__fr[1]; ?></span></div><?php endforeach; ?></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo $__wa; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 support</p>
</aside>
</section>
<!-- QUICK ANSWER (AEO / GEO Magnet) -->
<div class="rt-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; <?php echo htmlspecialchars($__e['service_name']); ?> Overview</div>
<p itemprop="text"><strong><?php echo htmlspecialchars($__e['service_name']); ?></strong> covers approximately <strong><?php echo $__e['km'] ? ($__e['km'].' km') : 'scenic highway/hill route'; ?></strong><?php echo $__e['time'] ? (' with an estimated drive time of '.$__e['time']) : ''; ?>. One-way taxi fare starts from <strong><?php echo $__sf ? ('₹'.number_format($__sf).' for Sedan (Dzire)') : 'budget rates'; ?></strong><?php echo $__sf ? (', ₹'.number_format((int)round($__sf*1.35)).' for SUV (Ertiga), and ₹'.number_format((int)round($__sf*1.6)).' for Innova Crysta') : ''; ?>. Anaya Cab Service provides 24x7 door-to-door pickups from anywhere in Dehradun with verified drivers and fixed fares.</p>
</div>
</div>
<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-route"></i> The journey</span><h2 class="disp">How the <?php echo htmlspecialchars($__e['from']); ?> to <?php echo htmlspecialchars($__e['to']); ?> drive goes</h2></div>
<div class="tl"><?php foreach ($__e['timeline'] as $__ti => $__tl): ?><div class="trow rv rv-stagger" style="--stagger-i:<?php echo $__ti; ?>"><div class="tdot"><i class="fa-solid <?php echo $__tl[0]; ?>"></i></div><div class="tbody"><h3><?php echo htmlspecialchars($__tl[1]); ?></h3><p><?php echo htmlspecialchars($__tl[2]); ?></p></div></div><?php endforeach; ?></div>
</div></section>
<section class="sec soft rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-star"></i> Highlights</span><h2 class="disp">What makes this route worth the drive</h2></div>
<div class="bento"><?php foreach ($__e['highlights'] as $__i => $__h): $__big=($__i===0); ?>
<div class="bv rv rv-stagger<?php echo $__big?' big':''; ?>" style="--stagger-i:<?php echo $__i; ?>" data-tilt><div class="vi"><i class="fa-solid <?php echo $__h[0]; ?>"></i></div><h3><?php echo htmlspecialchars($__h[1]); ?></h3><p><?php echo htmlspecialchars($__h[2]); ?></p></div>
<?php endforeach; ?></div>
</div></section>
<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-car-side"></i> Vehicle options</span><h2 class="disp">Pick the right cab for this trip</h2></div>
<div class="vgrid"><?php foreach ($__e['vehicles'] as $__vi => $__v): ?><div class="vitem rv rv-stagger" style="--stagger-i:<?php echo $__vi; ?>"><span class="vico"><i class="fa-solid <?php echo $__v[1]; ?>"></i></span><div><h3><?php echo htmlspecialchars($__v[0]); ?></h3><p><?php echo htmlspecialchars($__v[2]); ?> · <?php echo htmlspecialchars($__v[3]); ?></p></div></div><?php endforeach; ?></div>
</div></section>
<section class="sec soft rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-map-location-dot"></i> Pickup &amp; drop</span><h2 class="disp">Common pickup and drop combinations</h2></div>
<div class="twrap"><div class="tscr"><table aria-label="<?php echo htmlspecialchars($__e['service_name']); ?> pickup and drop options">
<thead><tr><th>Pickup / plan</th><th>Drop / sightseeing</th><th>Travel note</th></tr></thead>
<tbody><?php foreach ($__e['matrix'] as $__mx): ?><tr><td><strong><?php echo htmlspecialchars($__mx[0]); ?></strong></td><td><?php echo htmlspecialchars($__mx[1]); ?></td><td><?php echo htmlspecialchars($__mx[2]); ?></td></tr><?php endforeach; ?></tbody>
</table></div></div>
<div class="prose"><?php foreach ($__e['prose'] as $__pr): echo $__pr; endforeach; ?></div>
</div></section>
<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other taxis travellers book with this</h2></div>
<div class="rchips"><?php foreach ($__e['related'] as $__ri => $__rl): ?><a class="rchip rv rv-stagger" style="--stagger-i:<?php echo $__ri; ?>" href="/<?php echo $__rl[0]; ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($__rl[1]); ?></a><?php endforeach; ?></div>
</div></section>
<?php if (file_exists(__DIR__.'/route-links.php')) { require __DIR__.'/route-links.php'; } ?>
<section class="sec soft rv" id="faq"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($__e['service_name']); ?> — FAQs</h2></div>
<div class="fbox"><?php foreach ($__e['faqs'] as $__i => $__f): ?><div class="fi<?php echo $__i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($__f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($__f[1]); ?></p></div></div><?php endforeach; ?></div>
</div></section>
<section class="cta2 rv"><div class="rt-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($__e['from']); ?> to <?php echo htmlspecialchars($__e['to']); ?> taxi?</h2>
<p>Fixed fare, verified driver and pickup from anywhere — confirmed in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book this route</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo $__wa; ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div></div>
<script>
(function(){var r=document.querySelectorAll('.rt .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){var d=parseInt(e.target.style.getPropertyValue('--stagger-i')||'0')*80;setTimeout(function(){e.target.classList.add('in');},d);o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rt .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
if(window.matchMedia('(hover:hover) and (pointer:fine)').matches){document.querySelectorAll('.rt [data-tilt]').forEach(function(card){card.addEventListener('mousemove',function(e){var r=card.getBoundingClientRect();var x=(e.clientX-r.left)/r.width-.5;var y=(e.clientY-r.top)/r.height-.5;card.style.transform='perspective(800px) rotateY('+(x*7)+'deg) rotateX('+(-y*5)+'deg) translateY(-4px)';});card.addEventListener('mouseleave',function(){card.style.transform='';});});}
})();
</script>