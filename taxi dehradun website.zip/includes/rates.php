<?php
/**
* Anaya Cab Service --- SINGLE SOURCE FARE SYSTEM
* Saare rates includes/rates.json mein store hote hain (admin panel se edit).
* Agar rates.json missing/corrupt ho to DEFAULTS lagte hain => site kabhi nahi tootti.
* Usage: anaya_rate('r_delhi') | anaya_rates() | anaya_rates_save($arr)
* v2.1 fix: r_jim_corbett default 5000 -> 3500 (llms-full se aligned).
*/
/* key => [group, label, default value] */
function anaya_rate_meta() {
return array(
/* ---- Route fares: one-way sedan ---- */
'r_haridwar'=>array('Route fares (one-way sedan)','Dehradun to Haridwar',1350),
'r_rishikesh'=>array('Route fares (one-way sedan)','Dehradun to Rishikesh',1150),
'r_mussoorie'=>array('Route fares (one-way sedan)','Dehradun to Mussoorie',1050),
'r_delhi'=>array('Route fares (one-way sedan)','Dehradun to Delhi (ONE-WAY)',3500),
'r_nainital'=>array('Route fares (one-way sedan)','Dehradun to Nainital',5600),
'r_chandigarh'=>array('Route fares (one-way sedan)','Dehradun to Chandigarh',4000),
'r_agra'=>array('Route fares (one-way sedan)','Dehradun to Agra',9000),
'r_auli'=>array('Route fares (one-way sedan)','Dehradun to Auli',8500),
'r_chakrata'=>array('Route fares (one-way sedan)','Dehradun to Chakrata',3000),
'r_chopta'=>array('Route fares (one-way sedan)','Dehradun to Chopta',3000),
'r_kanatal'=>array('Route fares (one-way sedan)','Dehradun to Kanatal',2200),
'r_dhanaulti'=>array('Route fares (one-way sedan)','Dehradun to Dhanaulti',1800),
'r_tehri'=>array('Route fares (one-way sedan)','Dehradun to Tehri',3000),
'r_uttarkashi'=>array('Route fares (one-way sedan)','Dehradun to Uttarkashi',4000),
'r_srinagar_garhwal'=>array('Route fares (one-way sedan)','Dehradun to Srinagar Garhwal',4500),
'r_haldwani'=>array('Route fares (one-way sedan)','Dehradun to Haldwani',5000),
'r_jim_corbett'=>array('Route fares (one-way sedan)','Dehradun to Jim Corbett',3500),
'r_roorkee'=>array('Route fares (one-way sedan)','Dehradun to Roorkee',2500),
'r_saharanpur'=>array('Route fares (one-way sedan)','Dehradun to Saharanpur',2200),
'r_noida'=>array('Route fares (one-way sedan)','Dehradun to Noida',3600),
'r_gurgaon'=>array('Route fares (one-way sedan)','Dehradun to Gurgaon',3800),
'r_gurugram'=>array('Route fares (one-way sedan)','Dehradun to Gurugram',3800),
'r_ghaziabad'=>array('Route fares (one-way sedan)','Dehradun to Ghaziabad',3600),
'r_faridabad'=>array('Route fares (one-way sedan)','Dehradun to Faridabad',4000),
'r_jaipur'=>array('Route fares (one-way sedan)','Dehradun to Jaipur',9000),
'r_mathura'=>array('Route fares (one-way sedan)','Dehradun to Mathura',7000),
'r_shimla'=>array('Route fares (one-way sedan)','Dehradun to Shimla',4500),
'r_manali'=>array('Route fares (one-way sedan)','Dehradun to Manali',9000),
'r_kedarnath'=>array('Route fares (one-way sedan)','Dehradun to Kedarnath (0 = custom quote)',0),
'r_badrinath'=>array('Route fares (one-way sedan)','Dehradun to Badrinath (0 = custom quote)',0),
'r_gangotri'=>array('Route fares (one-way sedan)','Dehradun to Gangotri (0 = custom quote)',0),
'r_yamunotri'=>array('Route fares (one-way sedan)','Dehradun to Yamunotri (0 = custom quote)',0),
'r_joshimath'=>array('Route fares (one-way sedan)','Dehradun to Joshimath',4200),
'r_almora'=>array('Route fares (one-way sedan)','Dehradun to Almora',7200),
'r_ranikhet'=>array('Route fares (one-way sedan)','Dehradun to Ranikhet',6000),
'r_kausani'=>array('Route fares (one-way sedan)','Dehradun to Kausani',7000),
'r_pithoragarh'=>array('Route fares (one-way sedan)','Dehradun to Pithoragarh',8500),
'r_rudraprayag'=>array('Route fares (one-way sedan)','Dehradun to Rudraprayag',3500),
'r_devprayag'=>array('Route fares (one-way sedan)','Dehradun to Devprayag',1800),
'r_pauri'=>array('Route fares (one-way sedan)','Dehradun to Pauri',2500),
'r_lansdowne'=>array('Route fares (one-way sedan)','Dehradun to Lansdowne',3200),
'r_ramnagar'=>array('Route fares (one-way sedan)','Dehradun to Ramnagar',4200),
'r_meerut'=>array('Route fares (one-way sedan)','Dehradun to Meerut',4500),
'r_bareilly'=>array('Route fares (one-way sedan)','Dehradun to Bareilly',5000),
'r_kalka'=>array('Route fares (one-way sedan)','Dehradun to Kalka',3800),
'r_panchkula'=>array('Route fares (one-way sedan)','Dehradun to Panchkula',3800),
'r_mohali'=>array('Route fares (one-way sedan)','Dehradun to Mohali',4000),
'r_ludhiana'=>array('Route fares (one-way sedan)','Dehradun to Ludhiana',5500),
'r_amritsar'=>array('Route fares (one-way sedan)','Dehradun to Amritsar',8500),
'r_patiala'=>array('Route fares (one-way sedan)','Dehradun to Patiala',4800),
'r_jalandhar'=>array('Route fares (one-way sedan)','Dehradun to Jalandhar',6500),
'r_kasauli'=>array('Route fares (one-way sedan)','Dehradun to Kasauli',4800),
'r_chail'=>array('Route fares (one-way sedan)','Dehradun to Chail',5500),
'r_kufri'=>array('Route fares (one-way sedan)','Dehradun to Kufri',5200),
'r_dharamshala'=>array('Route fares (one-way sedan)','Dehradun to Dharamshala',9500),
'r_kullu'=>array('Route fares (one-way sedan)','Dehradun to Kullu',8500),
'r_solan'=>array('Route fares (one-way sedan)','Dehradun to Solan',4200),
'r_mandi'=>array('Route fares (one-way sedan)','Dehradun to Mandi',7500),
'r_dalhousie'=>array('Route fares (one-way sedan)','Dehradun to Dalhousie',11000),
'r_binsar'=>array('Route fares (one-way sedan)','Dehradun to Binsar',7500),
'r_mukteshwar'=>array('Route fares (one-way sedan)','Dehradun to Mukteshwar',6500),
'r_bhimtal'=>array('Route fares (one-way sedan)','Dehradun to Bhimtal',5500),
'r_naukuchiatal'=>array('Route fares (one-way sedan)','Dehradun to Naukuchiatal',5600),
'r_munsiyari'=>array('Route fares (one-way sedan)','Dehradun to Munsiyari',12000),
'r_guptkashi'=>array('Route fares (one-way sedan)','Dehradun to Guptkashi',5500),
'r_sonprayag'=>array('Route fares (one-way sedan)','Dehradun to Sonprayag',6000),
'r_phata'=>array('Route fares (one-way sedan)','Dehradun to Phata',5800),
'r_sitapur'=>array('Route fares (one-way sedan)','Dehradun to Sitapur',6000),
'r_ukhimath'=>array('Route fares (one-way sedan)','Dehradun to Ukhimath',5200),
'r_karnaprayag'=>array('Route fares (one-way sedan)','Dehradun to Karnaprayag',4500),
'r_govindghat'=>array('Route fares (one-way sedan)','Dehradun to Govindghat',8000),
'r_hemkund_sahib'=>array('Route fares (one-way sedan)','Dehradun to Hemkund Sahib',8000),
'r_kainchi_dham'=>array('Route fares (one-way sedan)','Dehradun to Kainchi Dham',5800),
'r_kasol'=>array('Route fares (one-way sedan)','Dehradun to Kasol',9500),
'r_valley_of_flowers'=>array('Route fares (one-way sedan)','Dehradun to Valley of Flowers',8500),
'r_air_delhi'=>array('Airport transfer','Jolly Grant Airport to Delhi',4000),
'r_air_chandigarh'=>array('Airport transfer','Jolly Grant Airport to Chandigarh',4500),
'r_air_shimla'=>array('Airport transfer','Jolly Grant Airport to Shimla',5000),
'r_air_nainital'=>array('Airport transfer','Jolly Grant Airport to Nainital',6000),
'r_air_jim_corbett'=>array('Airport transfer','Jolly Grant Airport to Jim Corbett',4000),
'r_air_haridwar'=>array('Airport transfer','Jolly Grant Airport to Haridwar',1400),
'r_air_rishikesh'=>array('Airport transfer','Jolly Grant Airport to Rishikesh',1200),
'r_air_mussoorie'=>array('Airport transfer','Jolly Grant Airport to Mussoorie',1800),
'r_air_badrinath'=>array('Airport transfer','Jolly Grant Airport to Badrinath',0),
'r_air_kedarnath'=>array('Airport transfer','Jolly Grant Airport to Kedarnath',0),
/* ---- Delhi corridor extras ---- */
'rt_delhi'=>array('Delhi corridor','Dehradun-Delhi ROUND TRIP sedan',5000),
'delhi_ertiga'=>array('Delhi corridor','Delhi one-way Ertiga',4550),
'delhi_crysta'=>array('Delhi corridor','Delhi one-way Innova Crysta',5250),
'delhi_airport_sedan'=>array('Delhi corridor','IGI Airport pickup sedan',3800),
/* ---- Local packages ---- */
'local_hatch_4'=>array('Local packages','Hatchback 4hr / 40km',900),
'local_hatch_8'=>array('Local packages','Hatchback 8hr / 80km',1600),
'local_sedan_4'=>array('Local packages','Sedan 4hr / 40km',1100),
'local_sedan_8'=>array('Local packages','Sedan 8hr / 80km',1900),
'local_mpv_4'=>array('Local packages','Ertiga 4hr / 40km',1350),
'local_mpv_8'=>array('Local packages','Ertiga 8hr / 80km',2300),
'local_prem_4'=>array('Local packages','Crysta 4hr / 40km',1600),
'local_prem_8'=>array('Local packages','Crysta 8hr / 80km',2800),
/* ---- Fleet / events ---- */
'tempo_per_km'=>array('Fleet & events','Tempo Traveller per km',22),
'lux_sedan_day'=>array('Fleet & events','Luxury sedan per day',3000),
'lux_crysta_day'=>array('Fleet & events','Innova Crysta per day',4000),
'lux_urbania_day'=>array('Fleet & events','Force Urbania per day',9000),
'wed_sedan'=>array('Fleet & events','Wedding decorated sedan',8000),
'wed_suv'=>array('Fleet & events','Wedding luxury SUV',12000),
'wed_vintage'=>array('Fleet & events','Wedding vintage / classic',18000),
'wed_tempo'=>array('Fleet & events','Wedding Tempo Traveller / day',8000),
);
}
function anaya_rate_defaults() {
$out = array();
foreach (anaya_rate_meta() as $k => $m) { $out[$k] = $m[2]; }
return $out;
}
/* Poori rate sheet (json overrides + defaults merged) */
function anaya_rates() {
static $cache = null;
if ($cache !== null) { return $cache; }
$file = __DIR__ . '/rates.json';
$data = array();
if (file_exists($file)) {
$raw = file_get_contents($file);
if ($raw !== false) {
$decoded = json_decode($raw, true);
if (is_array($decoded)) { $data = $decoded; }
}
}
$cache = array_merge(anaya_rate_defaults(), $data);
return $cache;
}
/* Single rate nikalo (kabhi null nahi toota hua) */
function anaya_rate($key) {
$all = anaya_rates();
if (isset($all[$key]) && $all[$key] !== '' && $all[$key] !== null) { return (int)$all[$key]; }
$meta = anaya_rate_meta();
if (isset($meta[$key])) { return (int)$meta[$key][2]; }
return 0;
}
/* Admin save */
function anaya_rates_save($arr) {
$file = __DIR__ . '/rates.json';
$json = json_encode($arr, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
if ($json === false) { return false; }
return file_put_contents($file, $json) !== false;
}