<?php
/**
 * Anaya Cab Service — ROUTE ENGINE
 *
 * SINGLE SOURCE OF TRUTH:
 * Route fares are always resolved from anaya_rate() / rates.json.
 *
 * This file generates:
 * - Route data
 * - SEO title / description
 * - Hero tagline
 * - Fare
 * - Highlights
 * - FAQs
 * - Related routes
 * - Route prose
 * - Timeline
 *
 * IMPORTANT:
 * Never hardcode route fares inside this file.
 */

declare(strict_types=1);

if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/config.php';
}

/*
|--------------------------------------------------------------------------
| Load master fare system
|--------------------------------------------------------------------------
|
| rates.php must contain:
| anaya_rate()
| anaya_rates()
| anaya_rates_save()
|
|--------------------------------------------------------------------------
*/

if (!function_exists('anaya_rate')) {
    $rateFile = __DIR__ . '/rates.php';

    if (is_file($rateFile)) {
        require_once $rateFile;
    }
}

/*
|--------------------------------------------------------------------------
| Route entry
|--------------------------------------------------------------------------
*/

function anaya_route_entry(string $slug): array
{
    static $cache = [];

    if (isset($cache[$slug])) {
        return $cache[$slug];
    }

    $overrides = anaya_route_overrides();

    if (isset($overrides[$slug])) {
        $cache[$slug] = anaya_route_merge(
            $slug,
            $overrides[$slug]
        );
    } else {
        $cache[$slug] = anaya_route_generate($slug);
    }

    return $cache[$slug];
}

/*
|--------------------------------------------------------------------------
| MASTER FARE MAPPING
|--------------------------------------------------------------------------
|
| Route slug => rates.php key
|
| This is the only place where route -> rate key mapping exists.
|--------------------------------------------------------------------------
*/

function anaya_route_fare_key(string $slug): ?string
{
    static $map = [

        'dehradun-to-haridwar-taxi'       => 'r_haridwar',
        'dehradun-to-rishikesh-taxi'     => 'r_rishikesh',
        'dehradun-to-mussoorie-taxi'     => 'r_mussoorie',
        'dehradun-to-delhi-taxi'         => 'r_delhi',
        'dehradun-to-nainital-taxi'      => 'r_nainital',
        'dehradun-to-chandigarh-taxi'    => 'r_chandigarh',
        'dehradun-to-agra-taxi'          => 'r_agra',
        'dehradun-to-auli-taxi'          => 'r_auli',
        'dehradun-to-chakrata-taxi'      => 'r_chakrata',
        'dehradun-to-chopta-taxi'        => 'r_chopta',
        'dehradun-to-kanatal-taxi'       => 'r_kanatal',
        'dehradun-to-dhanaulti-taxi'     => 'r_dhanaulti',
        'dehradun-to-tehri-taxi'         => 'r_tehri',
        'dehradun-to-uttarkashi-taxi'    => 'r_uttarkashi',
        'dehradun-to-srinagar-garhwal-taxi' => 'r_srinagar_garhwal',
        'dehradun-to-haldwani-taxi'      => 'r_haldwani',
        'dehradun-to-jim-corbett-taxi'   => 'r_jim_corbett',
        'dehradun-to-roorkee-taxi'       => 'r_roorkee',
        'dehradun-to-saharanpur-taxi'    => 'r_saharanpur',
        'dehradun-to-noida-taxi'         => 'r_noida',
        'dehradun-to-gurgaon-taxi'       => 'r_gurgaon',
        'dehradun-to-gurugram-taxi'      => 'r_gurugram',
        'dehradun-to-ghaziabad-taxi'     => 'r_ghaziabad',
        'dehradun-to-faridabad-taxi'     => 'r_faridabad',
        'dehradun-to-jaipur-taxi'        => 'r_jaipur',
        'dehradun-to-mathura-taxi'       => 'r_mathura',
        'dehradun-to-shimla-taxi'        => 'r_shimla',
        'dehradun-to-manali-taxi'        => 'r_manali',
        'dehradun-to-kedarnath-taxi'     => 'r_kedarnath',
        'dehradun-to-badrinath-taxi'     => 'r_badrinath',
        'dehradun-to-gangotri-taxi'      => 'r_gangotri',
        'dehradun-to-yamunotri-taxi'     => 'r_yamunotri',
        'dehradun-to-joshimath-taxi'     => 'r_joshimath',
        'dehradun-to-almora-taxi'        => 'r_almora',
        'dehradun-to-ranikhet-taxi'      => 'r_ranikhet',
        'dehradun-to-kausani-taxi'       => 'r_kausani',
        'dehradun-to-pithoragarh-taxi'   => 'r_pithoragarh',
        'dehradun-to-rudraprayag-taxi'   => 'r_rudraprayag',
        'dehradun-to-devprayag-taxi'     => 'r_devprayag',
        'dehradun-to-pauri-taxi'         => 'r_pauri',
        'dehradun-to-lansdowne-taxi'     => 'r_lansdowne',
        'dehradun-to-ramnagar-taxi'      => 'r_ramnagar',
        'dehradun-to-meerut-taxi'        => 'r_meerut',
        'dehradun-to-bareilly-taxi'      => 'r_bareilly',
        'dehradun-to-kalka-taxi'         => 'r_kalka',
        'dehradun-to-panchkula-taxi'     => 'r_panchkula',
        'dehradun-to-mohali-taxi'        => 'r_mohali',
        'dehradun-to-ludhiana-taxi'      => 'r_ludhiana',
        'dehradun-to-amritsar-taxi'      => 'r_amritsar',
        'dehradun-to-patiala-taxi'       => 'r_patiala',
        'dehradun-to-jalandhar-taxi'     => 'r_jalandhar',
        'dehradun-to-kasauli-taxi'       => 'r_kasauli',
        'dehradun-to-chail-taxi'         => 'r_chail',
        'dehradun-to-kufri-taxi'         => 'r_kufri',
        'dehradun-to-dharamshala-taxi'   => 'r_dharamshala',
        'dehradun-to-kullu-taxi'         => 'r_kullu',
        'dehradun-to-solan-taxi'         => 'r_solan',
        'dehradun-to-mandi-taxi'         => 'r_mandi',
        'dehradun-to-dalhousie-taxi'     => 'r_dalhousie',
        'dehradun-to-binsar-taxi'        => 'r_binsar',
        'dehradun-to-mukteshwar-taxi'    => 'r_mukteshwar',
        'dehradun-to-bhimtal-taxi'       => 'r_bhimtal',
        'dehradun-to-naukuchiatal-taxi'  => 'r_naukuchiatal',
        'dehradun-to-munsiyari-taxi'     => 'r_munsiyari',
        'dehradun-to-guptkashi-taxi'     => 'r_guptkashi',
        'dehradun-to-sonprayag-taxi'     => 'r_sonprayag',
        'dehradun-to-phata-taxi'         => 'r_phata',
        'dehradun-to-sitapur-taxi'       => 'r_sitapur',
        'dehradun-to-ukhimath-taxi'      => 'r_ukhimath',
        'dehradun-to-karnaprayag-taxi'   => 'r_karnaprayag',
        'dehradun-to-govindghat-taxi'    => 'r_govindghat',
        'dehradun-to-hemkund-sahib-taxi' => 'r_hemkund_sahib',
        'dehradun-to-kainchi-dham-taxi'  => 'r_kainchi_dham',
        'dehradun-to-kasol-taxi'         => 'r_kasol',
        'dehradun-to-valley-of-flowers-taxi' => 'r_valley_of_flowers',
    ];

    return $map[$slug] ?? null;
}

/*
|--------------------------------------------------------------------------
| Resolve master route fare
|--------------------------------------------------------------------------
*/

function anaya_route_master_fare(string $slug): ?int
{
    $key = anaya_route_fare_key($slug);

    if ($key === null) {
        return null;
    }

    if (!function_exists('anaya_rate')) {
        return null;
    }

    $fare = anaya_rate($key);

    return $fare > 0 ? $fare : null;
}

/*
|--------------------------------------------------------------------------
| Fare formatter
|--------------------------------------------------------------------------
*/

function anaya_route_fare_text(?int $fare): string
{
    if (!$fare) {
        return 'fare confirmed before you book';
    }

    return 'fare from Rs ' . number_format($fare);
}

/*
|--------------------------------------------------------------------------
| Synchronise authored fare text
|--------------------------------------------------------------------------
|
| Existing authored content may contain old fare values.
| Example:
| Rs 5,000 -> current master rate
| ₹5,500   -> current master rate
|
| Only the FIRST fare occurrence is replaced.
| This prevents vehicle-specific prices from being destroyed.
|--------------------------------------------------------------------------
*/

function anaya_route_sync_fare_text(
    string $text,
    ?int $fare
): string {

    if (!$fare) {
        return $text;
    }

    $formatted = number_format($fare);

    $patterns = [
        '/Rs\.?\s*[0-9][0-9,]*/i',
        '/₹\s*[0-9][0-9,]*/u',
        '/INR\s*[0-9][0-9,]*/i',
    ];

    foreach ($patterns as $pattern) {
        $new = preg_replace(
            $pattern,
            'Rs ' . $formatted,
            $text,
            1
        );

        if ($new !== null && $new !== $text) {
            return $new;
        }
    }

    return $text;
}

/*
|--------------------------------------------------------------------------
| Approximate distance
|--------------------------------------------------------------------------
*/

function anaya_route_km(): array
{
    return [
        'mussoorie' => 35,
        'haridwar' => 55,
        'rishikesh' => 45,
        'delhi' => 250,
        'nainital' => 280,
        'chandigarh' => 210,
        'kedarnath' => 230,
        'badrinath' => 335,
        'gangotri' => 270,
        'yamunotri' => 220,
        'auli' => 300,
        'chopta' => 200,
        'chakrata' => 90,
        'kanatal' => 80,
        'dhanaulti' => 60,
        'tehri' => 120,
        'uttarkashi' => 180,
        'srinagar-garhwal' => 230,
        'haldwani' => 250,
        'jim-corbett' => 240,
        'manali' => 480,
        'shimla' => 220,
        'roorkee' => 170,
        'saharanpur' => 150,
        'noida' => 230,
        'gurgaon' => 240,
        'gurugram' => 240,
        'ghaziabad' => 225,
        'faridabad' => 250,
        'jaipur' => 530,
        'agra' => 430,
        'mathura' => 380,
        'dehradun' => 0,
        'pauri' => 110,
        'lansdowne' => 150,
        'almora' => 360,
        'ranikhet' => 300,
        'kausani' => 350,
        'pithoragarh' => 410,
        'rudraprayag' => 150,
        'devprayag' => 70,
        'meerut' => 220,
        'bareilly' => 250,
        'ramnagar' => 200,
        'kalka' => 220,
        'panchkula' => 205,
        'mohali' => 215,
        'ludhiana' => 310,
        'amritsar' => 440,
        'patiala' => 230,
        'jalandhar' => 370,
        'kasauli' => 235,
        'chail' => 245,
        'kufri' => 235,
        'dharamshala' => 450,
        'kullu' => 440,
        'solan' => 210,
        'mandi' => 370,
        'dalhousie' => 520,
        'binsar' => 380,
        'mukteshwar' => 320,
        'bhimtal' => 290,
        'naukuchiatal' => 295,
        'munsiyari' => 490,
        'guptkashi' => 215,
        'sonprayag' => 245,
        'phata' => 225,
        'sitapur' => 240,
        'ukhimath' => 210,
        'karnaprayag' => 195,
        'govindghat' => 310,
        'hemkund-sahib' => 310,
        'kainchi-dham' => 300,
        'kasol' => 460,
        'valley-of-flowers' => 310,
    ];
}

/*
|--------------------------------------------------------------------------
| Theme
|--------------------------------------------------------------------------
*/

function anaya_route_theme(string $to): string
{
    $t = strtolower($to);

    if (preg_match(
        '/kedarnath|badrinath|gangotri|yamunotri|char dham|do dham/',
        $t
    )) {
        return 'pilgrim';
    }

    if (preg_match('/auli/', $t)) {
        return 'snow';
    }

    if (preg_match(
        '/chopta|kanatal|dhanaulti|mussoorie|chakrata|manali|shimla|nainital|tehri|uttarkashi|srinagar/',
        $t
    )) {
        return 'hill';
    }

    if (preg_match('/corbett|ramnagar/', $t)) {
        return 'wildlife';
    }

    if (preg_match('/haridwar|rishikesh|mathura/', $t)) {
        return 'river';
    }

    if (preg_match(
        '/delhi|noida|gurgaon|gurugram|ghaziabad|faridabad|chandigarh|roorkee|saharanpur|jaipur|agra|meerut|bareilly/',
        $t
    )) {
        return 'highway';
    }

    return 'hill';
}

/*
|--------------------------------------------------------------------------
| Theme hooks
|--------------------------------------------------------------------------
*/

function anaya_route_theme_hook(string $th): array
{
    return [
        'pilgrim' => [
            'a sacred, well-planned yatra drive',
            'yatra route',
        ],

        'snow' => [
            'a safe climb into the snow belt',
            'mountain route',
        ],

        'hill' => [
            'a scenic, careful hill-road drive',
            'hill route',
        ],

        'forest' => [
            'a quiet forest-cantonment escape',
            'forest route',
        ],

        'highway' => [
            'a smooth, timed highway run',
            'highway',
        ],

        'river' => [
            'a calm riverside pilgrimage drive',
            'route',
        ],

        'plains' => [
            'a comfortable intercity highway drive',
            'highway',
        ],

        'wildlife' => [
            'a wildlife-gateway road trip',
            'route',
        ],
    ][$th] ?? [
        'a comfortable, verified-driver journey',
        'route',
    ];
}

/*
|--------------------------------------------------------------------------
| Parse slug
|--------------------------------------------------------------------------
*/

function anaya_route_parse(string $slug): array
{
    $parts = explode('-to-', $slug, 2);

    $from = str_replace(
        '-',
        ' ',
        $parts[0] ?? ''
    );

    $to = preg_replace(
        '/-taxi$/',
        '',
        $parts[1] ?? ''
    );

    $to = str_replace(
        '-',
        ' ',
        (string)$to
    );

    $f = ucwords($from);
    $t = ucwords($to);

    $dir = (
        strtolower($to) === 'dehradun'
    )
        ? 'in'
        : (
            strtolower($from) === 'dehradun'
                ? 'out'
                : 'cross'
        );

    return [
        'from' => $f,
        'to' => $t,
        'dir' => $dir,
    ];
}

/*
|--------------------------------------------------------------------------
| Travel time
|--------------------------------------------------------------------------
*/

function anaya_route_time(?int $km): string
{
    if (!$km) {
        return '';
    }

    $h = max(
        1,
        (int)ceil($km / 50)
    );

    return $h . '–' . ($h + 1) . ' hr';
}

/*
|--------------------------------------------------------------------------
| Highlights
|--------------------------------------------------------------------------
*/

function anaya_route_pool_highlights(string $th): array
{
    return [
        'pilgrim' => [
            [
                'fa-place-of-worship',
                'Temple darshan',
                'Door-to-temple-area drop with a calm, planned schedule.',
            ],
            [
                'fa-mountain-sun',
                'Scenic valley drive',
                'Confluences and mountain views all the way.',
            ],
            [
                'fa-bed',
                'Overnight halt planning',
                'Sensible halts so the yatra never feels rushed.',
            ],
            [
                'fa-clipboard-check',
                'Yatra logistics support',
                'Registration, road-timing and buffer-day advice.',
            ],
        ],

        'snow' => [
            [
                'fa-snowflake',
                'Snow-belt climb',
                'Drivers trained for ice, fog and chain conditions.',
            ],
            [
                'fa-mountain-sun',
                'Himalayan viewpoints',
                'Clear-weather panoramas of the high peaks.',
            ],
            [
                'fa-van-shuttle',
                'Innova / Crysta advised',
                'Ground clearance and stability on the snow road.',
            ],
            [
                'fa-bed',
                'Joshimath halt option',
                'A comfortable overnight break before the climb.',
            ],
        ],

        'hill' => [
            [
                'fa-mountain-sun',
                'Scenic hill road',
                'Winding ghat sections driven with extra care.',
            ],
            [
                'fa-camera',
                'Viewpoints & falls',
                'Stops at the popular lookouts and waterfalls.',
            ],
            [
                'fa-van-shuttle',
                'Hill-ready vehicles',
                'SUV and Innova options for the climb.',
            ],
            [
                'fa-cloud-sun-rain',
                'Weather-aware driving',
                'Caution planned for monsoon and winter fog.',
            ],
        ],

        'highway' => [
            [
                'fa-road',
                'Open highway run',
                'Mostly expressway for a fast, smooth drive.',
            ],
            [
                'fa-plane-departure',
                'Airport-side drops',
                'Direct to IGI / terminal or city hotels.',
            ],
            [
                'fa-clock',
                'Early-start advised',
                'Beat the traffic for the best travel time.',
            ],
            [
                'fa-van-shuttle',
                'Comfort for long hours',
                'Innova / Crysta for a relaxed long drive.',
            ],
        ],

        'river' => [
            [
                'fa-water',
                'Riverside route',
                'Ghats, ashrams and the Ganga along the way.',
            ],
            [
                'fa-place-of-worship',
                'Pilgrimage stops',
                'Temples and aarti points on request.',
            ],
            [
                'fa-person-swimming',
                'Adventure add-ons',
                'Rafting and yoga-camp drops available.',
            ],
            [
                'fa-clock',
                'Flexible timing',
                'Plan around aarti and check-in times.',
            ],
        ],

        'wildlife' => [
            [
                'fa-paw',
                'Safari-gateway drop',
                'Direct to resort and safari-gate entrances.',
            ],
            [
                'fa-tree',
                'Forest corridor drive',
                'A green, scenic approach to the park.',
            ],
            [
                'fa-binoculars',
                'Sightings en route',
                'Watch for wildlife on the forest stretch.',
            ],
            [
                'fa-bed',
                'Resort check-in help',
                'Door-to-resort drop with luggage care.',
            ],
        ],
    ][$th] ?? [
        [
            'fa-road',
            'Verified driver',
            'A police-verified, route-experienced driver.',
        ],
        [
            'fa-spray-can-sparkles',
            'Clean AC cab',
            'Sanitised, air-conditioned vehicle.',
        ],
        [
            'fa-tags',
            'Fare confirmed upfront',
            'No hidden charges, ever.',
        ],
        [
            'fa-headset',
            '24x7 support',
            'One call away throughout the trip.',
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| FAQ generator
|--------------------------------------------------------------------------
*/

function anaya_route_pool_faq(
    string $th,
    string $from,
    string $to,
    ?int $km,
    string $time,
    ?int $sf
): array {

    $fareA = $sf
        ? (
            'A one way sedan taxi from ' .
            $from .
            ' to ' .
            $to .
            ' usually starts from around ' .
            number_format($sf) .
            ' rupees, with SUV and Innova fares a little higher and confirmed before you book.'
        )
        : (
            'The ' .
            $from .
            ' to ' .
            $to .
            ' taxi fare is confirmed on booking based on vehicle, date and route conditions, and is shared with you before you travel.'
        );

    $distA = $km
        ? (
            'The distance from ' .
            $from .
            ' to ' .
            $to .
            ' is about ' .
            $km .
            ' km and the drive usually takes around ' .
            $time .
            ', depending on traffic, weather and the exact pickup point.'
        )
        : (
            'Travel time and distance for ' .
            $from .
            ' to ' .
            $to .
            ' depend on the chosen route and conditions, and our driver plans the best path when you book.'
        );

    if ($th === 'pilgrim') {

        $q3 = 'Do I need to register for the ' . $to . ' yatra?';

        $a3 = 'Yes, yatra registration is required and our drivers help plan around checkpoints, road timings and buffer days for a smooth darshan.';

    } elseif (in_array($th, ['hill', 'snow'], true)) {

        $q3 = 'Is the ' . $to . ' road safe in monsoon and winter?';

        $a3 = 'Our drivers know the ' . $to . ' hill road well and drive with extra caution in rain, fog and snow; we recommend an Innova or Crysta in winter.';

    } else {

        $q3 = 'Can I book a one way or round trip taxi to ' . $to . '?';

        $a3 = 'Yes, both one way drops and round trips are available, and you can keep the same driver for sightseeing or the return journey.';
    }

    if (in_array($th, ['hill', 'snow'], true)) {

        $a4 = 'An Innova or Crysta is recommended for the ' .
            $to .
            ' hill road, with an Ertiga or SUV for budget family travel and a Tempo Traveller for groups.';

    } elseif ($th === 'pilgrim') {

        $a4 = 'An Innova or Crysta suits families on the ' .
            $to .
            ' yatra, and a Tempo Traveller suits joint families and groups.';

    } else {

        $a4 = 'A sedan is comfortable and economical for two to three travellers, while an Ertiga, Innova or Crysta suits families with luggage on the ' .
            $to .
            ' route.';
    }

    return [
        [
            'What is the taxi fare from ' .
            $from .
            ' to ' .
            $to .
            '?',
            $fareA,
        ],

        [
            'How far is ' .
            $to .
            ' from ' .
            $from .
            ' and how long does it take?',
            $distA,
        ],

        [
            $q3,
            $a3,
        ],

        [
            'Which vehicle is best for ' .
            $from .
            ' to ' .
            $to .
            '?',
            $a4,
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| Related routes
|--------------------------------------------------------------------------
*/

function anaya_route_pool_related(
    string $slug,
    string $th
): array {

    $pool = [

        'pilgrim' => [
            [
                'dehradun-to-kedarnath-taxi',
                'Dehradun to Kedarnath',
            ],
            [
                'dehradun-to-badrinath-taxi',
                'Dehradun to Badrinath',
            ],
            [
                'dehradun-to-gangotri-taxi',
                'Dehradun to Gangotri',
            ],
            [
                'dehradun-to-yamunotri-taxi',
                'Dehradun to Yamunotri',
            ],
            [
                'char-dham-yatra-taxi',
                'Char Dham Yatra',
            ],
            [
                'dehradun-to-rishikesh-taxi',
                'Dehradun to Rishikesh',
            ],
        ],

        'snow' => [
            [
                'dehradun-to-auli-taxi',
                'Dehradun to Auli',
            ],
            [
                'dehradun-to-chopta-taxi',
                'Dehradun to Chopta',
            ],
            [
                'dehradun-to-joshimath-taxi',
                'Dehradun to Joshimath',
            ],
            [
                'dehradun-to-badrinath-taxi',
                'Dehradun to Badrinath',
            ],
            [
                'dehradun-to-kedarnath-taxi',
                'Dehradun to Kedarnath',
            ],
            [
                'dehradun-to-mussoorie-taxi',
                'Dehradun to Mussoorie',
            ],
        ],

        'hill' => [
            [
                'dehradun-to-mussoorie-taxi',
                'Dehradun to Mussoorie',
            ],
            [
                'dehradun-to-dhanaulti-taxi',
                'Dehradun to Dhanaulti',
            ],
            [
                'dehradun-to-chakrata-taxi',
                'Dehradun to Chakrata',
            ],
            [
                'dehradun-to-kanatal-taxi',
                'Dehradun to Kanatal',
            ],
            [
                'dehradun-to-nainital-taxi',
                'Dehradun to Nainital',
            ],
            [
                'dehradun-to-auli-taxi',
                'Dehradun to Auli',
            ],
        ],

        'highway' => [
            [
                'dehradun-to-delhi-taxi',
                'Dehradun to Delhi',
            ],
            [
                'dehradun-to-chandigarh-taxi',
                'Dehradun to Chandigarh',
            ],
            [
                'dehradun-to-noida-taxi',
                'Dehradun to Noida',
            ],
            [
                'dehradun-to-gurgaon-taxi',
                'Dehradun to Gurgaon',
            ],
            [
                'dehradun-to-agra-taxi',
                'Dehradun to Agra',
            ],
            [
                'dehradun-to-haridwar-taxi',
                'Dehradun to Haridwar',
            ],
        ],

        'river' => [
            [
                'dehradun-to-haridwar-taxi',
                'Dehradun to Haridwar',
            ],
            [
                'dehradun-to-rishikesh-taxi',
                'Dehradun to Rishikesh',
            ],
            [
                'dehradun-to-mathura-taxi',
                'Dehradun to Mathura',
            ],
            [
                'dehradun-to-kedarnath-taxi',
                'Dehradun to Kedarnath',
            ],
            [
                'dehradun-to-delhi-taxi',
                'Dehradun to Delhi',
            ],
            [
                'dehradun-to-mussoorie-taxi',
                'Dehradun to Mussoorie',
            ],
        ],

        'wildlife' => [
            [
                'dehradun-to-jim-corbett-taxi',
                'Dehradun to Jim Corbett',
            ],
            [
                'dehradun-to-nainital-taxi',
                'Dehradun to Nainital',
            ],
            [
                'dehradun-to-haldwani-taxi',
                'Dehradun to Haldwani',
            ],
            [
                'dehradun-to-rishikesh-taxi',
                'Dehradun to Rishikesh',
            ],
            [
                'dehradun-to-delhi-taxi',
                'Dehradun to Delhi',
            ],
            [
                'dehradun-to-mussoorie-taxi',
                'Dehradun to Mussoorie',
            ],
        ],
    ];

    $out = [];

    foreach (
        ($pool[$th] ?? $pool['hill'])
        as $r
    ) {

        if ($r[0] !== $slug) {

            $out[] = $r;

            if (count($out) >= 6) {
                break;
            }
        }
    }

    return $out;
}

/*
|--------------------------------------------------------------------------
| Route matrix
|--------------------------------------------------------------------------
*/

function anaya_route_pool_matrix(
    string $dir,
    string $from,
    string $to
): array {

    if ($dir === 'out') {

        return [
            [
                'Dehradun city',
                $to . ' main drop',
                'Direct door-to-door at your chosen time.',
            ],
            [
                'Jolly Grant Airport',
                $to,
                'Longer total travel; ideal for fly-in travellers.',
            ],
            [
                'Dehradun Railway Station',
                $to,
                'Good for travellers arriving by train.',
            ],
        ];
    }

    if ($dir === 'in') {

        return [
            [
                $from . ' city / hotel',
                'Dehradun city drop',
                'Direct to your home, hotel or office.',
            ],
            [
                $from,
                'Jolly Grant Airport',
                'Plan an early start for a flight connection.',
            ],
            [
                $from,
                'Dehradun Railway Station',
                'Timed to your onward train.',
            ],
        ];
    }

    return [
        [
            $from . ' city',
            $to . ' main drop',
            'Direct intercity door-to-door drop.',
        ],
        [
            $from,
            $to . ' via best route',
            'Driver picks the fastest open route.',
        ],
        [
            $from . ' station / airport',
            $to,
            'Coordinated pickup on request.',
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| Vehicles
|--------------------------------------------------------------------------
*/

function anaya_route_pool_vehicles(): array
{
    return [
        [
            'Sedan / Dzire',
            'fa-car',
            '1–4 pax',
            'Budget one-way drops',
        ],
        [
            'Ertiga / SUV',
            'fa-truck-monster',
            '4–6 pax',
            'Families and extra luggage',
        ],
        [
            'Innova / Crysta',
            'fa-van-shuttle',
            '5–7 pax',
            'Hill routes and long journeys',
        ],
        [
            'Tempo / Urbania',
            'fa-bus-simple',
            'Groups',
            'On request for groups',
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| Merge authored override
|--------------------------------------------------------------------------
*/

function anaya_route_merge(
    string $slug,
    array $ov
): array {

    $p = anaya_route_parse($slug);

    $km = $ov['km']
        ?? (
            anaya_route_km()[
                strtolower($p['to'])
            ]
            ?? null
        );

    $time = $ov['time']
        ?? anaya_route_time($km);

    $th = $ov['theme']
        ?? anaya_route_theme($p['to']);

    /*
     * MASTER FARE
     *
     * Override value is intentionally ignored for normal
     * routes if a rates.php key exists.
     */
    $masterFare = anaya_route_master_fare($slug);

    /*
     * Custom quote routes:
     * Kedarnath / Badrinath / Gangotri / Yamunotri
     * have 0 in rates.php, therefore null.
     */
    $sf = $masterFare;

    $sn = $ov['service_name']
        ?? anaya_route_service_name($p);

    /*
     * Tagline
     *
     * If authored tagline exists, sync its first fare.
     * Otherwise generate dynamically.
     */
    if (isset($ov['tagline'])) {

        $tagline = anaya_route_sync_fare_text(
            (string)$ov['tagline'],
            $sf
        );

    } else {

        $tagline = anaya_route_tagline(
            $p,
            $sf
        );
    }

    /*
     * FAQs
     */
    if (isset($ov['faqs']) && is_array($ov['faqs'])) {

        $faqs = $ov['faqs'];

        foreach ($faqs as $i => $faq) {

            if (
                is_array($faq) &&
                isset($faq[1]) &&
                is_string($faq[1])
            ) {

                $faqs[$i][1] =
                    anaya_route_sync_fare_text(
                        $faq[1],
                        $sf
                    );
            }
        }

    } else {

        $faqs = anaya_route_pool_faq(
            $th,
            $p['from'],
            $p['to'],
            $km,
            $time,
            $sf
        );
    }

    /*
     * Description
     */
    $desc = $ov['desc']
        ?? anaya_route_desc(
            $sn,
            $km
        );

    return [
        'slug' => $slug,

        'from' => $p['from'],

        'to' => $p['to'],

        'dir' => $p['dir'],

        'theme' => $th,

        'km' => $km,

        'time' => $time,

        'sedan_from' => $sf,

        'service_name' => $sn,

        'title' => $ov['title']
            ?? anaya_route_title(
                $sn,
                $th
            ),

        'desc' => $desc,

        'tagline' => $tagline,

        'highlights' => $ov['highlights']
            ?? anaya_route_pool_highlights($th),

        'vehicles' => $ov['vehicles']
            ?? anaya_route_pool_vehicles(),

        'matrix' => $ov['matrix']
            ?? anaya_route_pool_matrix(
                $p['dir'],
                $p['from'],
                $p['to']
            ),

        'faqs' => $faqs,

        'related' => $ov['related']
            ?? anaya_route_pool_related(
                $slug,
                $th
            ),

        'prose' => $ov['prose']
            ?? anaya_route_prose(
                $p,
                $th,
                $km,
                $time
            ),

        'timeline' => $ov['timeline']
            ?? anaya_route_timeline(
                $p,
                $th,
                $p['to']
            ),
    ];
}

/*
|--------------------------------------------------------------------------
| Generate route
|--------------------------------------------------------------------------
*/

function anaya_route_generate(
    string $slug
): array {

    return anaya_route_merge(
        $slug,
        []
    );
}

/*
|--------------------------------------------------------------------------
| Service name
|--------------------------------------------------------------------------
*/

function anaya_route_service_name(
    array $p
): string {

    if ($p['dir'] === 'in') {

        return $p['from'] .
            ' to Dehradun Taxi';
    }

    if ($p['dir'] === 'cross') {

        return $p['from'] .
            ' to ' .
            $p['to'] .
            ' Taxi';
    }

    return 'Dehradun to ' .
        $p['to'] .
        ' Taxi';
}

/*
|--------------------------------------------------------------------------
| SEO title
|--------------------------------------------------------------------------
*/

function anaya_route_title(
    string $sn,
    string $th
): string {

    return $sn .
        (
            $th === 'pilgrim'
                ? ' | Yatra Cab & Fare - Anaya Cab'
                : ' | Cab Fare & Booking - Anaya Cab'
        );
}

/*
|--------------------------------------------------------------------------
| SEO description
|--------------------------------------------------------------------------
*/

function anaya_route_desc(
    string $sn,
    ?int $km
): string {

    $d = 'Book ' .
        $sn .
        ' with Anaya Cab Service.';

    if ($km) {

        $d .=
            ' About ' .
            $km .
            ' km, verified drivers, fixed fares and 24x7 booking.';

    } else {

        $d .=
            ' Verified drivers, fixed fares and 24x7 booking.';
    }

    $d .=
        ' Call ' .
        BUSINESS_PHONE .
        '.';

    return $d;
}

/*
|--------------------------------------------------------------------------
| Tagline
|--------------------------------------------------------------------------
*/

function anaya_route_tagline(
    array $p,
    ?int $sf
): string {

    $fare = $sf
        ? (
            'fare from Rs ' .
            number_format($sf) .
            ' for a sedan, '
        )
        : 'fare confirmed before you book, ';

    if ($p['dir'] === 'in') {

        return 'Book a ' .
            $p['from'] .
            ' to Dehradun taxi with Anaya Cab Service — ' .
            $fare .
            'verified drivers and clean AC cabs.';
    }

    if ($p['dir'] === 'cross') {

        return 'Book a ' .
            $p['from'] .
            ' to ' .
            $p['to'] .
            ' taxi with Anaya Cab Service — ' .
            $fare .
            'verified drivers and clean AC cabs.';
    }

    return 'Book a Dehradun to ' .
        $p['to'] .
        ' taxi with Anaya Cab Service — ' .
        $fare .
        'verified drivers and clean AC cabs.';
}

/*
|--------------------------------------------------------------------------
| Prose
|--------------------------------------------------------------------------
*/

function anaya_route_prose(
    array $p,
    string $th,
    ?int $km,
    string $time
): array {

    $from = $p['from'];
    $to = $p['to'];

    $hook = anaya_route_theme_hook($th);

    $dist = $km
        ? (
            'the ' .
            $km .
            ' km ' .
            $hook[1] .
            ' in about ' .
            $time
        )
        : 'the route';

    $a =
        '<h2>Planning the ' .
        $from .
        ' to ' .
        $to .
        ' taxi</h2>' .
        '<p>The ' .
        $from .
        ' to ' .
        $to .
        ' journey is ' .
        $hook[0] .
        ', and Anaya Cab Service assigns a police-verified driver who knows ' .
        $dist .
        '. Whether you need a simple one-way drop or a round trip with the cab kept with you, the fare is fixed and shared before you travel, with tolls, parking and any halt charges explained upfront so there are no surprises on the road.</p>';

    $b =
        '<p>Travelling with family or extra luggage? An <strong>Innova or Crysta</strong> makes the trip noticeably more comfortable, and a <strong>Tempo Traveller</strong> can be arranged with advance notice for groups. From the first call to the final drop, the same accountable team handles pickup timing, route planning and 24x7 support — so the ' .
        $from .
        ' to ' .
        $to .
        ' drive feels calm, safe and entirely handled.</p>';

    return [
        $a,
        $b,
    ];
}

/*
|--------------------------------------------------------------------------
| Timeline
|--------------------------------------------------------------------------
*/

function anaya_route_timeline(
    array $p,
    string $th,
    string $to
): array {

    $from = $p['from'];

    if ($th === 'pilgrim') {

        return [
            [
                'fa-circle-dot',
                'Pickup in ' . $from,
                'At your chosen time, usually an early start.',
            ],
            [
                'fa-water',
                'River valleys & confluences',
                'Scenic halts along the pilgrimage road.',
            ],
            [
                'fa-bed',
                'Overnight halt',
                'A sensible break before the final climb.',
            ],
            [
                'fa-place-of-worship',
                'Drop near the temple',
                'Direct to the temple area / roadhead.',
            ],
        ];
    }

    if (in_array($th, ['hill', 'snow'], true)) {

        return [
            [
                'fa-circle-dot',
                'Pickup in ' . $from,
                'Coordinated to your schedule.',
            ],
            [
                'fa-road',
                'Plains to hill approach',
                'The gradient begins to rise.',
            ],
            [
                'fa-mountain',
                'The ghat climb',
                'Winding sections driven with care.',
            ],
            [
                'fa-location-dot',
                'Drop in ' . $to,
                'At your hotel or sightseeing point.',
            ],
        ];
    }

    return [
        [
            'fa-circle-dot',
            'Pickup in ' . $from,
            'Door-to-door at your chosen time.',
        ],
        [
            'fa-road',
            'Highway stretch',
            'A fast, smooth open-road run.',
        ],
        [
            'fa-mug-hot',
            'Comfort stop',
            'A planned break on longer drives.',
        ],
        [
            'fa-location-dot',
            'Drop in ' . $to,
            'Direct to your hotel or address.',
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| AUTHORED OVERRIDES
|--------------------------------------------------------------------------
|
| IMPORTANT:
| Do NOT put route fare values here.
| sedan_from is resolved automatically from rates.php.
|
|--------------------------------------------------------------------------
*/

function anaya_route_overrides(): array
{
    return [

        /*
        |--------------------------------------------------------------------------
        | Dehradun -> Haridwar
        |--------------------------------------------------------------------------
        */

        'dehradun-to-haridwar-taxi' => [
            'km' => 55,
            'time' => '1.5–2 hr',
            'theme' => 'river',

            'tagline' =>
                'Book a Dehradun to Haridwar taxi from Rs 1,350 for a sedan — a calm Ganga-side drive with verified drivers and a fare fixed before you travel.',

            'highlights' => [
                [
                    'fa-water',
                    'Har Ki Pauri drop',
                    'Direct to the ghat, hotels and ashrams.',
                ],
                [
                    'fa-place-of-worship',
                    'Ganga aarti timing',
                    'Plan pickup around the evening aarti.',
                ],
                [
                    'fa-clock',
                    'Early or late pickups',
                    '24x7 for morning and night trains.',
                ],
                [
                    'fa-van-shuttle',
                    'Family & group cabs',
                    'Ertiga, Innova and Tempo options.',
                ],
            ],

            'faqs' => [
                [
                    'What is the taxi fare from Dehradun to Haridwar?',
                    'A one way sedan taxi from Dehradun to Haridwar usually starts from around 1,350 rupees, with SUV and Innova fares a little higher and confirmed before you book.',
                ],
                [
                    'How far is Haridwar from Dehradun and how long does it take?',
                    'Haridwar is about 55 km from Dehradun and the drive usually takes 1.5 to 2 hours depending on traffic and the exact pickup point.',
                ],
                [
                    'Can I combine Haridwar with Rishikesh on one trip?',
                    'Yes, the driver can cover Har Ki Pauri and then Rishikesh on a round trip or a multi-stop booking, with the plan agreed before travel.',
                ],
                [
                    'Which vehicle is best for Dehradun to Haridwar?',
                    'A sedan suits two to three travellers, while an Ertiga or Innova is better for families with luggage and a Tempo Traveller for groups.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'haridwar-to-dehradun-taxi',
                    'Haridwar to Dehradun',
                ],
                [
                    'dehradun-to-delhi-taxi',
                    'Dehradun to Delhi',
                ],
                [
                    'dehradun-to-badrinath-taxi',
                    'Dehradun to Badrinath',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Dehradun -> Rishikesh
        |--------------------------------------------------------------------------
        */

        'dehradun-to-rishikesh-taxi' => [
            'km' => 45,
            'time' => '1–1.5 hr',
            'theme' => 'river',

            'tagline' =>
                'Book a Dehradun to Rishikesh taxi from Rs 1,150 for a sedan — perfect for ashrams, rafting camps and yoga retreats, with verified drivers.',

            'highlights' => [
                [
                    'fa-person-swimming',
                    'Rafting-camp drops',
                    'Direct to Shivpuri and Tapovan camps.',
                ],
                [
                    'fa-spa',
                    'Yoga & ashram stays',
                    'Door-to-ashram pickup and drop.',
                ],
                [
                    'fa-water',
                    'Triveni & Ram Jhula',
                    'Popular ghat and bridge stops.',
                ],
                [
                    'fa-plane-departure',
                    'Airport connections',
                    'Easy link to Jolly Grant transfers.',
                ],
            ],

            'faqs' => [
                [
                    'What is the taxi fare from Dehradun to Rishikesh?',
                    'A one way sedan taxi from Dehradun to Rishikesh usually starts from around 1,150 rupees, with SUV and Innova fares a little higher and confirmed before you book.',
                ],
                [
                    'How far is Rishikesh from Dehradun and how long does it take?',
                    'Rishikesh is about 45 km from Dehradun and the drive usually takes 1 to 1.5 hours depending on traffic.',
                ],
                [
                    'Can the taxi drop me at a rafting camp or ashram?',
                    'Yes, direct drops to rafting camps in Shivpuri and ashrams in Tapovan or Swarg Ashram are available on request.',
                ],
                [
                    'Which vehicle is best for Dehradun to Rishikesh?',
                    'A sedan is ideal for solo and couple travel, while an Ertiga or Innova suits families with luggage.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'rishikesh-to-dehradun-taxi',
                    'Rishikesh to Dehradun',
                ],
                [
                    'dehradun-airport-taxi-service',
                    'Airport Taxi',
                ],
                [
                    'dehradun-to-delhi-taxi',
                    'Dehradun to Delhi',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Dehradun -> Delhi
        |--------------------------------------------------------------------------
        */

        'dehradun-to-delhi-taxi' => [
            'km' => 250,
            'time' => '5–6 hr',
            'theme' => 'highway',

            'tagline' =>
                'Book a Dehradun to Delhi taxi from Rs 3,500 for a sedan — a smooth expressway run with IGI Airport and NCR drops, verified drivers and a fixed fare.',

            'highlights' => [
                [
                    'fa-plane-departure',
                    'IGI Airport drops',
                    'Terminal-wise drop with flight-time planning.',
                ],
                [
                    'fa-road',
                    'Expressway run',
                    'A fast, comfortable open-highway drive.',
                ],
                [
                    'fa-city',
                    'NCR-wide drops',
                    'Noida, Gurgaon, Ghaziabad and more.',
                ],
                [
                    'fa-clock',
                    'Early-start advised',
                    'Beat the traffic for the best travel time.',
                ],
            ],

            'faqs' => [
                [
                    'What is the taxi fare from Dehradun to Delhi?',
                    'A one way sedan taxi from Dehradun to Delhi usually starts from around 3,500 rupees, with SUV and Innova fares higher and confirmed before you book.',
                ],
                [
                    'How far is Delhi from Dehradun and how long does it take?',
                    'Delhi is about 250 km from Dehradun and the expressway drive usually takes 5 to 6 hours depending on traffic and the exact drop point.',
                ],
                [
                    'Can you drop me at IGI Airport Terminal 1, 2 or 3?',
                    'Yes, terminal-wise drops at IGI Airport are available, and we plan the pickup time around your flight.',
                ],
                [
                    'Which vehicle is best for Dehradun to Delhi?',
                    'A sedan is comfortable for two to three travellers, while an Innova or Crysta is better for families on the long highway drive.',
                ],
            ],

            'related' => [
                [
                    'delhi-to-dehradun-taxi',
                    'Delhi to Dehradun',
                ],
                [
                    'dehradun-to-noida-taxi',
                    'Dehradun to Noida',
                ],
                [
                    'dehradun-to-gurgaon-taxi',
                    'Dehradun to Gurgaon',
                ],
                [
                    'dehradun-to-chandigarh-taxi',
                    'Dehradun to Chandigarh',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
                [
                    'dehradun-airport-taxi-service',
                    'Airport Taxi',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Nainital
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        | Old FAQ had ₹5,500 while master rate is ₹5,600.
        | Merge layer now automatically syncs first fare.
        |
        */

        'dehradun-to-nainital-taxi' => [
            'km' => 280,
            'time' => '7–8 hr',
            'theme' => 'hill',

            'tagline' =>
                'Book a Dehradun to Nainital taxi from Rs 5,600 for a sedan — a long Kumaon route via Haldwani and Kathgodam with hill-expert drivers.',

            'highlights' => [
                [
                    'fa-mountain',
                    'Kumaon lake route',
                    'Scenic drive up to the lake town.',
                ],
                [
                    'fa-water',
                    'Naini Lake drop',
                    'Direct to Mallital and Tallital hotels.',
                ],
                [
                    'fa-binoculars',
                    'Viewpoint stops',
                    'Snow View and Tiffin Top on request.',
                ],
                [
                    'fa-van-shuttle',
                    'Hill-ready cabs',
                    'Innova and SUV for the long climb.',
                ],
            ],

            'faqs' => [
                [
                    'What is the taxi fare from Dehradun to Nainital?',
                    'A one way sedan taxi from Dehradun to Nainital starts from the current website rate for a Dzire. Ertiga, SUV and Innova Crysta fares are confirmed separately before booking.',
                ],
                [
                    'How far is Nainital from Dehradun and how long does it take?',
                    'Nainital is about 280 km from Dehradun and the drive usually takes 7 to 8 hours via Haldwani and Kathgodam.',
                ],
                [
                    'Can the taxi cover Bhimtal or Corbett on the way?',
                    'Yes, side stops at Bhimtal, Sattal or the Corbett side can be added on a round trip or multi-day booking.',
                ],
                [
                    'Which vehicle is best for Dehradun to Nainital?',
                    'An Innova or SUV is recommended for the long hill route, with a Tempo Traveller for groups.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-haldwani-taxi',
                    'Dehradun to Haldwani',
                ],
                [
                    'dehradun-to-jim-corbett-taxi',
                    'Dehradun to Jim Corbett',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-delhi-taxi',
                    'Dehradun to Delhi',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-auli-taxi',
                    'Dehradun to Auli',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Kedarnath
        |--------------------------------------------------------------------------
        */

        'dehradun-to-kedarnath-taxi' => [
            'km' => 230,
            'time' => '8–9 hr',
            'theme' => 'pilgrim',

            'tagline' =>
                'Book a Dehradun to Kedarnath taxi with Anaya Cab Service — we take you to the permitted roadhead at Sonprayag / Gaurikund with hill-expert drivers and a custom yatra quote.',

            'highlights' => [
                [
                    'fa-om',
                    'Roadhead drop',
                    'Taxi to Sonprayag / Gaurikund; trek or heli onward.',
                ],
                [
                    'fa-mountain-sun',
                    'Mandakini valley drive',
                    'Scenic, careful mountain driving.',
                ],
                [
                    'fa-bed',
                    'Guptkashi halt',
                    'A common overnight stop before the climb.',
                ],
                [
                    'fa-clipboard-check',
                    'Yatra planning help',
                    'Registration, timing and buffer-day advice.',
                ],
            ],

            'faqs' => [
                [
                    'Does the taxi go all the way to Kedarnath temple?',
                    'No, the taxi goes up to the permitted roadhead at Sonprayag or Gaurikund, and the temple is reached on foot or by authorised helicopter, pony or palki.',
                ],
                [
                    'How much does a Dehradun to Kedarnath taxi cost?',
                    'The fare is a custom yatra quote based on vehicle, number of days and season, and is confirmed on WhatsApp or call before you travel.',
                ],
                [
                    'Which vehicle is best for the Kedarnath route?',
                    'An Innova or Crysta is recommended for hill comfort, and a Tempo Traveller suits joint families and groups.',
                ],
                [
                    'Should I keep buffer days for the Kedarnath yatra?',
                    'Yes, keeping one or two buffer days is wise in peak and monsoon season for weather and road closures.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-badrinath-taxi',
                    'Dehradun to Badrinath',
                ],
                [
                    'char-dham-yatra-taxi',
                    'Char Dham Yatra',
                ],
                [
                    'dehradun-to-gangotri-taxi',
                    'Dehradun to Gangotri',
                ],
                [
                    'dehradun-to-yamunotri-taxi',
                    'Dehradun to Yamunotri',
                ],
                [
                    'jolly-grant-airport-to-kedarnath-taxi',
                    'Airport to Kedarnath',
                ],
                [
                    'haridwar-to-kedarnath-taxi',
                    'Haridwar to Kedarnath',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Gangotri
        |--------------------------------------------------------------------------
        */

        'dehradun-to-gangotri-taxi' => [
            'km' => 270,
            'time' => '9–10 hr',
            'theme' => 'pilgrim',

            'tagline' =>
                'Book a Dehradun to Gangotri taxi with Anaya Cab Service — via Uttarkashi and the Harsil valley, with hill-expert drivers and a custom yatra quote.',

            'highlights' => [
                [
                    'fa-water',
                    'Source of the Ganga',
                    'Road up to the Gangotri temple town.',
                ],
                [
                    'fa-mountain-sun',
                    'Harsil valley views',
                    'One of the most scenic yatra stretches.',
                ],
                [
                    'fa-place-of-worship',
                    'Uttarkashi halt',
                    'A natural overnight stop on the route.',
                ],
                [
                    'fa-clipboard-check',
                    'Seasonal planning',
                    'Road and weather checks before departure.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-yamunotri-taxi',
                    'Dehradun to Yamunotri',
                ],
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-badrinath-taxi',
                    'Dehradun to Badrinath',
                ],
                [
                    'char-dham-yatra-taxi',
                    'Char Dham Yatra',
                ],
                [
                    'dehradun-to-uttarkashi-taxi',
                    'Dehradun to Uttarkashi',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Yamunotri
        |--------------------------------------------------------------------------
        */

        'dehradun-to-yamunotri-taxi' => [
            'km' => 220,
            'time' => '7–8 hr',
            'theme' => 'pilgrim',

            'tagline' =>
                'Book a Dehradun to Yamunotri taxi with Anaya Cab Service — to the roadhead near Janki Chatti, with hill-expert drivers and a custom yatra quote.',

            'highlights' => [
                [
                    'fa-mountain',
                    'Janki Chatti roadhead',
                    'Taxi to the trek base for Yamunotri.',
                ],
                [
                    'fa-person-hiking',
                    'Trek & pony support',
                    'Onward temple access on foot or pony.',
                ],
                [
                    'fa-bed',
                    'Barkot halt',
                    'A common overnight stop before the trek.',
                ],
                [
                    'fa-clipboard-check',
                    'Yatra logistics',
                    'Registration and timing help.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-gangotri-taxi',
                    'Dehradun to Gangotri',
                ],
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-badrinath-taxi',
                    'Dehradun to Badrinath',
                ],
                [
                    'char-dham-yatra-taxi',
                    'Char Dham Yatra',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Chandigarh
        |--------------------------------------------------------------------------
        */

        'dehradun-to-chandigarh-taxi' => [
            'km' => 210,
            'time' => '4–5 hr',
            'theme' => 'highway',

            'tagline' =>
                'Book a Dehradun to Chandigarh taxi from Rs 4,000 for a sedan — a smooth highway run to the Tricity with verified drivers and a fixed fare.',

            'highlights' => [
                [
                    'fa-city',
                    'Tricity drops',
                    'Chandigarh, Mohali and Panchkula.',
                ],
                [
                    'fa-road',
                    'Highway comfort',
                    'A fast, open-road intercity drive.',
                ],
                [
                    'fa-briefcase',
                    'Business travel',
                    'Reliable pickups for meetings.',
                ],
                [
                    'fa-van-shuttle',
                    'Family & group cabs',
                    'Innova and Tempo options.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-delhi-taxi',
                    'Dehradun to Delhi',
                ],
                [
                    'dehradun-to-shimla-taxi',
                    'Dehradun to Shimla',
                ],
                [
                    'dehradun-to-manali-taxi',
                    'Dehradun to Manali',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-noida-taxi',
                    'Dehradun to Noida',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Jim Corbett
        |--------------------------------------------------------------------------
        */

        'dehradun-to-jim-corbett-taxi' => [
            'km' => 240,
            'time' => '6–7 hr',
            'theme' => 'wildlife',

            'tagline' =>
                'Book a Dehradun to Jim Corbett taxi from Rs 3,500 for a sedan — direct to Ramnagar resorts and safari gates with verified drivers.',

            'highlights' => [
                [
                    'fa-paw',
                    'Safari-gate drops',
                    'Direct to resort and gate entrances.',
                ],
                [
                    'fa-tree',
                    'Forest corridor',
                    'A green, scenic approach to the park.',
                ],
                [
                    'fa-bed',
                    'Resort check-in',
                    'Door-to-resort drop with luggage care.',
                ],
                [
                    'fa-binoculars',
                    'Wildlife en route',
                    'Watch for sightings on the forest stretch.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-nainital-taxi',
                    'Dehradun to Nainital',
                ],
                [
                    'dehradun-to-haldwani-taxi',
                    'Dehradun to Haldwani',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-delhi-taxi',
                    'Dehradun to Delhi',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Chopta
        |--------------------------------------------------------------------------
        */

        'dehradun-to-chopta-taxi' => [
            'km' => 200,
            'time' => '6–7 hr',
            'theme' => 'hill',

            'tagline' =>
                'Book a Dehradun to Chopta taxi from Rs 3,000 for a sedan — the gateway to Tungnath and Chandrashila, with hill-expert drivers.',

            'highlights' => [
                [
                    'fa-mountain',
                    'Tungnath base',
                    'Drop for the Tungnath and Chandrashila trek.',
                ],
                [
                    'fa-tree',
                    'Mini-Switzerland meadows',
                    'Quiet alpine camps and views.',
                ],
                [
                    'fa-van-shuttle',
                    'Hill-ready cabs',
                    'Innova and SUV for the climb.',
                ],
                [
                    'fa-cloud-sun-rain',
                    'Weather-aware driving',
                    'Caution planned for fog and rain.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-kanatal-taxi',
                    'Dehradun to Kanatal',
                ],
                [
                    'dehradun-to-dhanaulti-taxi',
                    'Dehradun to Dhanaulti',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-auli-taxi',
                    'Dehradun to Auli',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Kanatal
        |--------------------------------------------------------------------------
        */

        'dehradun-to-kanatal-taxi' => [
            'km' => 80,
            'time' => '2.5–3 hr',
            'theme' => 'hill',

            'tagline' =>
                'Book a Dehradun to Kanatal taxi from Rs 2,200 for a sedan — a quiet hill-stay escape with camps, resorts and pine-forest views.',

            'highlights' => [
                [
                    'fa-campground',
                    'Camp & resort drops',
                    'Direct to Kanatal stays.',
                ],
                [
                    'fa-tree',
                    'Pine-forest views',
                    'Calm, scenic hill surroundings.',
                ],
                [
                    'fa-mountain-sun',
                    'Kempty-side route',
                    'A pretty hill approach.',
                ],
                [
                    'fa-van-shuttle',
                    'Family cabs',
                    'Ertiga and Innova options.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-dhanaulti-taxi',
                    'Dehradun to Dhanaulti',
                ],
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-chakrata-taxi',
                    'Dehradun to Chakrata',
                ],
                [
                    'dehradun-to-chopta-taxi',
                    'Dehradun to Chopta',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Dhanaulti
        |--------------------------------------------------------------------------
        */

        'dehradun-to-dhanaulti-taxi' => [
            'km' => 60,
            'time' => '2–2.5 hr',
            'theme' => 'hill',

            'tagline' =>
                'Book a Dehradun to Dhanaulti taxi from Rs 1,800 for a sedan — Eco Park, quiet viewpoints and a peaceful hill escape.',

            'highlights' => [
                [
                    'fa-tree',
                    'Eco Park drop',
                    'Direct to the park and resorts.',
                ],
                [
                    'fa-binoculars',
                    'Quiet viewpoints',
                    'Calm Himalayan lookouts.',
                ],
                [
                    'fa-mountain-sun',
                    'Scenic hill road',
                    'A short, pretty climb.',
                ],
                [
                    'fa-van-shuttle',
                    'Family cabs',
                    'Ertiga and Innova options.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-mussoorie-taxi',
                    'Dehradun to Mussoorie',
                ],
                [
                    'dehradun-to-kanatal-taxi',
                    'Dehradun to Kanatal',
                ],
                [
                    'dehradun-to-chakrata-taxi',
                    'Dehradun to Chakrata',
                ],
                [
                    'dehradun-to-chopta-taxi',
                    'Dehradun to Chopta',
                ],
                [
                    'dehradun-to-rishikesh-taxi',
                    'Dehradun to Rishikesh',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Mussoorie
        |--------------------------------------------------------------------------
        */

        'dehradun-to-mussoorie-taxi' => [
            'km' => 35,
            'time' => '1–1.5 hr',
            'theme' => 'hill',
        ],

        /*
        |--------------------------------------------------------------------------
        | Do Dham
        |--------------------------------------------------------------------------
        */

        'do-dham-yatra-taxi' => [
            'service_name' => 'Do Dham Yatra Taxi',

            'title' =>
                'Do Dham Yatra Taxi from Dehradun | Kedarnath + Badrinath Package - Anaya Cab',

            'desc' =>
                'Book a Do Dham Yatra taxi from Dehradun covering Kedarnath and Badrinath with hill-expert drivers, comfortable Innova Crysta and Tempo Traveller options, and a flexible day-by-day plan. Call ' .
                BUSINESS_PHONE .
                '.',

            'tagline' =>
                'Book a Do Dham Yatra taxi from Dehradun — Kedarnath and Badrinath in one planned circuit with hill-expert drivers and a custom yatra quote.',

            'theme' => 'pilgrim',

            'highlights' => [
                [
                    'fa-om',
                    'Both dhams, one circuit',
                    'Kedarnath and Badrinath planned in sequence.',
                ],
                [
                    'fa-van-shuttle',
                    'Innova / Crysta advised',
                    'Comfort on long mountain days.',
                ],
                [
                    'fa-bed',
                    'Sensible halts',
                    'Guptkashi and Joshimath overnight planning.',
                ],
                [
                    'fa-clipboard-check',
                    'Yatra logistics',
                    'Registration, road-timing and buffer-day advice.',
                ],
            ],

            'faqs' => [
                [
                    'How many days does the Do Dham Yatra take by taxi?',
                    'A Kedarnath + Badrinath circuit usually takes 5 to 7 days by taxi from Dehradun, depending on pace and halts.',
                ],
                [
                    'Which vehicle is best for the Do Dham Yatra?',
                    'An Innova or Crysta suits families, and a Tempo Traveller suits joint families and groups on the mountain circuit.',
                ],
                [
                    'Does the taxi go to the Kedarnath temple?',
                    'The taxi goes to the permitted roadhead at Sonprayag / Gaurikund; the temple is reached on foot or by helicopter, pony or palki.',
                ],
                [
                    'What is included in the Do Dham taxi package?',
                    'The package includes the vehicle with an experienced hill driver, fuel, toll and parking; registration and trek/heli costs are separate.',
                ],
            ],

            'related' => [
                [
                    'dehradun-to-kedarnath-taxi',
                    'Dehradun to Kedarnath',
                ],
                [
                    'dehradun-to-badrinath-taxi',
                    'Dehradun to Badrinath',
                ],
                [
                    'char-dham-yatra-taxi',
                    'Char Dham Yatra',
                ],
                [
                    'dehradun-to-rudraprayag-taxi',
                    'Dehradun to Rudraprayag',
                ],
                [
                    'dehradun-to-joshimath-taxi',
                    'Dehradun to Joshimath',
                ],
                [
                    'dehradun-to-haridwar-taxi',
                    'Dehradun to Haridwar',
                ],
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | Routes using master rates automatically
        |--------------------------------------------------------------------------
        */

        'dehradun-to-pauri-taxi' => [
            'km' => 110,
            'time' => '2.5–3 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-lansdowne-taxi' => [
            'km' => 150,
            'time' => '3–4 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-almora-taxi' => [
            'km' => 360,
            'time' => '8–9 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-ranikhet-taxi' => [
            'km' => 300,
            'time' => '7–8 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-kausani-taxi' => [
            'km' => 350,
            'time' => '8–9 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-pithoragarh-taxi' => [
            'km' => 410,
            'time' => '9–10 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-rudraprayag-taxi' => [
            'km' => 150,
            'time' => '3.5–4 hr',
            'theme' => 'pilgrim',
        ],

        'dehradun-to-devprayag-taxi' => [
            'km' => 70,
            'time' => '1.5–2 hr',
            'theme' => 'pilgrim',
        ],

        'dehradun-to-uttarkashi-taxi' => [
            'km' => 180,
            'time' => '5–6 hr',
            'theme' => 'pilgrim',
        ],

        'dehradun-to-srinagar-garhwal-taxi' => [
            'km' => 230,
            'time' => '6–7 hr',
            'theme' => 'pilgrim',
        ],

        'dehradun-to-joshimath-taxi' => [
            'km' => 290,
            'time' => '7–8 hr',
            'theme' => 'pilgrim',
        ],

        'dehradun-to-meerut-taxi' => [
            'km' => 220,
            'time' => '4–5 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-bareilly-taxi' => [
            'km' => 250,
            'time' => '5–6 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-roorkee-taxi' => [
            'km' => 170,
            'time' => '3.5–4 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-saharanpur-taxi' => [
            'km' => 150,
            'time' => '3–4 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-haldwani-taxi' => [
            'km' => 250,
            'time' => '6–7 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-ramnagar-taxi' => [
            'km' => 200,
            'time' => '5–6 hr',
            'theme' => 'wildlife',
        ],

        'dehradun-to-tehri-taxi' => [
            'km' => 120,
            'time' => '3–4 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-manali-taxi' => [
            'km' => 480,
            'time' => '10–11 hr',
            'theme' => 'hill',
        ],

        'dehradun-to-shimla-taxi' => [
            'km' => 220,
            'time' => '5–6 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-agra-taxi' => [
            'km' => 430,
            'time' => '8–9 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-mathura-taxi' => [
            'km' => 380,
            'time' => '7–8 hr',
            'theme' => 'river',
        ],

        'dehradun-to-jaipur-taxi' => [
            'km' => 530,
            'time' => '10–11 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-noida-taxi' => [
            'km' => 230,
            'time' => '5–6 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-ghaziabad-taxi' => [
            'km' => 225,
            'time' => '5–6 hr',
            'theme' => 'highway',
        ],

        'dehradun-to-faridabad-taxi' => [
            'km' => 250,
            'time' => '5–6 hr',
            'theme' => 'highway',
        ],
    ];
}