<?php
/**
* INTERNAL LINKING MATRIX v2.0 — pillar hub backlinks + blog cross-links + CTA reinforcement.
* route-template.php se $__e (route entry) padhta hai; theme ke hisaab se
* sahi pillar hub + blog posts link karta hai.
* Loop close: route page → pillar hub (hub pehle se routes ko link karta hai).
* v2.0: forest/plains themes added, staggered reveals, 3D tilt, booking CTA strip.
*/
if (!isset($__e) || !is_array($__e)) { return; }
$__lk_theme = $__e['theme'] ?? 'hill';
$__hub_pool = [
'pilgrim'=>[
['/char-dham-yatra-taxi','Char Dham Yatra Taxi','fa-om','Full 4-dham circuit with day-wise itinerary & winter seats.'],
['/tempo-traveller-in-dehradun','Tempo Traveller for Groups','fa-bus-simple','12–17 seater for joint families & groups.'],
['/dehradun-airport-taxi-service','Jolly Grant Airport Pickup','fa-plane-departure','Flight-tracked transfers to yatra roadheads.'],
],
'snow'=>[
['/char-dham-yatra-taxi','Char Dham Yatra Taxi','fa-om','Combine snow routes with the yatra circuit.'],
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','One-way & round-trip hill cabs at fixed fares.'],
['/innova-taxi-in-dehradun','Innova / Crysta for Hills','fa-van-shuttle','Ground clearance & stability on snow roads.'],
],
'hill'=>[
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','One-way & round-trip hill cabs at fixed fares.'],
['/dehradun-local-sightseeing-taxi','Local Sightseeing Packages','fa-map-location-dot','4hr / 8hr Doon Valley day tours.'],
['/luxury-car-rental-dehradun','Premium Hill Cabs','fa-gem','Crysta & chauffeur-driven comfort.'],
],
'forest'=>[
['/dehradun-to-jim-corbett-taxi','Jim Corbett Safari + Cab','fa-paw','Bundled cab + jeep safari guide with zones.'],
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','One-way & round-trip forest gateways.'],
['/dehradun-local-sightseeing-taxi','Nature & Forest Tours','fa-tree','Themed forest circuit day tours.'],
],
'highway'=>[
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','Fixed-fare intercity drops across North India.'],
['/one-way-taxi-service-in-dehradun','One-Way Taxi','fa-arrow-right-long','Pay only one side of the journey.'],
['/delhi-to-dehradun-taxi','Delhi → Dehradun Pickup','fa-rotate','IGI Airport & NCR to Dehradun transfers.'],
],
'river'=>[
['/char-dham-yatra-taxi','Char Dham Yatra Taxi','fa-om','Haridwar / Rishikesh are the yatra gateways.'],
['/one-way-taxi-service-in-dehradun','One-Way Taxi','fa-arrow-right-long','Ganga-side one-way drops.'],
['/dehradun-airport-taxi-service','Airport Transfer','fa-plane-departure','Jolly Grant pickup & drop, 24×7.'],
],
'plains'=>[
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','Fixed-fare long highway drops.'],
['/one-way-taxi-service-in-dehradun','One-Way Taxi','fa-arrow-right-long','Pay only one side — ideal for plains.'],
['/fleet','Fleet Options','fa-car-side','Sedan to Urbania — pick your ride.'],
],
'wildlife'=>[
['/dehradun-to-jim-corbett-taxi','Jim Corbett Safari + Cab','fa-paw','Bundled cab + jeep safari guide.'],
['/outstation-taxi-from-dehradun','Outstation Taxi','fa-route','One-way & round-trip wildlife gateways.'],
['/dehradun-to-nainital-taxi','Nainital Lake Town','fa-mountain','Pair Corbett with the Kumaon lakes.'],
],
];
$__hubs = $__hub_pool[$__lk_theme] ?? $__hub_pool['hill'];
$__blog_pool = [
'pilgrim'=>[
['/blog/char-dham-yatra-planning-guide','Char Dham planning guide'],
['/blog/char-dham-yatra-taxi-itinerary-dehradun','Day-wise yatra itinerary'],
['/blog/kedarnath-taxi-route-from-dehradun','Kedarnath route guide'],
['/blog/char-dham-yatra-2026-dates-fares','2026 dates & fares'],
],
'snow'=>[
['/blog/char-dham-yatra-planning-guide','Char Dham planning guide'],
['/blog/weekend-trips-from-dehradun-by-cab','Weekend hill trips'],
['/blog/best-time-to-visit-mussoorie','Best time for snow routes'],
],
'hill'=>[
['/blog/best-time-to-visit-mussoorie','Best time for Mussoorie'],
['/blog/weekend-trips-from-dehradun-by-cab','Weekend trips by cab'],
['/blog/one-day-trip-from-dehradun-by-taxi','One-day trips'],
['/blog/hill-driving-tips-uttarakhand','Hill driving tips'],
],
'forest'=>[
['/blog/one-day-trip-from-dehradun-by-taxi','One-day trips'],
['/blog/weekend-trips-from-dehradun-by-cab','Weekend trips'],
['/blog/places-to-visit-in-dehradun-by-taxi','Places near Dehradun'],
],
'highway'=>[
['/blog/dehradun-to-delhi-taxi-time','Delhi taxi time & route'],
['/blog/one-day-trip-from-dehradun-by-taxi','One-day trips'],
['/blog/dehradun-airport-taxi-guide','Airport taxi guide'],
['/blog/dehradun-to-haridwar-distance-taxi','Haridwar distance & fare'],
],
'river'=>[
['/blog/dehradun-to-haridwar-distance-taxi','Haridwar distance & fare'],
['/blog/dehradun-to-rishikesh-distance-taxi','Rishikesh distance & fare'],
['/blog/kanwar-yatra-taxi-from-dehradun','Kanwar Yatra guide'],
],
'plains'=>[
['/blog/dehradun-to-delhi-taxi-time','Delhi taxi time & route'],
['/blog/one-day-trip-from-dehradun-by-taxi','One-day trips'],
['/blog/weekend-trips-from-dehradun-by-cab','Weekend trips'],
],
'wildlife'=>[
['/blog/one-day-trip-from-dehradun-by-taxi','One-day trips'],
['/blog/weekend-trips-from-dehradun-by-cab','Weekend trips'],
['/blog/places-to-visit-in-dehradun-by-taxi','Places near Dehradun'],
],
];
$__bloglinks = $__blog_pool[$__lk_theme] ?? $__blog_pool['hill'];
?>
<style>
/* ═══ INTERNAL LINKING MATRIX v2.0 ═══ */
.rt .lk-sec{position:relative}
.rt .lk-sec::before{content:"";position:absolute;top:0;left:50%;transform:translateX(-50%);width:80px;height:3px;background:linear-gradient(90deg,var(--ac),var(--ac2));border-radius:3px;opacity:.6}
.rt .hubgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:22px}
.rt .hubcard{position:relative;display:flex;gap:14px;align-items:flex-start;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:20px;text-decoration:none;color:var(--ink);transition:transform .35s cubic-bezier(.2,.7,.2,1),box-shadow .35s,border-color .35s;overflow:hidden;transform-style:preserve-3d}
.rt .hubcard::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--ac),var(--ac2));transform:scaleX(0);transform-origin:left;transition:transform .45s cubic-bezier(.2,.7,.2,1)}
.rt .hubcard:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.28);border-color:color-mix(in srgb,var(--ac) 40%,var(--line))}
.rt .hubcard:hover::after{transform:scaleX(1)}
.rt .hub-ic{flex:none;width:46px;height:46px;border-radius:13px;background:color-mix(in srgb,var(--ac) 12%,#fff);color:var(--ac);display:grid;place-items:center;font-size:1.05rem;transition:transform .35s}
.rt .hubcard:hover .hub-ic{transform:scale(1.1) rotate(-5deg)}
.rt .hubcard h3{font-family:'Sora','Poppins',sans-serif;font-size:1rem;font-weight:800;margin:0 0 3px;transition:color .2s}
.rt .hubcard:hover h3{color:var(--ac)}
.rt .hubcard p{margin:0;color:var(--slate);font-size:.84rem;line-height:1.5}
.rt .hub-ar{margin-left:auto;color:var(--ac);align-self:center;transition:transform .3s;opacity:.5}
.rt .hubcard:hover .hub-ar{transform:translateX(5px);opacity:1}
/* Blog chips */
.rt .blogchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-bottom:26px}
/* Booking CTA strip */
.rt .lk-cta{display:flex;align-items:center;justify-content:center;gap:16px;flex-wrap:wrap;background:linear-gradient(135deg,color-mix(in srgb,var(--ac) 8%,#fff),color-mix(in srgb,var(--ac2) 6%,#fff));border:1px solid color-mix(in srgb,var(--ac) 18%,var(--line));border-radius:var(--radius);padding:18px 24px;margin-top:8px}
.rt .lk-cta-txt{font-weight:700;font-size:.95rem;color:var(--ink);display:flex;align-items:center;gap:10px}
.rt .lk-cta-txt i{color:var(--ac);font-size:1.1rem}
.rt .lk-cta-btn{display:inline-flex;align-items:center;gap:8px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.86rem;padding:11px 20px;border-radius:12px;background:var(--ac);color:#fff;text-decoration:none;transition:transform .25s,box-shadow .25s;box-shadow:0 10px 24px -8px color-mix(in srgb,var(--ac) 50%,transparent)}
.rt .lk-cta-btn:hover{transform:translateY(-2px);box-shadow:0 14px 30px -8px color-mix(in srgb,var(--ac) 60%,transparent)}
.rt .lk-cta-btn i{transition:transform .25s}
.rt .lk-cta-btn:hover i{transform:translateX(3px)}
/* Responsive */
@media(max-width:900px){.rt .hubgrid{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.rt .hubgrid{grid-template-columns:1fr}.rt .lk-cta{flex-direction:column;text-align:center;gap:12px}}
@media(prefers-reduced-motion:reduce){.rt .hubcard,.rt .hub-ic,.rt .hub-ar{transition:none!important;transform:none!important}}
</style>
<section class="sec soft rv lk-sec"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-compass"></i> Keep planning</span><h2 class="disp">More ways Anaya Cab helps</h2><p>Pillar guides & travel reads hand-picked for this route.</p></div>
<div class="hubgrid">
<?php foreach ($__hubs as $__hi => $__hb): ?>
<a class="hubcard rv rv-stagger" style="--stagger-i:<?php echo $__hi; ?>" href="<?php echo $__hb[0]; ?>" data-tilt>
<span class="hub-ic"><i class="fa-solid <?php echo $__hb[2]; ?>"></i></span>
<div><h3><?php echo $__hb[1]; ?></h3><p><?php echo $__hb[3]; ?></p></div>
<i class="fa-solid fa-arrow-right hub-ar"></i>
</a>
<?php endforeach; ?>
</div>
<div class="blogchips">
<?php foreach ($__bloglinks as $__bi => $__bl): ?>
<a class="rchip rv rv-stagger" style="--stagger-i:<?php echo $__bi + 3; ?>" href="<?php echo $__bl[0]; ?>"><i class="fa-solid fa-book-open"></i> <?php echo $__bl[1]; ?></a>
<?php endforeach; ?>
</div>
<div class="lk-cta rv">
<span class="lk-cta-txt"><i class="fa-solid fa-circle-check"></i> Fixed fare · Verified driver · 24×7 support</span>
<a class="lk-cta-btn" href="/#booking">Book now <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div></section>
<script>
/* Staggered reveal + 3D tilt for hubcards */
(function(){
var rv=document.querySelectorAll('.rt .lk-sec .rv');
if('IntersectionObserver' in window){
  var o=new IntersectionObserver(function(es){
    es.forEach(function(e){
      if(e.isIntersecting){
        var delay=parseInt(e.target.style.getPropertyValue('--stagger-i')||'0')*90;
        setTimeout(function(){e.target.classList.add('in');},delay);
        o.unobserve(e.target);
      }
    });
  },{threshold:.1,rootMargin:'0px 0px -4% 0px'});
  rv.forEach(function(e){o.observe(e);});
}else{rv.forEach(function(e){e.classList.add('in');});}
/* 3D tilt on hubcards (desktop only) */
if(window.matchMedia('(hover:hover) and (pointer:fine)').matches){
  document.querySelectorAll('.rt .lk-sec [data-tilt]').forEach(function(card){
    card.addEventListener('mousemove',function(e){
      var r=card.getBoundingClientRect();
      var x=(e.clientX-r.left)/r.width-.5;
      var y=(e.clientY-r.top)/r.height-.5;
      card.style.transform='perspective(700px) rotateY('+(x*7)+'deg) rotateX('+(-y*5)+'deg) translateY(-6px)';
    });
    card.addEventListener('mouseleave',function(){card.style.transform='';});
  });
}
})();
</script>