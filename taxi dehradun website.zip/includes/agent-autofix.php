<?php
/**
 * Gemini Agents Auto-Fix Pro helpers
 * Safe one-click fixes with backups.
 */
if (!defined('ADMIN_PASSWORD')) exit;

function autofix_root(): string { return realpath(__DIR__ . '/..') ?: dirname(__DIR__); }
function autofix_backup_dir(): string { $d = autofix_root() . '/agent-autofix-backups/' . date('Ymd-His'); if (!is_dir($d)) @mkdir($d,0755,true); return $d; }
function autofix_rel(string $file): string { return ltrim(str_replace(autofix_root(), '', $file), '/'); }
function autofix_backup(string $file, string $dir): bool { $dest = rtrim($dir,'/') . '/' . autofix_rel($file); if (!is_dir(dirname($dest))) @mkdir(dirname($dest),0755,true); return is_file($file) ? copy($file,$dest) : true; }
function autofix_write(string $file, string $new, string $dir, array &$log): bool {
    $old = is_file($file) ? file_get_contents($file) : null;
    if ($old === $new) { $log[] = 'No change: ' . autofix_rel($file); return true; }
    if (!autofix_backup($file,$dir)) { $log[] = 'Backup failed: ' . autofix_rel($file); return false; }
    if (file_put_contents($file,$new) === false) { $log[] = 'Write failed: ' . autofix_rel($file); return false; }
    $log[] = 'Fixed: ' . autofix_rel($file);
    return true;
}
function autofix_slug_title(string $slug): array {
    $slug = trim($slug, '/');
    $slug = preg_replace('/\.php$/','',$slug);
    if (str_starts_with($slug, 'blog/')) return [ucwords(str_replace('-', ' ', basename($slug))), ''];
    if (str_contains($slug, '-to-')) {
        [$from,$rest] = explode('-to-', $slug, 2);
        $to = preg_replace('/-taxi$/','',$rest);
        return [ucwords(str_replace('-',' ',$from)), ucwords(str_replace('-',' ',$to))];
    }
    return [ucwords(str_replace('-', ' ', preg_replace('/-taxi$/','',$slug))), ''];
}
function autofix_short_meta_for_path(string $path): array {
    $slug = trim($path, '/');
    [$from,$to] = autofix_slug_title($slug);
    if ($to) {
        if (str_contains($slug, 'kedarnath') || str_contains($slug, 'badrinath') || str_contains($slug, 'gangotri') || str_contains($slug, 'yamunotri') || str_contains($slug, 'dham')) {
            return ["{$from} to {$to} Taxi | Package", "Book {$from} to {$to} taxi package with Anaya Cab Service. SUV, Innova and Tempo Traveller options with hill drivers."];
        }
        return ["{$from} to {$to} Taxi | Cab Fare", "Book {$from} to {$to} taxi with Anaya Cab Service. One-way and round-trip cabs, verified drivers, 24x7 booking."];
    }
    $core = [
        'pricing'=>['Dehradun Taxi Fare | Cab Rate Chart','Check Dehradun taxi fare, local hourly cab packages, outstation route rates and vehicle-wise pricing from Anaya Cab Service.'],
        'fleet'=>['Taxi Fleet in Dehradun | Sedan, SUV, Innova','View Dzire, Ertiga, Innova, Crysta, Tempo Traveller and Urbania options for Dehradun taxi trips.'],
        'about'=>['About Anaya Cab Service Dehradun','Learn about Anaya Cab Service, Dehradun taxi provider for local rides, airport transfers, outstation trips and Char Dham Yatra.'],
        'contact'=>['Contact Anaya Cab Service Dehradun','Call Anaya Cab Service for Dehradun taxi booking, airport transfers, local rides, outstation cabs and Char Dham Yatra.'],
        'reviews'=>['Customer Reviews | Anaya Cab Service','Open Anaya Cab Service Google listing and customer review information for Dehradun taxi service verification.'],
        'services'=>['Taxi Services in Dehradun | Airport & Outstation','Explore local taxi, airport cab, outstation taxi, fleet rentals, route taxis and Char Dham Yatra packages in Dehradun.'],
    ];
    return $core[$slug] ?? [$from . ' | Anaya Cab Service', 'Book taxi services with Anaya Cab Service in Dehradun. Call for verified drivers, transparent fares and 24x7 support.'];
}
function autofix_replace_php_vars(string $content, string $title, string $desc): string {
    $title = str_replace(['\\','"'], ['\\\\','\\"'], $title);
    $desc = str_replace(['\\','"'], ['\\\\','\\"'], $desc);
    $content = preg_replace('/\$page_title\s*=\s*.*?;\s*/s', '$page_title = "'.$title.'";' . "\n", $content, 1) ?? $content;
    $content = preg_replace('/\$page_description\s*=\s*.*?;\s*/s', '$page_description = "'.$desc.' Call " . BUSINESS_PHONE . ".";' . "\n", $content, 1) ?? $content;
    return $content;
}
function autofix_global_template(array &$log, string $dir): void {
    $header = autofix_root() . '/includes/header.php';
    if (is_file($header)) {
        $c = file_get_contents($header);
        $n = str_replace([' /* google business profile in schema */','/* google business profile in schema */'], '', $c);
        autofix_write($header,$n,$dir,$log);
    }
    $slider = autofix_root() . '/includes/slider.php';
    if (is_file($slider)) {
        $c = file_get_contents($slider);
        $n = str_replace(['<h1 class="td-title">','</h1>'], ['<h2 class="td-title">','</h2>'], $c);
        if (strpos($n,'td-primary-h1') === false) {
            $n = str_replace('<section class="td-hero" id="home">','<section class="td-hero" id="home">' . "\n" . '  <h1 class="td-primary-h1">Dehradun Cab Service &amp; Outstation Taxi Booking</h1>', $n);
            $n = str_replace('<style>', '<style>.td-primary-h1{position:absolute!important;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}', $n);
        }
        autofix_write($slider,$n,$dir,$log);
    }
}
function agent_autofix_seo_task(int $taskId): array {
    $pdo = agent_db(); $log=[]; $dir=autofix_backup_dir();
    $stmt=$pdo->prepare('SELECT * FROM agent_tasks WHERE id=?'); $stmt->execute([$taskId]); $task=$stmt->fetch(PDO::FETCH_ASSOC);
    if(!$task) return ['ok'=>false,'message'=>'Task not found'];
    $out=json_decode($task['output_json'] ?: '{}', true) ?: [];
    autofix_global_template($log,$dir);
    foreach(($out['pages'] ?? []) as $p){
        $path=parse_url($p['url'] ?? '', PHP_URL_PATH) ?: '';
        if($path==='' || $path==='/') continue;
        if(str_starts_with($path,'/blog/')) continue; // blogs handled separately
        $file=autofix_root().$path.'.php';
        if(!is_file($file)) $file=autofix_root().$path;
        if(!is_file($file)) { $log[]='Skip missing file for '.$path; continue; }
        $issues=$p['issues'] ?? [];
        if(in_array('Title too long',$issues,true) || in_array('Meta description too long',$issues,true)){
            [$title,$desc]=autofix_short_meta_for_path($path);
            $c=file_get_contents($file); $n=autofix_replace_php_vars($c,$title,$desc); autofix_write($file,$n,$dir,$log);
        }
    }
    agent_log('autofix-agent','Applied safe SEO fixes for task #'.$taskId);
    return ['ok'=>true,'message'=>'Safe SEO fixes applied','backup'=>autofix_rel($dir),'log'=>$log];
}
function agent_autofix_image_task(int $taskId): array {
    $pdo=agent_db(); $log=[]; $dir=autofix_backup_dir();
    $stmt=$pdo->prepare('SELECT * FROM agent_tasks WHERE id=?'); $stmt->execute([$taskId]); $task=$stmt->fetch(PDO::FETCH_ASSOC);
    if(!$task) return ['ok'=>false,'message'=>'Task not found'];
    if(!function_exists('imagecreatetruecolor')) return ['ok'=>false,'message'=>'GD image extension not available on server'];
    $out=json_decode($task['output_json'] ?: '{}', true) ?: [];
    foreach(($out['images'] ?? []) as $img){
        if(empty($img['issues'])) continue;
        $rel=$img['path'] ?? ''; if(!$rel) continue;
        $file=autofix_root().$rel; if(!is_file($file)){ $log[]='Missing image '.$rel; continue; }
        $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
        $maxW=1200; $maxH=675; $quality=76;
        if(str_contains($rel,'/fleet/')){ $maxW=384; $maxH=256; $quality=72; }
        if(basename($file)==='logo-icon.png'){ $maxW=90; $maxH=110; }
        $info=@getimagesize($file); if(!$info){$log[]='Cannot read image '.$rel; continue;}
        [$w,$h]=$info; $scale=min(1,$maxW/$w,$maxH/$h); $nw=max(1,(int)round($w*$scale)); $nh=max(1,(int)round($h*$scale));
        if($ext==='webp' && function_exists('imagecreatefromwebp')) $src=@imagecreatefromwebp($file);
        elseif(in_array($ext,['jpg','jpeg'],true)) $src=@imagecreatefromjpeg($file);
        elseif($ext==='png') $src=@imagecreatefrompng($file);
        else { $log[]='Skip unsupported '.$rel; continue; }
        if(!$src){$log[]='Load failed '.$rel; continue;}
        $dst=imagecreatetruecolor($nw,$nh); imagealphablending($dst,false); imagesavealpha($dst,true);
        imagecopyresampled($dst,$src,0,0,0,0,$nw,$nh,$w,$h);
        backup_fap_placeholder:
        backup_fap_placeholder2:
        autofix_backup($file,$dir);
        if($ext==='png' && basename($file)==='logo-icon.png') imagepng($dst,$file,9);
        else imagewebp($dst,$file,$quality);
        imagedestroy($src); imagedestroy($dst);
        $log[]='Optimized '.$rel.' to '.round(filesize($file)/1024,1).'KB';
    }
    agent_log('autofix-agent','Optimized images for task #'.$taskId);
    return ['ok'=>true,'message'=>'Image optimization attempted','backup'=>autofix_rel($dir),'log'=>$log];
}
