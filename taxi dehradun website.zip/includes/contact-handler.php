<?php
/**
 * Contact Form Handler
 * NOTE: Requires server's mail() function or SMTP configured by hosting provider.
 * If using shared hosting (e.g. Hostinger, GoDaddy), mail() usually works out of the box.
 * For better deliverability, consider PHPMailer + SMTP — ask your developer to wire it in.
 */
require_once __DIR__ . '/config.php';

header('Content-Type: text/html; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /contact.php');
    exit;
}

$name = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');

// Basic validation
if (empty($name) || empty($phone) || empty($message)) {
    header('Location: /contact.php?status=error');
    exit;
}

// Sanitize for email headers
$name = filter_var($name, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
$phone = filter_var($phone, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$message = filter_var($message, FILTER_SANITIZE_FULL_SPECIAL_CHARS);

$to = BUSINESS_EMAIL;
$subject = "New Contact Form Submission - " . SITE_NAME;
$body = "You have a new enquiry from your website:\n\n";
$body .= "Name: $name\n";
$body .= "Phone: $phone\n";
$body .= "Email: $email\n";
$body .= "Message:\n$message\n";

$headers = "From: " . SITE_NAME . " Website <noreply@" . parse_url(SITE_DOMAIN, PHP_URL_HOST) . ">\r\n";
if (!empty($email)) {
    $headers .= "Reply-To: $email\r\n";
}

$sent = @mail($to, $subject, $body, $headers);

if ($sent) {
    header('Location: /contact.php?status=success');
} else {
    header('Location: /contact.php?status=error');
}
exit;
