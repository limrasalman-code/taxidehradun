<?php
/**
* Anaya Cab Service — Auto Service+Offer schema for route pages [v9.1 — Nainital aligned]
* v9: ROUTE_SERVICE_ALLOW ab EMPTY hai — har route page apna Service schema
*     route-template.php (v2.1) se khud generate karta hai. Purani allow-list
*     4 slugs pe DUPLICATE Service @id inject kar rahi thi (trust killer).
*     Function + dup-guard intact rakha hai taaki header.php fatal na ho.
*     Agar future mein koi route page template use NA kare, to slug yahan add karo.
* v9.1: ROUTE_PRICES['dehradun-to-nainital-taxi'] 5600 -> 5500
*       (owner-confirmed approved rate; single-source hygiene).
*/
if (!defined('SITE_DOMAIN')) { return; }

$GLOBALS['ROUTE_SERVICE_ALLOW'] = array(
/* v9: empty — route-template.php ab sab route pages ka Service schema own karta hai.
Yahan sirf un slugs ko add karna jo route-template include NAHI karte. */
);

$GLOBALS['ROUTE_PRICES'] = array(
'dehradun-to-haridwar-taxi'  => 1350,
'dehradun-to-mussoorie-taxi' => 1050,
'dehradun-to-delhi-taxi'     => 3500,
'dehradun-to-nainital-taxi'  => 5500,
);

$GLOBALS['ROUTE_PLACE_LABELS'] = array(
'dehradun'  => 'Dehradun',
'haridwar'  => 'Haridwar',
'mussoorie' => 'Mussoorie',
'delhi'     => 'Delhi',
'nainital'  => 'Nainital',
);

function anaya_route_service_schema($slug) {
static $emitted = array();

if (!is_string($slug) || $slug === '') {
return '';
}
if (isset($emitted[$slug])) {
return '';
}
$emitted[$slug] = true;

$allow  = isset($GLOBALS['ROUTE_SERVICE_ALLOW']) ? $GLOBALS['ROUTE_SERVICE_ALLOW'] : array();
$prices = isset($GLOBALS['ROUTE_PRICES']) ? $GLOBALS['ROUTE_PRICES'] : array();
$labels = isset($GLOBALS['ROUTE_PLACE_LABELS']) ? $GLOBALS['ROUTE_PLACE_LABELS'] : array();

if (!in_array($slug, $allow, true)) {
return '';
}

/* Dup guard: agar page ka apna schema already emit ho chuka hai */
$__ps = isset($GLOBALS['page_schema']) ? (string)$GLOBALS['page_schema'] : '';
$__needle = SITE_DOMAIN . '/' . $slug . '#service';
if ($__ps !== '' && strpos($__ps, $__needle) !== false) {
return '';
}

if (!preg_match('/^(.+)-to-(.+)-taxi$/', $slug, $m)) {
return '';
}

$from_key = $m[1];
$to_key = $m[2];
$from = isset($labels[$from_key]) ? $labels[$from_key] : ucwords(str_replace('-', ' ', $from_key));
$to = isset($labels[$to_key]) ? $labels[$to_key] : ucwords(str_replace('-', ' ', $to_key));

$node = array(
'@context'    => 'https://schema.org',
'@type'       => 'Service',
'@id'         => SITE_DOMAIN . '/' . $slug . '#service',
'name'        => $from . ' to ' . $to . ' Taxi',
'serviceType' => 'One-way and round-trip taxi service',
'provider'    => array('@id' => SITE_DOMAIN . '/#taxi-service'),
'areaServed'  => array(
array('@type' => 'City', 'name' => $from),
array('@type' => 'City', 'name' => $to),
),
'url'         => SITE_DOMAIN . '/' . $slug,
);

if (isset($prices[$slug])) {
$p = (int)$prices[$slug];
$node['offers'] = array(
'@type'         => 'Offer',
'url'           => SITE_DOMAIN . '/' . $slug,
'priceCurrency' => 'INR',
'price'         => (string)$p,
'availability'  => 'https://schema.org/InStock',
'description'   => $from . ' to ' . $to . ' one-way sedan taxi fare starts from Rs ' . number_format($p) . '. Toll, parking and hill charges extra where applicable.',
);
}

return '<script type="application/ld+json">' . json_encode($node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}