<?php
/**
 * Anaya Cab — shared renderer for bespoke route/place pages (ISBT, agra, auli, chakrata).
 * Defines anaya_rp_schema($V) + anaya_rp_body($V). No side effects. No heredoc.
 * Single source: $V['faqs'] drives BOTH schema and visible accordion (AEO drift impossible).
 */
if (!defined('SITE_DOMAIN')) { return; }

/** Return [public path, absolute URL] for the route image. */
function anaya_rp_image(array $V): array {
    $custom = trim((string)($V['image'] ?? ''));
    if ($custom !== '') {
        if (preg_match('~^https?://~i', $custom)) return [$custom, $custom];
        $path = '/' . ltrim($custom, '/');
        return [$path, SITE_DOMAIN . $path];
    }
    $url_path = (string)(parse_url((string)($V['url'] ?? ''), PHP_URL_PATH) ?? '');
    $slug = basename(rtrim($url_path, '/'));
    $slug = preg_replace('/[^a-z0-9-]/i', '', $slug);
    $path = '/assets/images/routes/' . $slug . '.webp';
    return [$path, SITE_DOMAIN . $path];
}

function anaya_rp_schema(array $V): string {
    $ent = [];
    foreach (($V['faqs'] ?? []) as $f) {
        $ent[] = ['@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f[1]]];
    }
    $area = [];
    foreach (($V['area'] ?? []) as $c) { $area[] = ['@type' => 'City', 'name' => $c]; }
    [$image_path, $image_url] = anaya_rp_image($V);
    // anaya_rp_schema() runs before header.php in the route stubs, so also
    // provide the same image to Open Graph/Twitter cards and image preload.
    if (empty($GLOBALS['page_image'])) $GLOBALS['page_image'] = $image_url;
    if (empty($GLOBALS['preload_image'])) $GLOBALS['preload_image'] = $image_path;
    $svc = [
        '@type' => 'Service', '@id' => $V['url'] . '#service', 'name' => $V['name'],
        'serviceType' => $V['service_type'] ?? 'Taxi service',
        'provider' => ['@id' => SITE_DOMAIN . '/#taxi-service'],
        'areaServed' => $area, 'url' => $V['url'], 'image' => $image_url,
    ];
    if (!empty($V['offers_price'])) {
        $svc['offers'] = ['@type' => 'Offer', 'priceCurrency' => 'INR', 'price' => (string)$V['offers_price'], 'availability' => 'https://schema.org/InStock', 'description' => $V['offer_desc'] ?? ''];
    }
    return '<script type="application/ld+json">' . json_encode(['@context' => 'https://schema.org', '@graph' => [$svc, ['@type' => 'FAQPage', '@id' => $V['url'] . '#faq', 'mainEntity' => $ent]]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

function anaya_rp_body(array $V): void {
    $h = static function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
    $ac = $h($V['ac'] ?? '#0057ff'); $ac2 = $h($V['ac2'] ?? '#39b6ff');
    $d1 = $h($V['d1'] ?? '#03102e'); $d2 = $h($V['d2'] ?? '#0a2a63'); $tint = $h($V['tint'] ?? '#eaf1ff');
    $wa = $h(BUSINESS_WHATSAPP); $tel = $h(BUSINESS_PHONE_TEL); $ph = $h(BUSINESS_PHONE);
    $wamsg = rawurlencode('Hi Anaya Cab, I want to book ' . $V['name'] . '.');
    [$image_path] = anaya_rp_image($V);

    echo '<link rel="stylesheet" href="/assets/css/route-premium.css?v=3">';
    echo '<style>.rp .rp-cover{position:relative;margin:18px 0 28px;border-radius:22px;overflow:hidden;aspect-ratio:1376/768;background:linear-gradient(135deg,var(--rp-d1),var(--rp-d2));box-shadow:0 26px 56px -30px rgba(9,32,84,.48)}.rp .rp-cover img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .6s ease}.rp .rp-cover:hover img{transform:scale(1.025)}.rp .rp-cover-fb{display:none;position:absolute;inset:0;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:#fff;text-align:center;padding:24px;background:radial-gradient(120% 120% at 30% 0%,color-mix(in srgb,var(--rp-ac) 48%,var(--rp-d1)),var(--rp-d2))}.rp .rp-cover-fb i{font-size:3rem;color:var(--rp-ac2)}.rp .rp-cover-fb strong{font-family:Sora,Poppins,sans-serif;font-size:1.1rem}@media(max-width:640px){.rp .rp-cover{border-radius:16px;min-height:210px;aspect-ratio:16/10}}</style>';
    echo '<div class="rp" style="--rp-ac:' . $ac . ';--rp-ac2:' . $ac2 . ';--rp-d1:' . $d1 . ';--rp-d2:' . $d2 . ';--rp-tint:' . $tint . ';">';
    echo '<div class="rp-in">';
    echo '<nav class="rp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i>';
    if (!empty($V['from'])) { echo '<a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i>'; }
    echo '<span class="cur">' . $h($V['crumb'] ?? $V['name']) . '</span></nav>';
    echo '<figure class="rp-cover rv"><img src="' . $h($image_path) . '" alt="' . $h($V['name'] . ' route') . '" width="1376" height="768" loading="eager" fetchpriority="high" decoding="async" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'"><figcaption class="rp-cover-fb"><i class="fa-solid ' . $h($V['char_icon'] ?? 'fa-route') . '"></i><strong>' . $h($V['name']) . '</strong></figcaption></figure>';

    echo '<section class="rp-hero"><div class="rv">';
    echo '<span class="rp-ey"><i class="fa-solid ' . $h($V['char_icon'] ?? 'fa-route') . '"></i> ' . $h($V['eyebrow'] ?? '') . '</span>';
    echo '<h1 class="disp">' . $h($V['headline'] ?? $V['name']) . '</h1>';
    echo '<p class="rp-lead"><strong>' . $h($V['lead_strong'] ?? '') . '</strong> ' . $h($V['lead'] ?? '') . '</p>';
    if (!empty($V['metrics'])) {
        echo '<div class="rp-m">';
        foreach ($V['metrics'] as $m) { echo '<span><i class="fa-solid ' . $h($m[0]) . '"></i> ' . $h($m[1]) . '</span>'; }
        echo '</div>';
    }
    echo '<div class="rp-cta"><a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>';
    echo '<a class="btn btn-g" href="https://wa.me/' . $wa . '?text=' . $wamsg . '" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>';
    echo '<a class="btn btn-o" href="tel:' . $tel . '"><i class="fa-solid fa-phone"></i> Call</a></div>';
    echo '</div>';

    echo '<aside class="rp-card rv"><span class="badge"><i class="fa-solid fa-star"></i> ' . $h($V['card']['badge'] ?? 'Available now') . '</span>';
    echo '<div class="live">Live fare desk</div>';
    echo '<h3 class="disp">' . $h($V['name']) . '</h3>';
    if (!empty($V['card']['rows'])) { foreach ($V['card']['rows'] as $r) { echo '<div class="fr"><span>' . $h($r[0]) . '</span><b>' . $h($r[1]) . '</b></div>'; } }
    if (!empty($V['card']['note'])) { echo '<p style="color:rgba(255,255,255,.7);font-size:.78rem;margin:6px 0 0;">' . $h($V['card']['note']) . '</p>'; }
    echo '<div class="cta"><a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>';
    echo '<a class="g" href="https://wa.me/' . $wa . '?text=' . $wamsg . '" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a></div></aside>';
    echo '</section></div>';

    if (!empty($V['highlights'])) {
        echo '<section class="sec"><div class="rp-in"><div class="sh rv"><span class="ey"><i class="fa-solid fa-star"></i> Highlights</span><h2 class="disp">What makes this worth the trip</h2></div><div class="bento">';
        foreach ($V['highlights'] as $i => $hl) { $big = ($i === 0); echo '<div class="bc rv' . ($big ? ' big' : '') . '"><div class="vi"><i class="fa-solid ' . $h($hl[0]) . '"></i></div><h3>' . $h($hl[1]) . '</h3><p>' . $h($hl[2]) . '</p></div>'; }
        echo '</div></div></section>';
    }
    if (!empty($V['timeline'])) {
        echo '<section class="sec soft"><div class="rp-in"><div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> The journey</span><h2 class="disp">How your trip works</h2></div><div class="tl">';
        foreach ($V['timeline'] as $t) { echo '<div class="tr rv"><div class="d"><i class="fa-solid ' . $h($t[0]) . '"></i></div><div class="b"><h3>' . $h($t[1]) . '</h3><p>' . $h($t[2]) . '</p></div></div>'; }
        echo '</div></div></section>';
    }
    if (!empty($V['related'])) {
        echo '<section class="sec"><div class="rp-in"><div class="sh rv"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related</span><h2 class="disp">Routes travellers also book</h2></div><div class="chips rv">';
        foreach ($V['related'] as $rl) { echo '<a class="chip" href="' . $h($rl[1]) . '"><i class="fa-solid fa-location-dot"></i> ' . $h($rl[0]) . '</a>'; }
        echo '</div></div></section>';
    }
    if (!empty($V['faqs'])) {
        echo '<section class="sec soft" id="faq"><div class="rp-in"><div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">' . $h($V['name']) . ' — FAQs</h2></div><div class="fbox">';
        foreach ($V['faqs'] as $i => $f) { echo '<div class="fi rv' . ($i === 0 ? ' open' : '') . '"><div class="fh">' . $h($f[0]) . '<span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px">' . $h($f[1]) . '</p></div></div>'; }
        echo '</div></div></section>';
    }
    echo '<section class="cta2 rv"><div class="rp-in"><div class="ctain"><h2 class="disp">Ready to book the ' . $h($V['short'] ?? $V['name']) . '?</h2><p>Share pickup, drop, date and luggage — we confirm a transparent fare before the trip.</p><div class="row"><a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a><a class="g" href="https://wa.me/' . $wa . '?text=' . $wamsg . '" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><a class="o" href="tel:' . $tel . '"><i class="fa-solid fa-phone"></i> Call ' . $ph . '</a></div></div></div></section>';
    echo '</div>';
    echo "<script>(function(){var r=document.querySelectorAll('.rp .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}document.querySelectorAll('.rp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();</script>";
}