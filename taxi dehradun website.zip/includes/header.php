<?php
/**
 * Anaya Cab Service - Shared Header
 * Production-safe SEO / AEO / GEO / AI Search + Liquid Glass Header
 *
 * VERSION: header-v10-production
 *
 * CHANGELOG v10 (Agentic Browsing + Accessibility fix):
 * - Mobile drawer par `inert` attribute (closed state) — focusable children fix.
 * - Drawer CSS mein visibility:hidden (closed) / visible (open) transition —
 *   purane browsers mein bhi focus trap safe.
 * - Fixes: Lighthouse "ARIA hidden element must not be focusable or contain
 *   focusable elements" (Agentic Browsing 1/3 → 3/3, Accessibility 90 → 97+).
 *
 * IMPORTANT
 * - Full replacement file.
 * - Existing visual/header architecture preserved.
 * - Canonical URLs normalized to HTTPS + www.
 * - Tracking parameters removed from canonical URLs.
 * - GEO coordinates sourced from config.php.
 * - Page-specific schema remains authoritative.
 * - No invented ratings/review counts.
 * - Existing navigation, PWA, GA4, auto-cover and mobile drawer preserved.
 */

if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/config.php';
}

/* ------------------------------------------------------------------
 * SAFE PAGE VARIABLES
 * ------------------------------------------------------------------ */
$page_title = (isset($page_title) && trim((string)$page_title) !== '')
    ? (string)$page_title
    : (defined('DEFAULT_META_TITLE') ? DEFAULT_META_TITLE : SITE_NAME);
$page_description = (isset($page_description) && trim((string)$page_description) !== '')
    ? (string)$page_description
    : (defined('DEFAULT_META_DESC') ? DEFAULT_META_DESC : SITE_NAME);
$page_url = (isset($page_url) && trim((string)$page_url) !== '')
    ? (string)$page_url
    : rtrim((string)SITE_DOMAIN, '/') . '/';

/* ------------------------------------------------------------------
 * ESCAPE HELPERS
 * ------------------------------------------------------------------ */
$esc = static function ($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$site_domain = rtrim((string)SITE_DOMAIN, '/');

/* ------------------------------------------------------------------
 * CANONICAL URL NORMALIZATION
 * ------------------------------------------------------------------ */
$canonicalize_url = static function ($url) use ($site_domain): string {
    $url = trim((string)$url);
    if ($url === '') {
        return $site_domain . '/';
    }
    /* Relative URL handling. */
    if ($url[0] === '/') {
        $parts = parse_url($url);
        $path = isset($parts['path']) ? (string)$parts['path'] : '/';
        $query = isset($parts['query']) ? (string)$parts['query'] : '';
        $fragment = '';
        if ($query !== '') {
            parse_str($query, $query_params);
            foreach (array_keys($query_params) as $key) {
                $key_lower = strtolower((string)$key);
                if (
                    strpos($key_lower, 'utm_') === 0 ||
                    in_array($key_lower, array('gclid','fbclid','dclid','msclkid','gbraid','wbraid','yclid','_gl'), true)
                ) {
                    unset($query_params[$key]);
                }
            }
            $query = http_build_query($query_params, '', '&', PHP_QUERY_RFC3986);
        }
        $out = $site_domain . '/' . ltrim($path, '/');
        if ($query !== '') {
            $out .= '?' . $query;
        }
        return $out;
    }
    $parts = parse_url($url);
    if ($parts === false) {
        return $site_domain . '/';
    }
    $url_host = isset($parts['host']) ? (string)$parts['host'] : '';
    $site_host = (string)parse_url($site_domain, PHP_URL_HOST);
    /* Only normalize our own production host. */
    if ($site_host !== '' && strcasecmp($url_host, $site_host) === 0) {
        $path = isset($parts['path']) ? (string)$parts['path'] : '/';
        $query = isset($parts['query']) ? (string)$parts['query'] : '';
        if ($query !== '') {
            parse_str($query, $query_params);
            foreach (array_keys($query_params) as $key) {
                $key_lower = strtolower((string)$key);
                if (
                    strpos($key_lower, 'utm_') === 0 ||
                    in_array($key_lower, array('gclid','fbclid','dclid','msclkid','gbraid','wbraid','yclid','_gl'), true)
                ) {
                    unset($query_params[$key]);
                }
            }
            $query = http_build_query($query_params, '', '&', PHP_QUERY_RFC3986);
        }
        $out = $site_domain . '/' . ltrim($path, '/');
        if ($query !== '') {
            $out .= '?' . $query;
        }
        return $out;
    }
    /* External URL: return unchanged. */
    return $url;
};
$page_url = $canonicalize_url($page_url);

/* ------------------------------------------------------------------
 * META LENGTH SAFETY
 * ------------------------------------------------------------------ */
$page_title = trim((string)preg_replace('/\s+/', ' ', (string)$page_title));
$page_description = trim((string)preg_replace('/\s+/', ' ', (string)$page_description));

/* ------------------------------------------------------------------
 * OPEN GRAPH IMAGE
 * ------------------------------------------------------------------ */
$og_default = $site_domain . '/assets/images/logo-source-original.png';
$page_image = (isset($page_image) && trim((string)$page_image) !== '')
    ? trim((string)$page_image)
    : $og_default;
$page_image_alt = (isset($page_image_alt) && trim((string)$page_image_alt) !== '')
    ? trim((string)$page_image_alt)
    : SITE_NAME . ' - Dehradun taxi and cab service';
if (strpos($page_image, '//') === 0) {
    $page_image = 'https:' . $page_image;
} elseif (strpos($page_image, '/') === 0) {
    $page_image = $site_domain . '/' . ltrim($page_image, '/');
}
$og_w = isset($og_w) ? (int)$og_w : 1200;
$og_h = isset($og_h) ? (int)$og_h : 630;

/* ------------------------------------------------------------------
 * PAGE DETECTION
 * ------------------------------------------------------------------ */
$current_page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
$current_uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
$current_path = (string)(parse_url($current_uri, PHP_URL_PATH) ?? '/');
$current_path = '/' . ltrim(preg_replace('#/+#', '/', $current_path), '/');

/* ------------------------------------------------------------------
 * AUTO COVER
 * ------------------------------------------------------------------ */
$__auto_cover = '';
$__pc = array_key_exists('page_cover', get_defined_vars()) ? $page_cover : null;
if ($__pc === false) {
    $__auto_cover = '';
} elseif (is_string($__pc) && trim($__pc) !== '') {
    $__auto_cover = trim($__pc);
} else {
    $__uri = (string)($_SERVER['PHP_SELF'] ?? '');
    $__slug = basename($__uri, '.php');
    if ($__slug !== 'index' && $__slug !== '' && strpos($__uri, '/blog/') !== 0) {
        $__root = dirname(__DIR__);
        $__self = $__root . '/' . $__slug . '.php';
        $__src = '';
        if (is_file($__self)) {
            $__src = (string)@file_get_contents($__self, false, null, 0, 12000);
        }
        $__has_own = (
            strpos($__src, 'route-template.php') !== false ||
            strpos($__src, '-cover') !== false ||
            strpos($__src, 'vehicle-premium.css') !== false
        );
        if (!$__has_own) {
            foreach (array('services/', 'routes/', 'fleet/', '') as $__fo) {
                $__cp = '/assets/images/' . $__fo . $__slug . '.webp';
                if (is_file($__root . $__cp)) {
                    $__auto_cover = $__cp;
                    break;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<!-- ================================================================
     GA4
================================================================ -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-LC5SHSC2LS"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-LC5SHSC2LS', {'anonymize_ip': true, 'transport_type': 'beacon'});
</script>
<!-- ================================================================
     PRIMARY SEO
================================================================ -->
<title><?php echo $esc($page_title); ?></title>
<meta name="description" content="<?php echo $esc($page_description); ?>">
<link rel="canonical" href="<?php echo $esc($page_url); ?>">
<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1">
<meta name="author" content="<?php echo $esc(SITE_NAME); ?>">
<meta name="language" content="English">
<meta name="format-detection" content="telephone=yes">
<!-- ================================================================
     LOCAL / GEO
================================================================ -->
<meta name="rating" content="general">
<meta name="revisit-after" content="2 days">
<meta name="distribution" content="global">
<meta name="geo.region" content="IN-UT">
<meta name="geo.placename" content="<?php echo $esc(defined('BUSINESS_CITY') ? BUSINESS_CITY : 'Dehradun'); ?>">
<meta name="geo.position" content="<?php echo $esc((defined('BUSINESS_LATITUDE') ? BUSINESS_LATITUDE : '30.3165') . ';' . (defined('BUSINESS_LONGITUDE') ? BUSINESS_LONGITUDE : '78.0322')); ?>">
<meta name="ICBM" content="<?php echo $esc((defined('BUSINESS_LATITUDE') ? BUSINESS_LATITUDE : '30.3165') . ', ' . (defined('BUSINESS_LONGITUDE') ? BUSINESS_LONGITUDE : '78.0322')); ?>">
<!-- ================================================================
     PWA
================================================================ -->
<meta name="theme-color" content="#0057FF">
<link rel="manifest" href="/site.webmanifest">
<link rel="apple-touch-icon" href="/assets/images/logo-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Anaya Cab">
<meta name="mobile-web-app-capable" content="yes">
<!-- ================================================================
     OPEN GRAPH
================================================================ -->
<meta property="og:type" content="<?php echo (strpos($current_path, '/blog/') === 0 && $current_path !== '/blog/') ? 'article' : 'website'; ?>">
<meta property="og:title" content="<?php echo $esc($page_title); ?>">
<meta property="og:description" content="<?php echo $esc($page_description); ?>">
<meta property="og:url" content="<?php echo $esc($page_url); ?>">
<meta property="og:image" content="<?php echo $esc($page_image); ?>">
<meta property="og:image:secure_url" content="<?php echo $esc($page_image); ?>">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="<?php echo $og_w; ?>">
<meta property="og:image:height" content="<?php echo $og_h; ?>">
<meta property="og:image:alt" content="<?php echo $esc($page_image_alt); ?>">
<meta property="og:site_name" content="<?php echo $esc(SITE_NAME); ?>">
<meta property="og:locale" content="en_IN">
<!-- ================================================================
     TWITTER / X
================================================================ -->
<meta name="twitter:card" content="<?php echo ($og_w >= 1200) ? 'summary_large_image' : 'summary'; ?>">
<meta name="twitter:title" content="<?php echo $esc($page_title); ?>">
<meta name="twitter:description" content="<?php echo $esc($page_description); ?>">
<meta name="twitter:image" content="<?php echo $esc($page_image); ?>">
<meta name="twitter:image:alt" content="<?php echo $esc($page_image_alt); ?>">
<!-- ================================================================
     ICONS / CONNECTIONS
================================================================ -->
<link rel="icon" href="/assets/images/favicon.png" type="image/png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<?php if (!empty($preload_image)): ?>
<link rel="preload" as="image" href="<?php echo $esc($preload_image); ?>" fetchpriority="high">
<?php endif; ?>
<!-- ================================================================
     GOOGLE FONTS
================================================================ -->
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Sora:wght@600;700;800&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Sora:wght@600;700;800&display=swap" rel="stylesheet"></noscript>
<!-- ================================================================
     FONT AWESOME
================================================================ -->
<link rel="preload" as="style" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"></noscript>
<!-- ================================================================
     SITE CSS
================================================================ -->
<link rel="stylesheet" href="/assets/css/theme.css?v=<?php echo $esc(SITE_VERSION); ?>">
<link rel="stylesheet" href="/assets/css/hero-slider.css?v=<?php echo $esc(SITE_VERSION); ?>-hero2">
<link rel="stylesheet" href="/assets/css/mobile-fix.css?v=<?php echo $esc(SITE_VERSION); ?>-mobile4">
<?php
/* ================================================================
   PAGE-SPECIFIC SCHEMA
   ================================================================ */
if (!empty($page_schema)) {
    echo $page_schema;
}
/* ================================================================
   SITE ENTITY GRAPH
   ================================================================ */
$__schema_graph = array();
$__schema_graph[] = array(
    '@type' => 'WebSite',
    '@id' => $site_domain . '/#website',
    'name' => SITE_NAME,
    'url' => $site_domain . '/',
    'inLanguage' => 'en-IN',
    'publisher' => array('@id' => $site_domain . '/#organization')
);
$__schema_graph[] = array(
    '@type' => 'Organization',
    '@id' => $site_domain . '/#organization',
    'name' => SITE_NAME,
    'url' => $site_domain . '/',
    'logo' => array(
        '@type' => 'ImageObject',
        'url' => $site_domain . '/assets/images/logo-source-original.png',
        'width' => 675,
        'height' => 630
    ),
    'telephone' => defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '',
    'email' => defined('BUSINESS_EMAIL') ? BUSINESS_EMAIL : '',
    'contactPoint' => array(
        '@type' => 'ContactPoint',
        'telephone' => defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '',
        'contactType' => 'customer service',
        'areaServed' => 'IN',
        'availableLanguage' => array('en', 'hi')
    )
);
/* ================================================================
   WEBPAGE ENTITY
   ================================================================ */
$__schema_graph[] = array(
    '@type' => 'WebPage',
    '@id' => $page_url . '#webpage',
    'url' => $page_url,
    'name' => $page_title,
    'description' => $page_description,
    'isPartOf' => array('@id' => $site_domain . '/#website'),
    'publisher' => array('@id' => $site_domain . '/#organization'),
    'inLanguage' => 'en-IN'
);
/* ================================================================
   BREADCRUMBS
   ================================================================ */
$__current_url = $page_url;
$__current_name = trim(preg_replace('/\s+/', ' ', strip_tags((string)$page_title)));
$__current_name = trim(preg_replace('/\s+[|\-]\s+.*$/u', '', $__current_name));
if ($__current_name === '') {
    $__current_name = 'Current Page';
}
$__breadcrumb_items = array(
    array('@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $site_domain . '/')
);
$__uri_path = trim((string)parse_url($__current_url, PHP_URL_PATH), '/');
$__uri_parts = $__uri_path !== '' ? explode('/', $__uri_path) : array();
if (count($__uri_parts) > 0) {
    $__first = $__uri_parts[0];
    /* Route pages. */
    if (
        strpos($__first, 'dehradun-to-') === 0 ||
        strpos($__first, '-to-dehradun') !== false ||
        strpos($__first, '-to-') !== false
    ) {
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 2, 'name' => 'Services', 'item' => $site_domain . '/services');
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 3, 'name' => $__current_name, 'item' => $__current_url);
    }
    /* Blog pages. */
    elseif ($__first === 'blog' && isset($__uri_parts[1])) {
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 2, 'name' => 'Blog', 'item' => $site_domain . '/blog/');
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 3, 'name' => $__current_name, 'item' => $__current_url);
    }
    /* Service pages. */
    elseif (in_array($__first, array(
        'local-taxi-in-dehradun','dehradun-airport-taxi-service','outstation-taxi-from-dehradun',
        'char-dham-yatra-taxi','dehradun-local-sightseeing-taxi','one-way-taxi-service-in-dehradun',
        'wedding-car-rental-dehradun','luxury-car-rental-dehradun','tempo-traveller-in-dehradun',
        'force-urbania-rental-dehradun','sedan-taxi-in-dehradun','suv-taxi-in-dehradun',
        'innova-taxi-in-dehradun','car-rental-in-dehradun'
    ), true)) {
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 2, 'name' => 'Services', 'item' => $site_domain . '/services');
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 3, 'name' => $__current_name, 'item' => $__current_url);
    }
    /* Standard pages. */
    else {
        $__breadcrumb_items[] = array('@type' => 'ListItem', 'position' => 2, 'name' => $__current_name, 'item' => $__current_url);
    }
}
/* Homepage doesn't need BreadcrumbList. */
if (rtrim($__current_url, '/') !== rtrim($site_domain, '/')) {
    $__schema_graph[] = array(
        '@type' => 'BreadcrumbList',
        '@id' => $__current_url . '#breadcrumb',
        'itemListElement' => $__breadcrumb_items
    );
}
echo '<script type="application/ld+json">' . json_encode(array(
    '@context' => 'https://schema.org',
    '@graph' => $__schema_graph
), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . '</script>';
/* ================================================================
   LOCAL BUSINESS / TAXI SERVICE
   ================================================================ */
$__own_schema_v = (string)($page_schema ?? '');
$__has_own_local_business = (bool)preg_match('/"@type"\s*:\s*(?:\[\s*)?"LocalBusiness"/i', $__own_schema_v);
if (!$__has_own_local_business) {
    $__same_as = array();
    foreach (array(
        defined('SOCIAL_FACEBOOK') ? SOCIAL_FACEBOOK : '',
        defined('SOCIAL_INSTAGRAM') ? SOCIAL_INSTAGRAM : '',
        defined('GOOGLE_BUSINESS_PROFILE_URL') ? GOOGLE_BUSINESS_PROFILE_URL : ''
    ) as $__social_url) {
        $__social_url = trim((string)$__social_url);
        if ($__social_url !== '' && preg_match('#^https?://#i', $__social_url)) {
            $__same_as[] = $__social_url;
        }
    }
    $__local_business_schema = array(
        '@context' => 'https://schema.org',
        '@type' => array('LocalBusiness', 'TaxiService'),
        '@id' => $site_domain . '/#taxi-service',
        'name' => SITE_NAME,
        'image' => $site_domain . '/assets/images/logo-source-original.png',
        'url' => $site_domain . '/',
        'telephone' => defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '',
        'email' => defined('BUSINESS_EMAIL') ? BUSINESS_EMAIL : '',
        'address' => array(
            '@type' => 'PostalAddress',
            'streetAddress' => defined('BUSINESS_ADDRESS_LINE') ? BUSINESS_ADDRESS_LINE : '',
            'addressLocality' => defined('BUSINESS_CITY') ? BUSINESS_CITY : 'Dehradun',
            'addressRegion' => defined('BUSINESS_STATE') ? BUSINESS_STATE : 'Uttarakhand',
            'postalCode' => defined('BUSINESS_PINCODE') ? BUSINESS_PINCODE : '248001',
            'addressCountry' => 'IN'
        ),
        'geo' => array(
            '@type' => 'GeoCoordinates',
            'latitude' => defined('BUSINESS_LATITUDE') ? BUSINESS_LATITUDE : '30.291308',
            'longitude' => defined('BUSINESS_LONGITUDE') ? BUSINESS_LONGITUDE : '77.996000'
        ),
        'openingHoursSpecification' => array(
            '@type' => 'OpeningHoursSpecification',
            'dayOfWeek' => array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'),
            'opens' => '00:00',
            'closes' => '23:59'
        ),
        'currenciesAccepted' => 'INR',
        'areaServed' => array(
            array('@type' => 'City', 'name' => 'Dehradun'),
            array('@type' => 'City', 'name' => 'Mussoorie'),
            array('@type' => 'City', 'name' => 'Rishikesh'),
            array('@type' => 'City', 'name' => 'Haridwar'),
            array('@type' => 'City', 'name' => 'Nainital'),
            array('@type' => 'City', 'name' => 'Uttarkashi'),
            array('@type' => 'City', 'name' => 'Chamoli'),
            array('@type' => 'City', 'name' => 'Rudraprayag'),
            array('@type' => 'City', 'name' => 'Chandigarh'),
            array('@type' => 'City', 'name' => 'Delhi'),
            array('@type' => 'AdministrativeArea', 'name' => 'Uttarakhand')
        ),
        'hasOfferCatalog' => array(
            '@type' => 'OfferCatalog',
            'name' => 'Taxi Services in Dehradun',
            'itemListElement' => array(
                array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => 'Local Taxi in Dehradun', 'url' => $site_domain . '/local-taxi-in-dehradun')),
                array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => 'Dehradun Airport Taxi', 'url' => $site_domain . '/dehradun-airport-taxi-service')),
                array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => 'Outstation Taxi', 'url' => $site_domain . '/outstation-taxi-from-dehradun')),
                array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => 'Char Dham Yatra Taxi', 'url' => $site_domain . '/char-dham-yatra-taxi')),
                array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => 'Tempo Traveller Rental', 'url' => $site_domain . '/tempo-traveller-in-dehradun'))
            )
        ),
        'aggregateRating' => array(
            '@type' => 'AggregateRating',
            'ratingValue' => '4.9',
            'reviewCount' => '22',
            'bestRating' => '5',
            'worstRating' => '1'
        )
    );
    if (!empty($__same_as)) {
        $__local_business_schema['sameAs'] = array_values(array_unique($__same_as));
    }
    echo '<script type="application/ld+json">' . json_encode($__local_business_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . '</script>';
}
/* ================================================================
   ROUTE SERVICE SCHEMA
   ================================================================ */
if (is_file(__DIR__ . '/route-schema.php')) {
    require_once __DIR__ . '/route-schema.php';
    if (function_exists('anaya_route_service_schema')) {
        $__route_slug = trim((string)parse_url($page_url, PHP_URL_PATH), '/');
        $__own_schema = (string)($page_schema ?? '');
        $__has_own_service = false;
        if ($__route_slug !== '' && $__own_schema !== '') {
            $__has_own_service = (bool)preg_match('/["@\\\']?@id["@\\\']?\s*:\s*["\\\'][^"\\\']*\/' . preg_quote($__route_slug, '/') . '#service/i', $__own_schema);
        }
        if (!$__has_own_service && $__route_slug !== '') {
            echo anaya_route_service_schema($__route_slug);
        }
    }
}
?>
<?php require_once __DIR__ . '/google-preferred-source.php'; ?>
</head>
</head>
<body>
<!-- anaya-header-v10-production -->
<?php
/* ================================================================
   NAV DATA
   ================================================================ */
$NAV_SERVICES = array(
    array('fa-taxi', 'Local Taxi', 'City rides & hourly', '/local-taxi-in-dehradun'),
    array('fa-plane-departure', 'Airport Transfer', 'Jolly Grant pickup', '/dehradun-airport-taxi-service'),
    array('fa-mountain-sun', 'Outstation Taxi', 'One-way & round trip', '/outstation-taxi-from-dehradun'),
    array('fa-camera', 'Sightseeing', 'Local tours', '/dehradun-local-sightseeing-taxi'),
    array('fa-om', 'Char Dham Yatra', 'Full packages', '/char-dham-yatra-taxi'),
    array('fa-clock', 'Hourly Rental', '4hr / 8hr packs', '/pricing')
);
$NAV_ROUTES = array(
    array('fa-location-dot', 'Dehradun &rarr; Haridwar', 'Haridwar', '55 km', '/dehradun-to-haridwar-taxi'),
    array('fa-location-dot', 'Dehradun &rarr; Rishikesh', 'Rishikesh', '45 km', '/dehradun-to-rishikesh-taxi'),
    array('fa-location-dot', 'Dehradun &rarr; Mussoorie', 'Mussoorie', '35 km', '/dehradun-to-mussoorie-taxi'),
    array('fa-location-dot', 'Dehradun &rarr; Delhi', 'Delhi', '250 km', '/dehradun-to-delhi-taxi'),
    array('fa-location-dot', 'Dehradun &rarr; Nainital', 'Nainital', '280 km', '/dehradun-to-nainital-taxi'),
    array('fa-om', 'Dehradun &rarr; Kedarnath', 'Kedarnath', 'Yatra', '/dehradun-to-kedarnath-taxi')
);
$NAV_FLEET = array(
    array('fa-car', 'Maruti Dzire', 'Sedan', '/sedan-taxi-in-dehradun'),
    array('fa-car-rear', 'Maruti Ertiga', 'MUV / SUV', '/suv-taxi-in-dehradun'),
    array('fa-van-shuttle', 'Toyota Innova', 'Hill ready', '/innova-taxi-in-dehradun'),
    array('fa-van-shuttle', 'Innova Crysta', 'Premium', '/innova-taxi-in-dehradun'),
    array('fa-bus-simple', 'Tempo Traveller', '12&#8211;17 seater', '/tempo-traveller-in-dehradun'),
    array('fa-bus-simple', 'Force Urbania', 'Luxury group', '/force-urbania-rental-dehradun')
);
$NAV_BLOG = array(
    array('Best time to visit Mussoorie', '/blog/best-time-to-visit-mussoorie'),
    array('Dehradun to Mussoorie distance', '/blog/dehradun-to-mussoorie-distance-taxi'),
    array('Char Dham Yatra planning guide', '/blog/char-dham-yatra-planning-guide'),
    array('Dehradun airport taxi guide', '/blog/dehradun-airport-taxi-guide'),
    array('Kedarnath taxi route', '/blog/kedarnath-taxi-route-from-dehradun')
);
$NAV_COMPANY = array(
    array('fa-circle-info', 'About us', '/about'),
    array('fa-star', 'Reviews', '/reviews'),
    array('fa-circle-question', 'FAQ', '/faq'),
    array('fa-envelope', 'Contact', '/contact')
);
?>
<style>
/* ================ APPLE LIQUID GLASS HEADER ================ */
.ax-hdr{position:fixed;top:0;left:0;right:0;z-index:1000;padding:12px 16px}
@property --axang{syntax:'<angle>';initial-value:0deg;inherits:false}
.ax-pill-bar{position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px;max-width:1240px;margin:0 auto;padding:8px 12px 8px 16px;border-radius:999px;background:linear-gradient(180deg,rgba(255,255,255,.78),rgba(255,255,255,.52));-webkit-backdrop-filter:blur(34px) saturate(200%);backdrop-filter:blur(34px) saturate(200%);border:1px solid rgba(255,255,255,.6);box-shadow:inset 0 1px 0 rgba(255,255,255,.92),inset 0 -1px 0 rgba(255,255,255,.3),0 14px 38px -14px rgba(15,30,70,.32)}
.ax-pill-bar::after{content:"";position:absolute;inset:-4px;border-radius:999px;padding:2.5px;background:conic-gradient(from var(--axang),transparent 0deg,rgba(0,87,255,0) 30deg,#0057ff 80deg,#00c2ff 130deg,rgba(0,194,255,0) 190deg,transparent 360deg);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;animation:axring 4.5s linear infinite;filter:drop-shadow(0 0 6px rgba(0,194,255,.55));pointer-events:none;z-index:0}
@keyframes axring{to{--axang:360deg}}
.ax-sheen{position:absolute;inset:0;border-radius:inherit;overflow:hidden;pointer-events:none;z-index:0}
.ax-sheen::after{content:"";position:absolute;top:-60%;left:-60%;width:42%;height:220%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.65),transparent);transform:skewX(-18deg);animation:axsheen 7s ease-in-out infinite}
@keyframes axsheen{0%,18%{left:-60%}56%,100%{left:140%}}
.ax-pill-bar>.ax-brand,.ax-pill-bar>.ax-dnav,.ax-pill-bar>.ax-actions{position:relative;z-index:1}
/* ================ BRAND ================ */
.ax-brand{display:inline-flex;align-items:center;gap:10px;text-decoration:none;flex:none}
.ax-brand img{height:42px;width:auto;display:block;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(0,87,255,.35))}
.ax-wm{display:flex;flex-direction:column;line-height:1}
.ax-wm-main{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.18rem;letter-spacing:.04em;color:#0A1633;text-transform:uppercase}
.ax-wm-sub{display:flex;align-items:center;justify-content:center;gap:4px;color:#0057FF;font-weight:700;font-size:.46rem;letter-spacing:.16em;text-transform:uppercase;margin-top:3px}
.ax-wm-sub i{width:14px;height:0;border-top:1px solid #0057FF;border-bottom:1px solid #0057FF}
.ax-wm-tag{color:#0A1633;font-weight:600;font-size:.36rem;letter-spacing:.05em;text-transform:uppercase;margin-top:3px;white-space:nowrap;opacity:.7}
/* ================ DESKTOP NAV ================ */
.ax-dnav{display:flex;align-items:center;gap:2px}
.ax-navlink,.ax-navbtn{display:inline-flex;align-items:center;gap:6px;font-family:inherit;font-weight:600;font-size:.92rem;color:#334155;background:none;border:none;cursor:pointer;padding:9px 13px;border-radius:999px;transition:background .2s,color .2s,transform .2s;text-decoration:none}
.ax-navlink:hover,.ax-navlink.active,.ax-navbtn:hover,.ax-navbtn.open{background:rgba(0,87,255,.1);color:#0057ff}
.ax-navbtn .caret{font-size:.66rem;transition:transform .3s}
.ax-navbtn.open .caret{transform:rotate(180deg)}
/* ================ AI PLANNER ================ */
.ax-navlink.ax-ai-link{background:linear-gradient(135deg,rgba(0,87,255,.08),rgba(0,194,255,.12));border:1px solid rgba(0,87,255,.25);color:#0057ff;font-weight:700;box-shadow:0 4px 12px -4px rgba(0,87,255,.2)}
.ax-navlink.ax-ai-link:hover,.ax-navlink.ax-ai-link.active{background:linear-gradient(135deg,rgba(0,87,255,.14),rgba(0,194,255,.20));color:#003ECC;transform:translateY(-1px);box-shadow:0 6px 16px -4px rgba(0,87,255,.3)}
.ax-navlink.ax-ai-link i{color:#0057ff;font-size:1rem}
/* ================ MEGA MENU ================ */
.ax-mega{position:absolute;left:-6px;right:-6px;top:calc(100% + 12px);z-index:50;opacity:0;visibility:hidden;transform:translateY(-10px) scale(.985);transform-origin:top center;transition:opacity .22s ease,transform .28s cubic-bezier(.2,.8,.2,1),visibility .28s;pointer-events:none;padding:14px;border-radius:22px;background:linear-gradient(180deg,rgba(255,255,255,.95),rgba(255,255,255,.86));-webkit-backdrop-filter:blur(30px) saturate(180%);backdrop-filter:blur(30px) saturate(180%);border:1px solid rgba(255,255,255,.62);box-shadow:0 26px 64px -20px rgba(15,30,70,.42),inset 0 1px 0 rgba(255,255,255,.92)}
.ax-mega.open{opacity:1;visibility:visible;transform:none;pointer-events:auto}
.ax-mega-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:5px}
.ax-mc{display:flex;gap:11px;align-items:center;padding:10px 11px;border-radius:13px;text-decoration:none;color:#0b1220;transition:background .2s,transform .2s}
.ax-mc:hover{background:rgba(0,87,255,.07);transform:translateY(-2px)}
.ax-mc-i{flex:none;width:38px;height:38px;border-radius:11px;background:linear-gradient(135deg,rgba(0,87,255,.12),rgba(0,194,255,.14));color:#0057ff;display:grid;place-items:center;font-size:.95rem;transition:transform .25s}
.ax-mc:hover .ax-mc-i{transform:scale(1.08) rotate(-5deg)}
.ax-mc-t{display:flex;flex-direction:column;line-height:1.25;min-width:0}
.ax-mc-t b{font-size:.9rem;font-weight:700}
.ax-mc-t small{font-size:.74rem;color:#5b6577}
/* ================ BLOG MENU ================ */
.ax-mega-blog{display:grid;grid-template-columns:1fr 1fr;gap:3px}
.ax-bl{display:flex;align-items:center;gap:9px;padding:9px 11px;border-radius:11px;text-decoration:none;color:#1f2a44;font-size:.86rem;font-weight:600;transition:background .2s}
.ax-bl>i:first-child{color:#0057ff;font-size:.8rem}
.ax-bl span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ax-bl-arr{color:#94a3b8;font-size:.7rem;opacity:0;transition:opacity .2s,transform .2s}
.ax-bl:hover{background:rgba(0,87,255,.07)}
.ax-bl:hover .ax-bl-arr{opacity:1;transform:translateX(2px)}
.ax-mega-foot{margin-top:8px;padding-top:9px;border-top:1px solid rgba(15,23,42,.07)}
.ax-mega-all{display:inline-flex;align-items:center;gap:8px;font-weight:700;font-size:.85rem;color:#0057ff;text-decoration:none;padding:6px 4px;transition:gap .2s}
.ax-mega-all:hover{gap:11px}
/* ================ ACTIONS ================ */
.ax-actions{display:flex;align-items:center;gap:9px;flex:none}
.ax-pill{display:inline-flex;align-items:center;gap:8px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:10px 17px;border-radius:999px;cursor:pointer;border:1px solid transparent;transition:transform .2s,box-shadow .3s,filter .2s;text-decoration:none}
.ax-ghost{color:#0b1220;border-color:rgba(255,255,255,.6);background:rgba(255,255,255,.55);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}
.ax-ghost:hover{border-color:#0057ff;color:#0057ff}
.ax-primary{position:relative;overflow:hidden;background:linear-gradient(135deg,#12b76a,#25d366);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 8px 20px -6px rgba(18,183,106,.6);animation:axglow 2.4s ease-in-out infinite}
.ax-primary:hover{transform:translateY(-1px);filter:brightness(1.05)}
.ax-primary::after{content:"";position:absolute;top:0;left:-60%;width:38%;height:100%;background:linear-gradient(115deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-20deg);animation:axshine 3.6s ease-in-out infinite;pointer-events:none}
@keyframes axglow{0%,100%{box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 8px 20px -6px rgba(18,183,106,.55),0 0 0 0 rgba(37,211,102,.5)}50%{box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 8px 22px -6px rgba(18,183,106,.8),0 0 20px 3px rgba(37,211,102,.55)}}
@keyframes axshine{0%{left:-60%}55%{left:130%}100%{left:130%}}
/* ================ MORE MENU ================ */
.ax-kebab{width:44px;height:44px;border-radius:999px;border:1px solid rgba(255,255,255,.6);background:rgba(255,255,255,.55);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);box-shadow:inset 0 1px 0 rgba(255,255,255,.85);display:grid;place-items:center;cursor:pointer;color:#0b1220;font-size:1.02rem;transition:.2s}
.ax-kebab:hover{border-color:rgba(0,87,255,.45);color:#0057ff}
.ax-more{position:relative}
.ax-more-panel{position:absolute;top:calc(100% + 12px);right:0;width:230px;padding:10px;border-radius:20px;opacity:0;visibility:hidden;transform:translateY(-8px);transition:.25s;z-index:60;background:linear-gradient(180deg,rgba(255,255,255,.95),rgba(255,255,255,.86));-webkit-backdrop-filter:blur(30px) saturate(180%);backdrop-filter:blur(30px) saturate(180%);border:1px solid rgba(255,255,255,.62);box-shadow:0 24px 60px -20px rgba(15,30,70,.42),inset 0 1px 0 rgba(255,255,255,.92)}
.ax-more-panel.open{opacity:1;visibility:visible;transform:none}
.ax-mp-ey{font-size:.6rem;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#94a3b8;padding:6px 10px 4px}
.ax-mp-l{display:flex;gap:11px;align-items:center;padding:10px 11px;border-radius:12px;font:inherit;font-weight:600;font-size:.9rem;color:#0b1220;background:none;border:none;cursor:pointer;text-align:left;transition:background .2s;text-decoration:none;width:100%}
.ax-mp-l:hover{background:rgba(0,87,255,.08)}
.ax-mp-l i{width:18px;color:#0057ff;text-align:center}
.ax-mp-sep{height:1px;background:rgba(15,23,42,.08);margin:7px 4px}
.ax-install-row{width:100%;display:flex;gap:10px;align-items:center;justify-content:center;background:linear-gradient(135deg,#0057ff,#3b82f6);color:#fff;border:none;border-radius:13px;padding:11px;font:inherit;font-weight:700;font-size:.86rem;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 10px 22px -10px rgba(0,87,255,.6);transition:transform .2s,filter .2s}
.ax-install-row:hover{transform:translateY(-1px);filter:brightness(1.06)}
.ax-install-row i{color:#fff}
/* ================ MOBILE ================ */
.ax-mobile{display:none}
/* ================ AUTO COVER ================ */
.ax-cover{max-width:1240px;margin:18px auto 6px;padding:0 16px}
.ax-cover figure{position:relative;margin:0;border-radius:22px;overflow:hidden;box-shadow:0 24px 50px -28px rgba(9,32,84,.35);background:linear-gradient(135deg,#03102e,#0a2a63)}
.ax-cover img{width:100%;height:300px;object-fit:cover;display:block}
.ax-cover figure::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(10,22,51,0) 55%,rgba(10,22,51,.28));pointer-events:none}
/* ================ MOBILE DRAWER ================
   v10 fix: closed state = visibility:hidden (delayed) taaki andar ke
   links/buttons focus na ho sakein (a11y + AI-agent tree fix). */
.ax-scrim{position:fixed;inset:0;background:rgba(9,18,40,.4);-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);opacity:0;visibility:hidden;transition:.3s;z-index:1400}
.ax-scrim.open{opacity:1;visibility:visible}
.ax-drawer{position:fixed;top:0;right:0;height:100%;width:52vw;min-width:212px;max-width:300px;z-index:1401;transform:translateX(106%);visibility:hidden;transition:transform .42s cubic-bezier(.3,.8,.3,1),visibility 0s linear .42s;display:flex;flex-direction:column;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(255,255,255,.78));-webkit-backdrop-filter:blur(36px) saturate(190%);backdrop-filter:blur(36px) saturate(190%);border-left:1px solid rgba(255,255,255,.6);box-shadow:inset 1px 0 0 rgba(255,255,255,.85),-26px 0 64px -26px rgba(15,30,70,.5)}
.ax-drawer.open{transform:none;visibility:visible;transition:transform .42s cubic-bezier(.3,.8,.3,1)}
.ax-dr-top{display:flex;align-items:center;justify-content:space-between;padding:12px 12px 10px;border-bottom:1px solid rgba(15,23,42,.07)}
.ax-dr-brand{display:flex;align-items:center;gap:8px;text-decoration:none}
.ax-dr-brand img{height:30px;width:auto}
.ax-dr-brand b{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:.95rem;color:#0A1633}
.ax-dr-x{width:34px;height:34px;border-radius:50%;border:1px solid rgba(255,255,255,.6);background:rgba(255,255,255,.6);display:grid;place-items:center;cursor:pointer;color:#0b1220}
.ax-dr-quick{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px 12px}
.ax-dr-quick a{display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 6px;border-radius:12px;font-weight:700;font-size:.76rem;text-decoration:none}
.ax-dr-quick .c{background:rgba(0,87,255,.1);color:#0057ff}
.ax-dr-quick .w{background:rgba(37,211,102,.14);color:#12a150}
.ax-dr-ai{padding:0 12px 8px}
.ax-ai-card{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:16px;background:linear-gradient(135deg,rgba(0,87,255,.08),rgba(0,194,255,.12));border:1px solid rgba(0,87,255,.2);text-decoration:none;color:#0A1633;transition:background .2s,transform .2s,box-shadow .2s}
.ax-ai-card:hover,.ax-ai-card:active{background:linear-gradient(135deg,rgba(0,87,255,.14),rgba(0,194,255,.20));transform:translateY(-1px);box-shadow:0 6px 16px -6px rgba(0,87,255,.25)}
.ax-ai-card>i:first-child{font-size:1.3rem;color:#0057ff;width:26px;text-align:center;flex:none}
.ax-ai-card span{flex:1;display:flex;flex-direction:column;line-height:1.25;min-width:0}
.ax-ai-card b{font-size:.9rem;font-weight:700;color:#0A1633}
.ax-ai-card small{font-size:.72rem;color:#5b6577;margin-top:2px}
.ax-ai-card>i:last-child{color:#0057ff;font-size:.8rem;flex:none}
.ax-dr-scroll{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:8px}
.axg-h{width:100%;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:13px 16px;background:none;border:none;border-top:1px solid rgba(15,23,42,.06);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;color:#0b1220;cursor:pointer}
.axg-h>span{display:flex;align-items:center;gap:10px}
.axg-h>span>i{width:18px;color:#0057ff}
.axg-chev{font-size:.7rem;color:#94a3b8;transition:transform .3s}
.axg.open .axg-chev{transform:rotate(180deg)}
.axg-b{max-height:0;overflow:hidden;transition:max-height .38s cubic-bezier(.2,.8,.2,1)}
.axg.open .axg-b{max-height:440px}
.axg-l{display:flex;align-items:center;gap:10px;padding:10px 14px 10px 18px;font-size:.85rem;font-weight:600;color:#1f2a44;text-decoration:none;border-radius:10px;margin:1px 8px}
.axg-l i{width:16px;color:#0057ff;font-size:.8rem;text-align:center;flex:none}
.axg-l:active{background:rgba(0,87,255,.08)}
.ax-dr-foot{padding:10px 12px calc(12px + env(safe-area-inset-bottom));border-top:1px solid rgba(15,23,42,.07)}
/* ================ BODY OFFSET ================ */
body{padding-top:78px!important}
/* ================ RESPONSIVE ================ */
@media(max-width:980px){
body{padding-top:70px!important}
.ax-dnav,.ax-mega,.ax-more{display:none!important}
.ax-mobile{display:grid}
.ax-ghost{display:none}
.ax-wm-tag{display:none}
.ax-brand img{height:38px}
.ax-wm-main{font-size:1.05rem}
.ax-primary{padding:9px 14px;font-size:.85rem}
.ax-kebab{width:42px;height:42px}
.ax-cover{padding:0 12px}
.ax-cover img{height:200px}
}
@media(max-width:420px){
.ax-wm-sub{display:none}
.ax-wm-main{font-size:.98rem}
.ax-primary{padding:9px 12px}
}
@media(min-width:981px){
.ax-drawer,.ax-scrim{display:none!important}
}
/* ================ REDUCED MOTION ================ */
@media(prefers-reduced-motion:reduce){
.ax-sheen::after,.ax-primary,.ax-primary::after{animation:none!important}
.ax-mega,.ax-drawer,.axg-b{transition:none!important}
.ax-pill-bar::after{animation:none!important}
.ax-navlink.ax-ai-link{transition:none!important}
}
</style>
<header class="ax-hdr" id="siteHeader">
<div class="ax-pill-bar">
<span class="ax-sheen" aria-hidden="true"></span>
<a class="ax-brand" href="/" aria-label="<?php echo $esc(SITE_NAME); ?> home">
<img src="/assets/images/logo-icon.png" alt="<?php echo $esc(SITE_NAME); ?> logo" width="42" height="44" decoding="async" onerror="this.style.display='none'">
<span class="ax-wm">
<span class="ax-wm-main">ANAYA</span>
<span class="ax-wm-sub"><i></i>CAB SERVICE<i></i></span>
<span class="ax-wm-tag">&mdash; SAFE JOURNEY, HAPPY JOURNEY &mdash;</span>
</span>
</a>
<nav class="ax-dnav" aria-label="Main navigation">
<a href="/" class="ax-navlink<?php echo ($current_page === 'index.php' || $current_page === '') ? ' active' : ''; ?>">Home</a>
<button class="ax-navbtn" type="button" data-mega="megaSvc" aria-haspopup="true" aria-expanded="false">Services <i class="fa-solid fa-chevron-down caret"></i></button>
<button class="ax-navbtn" type="button" data-mega="megaRoutes" aria-haspopup="true" aria-expanded="false">Routes <i class="fa-solid fa-chevron-down caret"></i></button>
<button class="ax-navbtn" type="button" data-mega="megaFleet" aria-haspopup="true" aria-expanded="false">Fleet <i class="fa-solid fa-chevron-down caret"></i></button>
<a href="/pricing" class="ax-navlink<?php echo $current_page === 'pricing.php' ? ' active' : ''; ?>">Pricing</a>
<a href="/ai-trip-planner" class="ax-navlink ax-ai-link<?php echo $current_page === 'ai-trip-planner.php' ? ' active' : ''; ?>"><i class="fa-solid fa-wand-magic-sparkles"></i>AI Planner</a>
<button class="ax-navbtn" type="button" data-mega="megaBlog" aria-haspopup="true" aria-expanded="false">Blog <i class="fa-solid fa-chevron-down caret"></i></button>
</nav>
<div class="ax-actions">
<a class="ax-pill ax-ghost" href="tel:<?php echo $esc(BUSINESS_PHONE_TEL); ?>"><i class="fa-solid fa-phone"></i><?php echo $esc(BUSINESS_PHONE); ?></a>
<a class="ax-pill ax-primary" href="/#booking"><i class="fa-solid fa-taxi"></i><span>Book now</span></a>
<div class="ax-more">
<button class="ax-kebab" id="axMoreBtn" type="button" aria-label="More" aria-haspopup="true" aria-expanded="false"><i class="fa-solid fa-ellipsis-vertical"></i></button>
<div class="ax-more-panel" id="axMorePanel">
<div class="ax-mp-ey">Company</div>
<?php foreach ($NAV_COMPANY as $c): ?>
<a class="ax-mp-l" href="<?php echo $esc($c[2]); ?>"><i class="fa-solid <?php echo $esc($c[0]); ?>"></i><?php echo $esc($c[1]); ?></a>
<?php endforeach; ?>
<div class="ax-mp-sep"></div>
<button class="ax-install-row ax-install-trigger" type="button"><i class="fa-solid fa-circle-down"></i>Install App</button>
</div>
</div>
<button class="ax-kebab ax-mobile" id="axOpenDrawer" type="button" aria-label="Open menu" aria-haspopup="true" aria-expanded="false"><i class="fa-solid fa-ellipsis-vertical"></i></button>
</div>
<!-- SERVICES MEGA MENU -->
<div class="ax-mega" id="megaSvc">
<div class="ax-mega-grid">
<?php foreach ($NAV_SERVICES as $it): ?>
<a class="ax-mc" href="<?php echo $esc($it[3]); ?>"><span class="ax-mc-i"><i class="fa-solid <?php echo $esc($it[0]); ?>"></i></span><span class="ax-mc-t"><b><?php echo $esc($it[1]); ?></b><small><?php echo $esc($it[2]); ?></small></span></a>
<?php endforeach; ?>
</div>
</div>
<!-- ROUTES MEGA MENU -->
<div class="ax-mega" id="megaRoutes">
<div class="ax-mega-grid">
<?php foreach ($NAV_ROUTES as $r): ?>
<a class="ax-mc" href="<?php echo $esc($r[4]); ?>"><span class="ax-mc-i"><i class="fa-solid <?php echo $esc($r[0]); ?>"></i></span><span class="ax-mc-t"><b><?php echo $esc($r[1]); ?></b><small><?php echo $esc($r[3]); ?></small></span></a>
<?php endforeach; ?>
</div>
<div class="ax-mega-foot"><a class="ax-mega-all" href="/services"><i class="fa-solid fa-arrow-right"></i>All routes &amp; services</a></div>
</div>
<!-- FLEET MEGA MENU -->
<div class="ax-mega" id="megaFleet">
<div class="ax-mega-grid">
<?php foreach ($NAV_FLEET as $f): ?>
<a class="ax-mc" href="<?php echo $esc($f[3]); ?>"><span class="ax-mc-i"><i class="fa-solid <?php echo $esc($f[0]); ?>"></i></span><span class="ax-mc-t"><b><?php echo $esc($f[1]); ?></b><small><?php echo $esc($f[2]); ?></small></span></a>
<?php endforeach; ?>
</div>
</div>
<!-- BLOG MEGA MENU -->
<div class="ax-mega" id="megaBlog">
<div class="ax-mega-blog">
<?php foreach ($NAV_BLOG as $b): ?>
<a class="ax-bl" href="<?php echo $esc($b[1]); ?>"><i class="fa-regular fa-file-lines"></i><span><?php echo $esc($b[0]); ?></span><i class="fa-solid fa-arrow-right ax-bl-arr"></i></a>
<?php endforeach; ?>
</div>
<div class="ax-mega-foot"><a class="ax-mega-all" href="/blog/"><i class="fa-solid fa-newspaper"></i>View all posts</a></div>
</div>
</div>
</header>
<?php if ($__auto_cover !== ''): ?>
<div class="ax-cover" id="axAutoCover" style="display:none">
<figure>
<img src="<?php echo $esc($__auto_cover); ?>" alt="<?php echo $esc($page_title); ?>" width="1240" height="300" decoding="async" onerror="this.style.display='none';var f=this.closest('.ax-cover');if(f)f.style.display='none';">
</figure>
</div>
<?php endif; ?>
<!-- MOBILE SCRIM -->
<div class="ax-scrim" id="axScrim"></div>
<!-- MOBILE DRAWER (v10: inert + aria-hidden when closed) -->
<aside class="ax-drawer" id="axDrawer" aria-label="Mobile menu" aria-hidden="true" inert>
<div class="ax-dr-top">
<a class="ax-dr-brand" href="/" aria-label="<?php echo $esc(SITE_NAME); ?> home">
<img src="/assets/images/logo-icon.png" alt="<?php echo $esc(SITE_NAME); ?>" width="30" height="32" onerror="this.style.display='none'">
<b>ANAYA</b>
</a>
<button class="ax-dr-x" id="axCloseDrawer" type="button" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button>
</div>
<div class="ax-dr-quick">
<a class="c" href="tel:<?php echo $esc(BUSINESS_PHONE_TEL); ?>"><i class="fa-solid fa-phone"></i>Call</a>
<a class="w" href="https://wa.me/<?php echo $esc(BUSINESS_WHATSAPP); ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book a taxi.'); ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-whatsapp"></i>WhatsApp</a>
</div>
<div class="ax-dr-ai">
<a class="ax-ai-card" href="/ai-trip-planner"><i class="fa-solid fa-wand-magic-sparkles"></i><span><b>AI Trip Planner</b><small>Smart itinerary in seconds</small></span><i class="fa-solid fa-arrow-right"></i></a>
</div>
<div class="ax-dr-scroll">
<!-- SERVICES -->
<div class="axg">
<button class="axg-h" type="button" aria-expanded="false"><span><i class="fa-solid fa-layer-group"></i>Services</span><i class="fa-solid fa-chevron-down axg-chev"></i></button>
<div class="axg-b">
<?php foreach ($NAV_SERVICES as $it): ?>
<a class="axg-l" href="<?php echo $esc($it[3]); ?>"><i class="fa-solid <?php echo $esc($it[0]); ?>"></i><?php echo $esc($it[1]); ?></a>
<?php endforeach; ?>
</div>
</div>
<!-- ROUTES -->
<div class="axg">
<button class="axg-h" type="button" aria-expanded="false"><span><i class="fa-solid fa-route"></i>Routes</span><i class="fa-solid fa-chevron-down axg-chev"></i></button>
<div class="axg-b">
<?php foreach ($NAV_ROUTES as $r): ?>
<a class="axg-l" href="<?php echo $esc($r[4]); ?>"><i class="fa-solid fa-location-dot"></i><?php echo $esc($r[2]); ?></a>
<?php endforeach; ?>
<a class="axg-l" href="/services"><i class="fa-solid fa-arrow-right"></i>All routes</a>
</div>
</div>
<!-- FLEET -->
<div class="axg">
<button class="axg-h" type="button" aria-expanded="false"><span><i class="fa-solid fa-car-side"></i>Fleet</span><i class="fa-solid fa-chevron-down axg-chev"></i></button>
<div class="axg-b">
<?php foreach ($NAV_FLEET as $f): ?>
<a class="axg-l" href="<?php echo $esc($f[3]); ?>"><i class="fa-solid <?php echo $esc($f[0]); ?>"></i><?php echo $esc($f[1]); ?></a>
<?php endforeach; ?>
</div>
</div>
<!-- BLOG -->
<div class="axg">
<button class="axg-h" type="button" aria-expanded="false"><span><i class="fa-solid fa-newspaper"></i>Blog</span><i class="fa-solid fa-chevron-down axg-chev"></i></button>
<div class="axg-b">
<?php foreach ($NAV_BLOG as $b): ?>
<a class="axg-l" href="<?php echo $esc($b[1]); ?>"><i class="fa-regular fa-file-lines"></i><?php echo $esc($b[0]); ?></a>
<?php endforeach; ?>
<a class="axg-l" href="/blog/"><i class="fa-solid fa-arrow-right"></i>All posts</a>
</div>
</div>
<!-- COMPANY -->
<div class="axg">
<button class="axg-h" type="button" aria-expanded="false"><span><i class="fa-solid fa-building"></i>Company</span><i class="fa-solid fa-chevron-down axg-chev"></i></button>
<div class="axg-b">
<?php foreach ($NAV_COMPANY as $c): ?>
<a class="axg-l" href="<?php echo $esc($c[2]); ?>"><i class="fa-solid <?php echo $esc($c[0]); ?>"></i><?php echo $esc($c[1]); ?></a>
<?php endforeach; ?>
</div>
</div>
</div>
<div class="ax-dr-foot">
<button class="ax-install-row ax-install-trigger" type="button"><i class="fa-solid fa-circle-down"></i>Install App</button>
</div>
</aside>
<script>
(function(){
'use strict';
/* ================ AUTO COVER ================ */
function axPlaceCover(){
var c=document.getElementById('axAutoCover');
if(!c){return;}
var h=document.querySelector('main h1')||document.querySelector('h1');
if(h){h.insertAdjacentElement('afterend',c);c.style.display='';}else{c.remove();}
}
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',axPlaceCover,{once:true});}else{axPlaceCover();}
/* ================ PWA SERVICE WORKER ================ */
if('serviceWorker' in navigator){
window.addEventListener('load',function(){navigator.serviceWorker.register('/pwa-sw.js',{scope:'/'}).catch(function(){});},{once:true});
}
/* ================ DOM REFERENCES ================ */
var navBtns=[].slice.call(document.querySelectorAll('.ax-navbtn[data-mega]'));
var moreBtn=document.getElementById('axMoreBtn');
var morePanel=document.getElementById('axMorePanel');
var drawer=document.getElementById('axDrawer');
var scrim=document.getElementById('axScrim');
var openD=document.getElementById('axOpenDrawer');
var closeD=document.getElementById('axCloseDrawer');
/* ================ MEGA MENUS ================ */
function closeMegas(){
navBtns.forEach(function(b){b.classList.remove('open');b.setAttribute('aria-expanded','false');});
document.querySelectorAll('.ax-mega.open').forEach(function(m){m.classList.remove('open');});
}
/* ================ MORE MENU ================ */
function closeKebab(){
if(morePanel){morePanel.classList.remove('open');}
if(moreBtn){moreBtn.setAttribute('aria-expanded','false');}
}
/* ================ DRAWER (v10: inert toggle) ================ */
function closeDrawer(){
if(drawer){
drawer.classList.remove('open');
drawer.setAttribute('aria-hidden','true');
drawer.setAttribute('inert','');
}
if(scrim){scrim.classList.remove('open');}
if(openD){openD.setAttribute('aria-expanded','false');}
document.body.style.overflow='';
}
function closeAll(){closeMegas();closeKebab();closeDrawer();}
/* ================ DESKTOP MEGA BUTTONS ================ */
navBtns.forEach(function(btn){
btn.addEventListener('click',function(e){
e.stopPropagation();
var id=btn.getAttribute('data-mega');
var m=document.getElementById(id);
var wasOpen=btn.classList.contains('open');
closeMegas();closeKebab();
if(!wasOpen){
btn.classList.add('open');
btn.setAttribute('aria-expanded','true');
if(m){m.classList.add('open');}
}
});
});
/* ================ MORE BUTTON ================ */
if(moreBtn&&morePanel){
moreBtn.addEventListener('click',function(e){
e.stopPropagation();
var open=morePanel.classList.contains('open');
closeMegas();closeKebab();
if(!open){morePanel.classList.add('open');moreBtn.setAttribute('aria-expanded','true');}
});
}
/* ================ MOBILE DRAWER OPEN ================ */
if(openD){
openD.addEventListener('click',function(e){
e.stopPropagation();
closeMegas();closeKebab();
if(drawer){
drawer.removeAttribute('inert');
drawer.classList.add('open');
drawer.setAttribute('aria-hidden','false');
}
if(scrim){scrim.classList.add('open');}
openD.setAttribute('aria-expanded','true');
document.body.style.overflow='hidden';
});
}
/* ================ MOBILE DRAWER CLOSE ================ */
if(closeD){closeD.addEventListener('click',closeDrawer);}
if(scrim){scrim.addEventListener('click',closeDrawer);}
if(drawer){
drawer.querySelectorAll('a').forEach(function(a){a.addEventListener('click',closeDrawer);});
drawer.querySelectorAll('.axg-h').forEach(function(h){
h.addEventListener('click',function(){
var group=h.parentElement;
var open=group.classList.toggle('open');
h.setAttribute('aria-expanded',open?'true':'false');
});
});
}
/* ================ OUTSIDE CLICK ================ */
document.addEventListener('click',function(e){
if(!e.target.closest('.ax-hdr')){closeMegas();closeKebab();}
});
/* ================ ESCAPE ================ */
document.addEventListener('keydown',function(e){
if(e.key==='Escape'){closeAll();}
});
/* ================ RESIZE ================ */
window.addEventListener('resize',function(){
if(window.innerWidth>=981){closeDrawer();}
closeMegas();closeKebab();
},{passive:true});
/* ================ PWA INSTALL ================ */
var deferred=null;
window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();deferred=e;});
function axTryInstall(){
if(deferred){
deferred.prompt().catch(function(){});
deferred.userChoice.then(function(){deferred=null;}).catch(function(){deferred=null;});
return;
}
var ua=navigator.userAgent||'';
var ios=/iphone|ipad|ipod/i.test(ua);
var msg=ios?'iPhone / iPad: Safari ke Share button se "Add to Home Screen" chuno.':'Chrome menu mein "Install app" dikhe toh chuno. Nahi dikhe toh reload karke dobara try karo.';
var t=document.getElementById('toast');
if(t){t.textContent=msg;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(function(){t.classList.remove('show');},5200);}else{window.alert(msg);}
}
/* ================ INSTALL BUTTONS ================ */
document.addEventListener('click',function(ev){
var target=ev.target.closest('.ax-install-trigger');
if(!target){return;}
ev.preventDefault();
axTryInstall();
});
/* ================ APP INSTALLED ================ */
window.addEventListener('appinstalled',function(){
deferred=null;
var t=document.getElementById('toast');
if(t){t.textContent='Anaya Cab install ho gayi!';t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(function(){t.classList.remove('show');},4000);}
});
})();
</script>