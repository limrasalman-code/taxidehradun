<?php
/**
 * Anaya Cab Service — Reusable "Yatra Quick Facts" block  [Fix A6]
 * ----------------------------------------------------------------
 * Pilgrimage pages pe ek clear, scannable facts box deta hai jo
 * TAXI DROP-POINT vs TEMPLE ACCESS spasht karta hai (accuracy + AEO).
 *
 * Use (kisi yatra page me, header include ke baad, intro ke neeche):
 *   <?php require_once __DIR__ . '/includes/yatra-facts.php'; echo anaya_yatra_facts('kedarnath'); ?>
 *
 * Valid keys: kedarnath, badrinath, gangotri, yamunotri, char-dham, do-dham
 * Unknown key -> empty string (kuch print nahi hota).
 */

function anaya_yatra_facts(string $dest): string {
    $data = [
        'kedarnath' => [
            'title' => 'Kedarnath Yatra — Quick Facts',
            'rows'  => [
                ['Taxi drop point', 'Sonprayag — the last point for private taxis. From there a shared local jeep runs to Gaurikund.'],
                ['Temple access', 'About 16–18 km trek from Gaurikund on foot, or by helicopter (from Phata / Guptkashi / Sersi) or pony / palki. A taxi does not reach the temple itself.'],
                ['Distance from Dehradun', 'Approx. 250 km to the Sonprayag / Guptkashi side.'],
                ['Drive time', '8–10 hours to the stay point (excluding breaks).'],
                ['Best vehicle', 'Innova / Innova Crysta or SUV for hill comfort; Tempo Traveller for groups.'],
                ['Season', 'Portal (kapat) usually opens around Apr–May and closes around Oct–Nov. Exact dates are announced each year.'],
            ],
        ],
        'badrinath' => [
            'title' => 'Badrinath Yatra — Quick Facts',
            'rows'  => [
                ['Taxi drop point', 'Badrinath town — the road goes up close to the temple, so the taxi reaches the temple area directly.'],
                ['Temple access', 'Short walk from the parking / town area to the temple.'],
                ['Distance from Dehradun', 'Approx. 335 km via Rishikesh–Devprayag–Joshimath.'],
                ['Best vehicle', 'Innova / Innova Crysta or SUV; Tempo Traveller for groups.'],
                ['Season', 'Usually open around Apr–May to Oct–Nov; exact dates announced each year.'],
            ],
        ],
        'gangotri' => [
            'title' => 'Gangotri Yatra — Quick Facts',
            'rows'  => [
                ['Taxi drop point', 'Gangotri temple town — motorable up to the town; the taxi reaches the temple area directly.'],
                ['Temple access', 'Short walk from the parking area to the temple.'],
                ['Distance from Dehradun', 'Approx. 240 km via Uttarkashi and Harsil.'],
                ['Best vehicle', 'Innova / SUV for hill roads; Tempo Traveller for groups.'],
                ['Season', 'Usually open around Apr–May to Oct–Nov; exact dates announced each year.'],
            ],
        ],
        'yamunotri' => [
            'title' => 'Yamunotri Yatra — Quick Facts',
            'rows'  => [
                ['Taxi drop point', 'Janki Chatti — the last motorable point.'],
                ['Temple access', 'About 5–6 km trek from Janki Chatti on foot, or by pony / palki. A taxi does not reach the temple itself.'],
                ['Distance from Dehradun', 'Approx. 180 km via Barkot.'],
                ['Best vehicle', 'Innova / SUV for hill roads; Tempo Traveller for groups.'],
                ['Season', 'Usually open around Apr–May to Oct–Nov; exact dates announced each year.'],
            ],
        ],
        'char-dham' => [
            'title' => 'Char Dham Yatra — Quick Facts',
            'rows'  => [
                ['Circuit', 'Yamunotri → Gangotri → Kedarnath → Badrinath, usually starting and ending at Dehradun / Haridwar.'],
                ['Typical duration', '10–12 days by taxi, depending on pace and halts.'],
                ['Access note', 'Gangotri and Badrinath are reached by road; Yamunotri (from Janki Chatti) and Kedarnath (from Sonprayag / Gaurikund) need a trek, or a heli / pony / palki. Taxis do not reach these two temples directly.'],
                ['Best vehicle', 'Innova / Innova Crysta for families; Tempo Traveller or Urbania for groups.'],
                ['Season', 'The yatra runs roughly Apr–May to Oct–Nov. Registration and road access can change; verify the current plan before departure.'],
            ],
        ],
        'do-dham' => [
            'title' => 'Do Dham Yatra — Quick Facts',
            'rows'  => [
                ['Circuit', 'Kedarnath and Badrinath, usually from Dehradun / Haridwar.'],
                ['Typical duration', '5–7 days by taxi, depending on pace and halts.'],
                ['Access note', 'Badrinath is reached by road; Kedarnath (from Sonprayag / Gaurikund) needs a trek, or a heli / pony / palki. The taxi does not reach the Kedarnath temple directly.'],
                ['Best vehicle', 'Innova / Innova Crysta for families; Tempo Traveller for groups.'],
                ['Season', 'Usually Apr–May to Oct–Nov; verify the current plan before departure.'],
            ],
        ],
    ];

    if (!isset($data[$dest])) return '';
    $card = $data[$dest];

    $html  = '<div class="yatra-facts" style="border:1px solid rgba(0,0,0,.1);border-radius:var(--radius,12px);padding:18px 20px;margin:8px 0 24px;background:var(--sky,#f6f9fc);">';
    $html .= '<h2 style="font-size:1.15rem;margin:0 0 12px;">' . htmlspecialchars($card['title']) . '</h2>';
    $html .= '<dl style="margin:0;color:var(--slate,#475569);line-height:1.7;">';
    foreach ($card['rows'] as $r) {
        $html .= '<dt style="font-weight:600;color:var(--ink,#0f172a);margin-top:10px;">' . htmlspecialchars($r[0]) . '</dt>';
        $html .= '<dd style="margin:2px 0 0;">' . htmlspecialchars($r[1]) . '</dd>';
    }
    $html .= '</dl>';
    $html .= '<p style="font-size:.85rem;color:var(--slate,#475569);margin:14px 0 0;">Distances and timings are approximate. Please confirm the final fare and plan on call / WhatsApp before booking.</p>';
    $html .= '</div>';

    return $html;
}
