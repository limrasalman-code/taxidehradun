<?php
/**
 * Anaya Cab Service — Site Configuration
 * Production source of truth for business identity, contact, SEO and database settings.
 */

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Production error handling
|--------------------------------------------------------------------------
| Never expose PHP/database errors to visitors. Details go to the server log.
*/
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
ini_set('html_errors', '0');

/*
|--------------------------------------------------------------------------
| Timezone
|--------------------------------------------------------------------------
*/
date_default_timezone_set('Asia/Kolkata');

/*
|--------------------------------------------------------------------------
| Admin Panel Security
|--------------------------------------------------------------------------
| Compatibility constants are preserved.
|
| SECURITY:
| Move these credentials to VPS environment variables when possible:
|   ANAYA_ADMIN_PASSWORD
|   ANAYA_DB_HOST
|   ANAYA_DB_NAME
|   ANAYA_DB_USER
|   ANAYA_DB_PASSWORD
|
| IMPORTANT: The currently supplied credentials were exposed in chat/source.
| Rotate the database password and admin password after deployment.
*/
define(
    'ADMIN_PASSWORD',
    (string) (getenv('ANAYA_ADMIN_PASSWORD') ?: 'Anaya@123')
);

/*
|--------------------------------------------------------------------------
| Database
|--------------------------------------------------------------------------
| Environment variables take priority; fallback values preserve compatibility
| with the existing production installation until credentials are rotated.
*/
$dbHost = (string) (getenv('ANAYA_DB_HOST') ?: 'localhost');
$dbUsername = (string) (getenv('ANAYA_DB_USER') ?: 'u961636265_taxidehradun');
$dbPassword = (string) (getenv('ANAYA_DB_PASSWORD') ?: 'Anayacab@121');
$dbName = (string) (getenv('ANAYA_DB_NAME') ?: 'u961636265_taxidehradun');

/*
|--------------------------------------------------------------------------
| PDO Database Connection
|--------------------------------------------------------------------------
*/
function db(): ?PDO
{
    global $dbHost, $dbName, $dbUsername, $dbPassword;

    static $pdo = null;

    if ($pdo instanceof PDO) {
        try {
            if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== '') {
                return $pdo;
            }
        } catch (Throwable $e) {
            $pdo = null;
        }
    }

    try {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=utf8mb4',
            $dbHost,
            $dbName
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
            PDO::ATTR_PERSISTENT         => false,
        ];

        $pdo = new PDO(
            $dsn,
            $dbUsername,
            $dbPassword,
            $options
        );

        /*
         * Make the connection explicit about UTF-8 and SQL mode.
         * This is safe for the existing application and prevents accidental
         * connection-level charset drift.
         */
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

        return $pdo;
    } catch (Throwable $e) {
        error_log(
            'Anaya Cab DB Error: ' .
            $e->getMessage()
        );
        return null;
    }
}

/*
|--------------------------------------------------------------------------
| Business Identity
|--------------------------------------------------------------------------
*/
define('SITE_NAME', 'Anaya Cab Service');
define('SITE_TAGLINE', 'Reliable Cab Service Anywhere, Anytime');
define('SITE_DOMAIN', 'https://www.taxidehradun.com');

/*
|--------------------------------------------------------------------------
| Contact
|--------------------------------------------------------------------------
*/
define('BUSINESS_PHONE', '+91 80776 11583');
define('BUSINESS_PHONE_TEL', '+918077611583');
define('BUSINESS_EMAIL', 'anayacabservice.in@gmail.com');
define('BUSINESS_WHATSAPP', '918077611583');

/*
|--------------------------------------------------------------------------
| Address / NAP
|--------------------------------------------------------------------------
*/
define(
    'BUSINESS_ADDRESS_LINE',
    'Shimla Bypass Road, Near St. Jude\'s School, Shanti Vihar Colony, Sewla Kalan Majra'
);

define('BUSINESS_CITY', 'Dehradun');
define('BUSINESS_STATE', 'Uttarakhand');
define('BUSINESS_PINCODE', '248001');
define('BUSINESS_COUNTRY', 'India');

define(
    'BUSINESS_FULL_ADDRESS',
    BUSINESS_ADDRESS_LINE . ', ' .
    BUSINESS_CITY . ', ' .
    BUSINESS_STATE . ' ' .
    BUSINESS_PINCODE . ', ' .
    BUSINESS_COUNTRY
);

/*
|--------------------------------------------------------------------------
| Geo
|--------------------------------------------------------------------------
| Keep these coordinates aligned with the real business location.
*/
define('BUSINESS_LATITUDE', '30.291308');
define('BUSINESS_LONGITUDE', '77.996000');

/*
|--------------------------------------------------------------------------
| Social Profiles
|--------------------------------------------------------------------------
*/
define(
    'SOCIAL_FACEBOOK',
    'https://facebook.com/anayacabservice'
);

define(
    'SOCIAL_INSTAGRAM',
    'https://instagram.com/anayacabservice'
);

define(
    'SOCIAL_WHATSAPP',
    'https://wa.me/918077611583'
);

define(
    'SOCIAL_LINKEDIN',
    'https://linkedin.com/company/anayacabservice'
);

/*
|--------------------------------------------------------------------------
| Google Business Profile
|--------------------------------------------------------------------------
*/
define(
    'GOOGLE_BUSINESS_PROFILE_URL',
    'https://share.google/j96GFirtHp7CzVY0e'
);

define(
    'GOOGLE_BUSINESS_SEARCH_URL',
    'https://www.google.com/search?kgmid=/g/11nqpdw6n2&q=Anaya+cab+service+Dehradun'
);

define(
    'GOOGLE_BUSINESS_MAPS_URL',
    'https://maps.google.com/maps?output=search&q=Anaya+cab+service+Dehradun'
);

define(
    'GOOGLE_BUSINESS_KGMID',
    '/g/11nqpdw6n2'
);

define(
    'GOOGLE_REVIEW_URL',
    'https://www.google.com/search?kgmid=/g/11nqpdw6n2&q=Anaya+cab+service+Dehradun'
);

/*
|--------------------------------------------------------------------------
| SEO Defaults
|--------------------------------------------------------------------------
*/
define(
    'DEFAULT_META_TITLE',
    'Anaya Cab Service | Best Cab & Taxi Service in Dehradun'
);

define(
    'DEFAULT_META_DESC',
    'Anaya Cab Service offers reliable taxi and cab service in Dehradun for local rides, airport transfers, outstation trips and Char Dham Yatra. Book with transparent fares and experienced drivers.'
);

/*
|--------------------------------------------------------------------------
| Business Stats
|--------------------------------------------------------------------------
| Keep these numbers factual and consistent with the visible website content.
*/
define('STAT_CUSTOMERS', '500+');
define('STAT_DRIVERS', '50+');
define('STAT_CITIES', '25+');
define('STAT_SAFETY', '100%');

/*
|--------------------------------------------------------------------------
| Site Version / Cache Busting
|--------------------------------------------------------------------------
*/
define('SITE_VERSION', '9');

/*
|--------------------------------------------------------------------------
| Current Year
|--------------------------------------------------------------------------
*/
define('CURRENT_YEAR', date('Y'));

/*
|--------------------------------------------------------------------------
| Security / Output Helpers
|--------------------------------------------------------------------------
*/
if (!function_exists('e')) {
    function e(?string $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('site_url')) {
    function site_url(string $path = ''): string
    {
        $base = rtrim((string) SITE_DOMAIN, '/');

        if ($path === '') {
            return $base . '/';
        }

        if ($path[0] !== '/') {
            $path = '/' . $path;
        }

        return $base . $path;
    }
}

if (!function_exists('json_for_html')) {
    function json_for_html(mixed $value): string
    {
        $json = json_encode(
            $value,
            JSON_UNESCAPED_SLASHES |
            JSON_UNESCAPED_UNICODE |
            JSON_HEX_TAG |
            JSON_HEX_AMP |
            JSON_HEX_APOS |
            JSON_HEX_QUOT
        );

        return $json !== false ? $json : '{}';
    }
}
