<?php
/**
 * Anaya Cab Service — Fleet & Route Configuration
 *
 * SINGLE SOURCE OF TRUTH
 *
 * Rules:
 * - Fleet + Routes available through $GLOBALS.
 * - PHP fallback fleet always remains available.
 * - Database fleet can override fallback only with valid ACTIVE rows.
 * - ZERO rate/base values are never allowed.
 * - Routes remain PHP controlled.
 */

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DEFAULT FLEET
|--------------------------------------------------------------------------
*/

$FLEET = [

    'dzire' => [
        'name' => 'Maruti Suzuki Dzire',
        'pax'  => 4,
        'bags' => 2,
        'rate' => 15,
        'mult' => 1.00,
        'desc' => 'Comfortable 4-seater sedan for local and outstation taxi trips.',
    ],

    'zest' => [
        'name' => 'Tata Zest',
        'pax'  => 4,
        'bags' => 2,
        'rate' => 13,
        'mult' => 0.90,
        'desc' => 'Budget-friendly 4-seater cab for economical taxi travel.',
    ],

    'ertiga' => [
        'name' => 'Maruti Suzuki Ertiga',
        'pax'  => 6,
        'bags' => 3,
        'rate' => 17,
        'mult' => 1.15,
        'desc' => 'Spacious MPV for families and small groups travelling together.',
    ],

    'innova' => [
        'name' => 'Toyota Innova',
        'pax'  => 7,
        'bags' => 4,
        'rate' => 18,
        'mult' => 1.25,
        'desc' => 'Comfortable 7-seater for family trips, hill routes and outstation travel.',
    ],

    'innova-crysta' => [
        'name' => 'Toyota Innova Crysta',
        'pax'  => 7,
        'bags' => 4,
        'rate' => 20,
        'mult' => 1.35,
        'desc' => 'Premium 7-seater MPV for long-distance, family and Char Dham journeys.',
    ],

    'tempo' => [
        'name' => 'Tempo Traveller',
        'pax'  => 12,
        'bags' => 10,
        'rate' => 26,
        'mult' => 1.80,
        'desc' => '12-seater traveller for group tours, family trips and pilgrimage travel.',
    ],

    'urbania' => [
        'name' => 'Force Urbania',
        'pax'  => 13,
        'bags' => 10,
        'rate' => 30,
        'mult' => 2.00,
        'desc' => 'Premium group travel van for comfortable long-distance journeys.',
    ],
];


/*
|--------------------------------------------------------------------------
| PUBLISHED ONE-WAY ROUTES
|--------------------------------------------------------------------------
|
| base = published starting sedan fare
| km   = approximate route distance
|
*/

$ROUTES = [

    'jolly grant airport' => [
        'km'   => 28,
        'base' => 800,
    ],

    'haridwar' => [
        'km'   => 55,
        'base' => 1350,
    ],

    'rishikesh' => [
        'km'   => 45,
        'base' => 1150,
    ],

    'mussoorie' => [
        'km'   => 35,
        'base' => 1050,
    ],

    'delhi' => [
        'km'   => 250,
        'base' => 3500,
    ],

    'nainital' => [
        'km'   => 280,
        'base' => 5500,
    ],
];


/*
|--------------------------------------------------------------------------
| OPTIONAL DATABASE FLEET OVERRIDE
|--------------------------------------------------------------------------
|
| DB fleet tabhi fallback fleet ko replace karegi jab:
|
| 1. Active rows available hon
| 2. Vehicle key valid ho
| 3. Name valid ho
| 4. Rate positive ho
| 5. Multiplier positive ho
| 6. Passenger capacity positive ho
|
| ZERO FARE/RATE IS NEVER ACCEPTED.
|--------------------------------------------------------------------------
*/

if (function_exists('db')) {

    try {

        $pdo = db();

        if ($pdo instanceof PDO) {

            $sql = "
                SELECT
                    vkey,
                    name,
                    pax,
                    bags,
                    rate,
                    mult,
                    active,
                    sort
                FROM fleet
                WHERE active = 1
                ORDER BY sort ASC, id ASC
            ";

            $stmt = $pdo->query($sql);

            $rows = $stmt
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $dbFleet = [];

            foreach ($rows as $row) {

                $key = trim(
                    (string)($row['vkey'] ?? '')
                );

                $name = trim(
                    (string)($row['name'] ?? '')
                );

                if ($key === '' || $name === '') {
                    continue;
                }

                /*
                 * IMPORTANT:
                 * Invalid DB rate is rejected instead of converted to zero.
                 */
                $dbRate = (float)($row['rate'] ?? 1);

                if ($dbRate <= 0) {
                    continue;
                }

                /*
                 * Invalid DB multiplier is rejected.
                 */
                $dbMult = (float)($row['mult'] ?? 1);

                if ($dbMult <= 0) {
                    continue;
                }

                /*
                 * Passenger capacity must remain positive.
                 */
                $dbPax = (int)($row['pax'] ?? 4);

                if ($dbPax < 1) {
                    continue;
                }

                /*
                 * Bags can legitimately be zero.
                 */
                $dbBags = (int)($row['bags'] ?? 2);

                if ($dbBags < 0) {
                    $dbBags = 0;
                }

                $dbFleet[$key] = [

                    'name' => $name,

                    'pax' => $dbPax,

                    'bags' => $dbBags,

                    'rate' => $dbRate,

                    'mult' => $dbMult,

                    'desc' => $FLEET[$key]['desc']
                        ?? 'Comfortable taxi for local and outstation travel.',
                ];
            }

            /*
             * NEVER replace the safe PHP fallback
             * with an empty or invalid DB fleet.
             */
            if (!empty($dbFleet)) {
                $FLEET = $dbFleet;
            }
        }

    } catch (Throwable $e) {

        /*
         * Database failure must NEVER break the website.
         */
        error_log(
            'Anaya Fleet DB fallback: ' .
            $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| NORMALISE FLEET
|--------------------------------------------------------------------------
*/

foreach ($FLEET as $key => &$vehicle) {

    $vehicle['name'] = (string)(
        $vehicle['name']
        ?? ucfirst((string)$key)
    );

    /*
     * Passenger capacity can never be zero.
     */
    $vehicle['pax'] = max(
        1,
        (int)($vehicle['pax'] ?? 4)
    );

    /*
     * Bags may be zero.
     */
    $vehicle['bags'] = max(
        0,
        (int)($vehicle['bags'] ?? 2)
    );

    /*
     * RATE MUST NEVER BE ZERO.
     */
    $vehicle['rate'] = max(
        1,
        (float)($vehicle['rate'] ?? 1)
    );

    /*
     * MULTIPLIER MUST ALWAYS BE POSITIVE.
     */
    $vehicle['mult'] = max(
        0.1,
        (float)($vehicle['mult'] ?? 1)
    );

    $vehicle['desc'] = (string)(
        $vehicle['desc']
        ?? 'Comfortable taxi for local and outstation travel.'
    );
}

unset($vehicle);


/*
|--------------------------------------------------------------------------
| NORMALISE ROUTES
|--------------------------------------------------------------------------
*/

foreach ($ROUTES as $routeKey => &$route) {

    /*
     * Distance must always be positive.
     */
    $route['km'] = max(
        1,
        (int)($route['km'] ?? 1)
    );

    /*
     * BASE FARE MUST NEVER BE ZERO.
     */
    $route['base'] = max(
        1,
        (int)($route['base'] ?? 1)
    );
}

unset($route);


/*
|--------------------------------------------------------------------------
| FINAL SAFETY VALIDATION
|--------------------------------------------------------------------------
|
| Kisi bhi unexpected DB/config value ko live fare system
| tak zero ke form mein pahunchne nahi dena.
|--------------------------------------------------------------------------
*/

foreach ($FLEET as $key => &$vehicle) {

    if (
        !isset($vehicle['rate']) ||
        (float)$vehicle['rate'] <= 0
    ) {
        $vehicle['rate'] = 1;
    }

    if (
        !isset($vehicle['mult']) ||
        (float)$vehicle['mult'] <= 0
    ) {
        $vehicle['mult'] = 0.1;
    }

    if (
        !isset($vehicle['pax']) ||
        (int)$vehicle['pax'] <= 0
    ) {
        $vehicle['pax'] = 1;
    }
}

unset($vehicle);


foreach ($ROUTES as $routeKey => &$route) {

    if (
        !isset($route['km']) ||
        (int)$route['km'] <= 0
    ) {
        $route['km'] = 1;
    }

    if (
        !isset($route['base']) ||
        (int)$route['base'] <= 0
    ) {
        $route['base'] = 1;
    }
}

unset($route);


/*
|--------------------------------------------------------------------------
| GLOBAL SOURCE OF TRUTH
|--------------------------------------------------------------------------
*/

$GLOBALS['FLEET']  = $FLEET;
$GLOBALS['ROUTES'] = $ROUTES;


/*
|--------------------------------------------------------------------------
| BACKWARD COMPATIBILITY
|--------------------------------------------------------------------------
*/

$FLEET  = $GLOBALS['FLEET'];
$ROUTES = $GLOBALS['ROUTES'];