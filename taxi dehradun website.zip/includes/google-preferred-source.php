<?php
/**
 * Google "Add as Preferred Source" — OFFICIAL implementation
 * - Publisher JS: ek baar per page (footer se, async, non-blocking)
 * - Button: <div google-add-preferred-source-btn></div> (official, custom/fake nahi)
 * - Neutral label: "Follow Taxi Dehradun on Google"
 * - SEO-safe: koi title/meta/canonical/schema/robots change nahi
 */

if (!function_exists('gps_render_script')) {
    function gps_render_script() {
        echo '<script async src="https://news.google.com/swg/js/v1/publisher.js"></script>' . "\n";
    }
}

if (!function_exists('gps_render_button')) {
    function gps_render_button() {
        ?>
<style>
.gps-band{position:relative;z-index:1;max-width:1180px;margin:0 auto 26px;padding:0 22px}
.gps-in{display:flex;align-items:center;gap:16px;flex-wrap:wrap;background:#fff;border:1px solid #e3eaf8;border-radius:18px;padding:16px 20px;box-shadow:0 10px 30px -18px rgba(9,32,84,.25)}
.gps-g{flex:none;width:44px;height:44px;border-radius:12px;display:grid;place-items:center;background:#f5f8ff}
.gps-txt{flex:1 1 240px}
.gps-txt b{display:block;font-family:'Sora','Plus Jakarta Sans',sans-serif;font-size:1rem;color:#0a1633}
.gps-txt small{display:block;color:#5b6b8c;font-size:.8rem;margin-top:2px}
.gps-btnwrap{margin-left:auto}
@media(max-width:560px){.gps-btnwrap{margin-left:0;width:100%}.gps-btnwrap>div{width:100%}}
</style>
<div class="gps-band" role="complementary" aria-label="Follow Taxi Dehradun on Google">
  <div class="gps-in">
    <span class="gps-g" aria-hidden="true">
      <svg width="26" height="26" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.11-10.36 7.11-17.63z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 17.37 0 21.12 0 24c0 2.88.92 5.63 2.55 8.78l7.98-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
    </span>
    <div class="gps-txt">
      <b>Follow Taxi Dehradun on Google</b>
      <small>Add us as a preferred source — latest fares, route guides &amp; yatra updates first.</small>
    </div>
    <div class="gps-btnwrap"><div google-add-preferred-source-btn></div></div>
  </div>
</div>
        <?php
    }
}