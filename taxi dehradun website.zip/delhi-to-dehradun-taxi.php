﻿<?php
require_once __DIR__ . '/includes/config.php';
$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';
$page_title = "Delhi to Dehradun Taxi | Airport Pickup Cab - Anaya Cab";
$page_description = 'Delhi to Dehradun taxi from ₹3,500 – IGI T1/T2/T3 & NCR doorstep pickup, Delhi–Dehradun Expressway route (250 km, 5 hr).';
$page_url         = $domain . "/delhi-to-dehradun-taxi";
$__faqs = [
["What is the taxi fare from Delhi to Dehradun?", "One-way sedan fare from Delhi to Dehradun starts at ₹4,500 for a Dzire, ₹5,500 for an Ertiga (SUV) and ₹6,500 for an Innova Crysta. IGI Airport pickups start at ₹4,800. All fares are fixed and confirmed before pickup."],
["Do you pick up from IGI Airport terminals?", "Yes. We pick up from Terminal 1, 2 and 3 with a driver holding a name board at arrivals. Share your flight number and the driver tracks delays, so a late flight never means a missed cab."],
["How long does Delhi to Dehradun take by taxi?", "The drive is about 250 km via NH 334 / Delhi-Dehradun Expressway and takes around 4.5 to 5.5 hours depending on the Delhi exit point and traffic at the city side."],
["Can I book a one-way cab from Delhi to Dehradun?", "Yes. One-way bookings are the default for this route — you pay only for your side of the journey, with no return fare added. Round trips with a halt in Dehradun are also available."],
["Are toll taxes included in the fare?", "The quoted fare covers fuel, driver allowance and vehicle rental. Expressway tolls and FASTag charges are extra as per actual receipts, and are spelled out in your quote before pickup."],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Delhi to Dehradun Taxi Service','serviceType'=>'Outstation intercity cab transfer with airport pickup','description'=>'One-way taxi from Delhi and IGI Airport to Dehradun over 250 km via Delhi-Dehradun Expressway with flight tracking, name-board pickup and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Delhi'],['@type'=>'City','name'=>'Gurgaon'],['@type'=>'City','name'=>'Noida'],['@type'=>'City','name'=>'Dehradun']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'4500','description'=>'One way sedan taxi fare from Delhi to Dehradun starts from 4,500 rupees.']],
['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';
require_once __DIR__ . '/includes/header.php';
$__fares = [
['Delhi City / Connaught Place → Dehradun','~250 km','4,500','5,500','6,500','/dehradun-to-delhi-taxi'],
['IGI Airport (T3 / T1) → Dehradun','~265 km','4,800','5,800','6,800','/dehradun-airport-taxi-service'],
['Gurgaon / Cyber City → Dehradun','~280 km','5,000','6,000','7,000','/dehradun-to-gurgaon-taxi'],
['Noida / Greater Noida → Dehradun','~260 km','4,600','5,600','6,600','/dehradun-to-noida-taxi'],
];
$__sights = [
['IGI Terminal 3','fa-plane-arrival','Name-board meet at international and domestic arrivals, with flight tracking for delayed landings.'],
['IGI Terminal 1 & 2','fa-plane','Domestic pickup with a calm waiting plan and luggage help to the car.'],
['New Delhi Railway Station','fa-train','On-time pickup at NDLS and Old Delhi for the expressway run to Dehradun.'],
['Gurgaon & Noida','fa-city','Door pickup from sectors, offices and hotels across Delhi NCR.'],
];
$__related = [
['Dehradun → Delhi','/dehradun-to-delhi-taxi','fa-rotate'],['Delhi → Mussoorie','/delhi-to-mussoorie-taxi','fa-mountain-sun'],
['Delhi → Haridwar','/delhi-to-haridwar-taxi','fa-om'],['Delhi → Rishikesh','/delhi-to-rishikesh-taxi','fa-water'],
['Jolly Grant Airport','/dehradun-airport-taxi-service','fa-plane-departure'],['Dehradun → Chandigarh','/dehradun-to-chandigarh-taxi','fa-road'],
];
?>
<main id="main">
<style>
.dl{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 440px)}
.dl *{box-sizing:border-box}
.dl::before{content:"";position:absolute;top:-180px;left:-120px;width:580px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.12),transparent 70%);pointer-events:none}
.dl .dl-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.dl .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.dl .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.dl .rv.in{opacity:1;transform:none}
.dl .dl-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.dl .dl-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.dl .dl-crumb a:hover{color:var(--blue)}
.dl .dl-crumb i{font-size:.6rem;color:var(--mute)}.dl .dl-crumb .cur{color:var(--ink);font-weight:600}
.dl .dl-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.dl .dl-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.dl .dl-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.dl .dl-hero h1 em{font-style:normal;color:var(--blue)}
.dl .dl-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.dl .dl-lead strong{color:var(--ink)}
.dl .dl-metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.dl .dl-m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.dl .dl-m i{color:var(--blue)}.dl .dl-m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.dl .dl-m span{font-size:.8rem;color:var(--slate)}
.dl .dl-herocta{display:flex;gap:12px;flex-wrap:wrap}
.dl .dl-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.dl .dl-btn-p{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.dl .dl-btn-p:hover{transform:translateY(-2px);filter:brightness(1.08)}
.dl .dl-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.dl .dl-btn-g:hover{transform:translateY(-2px)}
.dl .dl-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.dl .dl-btn-o:hover{border-color:var(--blue);color:var(--blue)}
.dl .dl-card{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,87,255,.5);overflow:hidden}
.dl .dl-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.dl .dl-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px;position:relative}
.dl .dl-fares{display:grid;gap:8px;margin:14px 0 0;position:relative}
.dl .dl-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.dl .dl-fr .v{font-weight:700;font-size:.9rem}
.dl .dl-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.dl .dl-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}
.dl .dl-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s,filter .2s}
.dl .dl-card .cta .w{background:#fff;color:var(--blue)}.dl .dl-card .cta .g{background:#25d366;color:#04260f}
.dl .dl-card .cta a:hover{transform:translateY(-2px)}
.dl .dl-card .note{font-size:.76rem;color:rgba(255,255,255,.66);text-align:center;margin:12px 0 0;position:relative}
.dl .dl-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.dl .dl-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.dl .dl-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.dl .dl-qa strong{color:var(--ink)}
.dl .dl-sec{padding:48px 0}
.dl .dl-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.dl .dl-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.dl .dl-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.dl .dl-sh p{color:var(--slate);margin:0}
.dl .dl-sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.dl .dl-sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px;transition:transform .3s,box-shadow .3s,border-color .3s}
.dl .dl-sitem:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#bfe6e0}
.dl .dl-sico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.dl .dl-sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}
.dl .dl-sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.dl .dl-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.dl .dl-tscroll{overflow-x:auto}
.dl table{width:100%;border-collapse:collapse;min-width:560px}
.dl th,.dl td{padding:15px 18px;text-align:left;font-size:.92rem}
.dl thead th{background:var(--soft);color:var(--blue-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.dl tbody tr{border-top:1px solid var(--line);transition:background .2s}.dl tbody tr:hover{background:var(--soft)}
.dl .dl-rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.dl .dl-rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.dl .dl-rchip i{color:var(--blue)}.dl .dl-rchip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}
.dl .dl-fbox{max-width:820px;margin:0 auto}
.dl .dl-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.dl .dl-fi:hover{border-color:#bfe6e0}
.dl .dl-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.dl .dl-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.dl .dl-fi.open .dl-ft{transform:rotate(45deg)}
.dl .dl-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.dl .dl-fi.open .dl-fb{max-height:380px;padding:0 20px 18px}
.dl .dl-soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.dl .dl-cta{padding:0 0 70px}
.dl .dl-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0057ff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.dl .dl-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.dl .dl-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.dl .dl-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.dl .dl-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.dl .dl-cta .w{background:#fff;color:var(--blue)}.dl .dl-cta .g{background:#25d366;color:#04260f}.dl .dl-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.dl .dl-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.dl .dl-hero{grid-template-columns:1fr;gap:24px}.dl .dl-card{position:static}}
@media(prefers-reduced-motion:reduce){.dl *{transition:none!important;animation:none!important}.dl .rv{opacity:1!important;transform:none!important}}
</style>
<div class="dl">
<div class="dl-in">
<nav class="dl-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Delhi to Dehradun Taxi</span></nav>
<section class="dl-hero">
<div class="rv">
<span class="dl-eyebrow"><i class="fa-solid fa-plane-arrival"></i> IGI Airport pickup · Expressway · 250 km</span>
<h1 class="disp">Delhi to Dehradun <em>taxi</em> — IGI Airport pickup &amp; one way cab</h1>
<p class="dl-lead"><strong>Delhi to Dehradun taxi fare starts from ₹4,500 for a sedan</strong> (₹4,800 from IGI Airport). Anaya Cab Service picks you up from any Delhi NCR address or IGI Terminal 1/2/3 with a name board and flight tracking, then runs you home via the Delhi-Dehradun Expressway with verified drivers and fixed fares.</p>
<div class="dl-metrics">
<span class="dl-m"><i class="fa-solid fa-road"></i> <b>250 km</b> <span>distance</span></span>
<span class="dl-m"><i class="fa-regular fa-clock"></i> <b>4.5–5 hr</b> <span>drive time</span></span>
<span class="dl-m"><i class="fa-solid fa-plane-arrival"></i> <b>T1/T2/T3</b> <span>airport pickup</span></span>
<span class="dl-m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹4,500+</b> <span>sedan</span></span>
</div>
<div class="dl-herocta">
<a class="dl-btn dl-btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book pickup cab</a>
<a class="dl-btn dl-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Delhi to Dehradun taxi with airport pickup.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="dl-btn dl-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="dl-card rv" aria-label="Delhi to Dehradun fare">
<span class="tag"><i class="fa-solid fa-plane-arrival"></i> Pickup fare</span>
<h3 class="disp">Delhi NCR → Dehradun</h3>
<div class="dl-fares">
<div class="dl-fr"><span class="v">Sedan (Dzire)</span><span class="p">₹4,500</span></div>
<div class="dl-fr"><span class="v">SUV (Ertiga)</span><span class="p">₹5,500</span></div>
<div class="dl-fr"><span class="v">Innova Crysta</span><span class="p">₹6,500</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Delhi to Dehradun taxi with airport pickup.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way fare · flight tracking · 24×7</p>
</aside>
</section>
<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="dl-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> runs a daily <strong>Delhi to Dehradun taxi</strong> (~250 km via Expressway, 4.5–5 hours) with one-way fares starting at <strong>₹4,500 for Sedan</strong>, <strong>₹5,500 for SUV</strong> and <strong>₹6,500 for Innova Crysta</strong>. IGI Airport pickups (T1/T2/T3) start at <strong>₹4,800</strong> with a name-board meet and flight tracking, available 24×7.</p>
</div>
</div>
<!-- FARES -->
<section class="dl-sec rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Delhi to Dehradun taxi fares by pickup point</h2></div>
<div class="dl-twrap"><div class="dl-tscroll">
<table aria-label="Delhi to Dehradun taxi fares">
<thead><tr><th>Pickup point</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</div></section>
<!-- PICKUPS -->
<section class="dl-sec dl-soft rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-plane-arrival"></i> Pickup points</span><h2 class="disp">Where we pick you up in Delhi NCR</h2></div>
<div class="dl-sgrid">
<?php foreach ($__sights as $s): ?>
<div class="dl-sitem rv"><span class="dl-sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- RELATED -->
<section class="dl-sec rv"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes on this corridor</h2></div>
<div class="dl-rchips">
<?php foreach ($__related as $r): ?>
<a class="dl-rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</div></section>
<!-- FAQ -->
<section class="dl-sec dl-soft rv" id="faq"><div class="dl-in">
<div class="dl-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Delhi to Dehradun taxi — FAQs</h2></div>
<div class="dl-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="dl-fi<?php echo $i===0?' open':''; ?>"><div class="dl-fh"><?php echo htmlspecialchars($f[0]); ?><span class="dl-ft"><i class="fa-solid fa-plus"></i></span></div><div class="dl-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>
<!-- CTA -->
<section class="dl-cta rv"><div class="dl-in">
<div class="dl-ctain">
<h2 class="disp">Landing in Delhi? Your cab to Dehradun is sorted.</h2>
<p>Share your flight number or pickup address — we confirm a fixed fare and your driver waits at arrivals.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book pickup cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Delhi to Dehradun taxi with airport pickup.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.dl .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.dl .dl-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>