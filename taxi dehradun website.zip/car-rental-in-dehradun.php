﻿<?php
require_once __DIR__ . '/includes/config.php';
$page_title = 'Car Rental in Dehradun with Driver | From ₹12/km';
$page_description = 'Chauffeur-driven car rental in Dehradun from ₹12/km — airport transfers, hourly packages, outstation & Char Dham trips. Fixed fares.';
$page_url         = SITE_DOMAIN . "/car-rental-in-dehradun";
$__faqs = [
['Do you provide self-drive car rental in Dehradun?', 'No, Anaya Cab Service provides chauffeur-driven car rental only, with a professional verified driver included in every booking for local, airport and outstation travel.'],
['What is the starting rate for car rental with driver?', 'Chauffeur-driven car rental in Dehradun starts from around 12 to 16 rupees per kilometre for a hatchback or sedan, with higher per-km rates for Ertiga, Innova and group vehicles.'],
['Can I hire a car for multiple days or a yatra?', 'Yes, multi-day car hire is available for Uttarakhand tours, Char Dham Yatra, business trips, weddings and family holidays, billed per day plus running kilometres.'],
['Which cars are available for rental?', 'Available vehicles include Wagon R, Dzire, Etios, Ertiga, Innova, Innova Crysta, Tempo Traveller and Force Urbania, assigned as per route, group size and luggage.'],
['Is the fare confirmed before the trip?', 'Yes, the fare or per-km rate is shared and confirmed before you book, with tolls, parking and any night halt charges explained upfront so there are no surprises.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Car Rental in Dehradun with Driver','serviceType'=>'Chauffeur-driven car rental and cab hire with driver','description'=>'Car rental in Dehradun with a verified professional driver for local rides, hourly packages, airport transfers, outstation trips and Char Dham Yatra. Chauffeur-driven only, not self-drive.','provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'AdministrativeArea','name'=>'Uttarakhand'],['@type'=>'City','name'=>'Mussoorie'],['@type'=>'City','name'=>'Rishikesh'],['@type'=>'City','name'=>'Haridwar'],['@type'=>'City','name'=>'Delhi']],'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'12','description'=>'Chauffeur-driven car rental in Dehradun starts from 12 rupees per kilometre for a hatchback or sedan.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$__rate = [
['Hatchback / Sedan','fa-car','Local rides, airport, short outstation','₹12 – ₹16 / km'],
['Ertiga / SUV','fa-truck-monster','Family trips and luggage comfort','₹16 – ₹19 / km'],
['Innova / Crysta','fa-van-shuttle','Hill routes and premium comfort','₹18 – ₹22 / km'],
['Tempo Traveller / Urbania','fa-bus-simple','Group tours and pilgrimage','On request'],
];
$__use = [
['big','fa-calendar-days','Multi-day tours & yatra','Keep the same car and verified driver for Char Dham, Do Dham, Kumaon and Garhwal circuits, billed per day plus running kilometres so the vehicle is always with you exactly when you need it on long mountain days.'],
['fa-hourglass-half','Hourly city errands','Meetings, shopping and local errands on a 4 or 8 hour package.'],
['fa-plane-departure','Airport transfers','Jolly Grant pickup and drop with flight tracking.'],
['fa-route','One-way outstation','Direct drops to Haridwar, Rishikesh, Delhi and beyond.'],
['fa-people-group','Weddings & corporate','Tempo Traveller and Urbania for groups and events.'],
];
$__dedicated = [
['Local taxi','/local-taxi-in-dehradun','fa-taxi'],['Airport taxi','/dehradun-airport-taxi-service','fa-plane-departure'],
['Outstation taxi','/outstation-taxi-from-dehradun','fa-route'],['Innova taxi','/innova-taxi-in-dehradun','fa-van-shuttle'],
['Tempo Traveller','/tempo-traveller-in-dehradun','fa-bus-simple'],
];
?>
<main id="main">
<style>
.rt{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--soft:#f5f8ff;--green:#16a34a;--radius:20px;--rsm:14px;--ac:#a16207;--ac2:#fcd34d;--acsoft:#f7edd6;--d1:#1c1407;--d2:#713f12;--bg1:#f6efe2;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,var(--bg1) 0%,#fff 440px)}
.rt *{box-sizing:border-box}
.rt::before{content:"";position:absolute;top:-200px;right:-120px;width:560px;height:440px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac) 14%,transparent),transparent 70%);pointer-events:none}
.rt .rt-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.rt .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.rt .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.rt .rv.in{opacity:1;transform:none}
.rt .rt-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.rt .rt-crumb a{color:var(--slate);text-decoration:none}.rt .rt-crumb a:hover{color:var(--ac)}.rt .rt-crumb i{font-size:.6rem;color:var(--mute)}.rt .rt-crumb .cur{color:var(--ink);font-weight:600}
.rt .rt-hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.rt .rt-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:var(--acsoft);padding:7px 13px;border-radius:999px}
.rt .rt-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.rt .rt-hero h1 em{font-style:normal;color:var(--ac)}
.rt .rt-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.rt .rt-lead strong{color:var(--ink)}
.rt .rt-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}.rt .rt-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.rt .rt-trust i{color:var(--green)}
.rt .rt-herocta{display:flex;gap:12px;flex-wrap:wrap}
.rt .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rsm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.rt .btn-a{background:var(--ac);color:#fff;box-shadow:0 16px 34px -14px color-mix(in srgb,var(--ac) 60%,transparent)}.rt .btn-a:hover{transform:translateY(-2px);filter:brightness(1.06)}
.rt .btn-g{background:#25d366;color:#04260f}.rt .btn-g:hover{transform:translateY(-2px)}
.rt .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.rt .btn-o:hover{border-color:var(--ac);color:var(--ac)}
.rt .rt-card{position:sticky;top:88px;background:linear-gradient(160deg,var(--d1),var(--d2));border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px color-mix(in srgb,var(--d1) 70%,transparent);overflow:hidden}
.rt .rt-card::before{content:"";position:absolute;top:-60px;right:-50px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--ac2) 30%,transparent),transparent 70%)}
.rt .rt-card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:var(--ac2);background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.rt .rt-card .tag .dot{width:7px;height:7px;border-radius:50%;background:var(--ac2);box-shadow:0 0 0 0 color-mix(in srgb,var(--ac2) 60%,transparent);animation:rtpl 1.8s infinite}
@keyframes rtpl{70%{box-shadow:0 0 0 7px color-mix(in srgb,var(--ac2) 0%,transparent)}100%{box-shadow:0 0 0 0 color-mix(in srgb,var(--ac2) 0%,transparent)}}
.rt .rt-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 4px;position:relative}
.rt .rt-card .sub{color:rgba(255,255,255,.78);font-size:.86rem;margin:0 0 14px;position:relative}
.rt .rt-anim{position:relative;height:64px;margin:0 0 8px}.rt .rt-anim .road{position:absolute;left:0;right:0;top:50%;height:4px;transform:translateY(-50%);background:repeating-linear-gradient(90deg,var(--ac2) 0 16px,transparent 16px 30px);border-radius:4px;opacity:.8}.rt .rt-anim .car{position:absolute;top:50%;left:6%;transform:translate(-50%,-50%);color:#fff;font-size:1.05rem;animation:rtdrv 4s ease-in-out infinite}
@keyframes rtdrv{0%,100%{left:6%}50%{left:88%}}
.rt .rt-fares{display:grid;gap:8px;position:relative}.rt .rt-fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}.rt .rt-fr .v{font-weight:700;font-size:.9rem}.rt .rt-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.rt .rt-card .cta{display:grid;gap:10px;margin-top:16px;position:relative}.rt .rt-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}.rt .rt-card .cta .w{background:#fff;color:var(--d1)}.rt .rt-card .cta .g{background:#25d366;color:#04260f}.rt .rt-card .cta a:hover{transform:translateY(-2px)}
.rt .rt-card .note{font-size:.76rem;color:rgba(255,255,255,.7);text-align:center;margin:12px 0 0;position:relative}
.rt .rt-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--ac);border-radius:16px;padding:20px 22px;box-shadow:0 18px 40px -26px rgba(9,32,84,.25)}.rt .rt-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin-bottom:8px}.rt .rt-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.rt .rt-qa strong{color:var(--ink)}
.rt .sec{padding:48px 0}
.rt .sh{text-align:center;max-width:680px;margin:0 auto 28px}.rt .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);background:var(--acsoft);padding:7px 13px;border-radius:999px}.rt .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.rt .sh p{color:var(--slate);margin:0}
.rt .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 24px 50px -30px rgba(9,32,84,.25);max-width:820px;margin:0 auto}.rt .tscr{overflow-x:auto}.rt table{width:100%;border-collapse:collapse;min-width:520px}.rt th,.rt td{padding:14px 18px;text-align:left;font-size:.92rem}.rt thead th{background:var(--soft);color:var(--ac);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}.rt tbody tr{border-top:1px solid var(--line);transition:background .2s}.rt tbody tr:hover{background:var(--soft)}.rt td .ic{color:var(--ac);margin-right:8px}
.rt .bento{display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:16px;grid-auto-flow:row dense}.rt .bv{position:relative;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:24px;overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}.rt .bv::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,var(--ac),var(--ac2));transform:scaleX(0);transform-origin:left;transition:transform .4s}.rt .bv:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3);border-color:color-mix(in srgb,var(--ac) 40%,var(--line))}.rt .bv:hover::after{transform:scaleX(1)}.rt .bv.big{grid-row:span 2;background:linear-gradient(155deg,var(--d1),var(--d2));color:#fff;border-color:transparent}.rt .bv.big::after{background:linear-gradient(90deg,var(--ac2),#fff)}.rt .bv .vi{width:50px;height:50px;border-radius:14px;background:var(--acsoft);color:var(--ac);display:grid;place-items:center;font-size:1.15rem;margin-bottom:14px;transition:transform .3s}.rt .bv.big .vi{background:rgba(255,255,255,.14);color:var(--ac2);width:56px;height:56px}.rt .bv:hover .vi{transform:scale(1.08) rotate(-5deg)}.rt .bv h3{font-family:'Sora','Poppins',sans-serif;font-size:1.06rem;font-weight:700;margin:0 0 6px}.rt .bv.big h3{font-size:1.4rem;color:#fff}.rt .bv p{margin:0;color:var(--slate);font-size:.9rem;line-height:1.58}.rt .bv.big p{color:rgba(255,255,255,.84);font-size:.98rem;line-height:1.66}
.rt .prose{max-width:840px;margin:24px auto 0}.rt .prose h2{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 10px}.rt .prose p{color:var(--slate);line-height:1.72;margin:0 0 12px;font-size:.96rem}.rt .prose strong{color:var(--ink)}
.rt .note-box{max-width:840px;margin:22px auto 0;background:var(--acsoft);border:1px solid color-mix(in srgb,var(--ac) 30%,var(--line));border-radius:16px;padding:18px 20px}.rt .note-box h3{font-family:'Sora','Poppins',sans-serif;font-size:1.05rem;font-weight:700;margin:0 0 6px;color:var(--ac)}.rt .note-box p{margin:0 0 12px;color:#33415c;font-size:.94rem;line-height:1.6}
.rt .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}.rt .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}.rt .rchip i{color:var(--ac)}.rt .rchip:hover{border-color:var(--ac);color:var(--ac);transform:translateY(-2px);box-shadow:0 12px 24px -14px color-mix(in srgb,var(--ac) 45%,transparent)}
.rt .fbox{max-width:820px;margin:0 auto}.rt .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.rt .fi:hover{border-color:color-mix(in srgb,var(--ac) 35%,var(--line))}.rt .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}.rt .ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--acsoft);color:var(--ac);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}.rt .fi.open .ft{transform:rotate(45deg)}.rt .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}.rt .fi.open .fb{max-height:400px;padding:0 20px 18px}
.rt .soft{background:linear-gradient(180deg,var(--bg1),#fff)}
.rt .cta2{padding:0 0 70px}.rt .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,var(--ac),transparent 55%),linear-gradient(120deg,var(--d1),var(--d2));color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}.rt .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}.rt .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}.rt .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.rt .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}.rt .cta2 .w{background:#fff;color:var(--d1)}.rt .cta2 .g{background:#25d366;color:#04260f}.rt .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.rt .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:900px){.rt .rt-hero{grid-template-columns:1fr;gap:24px}.rt .rt-card{position:static}.rt .bento{grid-template-columns:1fr 1fr}.rt .bv.big{grid-row:auto;grid-column:span 2}}
@media(max-width:560px){.rt .bento{grid-template-columns:1fr}.rt .bv.big{grid-column:auto}}
@media(prefers-reduced-motion:reduce){.rt *{transition:none!important;animation:none!important}.rt .rv{opacity:1!important;transform:none!important}}
</style>
<div class="rt"><div class="rt-in">
<nav class="rt-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Car Rental</span></nav>
<section class="rt-hero">
<div class="rv">
<span class="rt-ey"><i class="fa-solid fa-key"></i> Chauffeur-driven · with driver</span>
<h1 class="disp">Car rental in Dehradun <em>with driver</em> — your car, your schedule</h1>
<p class="rt-lead"><strong>Book car rental in Dehradun with a verified professional driver</strong> for local rides, hourly packages, Jolly Grant Airport transfers, outstation trips and the Char Dham Yatra. Anaya Cab Service gives you the comfort of your own car without the stress of driving — clean AC vehicles, transparent per-km rates and a driver who knows every Dehradun street and hill turn.</p>
<div class="rt-trust"><span><i class="fa-solid fa-circle-check"></i> Driver included</span><span><i class="fa-solid fa-circle-check"></i> From ₹12/km</span><span><i class="fa-solid fa-circle-check"></i> Local to yatra</span><span><i class="fa-solid fa-circle-check"></i> No self-drive</span></div>
<div class="rt-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-key"></i> Get rental quote</a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want car rental in Dehradun with driver.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> <?php echo BUSINESS_PHONE; ?></a>
</div>
</div>
<aside class="rt-card rv" aria-label="Car rental rates">
<span class="tag"><span class="dot"></span> Chauffeur included</span>
<h3 class="disp">Build your rental</h3>
<p class="sub">Pick a vehicle class — driver, fuel planning and support included.</p>
<div class="rt-anim" aria-hidden="true"><div class="road"></div><i class="fa-solid fa-car-side car"></i></div>
<div class="rt-fares">
<div class="rt-fr"><span class="v">Hatchback / Sedan</span><span class="p">₹12 – ₹16 / km</span></div>
<div class="rt-fr"><span class="v">Ertiga / SUV</span><span class="p">₹16 – ₹19 / km</span></div>
<div class="rt-fr"><span class="v">Innova / Crysta</span><span class="p">₹18 – ₹22 / km</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want car rental in Dehradun with driver.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp quote</a>
</div>
<p class="note">Per-km or per-day billing · final rate confirmed before booking</p>
</aside>
</section>
<div class="rt-qa rv"><div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> offers chauffeur-driven car rental in Dehradun from around ₹12/km for a hatchback or sedan, with a verified driver included for local rides, hourly packages, Jolly Grant Airport transfers, outstation drops and Char Dham Yatra. We provide car rental <strong>with driver only — not self-drive</strong> — and the rate is confirmed before you book.</p></div>
</div>

<section class="sec rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-gauge-high"></i> Rental rates</span><h2 class="disp">Car rental options by vehicle</h2><p>Indicative per-km rates with driver — exact fare shared before you confirm.</p></div>
<div class="twrap"><div class="tscr"><table aria-label="Car rental rates in Dehradun by vehicle">
<thead><tr><th>Vehicle type</th><th>Best for</th><th>Starting rate</th></tr></thead>
<tbody><?php foreach ($__rate as $r): ?><tr><td><i class="fa-solid <?php echo $r[1]; ?> ic"></i><strong><?php echo $r[0]; ?></strong></td><td><?php echo $r[2]; ?></td><td><strong><?php echo $r[3]; ?></strong></td></tr><?php endforeach; ?></tbody>
</table></div></div>
</div></section>

<section class="sec soft rv"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-solid fa-route"></i> Use cases</span><h2 class="disp">One rental, every kind of trip</h2><p>From a quick city errand to a ten-day yatra — the same trusted car and driver.</p></div>
<div class="bento"><?php foreach ($__use as $u): $big=($u[0]==='big'); $ic=$big?$u[1]:$u[0]; $ti=$big?$u[2]:$u[1]; $de=$big?$u[3]:$u[2]; ?>
<div class="bv rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $ic; ?>"></i></div><h3><?php echo $ti; ?></h3><p><?php echo $de; ?></p></div>
<?php endforeach; ?></div>
</div></section>

<section class="sec rv"><div class="rt-in">
<div class="note-box rv">
<h3><i class="fa-solid fa-circle-info"></i> Chauffeur-driven, not self-drive</h3>
<p>Anaya Cab Service provides car rental <strong>with a professional driver</strong>, not bare self-drive cars. This keeps every trip insured, coordinated and stress-free — especially on Uttarakhand hill and pilgrimage roads where an experienced local driver matters most.</p>
<p>If you already know your exact need, a dedicated page will get you there faster:</p>
<div class="rchips" style="justify-content:flex-start;margin-top:4px"><?php foreach ($__dedicated as $d): ?><a class="rchip" href="<?php echo $d[1]; ?>"><i class="fa-solid <?php echo $d[2]; ?>"></i> <?php echo $d[0]; ?></a><?php endforeach; ?></div>
</div>
<div class="prose">
<h2>How car rental pricing works in Dehradun</h2>
<p>For <strong>local and point-to-point trips</strong>, car rental with driver is usually billed per kilometre as per the vehicle class, with a minimum for short city rides. For <strong>full-day or hourly use</strong>, the 4 hour / 40 km and 8 hour / 80 km packages are often the simplest choice for errands, meetings and sightseeing. For <strong>outstation and multi-day travel</strong>, pricing moves to a per-day rate plus running kilometres, which is ideal when the car stays with you across a yatra or a family holiday.</p>
<p>In every case the rate is <strong>shared and confirmed before you book</strong>, and tolls, parking, state permits and any night-halt or waiting charges are explained upfront. There is no advance on most bookings, and the same verified driver who picks you up stays with you for the duration you choose — so whether it is a two-hour airport run or a twelve-day Char Dham circuit, you travel with one reliable, accountable team.</p>
</div>
</div></section>

<section class="sec soft rv" id="faq"><div class="rt-in">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Car rental in Dehradun — FAQs</h2></div>
<div class="fbox"><?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo $f[0]; ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo $f[1]; ?></p></div></div>
<?php endforeach; ?></div>
</div></section>

<section class="cta2 rv"><div class="rt-in"><div class="ctain">
<h2 class="disp">Need a car with driver in Dehradun?</h2>
<p>Share route, date, passengers and vehicle class — we confirm a transparent rate on WhatsApp.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-key"></i> Get rental quote</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want car rental in Dehradun with driver.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div></main>
<script>
(function(){var r=document.querySelectorAll('.rt .rv');if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.rt .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>