<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Auli Taxi | Sedan from ₹6,500';
$page_description = 'Dehradun to Auli taxi: 300 km, sedan ₹6,500, Ertiga ₹7,500, Crysta ₹8,500. Joshimath & ski-resort drops, snow-chain drivers.';
$page_url         = $domain . "/dehradun-to-auli-taxi";

$__faqs = [
["How far is Auli from Dehradun by taxi?", "Auli is approximately 300 km from Dehradun via Rishikesh, Devprayag, and Joshimath, taking around 9 to 10 hours of mountain highway drive."],
["What is the taxi fare from Dehradun to Auli / Joshimath?", "One-way sedan taxi fare from Dehradun to Joshimath/Auli starts at ₹6,500 for a Dzire, ₹7,500 for an Ertiga (SUV), and ₹8,500 for an Innova Crysta."],
["Is snow chain vehicle required for Auli in winter?", "During peak snowfall months (Jan-Feb), vehicles drop at Joshimath or use snow chains for the upper 12 km Joshimath-Auli road. Auli ropeway is also available."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Auli Taxi Service','serviceType'=>'Outstation mountain ski resort taxi','description'=>'One-way and round-trip taxi from Dehradun to Joshimath and Auli Ski Resort over 300 km with verified hill drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Joshimath'],['@type'=>'City','name'=>'Auli']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'6500','description'=>'One way sedan taxi fare from Dehradun to Auli starts from 6,500 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Joshimath / Auli Base','~295 km','6,500','7,500','8,500','/dehradun-to-auli-taxi'],
['Dehradun → Auli Ski Resort Top','~305 km','6,800','7,800','8,800','/dehradun-to-auli-taxi'],
['Dehradun → Pipalkoti / Chamoli','~250 km','5,800','6,800','7,800','/dehradun-to-auli-taxi'],
];

$__sights = [
['Auli Ski Resort & Artificial Lake','fa-snowflake','Premier skiing slopes with Nanda Devi peak views.'],
['Joshimath & Ropeway Station','fa-cable-car','Base town for Auli cable car and Badrinath route.'],
['Narsingh Temple & Shankracharya Math','fa-om','Spiritual heritage sites in Joshimath.'],
['Gurso Bugyal','fa-mountain','Scenic high-altitude meadow trek near Auli.'],
];

$__related = [
['Dehradun → Badrinath','/dehradun-to-badrinath-taxi','fa-om'],['Dehradun → Chopta','/dehradun-to-chopta-taxi','fa-mountain'],
['Dehradun → Nainital','/dehradun-to-nainital-taxi','fa-mountain-sun'],['Dehradun → Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],
];
?>
<main id="main">
<style>
.au{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 440px)}
.au *{box-sizing:border-box}
.au .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.au .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.au .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.au .rv.in{opacity:1;transform:none}
.au .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.au .crumb a{color:var(--slate);text-decoration:none}.au .crumb a:hover{color:var(--blue)}.au .crumb i{font-size:.6rem;color:var(--mute)}.au .crumb .cur{color:var(--ink);font-weight:600}
.au .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.au .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.au .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.au .hero h1 em{font-style:normal;color:var(--blue)}
.au .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.au .lead strong{color:var(--ink)}
.au .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.au .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.au .m i{color:var(--blue)}.au .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.au .m span{font-size:.8rem;color:var(--slate)}
.au .herocta{display:flex;gap:12px;flex-wrap:wrap}
.au .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.au .btn-p{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.au .btn-p:hover{transform:translateY(-2px)}
.au .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.au .btn-g:hover{transform:translateY(-2px)}
.au .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.au .btn-o:hover{border-color:var(--blue);color:var(--blue)}
.au .card{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,87,255,.5);overflow:hidden}
.au .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.au .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.au .fares{display:grid;gap:8px;margin:14px 0 0}
.au .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.au .fr .v{font-weight:700;font-size:.9rem}.au .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.au .card .cta{display:grid;gap:10px;margin-top:16px}
.au .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.au .card .cta .w{background:#fff;color:var(--blue)}.au .card .cta .g{background:#25d366;color:#04260f}
.au .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.au .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.au .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.au .qa strong{color:var(--ink)}
.au .sec{padding:48px 0}
.au .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.au .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.au .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.au .sh p{color:var(--slate);margin:0}
.au .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.au .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.au .sico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.au .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.au .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.au .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.au .tscroll{overflow-x:auto}
.au table{width:100%;border-collapse:collapse;min-width:560px}
.au th,.au td{padding:15px 18px;text-align:left;font-size:.92rem}
.au thead th{background:var(--soft);color:var(--blue);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.au tbody tr{border-top:1px solid var(--line)}
.au .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.au .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.au .rchip i{color:var(--blue)}.au .rchip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px)}
.au .fbox{max-width:820px;margin:0 auto}
.au .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.au .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.au .ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.au .fi.open .ft{transform:rotate(45deg)}
.au .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.au .fi.open .fb{max-height:380px;padding:0 20px 18px}
.au .soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.au .cta{padding:0 0 70px}
.au .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0057ff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px}
.au .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.au .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.au .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.au .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.au .cta .w{background:#fff;color:var(--blue)}.au .cta .g{background:#25d366;color:#04260f}.au .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.au .hero{grid-template-columns:1fr;gap:24px}.au .card{position:static}}
</style>

<div class="au">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Auli Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-snowflake"></i> Ski Resort · 300 km</span>
<h1 class="disp">Dehradun to Auli <em>taxi service</em> — Ski Resort Drops</h1>
<p class="lead"><strong>Dehradun to Auli taxi fare starts from ₹6,500 for a sedan.</strong> Anaya Cab Service offers mountain transfers to Joshimath and Auli Ski Resort with verified hill drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>300 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>9–10 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-mountain"></i> <b>~2,800 m</b> <span>altitude</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹6,500+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Auli cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Auli taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Auli fare">
<span class="tag"><i class="fa-solid fa-snowflake"></i> Mountain fare</span>
<h3 class="disp">Dehradun → Auli</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹6,500</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹7,500</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹8,500</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Auli taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> operates daily <strong>Dehradun to Auli taxi service</strong> (~300 km, 9.5 hours drive via Joshimath) with fixed fares starting at <strong>₹6,500 for Sedan</strong> (Dzire), <strong>₹7,500 for SUV</strong> (Ertiga), and <strong>₹8,500 for Innova Crysta</strong>. Direct drops to Joshimath, Auli ropeway station, and skiing resorts.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Auli taxi fares by destination</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Auli taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Auli / Joshimath</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Auli taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Auli Ski Resort? Book your cab now</h2>
<p>Fixed fare, verified hill driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-snowflake"></i> Book Auli cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Auli taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.au .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.au .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

