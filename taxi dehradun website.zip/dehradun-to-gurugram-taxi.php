<?php
/**
 * Anaya Cab Service — 301 Permanent Redirect.
 * "Gurugram" = "Gurgaon" same city; duplicate page consolidate kiya.
 */
require_once __DIR__ . '/includes/config.php';
$d = rtrim(SITE_DOMAIN, '/');
header('Location: ' . $d . '/dehradun-to-gurgaon-taxi', true, 301);
header('Cache-Control: max-age=3600');
exit;