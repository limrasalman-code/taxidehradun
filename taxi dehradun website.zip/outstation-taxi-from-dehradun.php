﻿<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Outstation Taxi from Dehradun | One Way Cabs';
$page_description = 'Outstation taxi from Dehradun: one-way & round trips to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital & Char Dham. Sedan from ₹1,000.';
$page_url         = $domain . "/outstation-taxi-from-dehradun";

$__faqs = [
["Do you provide one way outstation taxi from Dehradun?", "Yes. One way outstation taxi is available from Dehradun to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital, Chandigarh and many more destinations, so you pay only for the drop side."],
["Can I book a round trip cab from Dehradun?", "Yes. Round trip and multi day taxi bookings are available with the same driver and vehicle, which is usually more economical when you need the cab for the return journey too."],
["Which vehicles are available for outstation trips?", "Sedan, Ertiga, Innova, Innova Crysta, Tempo Traveller and Force Urbania options are available depending on group size, luggage and route, including hill and yatra roads."],
["How are outstation taxi fares calculated?", "One way drops are charged for a single direction, round trips keep the car with you for both sides, and multi day tours are billed per day plus running kilometres. The final fare is fixed and shared before you confirm."],
["Do outstation fares include tolls and parking?", "The quoted fare covers fuel, driver allowance and the vehicle for the agreed route. Tolls, parking, state permits and any night halt or waiting charges are extra where applicable and are shared upfront."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Outstation Taxi from Dehradun','serviceType'=>'Outstation taxi and intercity cab service','description'=>'One-way, round-trip and multi-day outstation taxi from Dehradun to Uttarakhand and North India with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Haridwar'],['@type'=>'City','name'=>'Rishikesh'],['@type'=>'City','name'=>'Mussoorie'],['@type'=>'City','name'=>'Delhi'],['@type'=>'City','name'=>'Nainital'],['@type'=>'City','name'=>'Chandigarh'],['@type'=>'AdministrativeArea','name'=>'Uttarakhand']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'1000','description'=>'Popular one-way outstation taxi fares from Dehradun start from 1000 rupees depending on route and vehicle.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Haridwar','~55 km','1,350','1,800','2,200','/dehradun-to-haridwar-taxi'],
['Dehradun → Rishikesh','~45 km','1,000','1,400','1,800','/dehradun-to-rishikesh-taxi'],
['Dehradun → Mussoorie','~35 km','1,200','1,600','2,000','/dehradun-to-mussoorie-taxi'],
['Dehradun → Delhi','~250 km','3,500','4,200','5,500','/dehradun-to-delhi-taxi'],
['Dehradun → Nainital','~270 km','5,500','6,500','7,500','/dehradun-to-nainital-taxi'],
['Dehradun → Chandigarh','~210 km','4,000','5,000','6,000','/dehradun-to-chandigarh-taxi'],
];

$__circuits = [
['Char Dham Yatra','10–12 days','Yamunotri, Gangotri, Kedarnath, Badrinath','/char-dham-yatra-taxi','fa-om'],
['Do Dham','5–7 days','Kedarnath and Badrinath for shorter schedules','/do-dham-yatra-taxi','fa-om'],
['Kumaon circuit','3–5 days','Nainital, Jim Corbett, Bhimtal and lakes','/dehradun-to-nainital-taxi','fa-mountain'],
['Garhwal hills','2–4 days','Mussoorie, Dhanaulti, Chakrata, Kanatal, Auli','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],
];

$__routes = [
['Haridwar','/dehradun-to-haridwar-taxi','fa-om'],['Rishikesh','/dehradun-to-rishikesh-taxi','fa-water'],
['Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],['Delhi','/dehradun-to-delhi-taxi','fa-road'],
['Nainital','/dehradun-to-nainital-taxi','fa-mountain'],['Chandigarh','/dehradun-to-chandigarh-taxi','fa-road'],
['Kedarnath','/dehradun-to-kedarnath-taxi','fa-om'],['Badrinath','/dehradun-to-badrinath-taxi','fa-om'],
['Jim Corbett','/dehradun-to-jim-corbett-taxi','fa-tree'],['Shimla','/dehradun-to-shimla-taxi','fa-mountain'],
];
?>
<main id="main">
<style>
.os{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-700:#0039ad;--blue-tint:#eaf1ff;--soft:#f5f8ff;--green:#16a34a;--teal:#0891b2;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 420px)}
.os *{box-sizing:border-box}
.os::before{content:"";position:absolute;top:-180px;right:-120px;width:560px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(8,145,178,.10),transparent 70%);pointer-events:none}
.os::after{content:"";position:absolute;top:320px;left:-160px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.08),transparent 70%);pointer-events:none}
.os .os-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.os .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.os .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.os .rv.in{opacity:1;transform:none}
.os .os-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}
.os .os-crumb a{color:var(--slate);text-decoration:none;transition:color .2s}.os .os-crumb a:hover{color:var(--blue)}
.os .os-crumb i{font-size:.6rem;color:var(--mute)}.os .os-crumb .cur{color:var(--ink);font-weight:600}
.os .os-hero{display:grid;grid-template-columns:1.25fr .95fr;gap:34px;align-items:start;padding:24px 0 10px}
.os .os-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.os .os-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}
.os .os-hero h1 em{font-style:normal;color:var(--blue)}
.os .os-lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.os .os-lead strong{color:var(--ink)}
.os .os-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}
.os .os-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.os .os-trust i{color:var(--green)}
.os .os-herocta{display:flex;gap:12px;flex-wrap:wrap}
.os .os-btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.os .os-btn-b{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.os .os-btn-b:hover{transform:translateY(-2px);filter:brightness(1.05)}
.os .os-btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.os .os-btn-g:hover{transform:translateY(-2px)}
.os .os-btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.os .os-btn-o:hover{border-color:var(--blue);color:var(--blue)}
/* trip-type asymmetric panel */
.os .os-trip{position:sticky;top:88px;display:grid;grid-template-rows:auto auto;gap:12px}
.os .os-tbig{position:relative;overflow:hidden;background:linear-gradient(150deg,#03102e,#0a2a63);border-radius:22px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(9,32,84,.5)}
.os .os-tbig::before{content:"";position:absolute;inset:0;background:radial-gradient(120% 80% at 100% 0%,rgba(34,201,232,.28),transparent 60%)}
.os .os-tbig .tag{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:#9fe6ff;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px;position:relative}
.os .os-tbig h3{font-family:'Sora','Poppins',sans-serif;font-size:1.4rem;font-weight:800;margin:12px 0 6px;position:relative}
.os .os-tbig p{color:rgba(255,255,255,.8);font-size:.9rem;margin:0 0 16px;position:relative}
.os .os-road{height:3px;background:repeating-linear-gradient(90deg,#22c9e8 0 10px,transparent 10px 20px);position:relative;margin:0 0 16px;border-radius:3px}
.os .os-road i{position:absolute;top:50%;left:8%;transform:translate(-50%,-50%);color:#fff;font-size:.95rem;animation:osdrv 3.4s ease-in-out infinite}
@keyframes osdrv{0%,100%{left:8%}50%{left:92%}}
.os .os-tbig a{display:inline-flex;align-items:center;gap:9px;background:#fff;color:#0057ff;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.88rem;padding:11px 18px;border-radius:12px;text-decoration:none;position:relative;transition:transform .2s}.os .os-tbig a:hover{transform:translateY(-2px)}
.os .os-trow2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.os .os-tsmall{position:relative;background:#fff;border:1px solid var(--line);border-radius:18px;padding:18px;overflow:hidden;transition:transform .3s,box-shadow .3s,border-color .3s}
.os .os-tsmall:hover{transform:translateY(-4px);box-shadow:0 18px 40px -24px rgba(9,32,84,.3);border-color:#cfe0ff}
.os .os-tsmall .ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:1rem;margin-bottom:10px}
.os .os-tsmall.r .ic{background:#e7f8ef;color:var(--green)}.os .os-tsmall.m .ic{background:#e6f6fb;color:var(--teal)}
.os .os-tsmall h4{font-family:'Sora','Poppins',sans-serif;font-size:1.02rem;font-weight:700;margin:0 0 4px}
.os .os-tsmall p{margin:0 0 10px;color:var(--slate);font-size:.82rem;line-height:1.5}
.os .os-tsmall a{font-weight:700;font-size:.82rem;color:var(--blue);text-decoration:none}
/* quick answer */
.os .os-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.os .os-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.os .os-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.os .os-qa strong{color:var(--ink)}
.os .os-sec{padding:48px 0}
.os .os-sh{text-align:center;max-width:680px;margin:0 auto 28px}
.os .os-sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.os .os-sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}
.os .os-sh p{color:var(--slate);margin:0}
.os .os-twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.os .os-tscroll{overflow-x:auto}
.os table{width:100%;border-collapse:collapse;min-width:640px}
.os th,.os td{padding:15px 18px;text-align:left;font-size:.92rem}
.os thead th{background:var(--soft);color:var(--blue-700);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.os tbody tr{border-top:1px solid var(--line);transition:background .2s}.os tbody tr:hover{background:var(--soft)}
.os td .rt{font-weight:700;color:var(--ink)}
.os td .pr{font-family:'Sora','Poppins',sans-serif;font-weight:700;color:var(--ink)}.os td .pr small{display:block;font-weight:600;font-size:.66rem;color:var(--mute);letter-spacing:.04em;text-transform:uppercase}
.os td a{color:var(--blue);font-weight:700;text-decoration:none}
.os .os-tnote{text-align:center;font-size:.8rem;color:var(--slate);margin-top:12px}
/* circuits */
.os .os-cgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:16px}
.os .os-ccard{position:relative;display:flex;flex-direction:column;gap:8px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:22px 20px;text-decoration:none;color:var(--ink);overflow:hidden;transition:transform .35s,box-shadow .35s,border-color .35s}
.os .os-ccard::after{content:"";position:absolute;left:0;top:0;height:3px;width:100%;background:linear-gradient(90deg,#e11d48,#f59e0b);transform:scaleX(0);transform-origin:left;transition:transform .4s}
.os .os-ccard:hover{transform:translateY(-6px);box-shadow:0 24px 48px -24px rgba(9,32,84,.3);border-color:#f3c0cf}
.os .os-ccard:hover::after{transform:scaleX(1)}
.os .os-cico{width:48px;height:48px;border-radius:13px;background:#fde7ec;color:#e11d48;display:grid;place-items:center;font-size:1.1rem;transition:transform .35s}
.os .os-ccard:hover .os-cico{transform:scale(1.08) rotate(-5deg)}
.os .os-ccard .cd{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#e11d48}
.os .os-ccard h3{font-family:'Sora','Poppins',sans-serif;font-size:1.06rem;font-weight:700;margin:0}
.os .os-ccard p{margin:0;color:var(--slate);font-size:.85rem;line-height:1.5;flex:1}
.os .os-rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.os .os-rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.os .os-rchip i{color:var(--blue)}.os .os-rchip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px);box-shadow:0 12px 24px -14px rgba(0,87,255,.4)}
.os .os-inc{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;max-width:920px;margin:0 auto}
.os .os-iitem{display:flex;gap:12px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.os .os-iitem i{color:var(--green);margin-top:3px}
.os .os-iitem p{margin:0;color:#33415c;font-size:.9rem;line-height:1.55}
.os .os-fbox{max-width:820px;margin:0 auto}
.os .os-fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden;transition:border-color .3s,box-shadow .3s}.os .os-fi:hover{border-color:#cfe0ff}
.os .os-fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.os .os-ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.os .os-fi.open .os-ft{transform:rotate(45deg)}
.os .os-fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.os .os-fi.open .os-fb{max-height:380px;padding:0 20px 18px}
.os .os-soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.os .os-cta{padding:0 0 70px}
.os .os-ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px;position:relative;overflow:hidden}
.os .os-cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.os .os-cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.os .os-cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.os .os-cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s,filter .2s}
.os .os-cta .w{background:#fff;color:#0057ff}.os .os-cta .g{background:#25d366;color:#04260f}.os .os-cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
.os .os-cta a:hover{transform:translateY(-2px)}
@media(max-width:900px){.os .os-hero{grid-template-columns:1fr;gap:24px}.os .os-trip{position:static}}
@media(max-width:520px){.os .os-trow2{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.os *{transition:none!important;animation:none!important}.os .rv{opacity:1!important;transform:none!important}}
</style>

<div class="os">
<div class="os-in">
<nav class="os-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Outstation Taxi</span></nav>

<section class="os-hero">
<div class="rv">
<span class="os-eyebrow"><i class="fa-solid fa-route"></i> One-way · round-trip · multi-day</span>
<h1 class="disp">Outstation taxi from <em>Dehradun</em> — One Way Drops &amp; Round Trips</h1>
<p class="os-lead"><strong>Outstation taxi fares from Dehradun start around ₹900 for a one-way sedan drop.</strong> Anaya Cab Service runs verified drivers and clean AC cabs to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital, Chandigarh and the Char Dham circuit — as a one-way drop, a round trip, or a multi-day tour with the same trusted driver.</p>
<div class="os-trust">
<span><i class="fa-solid fa-circle-check"></i> One-way drops</span>
<span><i class="fa-solid fa-circle-check"></i> Same driver round-trip</span>
<span><i class="fa-solid fa-circle-check"></i> Hill &amp; yatra ready</span>
<span><i class="fa-solid fa-circle-check"></i> No hidden charges</span>
</div>
<div class="os-herocta">
<a class="os-btn os-btn-b" href="/#booking"><i class="fa-solid fa-taxi"></i> Book outstation cab</a>
<a class="os-btn os-btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want an outstation taxi from Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Get fare on WhatsApp</a>
<a class="os-btn os-btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> <?php echo $phone; ?></a>
</div>
</div>
<aside class="os-trip rv" aria-label="Trip types">
<div class="os-tbig">
<span class="tag"><i class="fa-solid fa-arrow-right-long"></i> Most booked</span>
<h3 class="disp">One-way taxi</h3>
<p>Pay only for the drop side — ideal when you are not returning the same day. Direct door-to-door to any city.</p>
<div class="os-road" aria-hidden="true"><i class="fa-solid fa-car-side"></i></div>
<a href="/#booking"><i class="fa-solid fa-taxi"></i> Book one-way</a>
</div>
<div class="os-trow2">
<div class="os-tsmall r">
<div class="ic"><i class="fa-solid fa-rotate"></i></div>
<h4>Round trip</h4>
<p>Same cab and driver for the return — economical when you need the cab for both sides.</p>
<a href="/#booking">Book round trip →</a>
</div>
<div class="os-tsmall m">
<div class="ic"><i class="fa-solid fa-calendar-days"></i></div>
<h4>Multi-day tour</h4>
<p>Per-day billing for yatra and holiday circuits with the vehicle kept with you.</p>
<a href="/char-dham-yatra-taxi">Plan a tour →</a>
</div>
</div>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="os-qa rv" itemscope itemtype="https://schema.org/Answer">
<div class="ey"><i class="fa-solid fa-bolt"></i> Direct Answer &middot; Outstation Taxi from Dehradun</div>
<p itemprop="text"><strong>Anaya Cab Service</strong> provides 24x7 outstation taxi service from Dehradun as <strong>one-way drops (starting at ₹1,000)</strong>, <strong>round trips</strong> with the same verified driver, and <strong>multi-day hill &amp; yatra circuits</strong>. Popular fixed fares: Rishikesh (₹1,000), Mussoorie (₹1,200), Haridwar (₹1,350), Delhi NCR (₹3,500), Chandigarh (₹4,000), and Nainital (₹5,500). Clean AC Sedans, Ertiga, Innova Crysta, and Tempo Travellers available with zero surge pricing.</p>
</div>
</div>

<!-- FARES -->
<section class="os-sec rv"><div class="os-in">
<div class="os-sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Indicative fares</span><h2 class="disp">Popular one-way outstation fares</h2><p>Sedan starting fares with SUV and Innova guidance — final fare confirmed before you book.</p></div>
<div class="os-twrap"><div class="os-tscroll">
<table aria-label="Outstation taxi fares from Dehradun by route and vehicle">
<thead><tr><th>Route</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova / Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr"><small>from</small>₹<?php echo $f[2]; ?></td><td class="pr"><small>from</small>₹<?php echo $f[3]; ?></td><td class="pr"><small>from</small>₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
<p class="os-tnote">Toll, parking, state permits &amp; night halt charges extra where applicable. Final fare shared on booking — no hidden fees.</p>
</div></section>

<!-- CIRCUITS -->
<section class="os-sec os-soft rv"><div class="os-in">
<div class="os-sh"><span class="ey"><i class="fa-solid fa-map"></i> Multi-day circuits</span><h2 class="disp">Popular tour circuits from Dehradun</h2><p>Keep the same cab and driver throughout — billed per day plus running kilometres.</p></div>
<div class="os-cgrid">
<?php foreach ($__circuits as $c): ?>
<a class="os-ccard rv" href="<?php echo $c[3]; ?>">
<div class="os-cico"><i class="fa-solid <?php echo $c[4]; ?>"></i></div>
<span class="cd"><?php echo $c[1]; ?></span>
<h3><?php echo $c[0]; ?></h3>
<p><?php echo $c[2]; ?></p>
</a>
<?php endforeach; ?>
</div>
</div></section>

<!-- ROUTES -->
<section class="os-sec rv"><div class="os-in">
<div class="os-sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Where we go</span><h2 class="disp">Popular outstation routes</h2></div>
<div class="os-rchips">
<?php foreach ($__routes as $r): ?>
<a class="os-rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> Dehradun → <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</div></section>

<!-- INCLUDED -->
<section class="os-sec os-soft rv"><div class="os-in">
<div class="os-sh"><span class="ey"><i class="fa-solid fa-circle-check"></i> What is included</span><h2 class="disp">Every outstation booking includes</h2></div>
<div class="os-inc">
<div class="os-iitem rv"><i class="fa-solid fa-circle-check"></i><p>Fuel, driver allowance and the vehicle for the agreed route.</p></div>
<div class="os-iitem rv"><i class="fa-solid fa-circle-check"></i><p>Experienced hill-route drivers and clean, sanitised AC cars.</p></div>
<div class="os-iitem rv"><i class="fa-solid fa-circle-check"></i><p>Fare confirmed before booking — no hidden charges.</p></div>
<div class="os-iitem rv"><i class="fa-solid fa-circle-check"></i><p>24×7 support by call and WhatsApp throughout the trip.</p></div>
</div>
</div></section>

<!-- FAQ -->
<section class="os-sec rv" id="faq"><div class="os-in">
<div class="os-sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Outstation taxi — FAQs</h2></div>
<div class="os-fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="os-fi<?php echo $i===0?' open':''; ?>"><div class="os-fh"><?php echo htmlspecialchars($f[0]); ?><span class="os-ft"><i class="fa-solid fa-plus"></i></span></div><div class="os-fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</div></section>

<!-- CTA -->
<section class="os-cta rv"><div class="os-in">
<div class="os-ctain">
<h2 class="disp">Planning an outstation trip from Dehradun?</h2>
<p>Share route, date, vehicle and trip type — we confirm the exact fare on WhatsApp.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book outstation cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want an outstation taxi from Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.os .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.os .os-fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

