<?php
/**
 * Anaya Cab Service --- OPcache Clear Tool
 * Deploy ke BAAD ye kholo taaki purana compiled PHP cache hat jaye
 * aur naya code turant live dikhe (Hostinger opcache gotcha).
 * URL: https://www.taxidehradun.com/clear-opcache  (ya /clear-opcache.php)
 * Security: admin password (session-based, ek baar login = poore session one-click).
 */

require_once __DIR__ . '/includes/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$authenticated = false;
$auth_error = '';

if (isset($_SESSION['opcache_auth']) && $_SESSION['opcache_auth'] === true) {
    $authenticated = true;
}

if (!$authenticated && isset($_POST['opcache_password'])) {
    $submitted = trim((string)$_POST['opcache_password']);
    if (hash_equals(ADMIN_PASSWORD, $submitted)) {
        $_SESSION['opcache_auth'] = true;
        $authenticated = true;
    } else {
        $auth_error = 'Galat password. Dobara try karo.';
    }
}

/* ---------- LOGIN SCREEN ---------- */
if (!$authenticated) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>OPcache Clear | Anaya Cab</title>
        <style>
            * { margin:0; padding:0; box-sizing:border-box; }
            body {
                font-family:'Plus Jakarta Sans', sans-serif;
                background:#0A1633; color:#F5F8FF;
                display:flex; align-items:center; justify-content:center;
                min-height:100vh; padding:20px;
            }
            .login-box {
                background:#111f42; border:1px solid #E3EAF8;
                border-radius:16px; padding:36px; width:100%; max-width:380px;
            }
            .login-box h1 { font-family:'Sora',sans-serif; font-size:1.3rem; margin-bottom:8px; }
            .login-box p { color:#5B6B8C; font-size:0.9rem; margin-bottom:20px; }
            .login-box input {
                width:100%; padding:12px 14px; border-radius:10px;
                border:1px solid #E3EAF8; background:#0A1633; color:#F5F8FF;
                font-size:1rem; margin-bottom:14px;
            }
            .login-box button {
                width:100%; padding:12px; border:none; border-radius:10px;
                background:#0057FF; color:#fff; font-weight:700; font-size:1rem;
                cursor:pointer;
            }
            .err { color:#ff6b6b; font-size:0.85rem; margin-bottom:12px; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h1>⚡ OPcache Clear</h1>
            <p>Admin password daalo — deploy ke baad purana PHP cache hat jayega.</p>
            <?php if ($auth_error !== '') { echo '<div class="err">' . htmlspecialchars($auth_error) . '</div>'; } ?>
            <form method="post">
                <input type="password" name="opcache_password" placeholder="Admin password" required>
                <button type="submit">Clear Cache</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/* ---------- CLEAR LOGIC ---------- */
$has_fn = function_exists('opcache_reset');
$enabled = $has_fn && (bool)ini_get('opcache.enable');
$script_count = 0;
$cleared = false;

if ($enabled) {
    $status = opcache_get_status(false);
    if (is_array($status) && isset($status['opcache_statistics']['num_cached_scripts'])) {
        $script_count = (int)$status['opcache_statistics']['num_cached_scripts'];
    }
    $cleared = opcache_reset();
}

clearstatcache(true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>OPcache Cleared | Anaya Cab</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
        font-family:'Plus Jakarta Sans', sans-serif;
        background:#0A1633; color:#F5F8FF;
        display:flex; align-items:center; justify-content:center;
        min-height:100vh; padding:20px;
    }
    .box {
        background:#111f42; border:1px solid #E3EAF8;
        border-radius:16px; padding:36px; width:100%; max-width:440px; text-align:center;
    }
    .box h1 { font-family:'Sora',sans-serif; font-size:1.4rem; margin-bottom:18px; }
    .row {
        display:flex; justify-content:space-between; align-items:center;
        background:#0A1633; border:1px solid #1c2c55; border-radius:10px;
        padding:12px 16px; margin-bottom:10px; font-size:0.9rem;
    }
    .row .lbl { color:#5B6B8C; }
    .ok { color:#2ee59d; font-weight:700; }
    .warn { color:#fcd34d; font-weight:700; }
    .note {
        margin-top:18px; background:rgba(0,87,255,0.1); border-left:3px solid #0057FF;
        padding:12px 14px; border-radius:8px; font-size:0.85rem; color:#c9d6f5; text-align:left;
    }
    a.back { display:inline-block; margin-top:16px; color:#00C2FF; font-weight:700; text-decoration:none; font-size:0.9rem; }
</style>
</head>
<body>
<div class="box">
    <h1>⚡ OPcache Status</h1>

    <div class="row">
        <span class="lbl">OPcache enabled?</span>
        <?php if ($enabled) { echo '<span class="ok">YES</span>'; } else { echo '<span class="warn">NO</span>'; } ?>
    </div>

    <div class="row">
        <span class="lbl">Cached scripts pehle</span>
        <span class="ok"><?php echo $script_count; ?></span>
    </div>

    <div class="row">
        <span class="lbl">Reset result</span>
        <?php
        if (!$has_fn) { echo '<span class="warn">Function missing</span>'; }
        elseif (!$enabled) { echo '<span class="warn">Not enabled (kuch clear nahi karna tha)</span>'; }
        elseif ($cleared) { echo '<span class="ok">SUCCESS ✅</span>'; }
        else { echo '<span class="warn">Reset failed</span>'; }
        ?>
    </div>

    <div class="note">
        💡 Ab live page pe <strong>Ctrl + Shift + R</strong> (hard refresh) karo.
        OPcache disabled ho to bhi tension nahi — har deploy turant live hota hai.
    </div>

    <a class="back" href="/">← Wapas site pe</a>
</div>
</body>
</html>