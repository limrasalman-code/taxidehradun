<?php
require_once __DIR__ . '/includes/config.php';
$V = [
'slug'=>'suv-taxi-in-dehradun','name'=>'SUV Taxi in Dehradun','short'=>'SUV','cls'=>'MUV / SUV · Ertiga',
'char'=>'MUV / SUV · Ertiga','char_icon'=>'fa-car-rear','glyph'=>'fa-car-rear','img'=>'/assets/images/fleet/ertiga.webp',
'ac'=>'#7c3aed','ac2'=>'#b69bff','d1'=>'#1e1240','d2'=>'#33245e','tint'=>'#f1e9fe',
'headline'=>'Room for the family, and the bags',
'lead'=>'Book an SUV taxi in Dehradun when a sedan is too small — the Maruti Ertiga gives you six to seven seats and a roomy boot for family trips, hill routes, airport transfers with luggage and small-group outstation travel, all at a fare that stays budget-friendly.',
'pax'=>'6–7','bags'=>'4','rate_range'=>'₹16 – ₹19 / km','pkg4'=>'₹1,350','pkg8'=>'₹2,300',
'service_type'=>'SUV / MUV cab booking','offers_price'=>'16','offer_desc'=>'SUV taxi in Dehradun available from approx. ₹16 per km depending on vehicle, route and availability.',
'area'=>['Dehradun','Mussoorie','Nainital','Rishikesh','Haridwar','Char Dham'],
'best_for'=>[
['fa-user-group','Family trips','Six to seven seats and extra boot space — the easy choice for family outings and weekend getaways.'],
['fa-mountain-sun','Hill routes on a budget','More stability and comfort than a sedan for Mussoorie, Nainital and hill drives.'],
['fa-plane-departure','Airport with luggage','Jolly Grant pickup and drop when you are travelling with suitcases and kids.'],
['fa-people-group','Small-group outstation','Haridwar, Rishikesh, Delhi and multi-stop tours without splitting into two cabs.'],
],
'compare_title'=>'Ertiga vs Innova vs sedan',
'compare'=>[['Maruti Ertiga','6–7 passengers','Budget family & hill space'],['Toyota Innova','6–7 passengers','Premium comfort & long routes'],['Sedan (Dzire)','4 passengers','Budget local & airport']],
'routes'=>[['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi'],['Dehradun → Nainital','/dehradun-to-nainital-taxi'],['Char Dham Yatra','/char-dham-yatra-taxi'],['Jolly Grant Airport','/dehradun-airport-taxi-service'],['Outstation taxi','/outstation-taxi-from-dehradun'],['Dehradun → Haridwar','/dehradun-to-haridwar-taxi']],
'use_cases'=>['Family travel','Hill & yatra routes','Airport with luggage','Small-group tours','Weekend getaways'],
'faqs'=>[
['Which SUV taxis are available in Dehradun?','SUV and MUV options include the Maruti Suzuki Ertiga, with the Toyota Innova and Innova Crysta available when you need premium comfort on hill and long routes.'],
['Is an SUV taxi better for hill routes?','Yes, SUVs are preferred for hill routes and family trips because they offer more space, comfort and stability on long journeys than a sedan.'],
['Can I book an SUV for Char Dham Yatra?','Yes, SUVs like the Ertiga and Innova are commonly used for Char Dham Yatra, Do Dham Yatra and multi-day Uttarakhand tours.'],
],
'title'=>'SUV Taxi in Dehradun | Ertiga, Innova & Hill Route Cab - Anaya Cab',
'desc'=>'Book SUV taxi in Dehradun for family trips, hill routes, airport transfers, Char Dham Yatra and outstation travel. Ertiga, Innova and Crysta options. Call '.BUSINESS_PHONE.'.',
];
$page_url = SITE_DOMAIN . '/' . $V['slug'];
$__faq_ent = [];
foreach ($V['faqs'] as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$__area = []; foreach ($V['area'] as $c) { $__area[] = ['@type'=>'City','name'=>$c]; }
$__svc = ['@type'=>'Service','@id'=>$page_url.'#service','name'=>$V['name'],'serviceType'=>$V['service_type'],'provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>$__area,'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>$V['offers_price'],'description'=>$V['offer_desc']]];
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[$__svc,['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent]]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
$page_title = $V['title']; $page_description = $V['desc'];
require_once __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/vehicle-premium.css?v=2">
<main id="main">
<div class="vp" style="--vp-ac:<?php echo $V['ac']; ?>;--vp-ac2:<?php echo $V['ac2']; ?>;--vp-d1:<?php echo $V['d1']; ?>;--vp-d2:<?php echo $V['d2']; ?>;--vp-tint:<?php echo $V['tint']; ?>;">
<div class="vp-in">
<nav class="vp-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/fleet">Fleet</a><i class="fa-solid fa-chevron-right"></i><span class="cur"><?php echo htmlspecialchars($V['name']); ?></span></nav>
<section class="vp-hero">
<div class="rv">
<span class="vp-ey"><i class="fa-solid <?php echo $V['char_icon']; ?>"></i> <?php echo htmlspecialchars($V['char']); ?></span>
<h1 class="disp"><?php echo htmlspecialchars($V['headline']); ?></h1>
<p class="vp-lead"><strong><?php echo htmlspecialchars($V['lead']); ?></strong></p>
<div class="vp-metrics">
<span class="vp-m"><i class="fa-solid fa-user-group"></i><b><?php echo htmlspecialchars($V['pax']); ?></b><span>passengers</span></span>
<span class="vp-m"><i class="fa-solid fa-suitcase-rolling"></i><b><?php echo htmlspecialchars($V['bags']); ?></b><span>luggage</span></span>
<span class="vp-m"><i class="fa-solid fa-snowflake"></i><b>AC</b><span>sanitised</span></span>
<span class="vp-m"><i class="fa-solid fa-indian-rupee-sign"></i><b><?php echo htmlspecialchars($V['rate_range']); ?></b><span>base fare</span></span>
</div>
<div class="vp-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book <?php echo htmlspecialchars($V['short']); ?></a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="/pricing"><i class="fa-solid fa-tags"></i> See fares</a>
</div>
</div>
<aside class="card rv" aria-label="<?php echo htmlspecialchars($V['name']); ?> fare and specs">
<span class="badge"><i class="fa-solid fa-star"></i> Available now</span>
<div class="stage">
<span class="floatchip"><?php echo htmlspecialchars($V['cls']); ?></span>
<img src="<?php echo htmlspecialchars($V['img']); ?>" alt="<?php echo htmlspecialchars($V['name']); ?> in Dehradun" width="1200" height="675" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">
<i class="fa-solid <?php echo $V['glyph']; ?> glyph" style="display:none"></i>
</div>
<div class="disp" style="font-size:1.15rem;font-weight:800;margin:0 0 10px;line-height:1.2"><?php echo htmlspecialchars($V['cls']); ?></div>
<p class="cat"><?php echo htmlspecialchars($V['name']); ?></p>
<div class="specs">
<span><i class="fa-solid fa-user-group"></i> <?php echo htmlspecialchars($V['pax']); ?> Pax</span>
<span><i class="fa-solid fa-suitcase-rolling"></i> <?php echo htmlspecialchars($V['bags']); ?> Bags</span>
<span><i class="fa-solid fa-snowflake"></i> AC</span>
<span><i class="fa-solid fa-gauge-high"></i> <?php echo htmlspecialchars($V['rate_range']); ?></span>
</div>
<div class="rate"><?php echo htmlspecialchars($V['rate_range']); ?> <small>base fare</small></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
</div>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-bullseye"></i> Best for</span><h2 class="disp">Where this cab shines</h2></div>
<div class="bento">
<?php foreach ($V['best_for'] as $i => $b): $big=($i===0); ?>
<div class="bc rv<?php echo $big?' big':''; ?>"><div class="vi"><i class="fa-solid <?php echo $b[0]; ?>"></i></div><h3><?php echo htmlspecialchars($b[1]); ?></h3><p><?php echo htmlspecialchars($b[2]); ?></p></div>
<?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-receipt"></i> Fare guide</span><h2 class="disp"><?php echo htmlspecialchars($V['cls']); ?> fare at a glance</h2><p>Per-km and hourly packages — final fare confirmed before you travel.</p></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> fare guide">
<thead><tr><th>Plan</th><th>What you get</th><th>Fare</th></tr></thead>
<tbody>
<tr><td>Per kilometre</td><td>Local &amp; outstation, metered by route</td><td class="fare"><?php echo htmlspecialchars($V['rate_range']); ?></td></tr>
<tr><td>4 Hr / 40 Km</td><td>City errands, airport + short sightseeing</td><td class="fare"><?php echo htmlspecialchars($V['pkg4']); ?></td></tr>
<tr><td>8 Hr / 80 Km</td><td>Full-day local or short outstation</td><td class="fare"><?php echo htmlspecialchars($V['pkg8']); ?></td></tr>
</tbody></table></div></div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-scale-balanced"></i> Compare</span><h2 class="disp"><?php echo htmlspecialchars($V['compare_title']); ?></h2></div>
<div class="tw rv"><div class="ts"><table aria-label="<?php echo htmlspecialchars($V['name']); ?> comparison">
<thead><tr><th>Vehicle</th><th>Capacity</th><th>Best for</th></tr></thead>
<tbody>
<?php foreach ($V['compare'] as $c): ?><tr><td><strong><?php echo htmlspecialchars($c[0]); ?></strong></td><td><?php echo htmlspecialchars($c[1]); ?></td><td><?php echo htmlspecialchars($c[2]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div></section>
<section class="sec soft"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular routes</span><h2 class="disp">Routes travellers book</h2></div>
<div class="chips rv">
<?php foreach ($V['routes'] as $r): ?><a class="chip" href="<?php echo htmlspecialchars($r[1]); ?>"><i class="fa-solid fa-location-dot"></i> <?php echo htmlspecialchars($r[0]); ?></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-wand-magic-sparkles"></i> Good to know</span><h2 class="disp">This cab is ideal for</h2></div>
<div class="uchips rv">
<?php foreach ($V['use_cases'] as $u): ?><span class="uchip"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($u); ?></span><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="vp-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp"><?php echo htmlspecialchars($V['name']); ?> — FAQs</h2></div>
<div class="fbox">
<?php foreach ($V['faqs'] as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="vp-in"><div class="ctain">
<h2 class="disp">Ready to book the <?php echo htmlspecialchars($V['short']); ?>?</h2>
<p>Share your route, date and luggage — we confirm a transparent fare before the trip.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want to book '.$V['name'].'.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.vp .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.vp .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>