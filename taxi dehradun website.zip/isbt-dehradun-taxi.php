<?php
require_once __DIR__ . '/includes/config.php';
$page_title       = "ISBT Dehradun Taxi | Cab Pickup from Bus Stand - Anaya Cab";
$page_description = "Book taxi from ISBT Dehradun for local city drops, railway station, Jolly Grant Airport, Mussoorie, Rishikesh and Haridwar.";
$page_url         = SITE_DOMAIN . "/isbt-dehradun-taxi";
/* Single source: schema + visible FAQ isi array se => exact-match, drift impossible. */
$__faqs = [
['Can I book a taxi from ISBT Dehradun?', 'Yes, taxi pickup is available from ISBT Dehradun for local city drops, the railway station, Jolly Grant Airport and outstation destinations.'],
['Is late-night pickup available from ISBT Dehradun?', 'Yes, late-night and early-morning pickup from ISBT Dehradun can be arranged with advance booking.'],
['Can I go from ISBT Dehradun to Mussoorie by taxi?', 'Yes, direct taxi service from ISBT Dehradun to Mussoorie is available in sedan, SUV and Innova options.'],
];
$__faq_ent = [];
foreach ($__faqs as $f) { $__faq_ent[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'ISBT Dehradun Taxi','serviceType'=>'Bus stand taxi pickup and drop','provider'=>['@id'=>SITE_DOMAIN.'/#taxi-service'],'areaServed'=>[['@type'=>'Place','name'=>'ISBT Dehradun'],['@type'=>'City','name'=>'Dehradun'],['@type'=>'Airport','name'=>'Jolly Grant Airport'],['@type'=>'City','name'=>'Mussoorie'],['@type'=>'City','name'=>'Rishikesh'],['@type'=>'City','name'=>'Haridwar']],'url'=>$page_url,'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'800','availability'=>'https://schema.org/InStock','description'=>'Taxi from ISBT Dehradun available for local and outstation drops. Fare depends on route and vehicle.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_ent],
]], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
$__routes = [
['fa-train','ISBT → Railway Station','Train connection, quick transfer','/dehradun-railway-station-taxi'],
['fa-plane-departure','ISBT → Jolly Grant Airport','Flight-time aware pickup','/dehradun-airport-taxi-service'],
['fa-mountain-sun','ISBT → Mussoorie','Hill station drop','/dehradun-to-mussoorie-taxi'],
['fa-water','ISBT → Rishikesh','Yoga & rafting trips','/dehradun-to-rishikesh-taxi'],
['fa-om','ISBT → Haridwar','Pilgrimage & family drop','/dehradun-to-haridwar-taxi'],
['fa-road','ISBT → Delhi','Long-distance outstation','/dehradun-to-delhi-taxi'],
];
$__expect = [
['fa-bus','Bus arrives','We track the schedule and adjust the driver for delays so you never wait long.'],
['fa-location-dot','Exit-point meet','Your driver waits near the ISBT exit with your name on display.'],
['fa-suitcase-rolling','Luggage loaded','Help with bags into the boot before you set off.'],
['fa-flag-checkered','Drop-off','At your hotel, station, airport or outstation destination.'],
];
$__why = [
['fa-clock','24/7 booking','Call or WhatsApp any hour, day or night.'],
['fa-car-side','All vehicle types','Sedan, Ertiga, Innova and Tempo Traveller on request.'],
['fa-tags','Transparent fare','The quote we share is the fare you pay.'],
['fa-shield-halved','Verified drivers','Police-verified, ISBT-route experienced drivers.'],
];
?>
<main id="main">
<style>
.isbt{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue2:#00c2ff;--tint:#eaf1ff;--green:#16a34a;--radius:20px;--rsm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#fff 480px)}
.isbt *{box-sizing:border-box}
.isbt::before{content:"";position:absolute;top:-200px;right:-140px;width:560px;height:460px;border-radius:50%;background:radial-gradient(circle,rgba(0,87,255,.10),transparent 70%);pointer-events:none}
.isbt::after{content:"";position:absolute;top:420px;left:-160px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(0,194,255,.08),transparent 70%);pointer-events:none}
.isbt .isbt-in{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:0 22px}
.isbt .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.isbt .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.isbt .rv.in{opacity:1;transform:none}
.isbt .isbt-crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.isbt .isbt-crumb a{color:var(--slate);text-decoration:none}.isbt .isbt-crumb a:hover{color:var(--blue)}.isbt .isbt-crumb i{font-size:.6rem;color:var(--mute)}.isbt .isbt-crumb .cur{color:var(--ink);font-weight:600}
.isbt .isbt-hero{display:grid;grid-template-columns:1.15fr 1fr;gap:34px;align-items:start;padding:24px 0 12px}
.isbt .isbt-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--tint);padding:7px 13px;border-radius:999px}
.isbt .isbt-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.isbt .isbt-hero h1 em{font-style:normal;color:var(--blue)}
.isbt .isbt-lead{color:var(--slate);font-size:1.05rem;line-height:1.66;max-width:54ch;margin:0 0 18px}.isbt .isbt-lead strong{color:var(--ink)}
.isbt .isbt-trust{display:flex;flex-wrap:wrap;gap:10px 18px;margin:0 0 20px}.isbt .isbt-trust span{display:inline-flex;align-items:center;gap:8px;font-size:.88rem;font-weight:600;color:#33415c}.isbt .isbt-trust i{color:var(--green)}
.isbt .isbt-herocta{display:flex;gap:12px;flex-wrap:wrap}
.isbt .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--rsm);text-decoration:none;transition:transform .2s,box-shadow .3s,filter .2s}
.isbt .btn-a{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.isbt .btn-a:hover{transform:translateY(-2px);filter:brightness(1.06)}
.isbt .btn-g{background:#25d366;color:#04260f}.isbt .btn-g:hover{transform:translateY(-2px)}
.isbt .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.isbt .btn-o:hover{border-color:var(--blue);color:var(--blue)}
.isbt .isbt-card{position:sticky;top:88px;border-radius:24px;overflow:hidden;background:radial-gradient(120% 100% at 100% 0%,color-mix(in srgb,var(--blue2) 55%,transparent),transparent 60%),linear-gradient(160deg,#03102e,#0a2a63);color:#fff;box-shadow:0 30px 60px -28px rgba(3,16,46,.6);padding:26px}
.isbt .isbt-card .badge{display:inline-flex;align-items:center;gap:8px;font-size:.7rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;background:rgba(255,255,255,.16);padding:6px 12px;border-radius:999px}
.isbt .isbt-card .live{display:inline-flex;align-items:center;gap:7px;font-size:.72rem;font-weight:800;color:#9fe0ff;margin:12px 0 4px}.isbt .isbt-card .live::before{content:"";width:7px;height:7px;border-radius:50%;background:#38d6f0;animation:isbtp 1.8s infinite}
@keyframes isbtp{70%{box-shadow:0 0 0 7px rgba(56,214,240,0)}100%{box-shadow:0 0 0 0 rgba(56,214,240,0)}}
.isbt .isbt-card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.3rem;font-weight:800;margin:0 0 12px}
.isbt .isbt-fr{display:flex;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px;margin-bottom:8px;font-size:.9rem}.isbt .isbt-fr .v{font-weight:700}.isbt .isbt-fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.isbt .isbt-card .cta{display:grid;gap:10px;margin-top:14px}.isbt .isbt-card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none;transition:transform .2s}.isbt .isbt-card .cta .w{background:#fff;color:#0a2a63}.isbt .isbt-card .cta .g{background:#25d366;color:#04260f}.isbt .isbt-card .cta a:hover{transform:translateY(-2px)}
.isbt .isbt-qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.isbt .isbt-qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.isbt .isbt-qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.isbt .isbt-qa strong{color:var(--ink)}
.isbt .sec{padding:48px 0}.isbt .soft{background:linear-gradient(180deg,#eef3fb,#f7f9fc)}
.isbt .sh{text-align:center;max-width:700px;margin:0 auto 28px}.isbt .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--tint);padding:7px 13px;border-radius:999px}.isbt .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.isbt .sh p{color:var(--slate);margin:0}
.isbt .rt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
.isbt .rt{display:flex;gap:14px;align-items:flex-start;background:#fff;border:1px solid var(--line);border-radius:var(--rsm);padding:18px;text-decoration:none;color:var(--ink);transition:transform .3s,box-shadow .3s,border-color .3s}
.isbt .rt:hover{transform:translateY(-4px);box-shadow:0 16px 34px -22px rgba(9,32,84,.28);border-color:#cfe0ff}
.isbt .rt .ci{flex:none;width:44px;height:44px;border-radius:12px;background:var(--tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.isbt .rt b{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px;display:block}.isbt .rt span{color:var(--slate);font-size:.85rem}.isbt .rt .chev{margin-left:auto;color:var(--mute);align-self:center}
.isbt .tl{max-width:780px;margin:0 auto}.isbt .tr{display:grid;grid-template-columns:46px 1fr;gap:16px;padding:0 0 18px}.isbt .tr .d{width:46px;height:46px;border-radius:13px;background:#fff;border:1px solid var(--line);display:grid;place-items:center;color:var(--blue);box-shadow:0 8px 18px -10px rgba(0,87,255,.3)}.isbt .tr .b{background:#fff;border:1px solid var(--line);border-radius:15px;padding:14px 17px}.isbt .tr .b h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.isbt .tr .b p{margin:0;color:var(--slate);font-size:.87rem}
.isbt .why-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.isbt .why{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:22px;transition:transform .3s,box-shadow .3s}.isbt .why:hover{transform:translateY(-5px);box-shadow:0 22px 46px -26px rgba(9,32,84,.3)}
.isbt .why .ic{width:48px;height:48px;border-radius:13px;background:var(--tint);color:var(--blue);display:grid;place-items:center;font-size:1.1rem;margin-bottom:12px}
.isbt .why h3{font-family:'Sora','Poppins',sans-serif;font-size:1.02rem;font-weight:700;margin:0 0 5px}.isbt .why p{margin:0;color:var(--slate);font-size:.88rem;line-height:1.55}
.isbt .fbox{max-width:820px;margin:0 auto}.isbt .fi{background:#fff;border:1px solid var(--line);border-radius:var(--rsm);margin-bottom:12px;overflow:hidden;transition:border-color .3s}.isbt .fi:hover{border-color:#cfe0ff}.isbt .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}.isbt .ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}.isbt .fi.open .ft{transform:rotate(45deg)}.isbt .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}.isbt .fi.open .fb{max-height:340px;padding:0 20px 18px}
.isbt .cta2{padding:0 0 70px}.isbt .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#1e4bff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px}.isbt .cta2 h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}.isbt .cta2 p{color:rgba(255,255,255,.84);margin:0 0 22px}.isbt .cta2 .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.isbt .cta2 a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none;transition:transform .2s}.isbt .cta2 .w{background:#fff;color:#0057ff}.isbt .cta2 .g{background:#25d366;color:#04260f}.isbt .cta2 .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}.isbt .cta2 a:hover{transform:translateY(-2px)}
@media(max-width:900px){.isbt .isbt-hero{grid-template-columns:1fr;gap:24px}.isbt .isbt-card{position:static}}
@media(prefers-reduced-motion:reduce){.isbt *{animation:none!important;transition:none!important}.isbt .rv{opacity:1!important;transform:none!important}}
</style>
<div class="isbt">
<div class="isbt-in">
<nav class="isbt-crumb" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span class="cur">ISBT Dehradun Taxi</span></nav>
<section class="isbt-hero">
<div class="rv">
<span class="isbt-ey"><i class="fa-solid fa-bus"></i> Bus stand pickup · 24/7</span>
<h1 class="disp">Taxi waiting at ISBT Dehradun, <em>the moment you arrive</em></h1>
<p class="isbt-lead"><strong>Pre-book a cab from ISBT Dehradun</strong> and skip the last-minute negotiation, luggage hassle and long wait after a tiring bus journey. We coordinate pickup near the bus-stand exit and take you anywhere — city drops, the railway station, Jolly Grant Airport, or outstation to Mussoorie, Rishikesh, Haridwar and Delhi.</p>
<div class="isbt-trust"><span><i class="fa-solid fa-circle-check"></i> Exit-point meet</span><span><i class="fa-solid fa-circle-check"></i> Verified drivers</span><span><i class="fa-solid fa-circle-check"></i> Fixed fare upfront</span></div>
<div class="isbt-herocta">
<a class="btn btn-a" href="/#booking"><i class="fa-solid fa-taxi"></i> Book ISBT pickup</a>
<a class="btn btn-g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from ISBT Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="btn btn-o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call</a>
</div>
</div>
<aside class="isbt-card rv" aria-label="ISBT Dehradun taxi fare">
<span class="badge"><i class="fa-solid fa-bus"></i> ISBT pickup</span>
<div class="live">Live fare desk</div>
<h3 class="disp">From ISBT Dehradun</h3>
<div class="isbt-fr"><span class="v">City drop</span><span class="p">From ₹300</span></div>
<div class="isbt-fr"><span class="v">Jolly Grant Airport</span><span class="p">From ₹800</span></div>
<div class="isbt-fr"><span class="v">Mussoorie / Rishikesh</span><span class="p">Route fare</span></div>
<div class="isbt-fr"><span class="v">Delhi / outstation</span><span class="p">Route fare</span></div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from ISBT Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</aside>
</section>
<div class="isbt-qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Yes — you can book a taxi from ISBT Dehradun</strong> for local city drops, the railway station, Jolly Grant Airport and outstation routes like Mussoorie, Rishikesh, Haridwar and Delhi. Anaya Cab Service runs 24/7 with verified drivers; share your bus arrival time and we coordinate pickup near the exit point with a fixed, upfront fare.</p>
</div>
</div>
<section class="sec"><div class="isbt-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-route"></i> Popular ISBT routes</span><h2 class="disp">Where do you need to go from ISBT?</h2><p>Direct taxi from the bus stand to these frequent destinations.</p></div>
<div class="rt-grid">
<?php foreach ($__routes as $r): ?><a class="rt rv" href="<?php echo $r[3]; ?>"><span class="ci"><i class="fa-solid <?php echo $r[0]; ?>"></i></span><div><b><?php echo htmlspecialchars($r[1]); ?></b><span><?php echo htmlspecialchars($r[2]); ?></span></div><i class="fa-solid fa-arrow-right chev"></i></a><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft"><div class="isbt-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-clock-rotate-left"></i> What to expect</span><h2 class="disp">How your ISBT pickup works</h2><p>From bus arrival to final drop — a coordinated, stress-free handover.</p></div>
<div class="tl">
<?php foreach ($__expect as $t): ?><div class="tr rv"><div class="d"><i class="fa-solid <?php echo $t[0]; ?>"></i></div><div class="b"><h3><?php echo htmlspecialchars($t[1]); ?></h3><p><?php echo htmlspecialchars($t[2]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="sec"><div class="isbt-in">
<div class="sh rv"><span class="ey"><i class="fa-solid fa-medal"></i> Why book ISBT pickup with us</span><h2 class="disp">One reliable team from the bus stand</h2></div>
<div class="why-grid">
<?php foreach ($__why as $w): ?><div class="why rv"><span class="ic"><i class="fa-solid <?php echo $w[0]; ?>"></i></span><h3><?php echo htmlspecialchars($w[1]); ?></h3><p><?php echo htmlspecialchars($w[2]); ?></p></div><?php endforeach; ?>
</div>
</div></section>
<section class="sec soft" id="faq"><div class="isbt-in">
<div class="sh rv"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">ISBT Dehradun Taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?><div class="fi rv<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div><?php endforeach; ?>
</div>
</div></section>
<section class="cta2 rv"><div class="isbt-in"><div class="ctain">
<h2 class="disp">Arriving at ISBT Dehradun?</h2>
<p>Share your bus arrival time, pickup point and destination — we confirm a transparent fare before you travel.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book pickup</a>
<a class="g" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want taxi pickup from ISBT Dehradun.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo BUSINESS_PHONE; ?></a>
</div>
</div></div></section>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.isbt .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.isbt .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>