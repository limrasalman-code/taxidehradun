<?php
require_once __DIR__ . '/includes/config.php';

$domain      = defined('SITE_DOMAIN') ? rtrim(SITE_DOMAIN, '/') : 'https://www.taxidehradun.com';
$phone       = defined('BUSINESS_PHONE') ? BUSINESS_PHONE : '+91 80776 11583';
$phone_tel   = defined('BUSINESS_PHONE_TEL') ? BUSINESS_PHONE_TEL : '+918077611583';
$whatsapp    = defined('BUSINESS_WHATSAPP') ? BUSINESS_WHATSAPP : '918077611583';

$page_title = 'Dehradun to Chandigarh Taxi | Sedan from ₹4,000';
$page_description = 'Dehradun to Chandigarh taxi: 210 km, sedan ₹4,000, Ertiga ₹5,000, Crysta ₹6,000. Mohali & Panchkula drops. Fixed fares, 24x7.';
$page_url         = $domain . "/dehradun-to-chandigarh-taxi";

$__faqs = [
["How far is Chandigarh from Dehradun by taxi?", "The distance from Dehradun to Chandigarh is approximately 210 km via Paonta Sahib / Nahan highway, taking around 4.5 to 5 hours."],
["What is the one-way taxi fare from Dehradun to Chandigarh?", "One-way sedan taxi fare from Dehradun to Chandigarh starts at ₹4,000 for a Dzire, ₹5,000 for an Ertiga (SUV), and ₹6,000 for an Innova Crysta."],
["Do you drop at Chandigarh Airport (IXC) and Mohali?", "Yes. We offer direct door-to-door drops to Shaheed Bhagat Singh Chandigarh International Airport (IXC), Mohali IT Park, and Panchkula."],
];

$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]]; }

$page_schema = '<script type="application/ld+json">'
. json_encode(['@context'=>'https://schema.org','@graph'=>[
  ['@type'=>'Service','@id'=>$page_url.'#service','name'=>'Dehradun to Chandigarh Taxi Service','serviceType'=>'Outstation highway taxi transfer','description'=>'One-way and round-trip taxi from Dehradun to Chandigarh, Mohali, and Panchkula over 210 km with verified drivers and fixed fares.','provider'=>['@type'=>'TaxiService','name'=>'Anaya Cab Service','telephone'=>$phone_tel,'url'=>$domain.'/'],'areaServed'=>[['@type'=>'City','name'=>'Dehradun'],['@type'=>'City','name'=>'Chandigarh'],['@type'=>'City','name'=>'Mohali']],'offers'=>['@type'=>'Offer','priceCurrency'=>'INR','price'=>'4000','description'=>'One way sedan taxi fare from Dehradun to Chandigarh starts from 4,000 rupees.']],
  ['@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities],
]], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
. '</script>';

require_once __DIR__ . '/includes/header.php';

$__fares = [
['Dehradun → Chandigarh Sector 17 / City','~210 km','4,000','5,000','6,000','/dehradun-to-chandigarh-taxi'],
['Dehradun → Chandigarh Airport (IXC)','~205 km','4,200','5,200','6,200','/dehradun-to-chandigarh-taxi'],
['Dehradun → Mohali IT Park','~215 km','4,100','5,100','6,100','/dehradun-to-chandigarh-taxi'],
['Dehradun → Panchkula Sector 5','~195 km','3,900','4,900','5,900','/dehradun-to-chandigarh-taxi'],
];

$__sights = [
['Chandigarh Airport (IXC)','fa-plane-departure','Direct transfers to Chandigarh International Airport for flights.'],
['Mohali IT Park & Stadium','fa-building-user','Corporate travel to Mohali tech hubs and PCA Stadium.'],
['Panchkula Sectors','fa-city','Residential and commercial drops across Panchkula.'],
['Rock Garden & Elante Mall','fa-tree','Local sightseeing drops at Rock Garden, Sukhna Lake, and Elante.'],
];

$__related = [
['Dehradun → Shimla','/dehradun-to-shimla-taxi','fa-mountain'],['Dehradun → Delhi','/dehradun-to-delhi-taxi','fa-road'],
['Dehradun → Haridwar','/dehradun-to-haridwar-taxi','fa-om'],['Dehradun → Mussoorie','/dehradun-to-mussoorie-taxi','fa-mountain-sun'],
];
?>
<main id="main">
<style>
.ch{--ink:#0b1220;--slate:#5b6577;--mute:#94a3b8;--line:#e7edf6;--blue:#0057ff;--blue-tint:#eaf1ff;--soft:#f5f8ff;--radius:20px;--radius-sm:14px;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink);position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#ffffff 440px)}
.ch *{box-sizing:border-box}
.ch .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.ch .wrap{max-width:1180px;margin:0 auto;padding:0 22px}
.ch .rv{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}.ch .rv.in{opacity:1;transform:none}
.ch .crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:.82rem;color:var(--slate);padding:30px 0 0}.ch .crumb a{color:var(--slate);text-decoration:none}.ch .crumb a:hover{color:var(--blue)}.ch .crumb i{font-size:.6rem;color:var(--mute)}.ch .crumb .cur{color:var(--ink);font-weight:600}
.ch .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:start;padding:24px 0 10px}
.ch .eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.ch .hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(2rem,4.6vw,3.1rem);font-weight:800;letter-spacing:-.035em;line-height:1.04;margin:14px 0 14px}.ch .hero h1 em{font-style:normal;color:var(--blue)}
.ch .lead{color:var(--slate);font-size:1.06rem;line-height:1.66;max-width:56ch;margin:0 0 16px}.ch .lead strong{color:var(--ink)}
.ch .metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 20px}
.ch .m{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 15px}
.ch .m i{color:var(--blue)}.ch .m b{font-family:'Sora','Poppins',sans-serif;font-weight:800;color:var(--ink)}.ch .m span{font-size:.8rem;color:var(--slate)}
.ch .herocta{display:flex;gap:12px;flex-wrap:wrap}
.ch .btn{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:var(--radius-sm);text-decoration:none;transition:transform .2s}
.ch .btn-p{background:var(--blue);color:#fff;box-shadow:0 16px 34px -14px rgba(0,87,255,.55)}.ch .btn-p:hover{transform:translateY(-2px)}
.ch .btn-g{background:#25d366;color:#04260f;box-shadow:0 14px 30px -14px rgba(37,211,102,.6)}.ch .btn-g:hover{transform:translateY(-2px)}
.ch .btn-o{background:#fff;color:var(--ink);border:1px solid var(--line)}.ch .btn-o:hover{border-color:var(--blue);color:var(--blue)}
.ch .card{position:sticky;top:88px;background:linear-gradient(160deg,#03102e,#0057ff);border-radius:24px;padding:24px;color:#fff;box-shadow:0 30px 60px -28px rgba(0,87,255,.5);overflow:hidden}
.ch .card .tag{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;color:#c9f7dd;background:rgba(255,255,255,.12);padding:6px 12px;border-radius:999px}
.ch .card h3{font-family:'Sora','Poppins',sans-serif;font-size:1.2rem;font-weight:800;margin:14px 0 14px}
.ch .fares{display:grid;gap:8px;margin:14px 0 0}
.ch .fr{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:11px 14px}
.ch .fr .v{font-weight:700;font-size:.9rem}.ch .fr .p{font-family:'Sora','Poppins',sans-serif;font-weight:800}
.ch .card .cta{display:grid;gap:10px;margin-top:16px}
.ch .card .cta a{display:flex;align-items:center;justify-content:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.9rem;padding:12px;border-radius:12px;text-decoration:none}
.ch .card .cta .w{background:#fff;color:var(--blue)}.ch .card .cta .g{background:#25d366;color:#04260f}
.ch .qa{margin:30px 0 6px;background:#fff;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:16px;padding:20px 22px;box-shadow:0 1px 2px rgba(11,18,32,.04),0 18px 40px -26px rgba(9,32,84,.25)}
.ch .qa .ey{display:inline-flex;align-items:center;gap:8px;font-size:.68rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);margin-bottom:8px}
.ch .qa p{margin:0;color:#33415c;line-height:1.66;font-size:.98rem}.ch .qa strong{color:var(--ink)}
.ch .sec{padding:48px 0}
.ch .sh{text-align:center;max-width:680px;margin:0 auto 28px}
.ch .sh .ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:var(--blue-tint);padding:7px 13px;border-radius:999px}
.ch .sh h2{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.03em;margin:12px 0 6px}.ch .sh p{color:var(--slate);margin:0}
.ch .sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.ch .sitem{display:flex;gap:14px;background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:18px}
.ch .sico{flex:none;width:44px;height:44px;border-radius:12px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:1rem}
.ch .sitem h3{font-family:'Sora','Poppins',sans-serif;font-size:.98rem;font-weight:700;margin:0 0 3px}.ch .sitem p{margin:0;color:var(--slate);font-size:.86rem;line-height:1.55}
.ch .twrap{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:0 1px 2px rgba(11,18,32,.04),0 24px 50px -30px rgba(9,32,84,.25)}
.ch .tscroll{overflow-x:auto}
.ch table{width:100%;border-collapse:collapse;min-width:560px}
.ch th,.ch td{padding:15px 18px;text-align:left;font-size:.92rem}
.ch thead th{background:var(--soft);color:var(--blue);font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.78rem;letter-spacing:.02em}
.ch tbody tr{border-top:1px solid var(--line)}
.ch .rchips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}
.ch .rchip{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:12px 18px;font-weight:600;font-size:.92rem;color:var(--ink);text-decoration:none;transition:.25s}
.ch .rchip i{color:var(--blue)}.ch .rchip:hover{border-color:var(--blue);color:var(--blue);transform:translateY(-2px)}
.ch .fbox{max-width:820px;margin:0 auto}
.ch .fi{background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);margin-bottom:12px;overflow:hidden}
.ch .fh{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 20px;font-family:'Sora','Poppins',sans-serif;font-weight:600;font-size:1rem;cursor:pointer}
.ch .ft{flex:none;width:26px;height:26px;border-radius:8px;background:var(--blue-tint);color:var(--blue);display:grid;place-items:center;font-size:.82rem;transition:transform .3s}
.ch .fi.open .ft{transform:rotate(45deg)}
.ch .fb{max-height:0;overflow:hidden;color:var(--slate);font-size:.93rem;line-height:1.66;padding:0 20px;transition:max-height .4s,padding .4s}
.ch .fi.open .fb{max-height:380px;padding:0 20px 18px}
.ch .soft{background:linear-gradient(180deg,#eef3fb,#f6f9ff)}
.ch .cta{padding:0 0 70px}
.ch .ctain{border-radius:28px;background:radial-gradient(120% 140% at 90% 0%,#0057ff,transparent 55%),linear-gradient(120deg,#03102e,#0057ff);color:#fff;text-align:center;padding:50px 24px}
.ch .cta h2{font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.1rem);letter-spacing:-.03em;margin:0 0 8px}
.ch .cta p{color:rgba(255,255,255,.84);margin:0 0 22px}
.ch .cta .row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.ch .cta a{display:inline-flex;align-items:center;gap:9px;font-family:'Sora','Poppins',sans-serif;font-weight:700;font-size:.92rem;padding:13px 22px;border-radius:13px;text-decoration:none}
.ch .cta .w{background:#fff;color:var(--blue)}.ch .cta .g{background:#25d366;color:#04260f}.ch .cta .o{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media(max-width:900px){.ch .hero{grid-template-columns:1fr;gap:24px}.ch .card{position:static}}
</style>

<div class="ch">
<div class="wrap">
<nav class="crumb rv"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><a href="/services">Services</a><i class="fa-solid fa-chevron-right"></i><span class="cur">Dehradun to Chandigarh Taxi</span></nav>

<section class="hero">
<div class="rv">
<span class="eyebrow"><i class="fa-solid fa-road"></i> Highway Route · 210 km</span>
<h1 class="disp">Dehradun to Chandigarh <em>taxi service</em> — Mohali &amp; Airport Drops</h1>
<p class="lead"><strong>Dehradun to Chandigarh taxi fare starts from ₹4,000 for a sedan.</strong> Anaya Cab Service offers direct door-to-door drops to Chandigarh Sector 17, Mohali IT Park, Panchkula, and Chandigarh Airport (IXC) with verified drivers and fixed transparent rates.</p>
<div class="metrics">
<span class="m"><i class="fa-solid fa-road"></i> <b>210 km</b> <span>distance</span></span>
<span class="m"><i class="fa-regular fa-clock"></i> <b>4.5–5 hr</b> <span>drive time</span></span>
<span class="m"><i class="fa-solid fa-plane"></i> <b>IXC Airport</b> <span>direct drop</span></span>
<span class="m"><i class="fa-solid fa-indian-rupee-sign"></i> <b>₹4,000+</b> <span>sedan</span></span>
</div>
<div class="herocta">
<a class="btn btn-p" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Chandigarh cab</a>
<a class="btn btn-g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chandigarh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
<a class="btn btn-o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
<aside class="card rv" aria-label="Dehradun to Chandigarh fare">
<span class="tag"><i class="fa-solid fa-road"></i> Highway fare</span>
<h3 class="disp">Dehradun → Chandigarh</h3>
<div class="fares">
<div class="fr"><span class="v">Sedan (Dzire)</span><span class="p">₹4,000</span></div>
<div class="fr"><span class="v">SUV (Ertiga)</span><span class="p">₹5,000</span></div>
<div class="fr"><span class="v">Innova Crysta</span><span class="p">₹6,000</span></div>
</div>
<div class="cta">
<a class="w" href="/#booking"><i class="fa-solid fa-calendar-check"></i> Book now</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chandigarh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp fare</a>
</div>
<p class="note">One-way or round-trip · 24×7 availability</p>
</aside>
</section>

<!-- QUICK ANSWER (GEO / AEO Magnet) -->
<div class="qa rv">
<div class="ey"><i class="fa-solid fa-bolt"></i> Quick answer</div>
<p><strong>Anaya Cab Service</strong> operates daily <strong>Dehradun to Chandigarh taxi service</strong> (~210 km, 4.5 hours drive via Paonta Sahib) with fixed fares starting at <strong>₹4,000 for Sedan</strong> (Dzire), <strong>₹5,000 for SUV</strong> (Ertiga), and <strong>₹6,000 for Innova Crysta</strong>. Direct door-to-door drops to Chandigarh City, Mohali IT Park, Panchkula, and IXC Airport.</p>
</div>

<!-- FARES -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-indian-rupee-sign"></i> Fare table</span><h2 class="disp">Dehradun to Chandigarh taxi fares by drop location</h2></div>
<div class="twrap"><div class="tscroll">
<table aria-label="Dehradun to Chandigarh taxi fares">
<thead><tr><th>Destination</th><th>Distance</th><th>Sedan</th><th>SUV / Ertiga</th><th>Innova Crysta</th><th></th></tr></thead>
<tbody>
<?php foreach ($__fares as $f): ?>
<tr><td class="rt"><?php echo $f[0]; ?></td><td><?php echo $f[1]; ?></td><td class="pr">₹<?php echo $f[2]; ?></td><td class="pr">₹<?php echo $f[3]; ?></td><td class="pr">₹<?php echo $f[4]; ?></td><td><a href="<?php echo $f[5]; ?>">Details →</a></td></tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div>
</section>

<!-- SIGHTS -->
<section class="sec soft rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-location-dot"></i> Popular drops</span><h2 class="disp">Where we drop passengers in Chandigarh / Tricity</h2></div>
<div class="sgrid">
<?php foreach ($__sights as $s): ?>
<div class="sitem rv"><span class="sico"><i class="fa-solid <?php echo $s[1]; ?>"></i></span><div><h3><?php echo $s[0]; ?></h3><p><?php echo $s[2]; ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- RELATED -->
<section class="sec rv">
<div class="sh"><span class="ey"><i class="fa-solid fa-arrows-turn-right"></i> Related routes</span><h2 class="disp">Other popular routes</h2></div>
<div class="rchips">
<?php foreach ($__related as $r): ?>
<a class="rchip" href="<?php echo $r[1]; ?>"><i class="fa-solid <?php echo $r[2]; ?>"></i> <?php echo $r[0]; ?></a>
<?php endforeach; ?>
</div>
</section>

<!-- FAQ -->
<section class="sec soft rv" id="faq">
<div class="sh"><span class="ey"><i class="fa-regular fa-circle-question"></i> FAQs</span><h2 class="disp">Dehradun to Chandigarh taxi — FAQs</h2></div>
<div class="fbox">
<?php foreach ($__faqs as $i => $f): ?>
<div class="fi<?php echo $i===0?' open':''; ?>"><div class="fh"><?php echo htmlspecialchars($f[0]); ?><span class="ft"><i class="fa-solid fa-plus"></i></span></div><div class="fb"><p style="padding-top:2px"><?php echo htmlspecialchars($f[1]); ?></p></div></div>
<?php endforeach; ?>
</div>
</section>

<!-- CTA -->
<section class="cta rv">
<div class="ctain">
<h2 class="disp">Heading to Chandigarh or Mohali? Book your cab now</h2>
<p>Fixed fare, verified driver, and direct door-to-door pickup — confirm in under a minute.</p>
<div class="row">
<a class="w" href="/#booking"><i class="fa-solid fa-taxi"></i> Book Chandigarh cab</a>
<a class="g" href="https://wa.me/<?php echo $whatsapp; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I want a Dehradun to Chandigarh taxi.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
<a class="o" href="tel:<?php echo $phone_tel; ?>"><i class="fa-solid fa-phone"></i> Call <?php echo $phone; ?></a>
</div>
</div>
</section>

</div>
</div>
</main>
<script>
(function(){
var r=document.querySelectorAll('.ch .rv');
if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -5% 0px'});r.forEach(function(e){o.observe(e);});}else{r.forEach(function(e){e.classList.add('in');});}
document.querySelectorAll('.ch .fh').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>

