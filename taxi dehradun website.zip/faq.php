﻿<?php
require_once __DIR__ . '/includes/config.php';
$page_title = "FAQs | Anaya Cab Service Dehradun - Booking Help";
$page_description = "Common questions about Anaya Cab Service: booking, fares, vehicle types, outstation trips, airport transfers and Char Dham Yatra taxi service in Dehradun.";
$page_url = SITE_DOMAIN . "/faq";
/* single-source FAQs (schema + visible dono yahin se) */
$__faqs = [
['Booking', 'Does Anaya Cab Service operate 24/7?', 'Yes, we offer 24/7 taxi service across Dehradun and Uttarakhand, including airport transfers and outstation trips at any hour.'],
['Booking', 'How do I book a taxi with Anaya Cab Service?', 'You can book by calling us directly, messaging on WhatsApp, or using the booking form on our homepage with your pickup and drop details.'],
['Booking', 'Can I cancel or reschedule a booking?', 'Yes, please call or WhatsApp us as early as possible to cancel or reschedule a booking so we can adjust driver and vehicle availability.'],
['Fares & Payment', 'How does pricing work?', 'Pricing is transparent and based on vehicle type, distance and trip duration. Local rides are charged per km or as hourly packages; outstation trips have fixed route-based fares. See our pricing page for details.'],
['Fares & Payment', 'Do you charge any advance for booking?', 'No advance is needed for most bookings. You pay the driver directly after your trip. Fares are fixed and shared upfront — no hidden charges.'],
['Fares & Payment', 'What payment methods do you accept?', 'We accept cash and major digital payment methods. Ask at the time of booking for current options.'],
['Vehicles', 'What vehicles are available?', 'Our fleet includes hatchbacks (Maruti Wagon R, Toyota Glanza), sedans (Maruti Suzuki Dzire, Toyota Etios), the Maruti Suzuki Ertiga MUV, the Toyota Innova Crysta SUV, and Tempo Travellers for larger groups.'],
['Vehicles', 'Are your drivers verified?', 'Yes, all our drivers are verified and experienced with local Dehradun routes as well as hill and highway driving.'],
['Routes & Outstation', 'Do you provide one-way outstation taxi service?', 'Yes, we offer one-way and round-trip outstation taxis to Haridwar, Rishikesh, Mussoorie, Delhi, Nainital and Char Dham destinations.'],
['Routes & Outstation', 'Can I book an airport transfer?', 'Yes, we offer reliable pickup and drop service to and from Dehradun Jolly Grant Airport, with flight-time tracking so your driver adjusts for delays.'],
['Yatra', 'Do you offer Char Dham Yatra packages?', 'Yes, we offer dedicated Char Dham Yatra taxi packages covering Yamunotri, Gangotri, Kedarnath and Badrinath, with experienced hill drivers.'],
['Yatra', 'Does the taxi go up to Kedarnath temple?', 'No. The taxi goes up to the permitted roadhead (such as Sonprayag/Gaurikund). The temple is reached on foot or by authorised helicopter, pony or palki service.'],
];
$__faq_entities = [];
foreach ($__faqs as $f) { $__faq_entities[] = ['@type'=>'Question','name'=>$f[1],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[2]]]; }
$page_schema = '<script type="application/ld+json">' . json_encode(['@context'=>'https://schema.org','@type'=>'FAQPage','@id'=>$page_url.'#faq','mainEntity'=>$__faq_entities], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>';
require_once __DIR__ . '/includes/header.php';
/* group by category, preserve order */
$__cats = [];
foreach ($__faqs as $f) { $__cats[$f[0]][] = [$f[1], $f[2]]; }
?>
<style>
.fq{--blue:#0057ff;--ink:#0b1220;--slate:#5b6577;--line:#e7edf6;font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:var(--ink)}
.fq .disp{font-family:'Sora','Poppins',sans-serif;letter-spacing:-.03em}
.fq-hero{position:relative;overflow:hidden;background:linear-gradient(180deg,#eef3fb 0%,#fff 460px);padding:44px 0 10px;text-align:center}
.fq-hero .fq-amb{position:absolute;inset:0;pointer-events:none;background-image:radial-gradient(rgba(0,87,255,.07) 1px,transparent 1.4px);background-size:28px 28px;-webkit-mask-image:radial-gradient(120% 80% at 50% 0%,#000,transparent 72%);mask-image:radial-gradient(120% 80% at 50% 0%,#000,transparent 72%)}
.fq-hero .container{position:relative;z-index:2}
.fq-ey{display:inline-flex;align-items:center;gap:8px;font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--blue);background:rgba(0,87,255,.08);padding:7px 13px;border-radius:999px}
.fq-hero h1{font-family:'Sora','Poppins',sans-serif;font-size:clamp(1.9rem,4.6vw,3rem);font-weight:800;letter-spacing:-.035em;margin:14px 0 10px}
.fq-hero p{color:var(--slate);font-size:1.05rem;max-width:56ch;margin:0 auto 22px}
.fq-search{max-width:520px;margin:0 auto;position:relative}
.fq-search i{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--blue);pointer-events:none}
.fq-search input{width:100%;padding:14px 16px 14px 44px;border:1.5px solid var(--line);border-radius:14px;font:inherit;font-size:.95rem;font-weight:600;background:#fff;transition:border .2s,box-shadow .2s}
.fq-search input:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 4px rgba(0,87,255,.12)}
.fq-sec{padding:40px 0}
.fq-cat{margin-bottom:34px}
.fq-cat-h{display:flex;align-items:center;gap:10px;font-family:'Sora','Poppins',sans-serif;font-weight:800;font-size:1.15rem;letter-spacing:-.02em;margin:0 0 16px}
.fq-cat-h .ic{flex:none;width:38px;height:38px;border-radius:11px;background:rgba(0,87,255,.08);color:var(--blue);display:grid;place-items:center;font-size:.95rem}
.fq-wrap{max-width:820px;margin:0 auto}
.fq-empty{display:none;text-align:center;color:var(--slate);padding:40px 0;font-weight:600}
.fq-empty.show{display:block}
.fq-rv{opacity:0;transform:translateY(22px);transition:opacity .7s cubic-bezier(.2,.7,.2,1),transform .7s cubic-bezier(.2,.7,.2,1)}
.fq-rv.in{opacity:1;transform:none}
.fq-cta{padding:0 0 64px}
@media(prefers-reduced-motion:reduce){.fq *{animation:none!important;transition:none!important}.fq-rv{opacity:1!important;transform:none!important}}
</style>

<div class="fq">
<section class="fq-hero">
<div class="fq-amb" aria-hidden="true"></div>
<div class="container">
<span class="fq-ey"><i class="fa-regular fa-circle-question"></i> Help centre</span>
<h1 class="disp">Frequently Asked Questions</h1>
<p>Everything about booking, fares, vehicles, routes and Char Dham Yatra — answered. Search a question or browse by topic.</p>
<div class="fq-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" id="fqSearch" placeholder="Search questions… e.g. fare, airport, Char Dham" aria-label="Search FAQs"></div>
</div>
</section>

<section class="fq-sec"><div class="container">
<div class="fq-wrap">
<?php
$catIcons = ['Booking'=>'fa-calendar-check','Fares & Payment'=>'fa-indian-rupee-sign','Vehicles'=>'fa-car-side','Routes & Outstation'=>'fa-route','Yatra'=>'fa-om'];
foreach ($__cats as $cat => $items): ?>
<div class="fq-cat fq-rv" data-cat>
<h2 class="fq-cat-h"><span class="ic"><i class="fa-solid <?php echo $catIcons[$cat] ?? 'fa-circle-question'; ?>"></i></span> <?php echo htmlspecialchars($cat); ?></h2>
<?php foreach ($items as $it): ?>
<div class="faq-item" data-faq data-q="<?php echo htmlspecialchars(strtolower($it[0] . ' ' . $it[1])); ?>">
<div class="faq-q"><?php echo htmlspecialchars($it[0]); ?><span class="faq-toggle">+</span></div>
<div class="faq-a"><?php echo htmlspecialchars($it[1]); ?></div>
</div>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<div class="fq-empty" id="fqEmpty"><i class="fa-solid fa-face-meh" style="font-size:1.6rem;display:block;margin-bottom:10px;"></i> Koi matching question nahi mila. Neeche call ya WhatsApp karo — hum turant jawab denge.</div>
</div>
</div></section>

<section class="fq-cta"><div class="container"><div class="cta-banner fq-rv">
<div><h2>Still have questions?</h2><p>Call or WhatsApp us anytime — we're happy to help with fares, routes and bookings.</p></div>
<div class="cta-actions" style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
<a class="btn btn-light" href="tel:<?php echo BUSINESS_PHONE_TEL; ?>"><i class="fa-solid fa-phone"></i> <?php echo BUSINESS_PHONE; ?></a>
<a class="btn btn-outline-light" href="https://wa.me/<?php echo BUSINESS_WHATSAPP; ?>?text=<?php echo rawurlencode('Hi Anaya Cab, I have a question.'); ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
</div>
</div></div></section>
</div>

<script>
(function(){
  document.querySelectorAll('.fq .faq-q').forEach(function(h){h.addEventListener('click',function(){h.parentElement.classList.toggle('open');});});
  var rv=document.querySelectorAll('.fq .fq-rv');
  if('IntersectionObserver' in window){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');o.unobserve(e.target);}});},{threshold:.08,rootMargin:'0px 0px -6% 0px'});rv.forEach(function(e){o.observe(e);});}else{rv.forEach(function(e){e.classList.add('in');});}
  /* live search filter */
  var s=document.getElementById('fqSearch'), empty=document.getElementById('fqEmpty');
  if(s){ s.addEventListener('input',function(){
    var q=s.value.trim().toLowerCase(); var any=false;
    document.querySelectorAll('[data-faq]').forEach(function(item){
      var hit = q==='' || item.getAttribute('data-q').indexOf(q)>-1;
      item.style.display = hit ? '' : 'none';
      if(hit) any=true;
    });
    document.querySelectorAll('[data-cat]').forEach(function(cat){
      var visible = cat.querySelectorAll('[data-faq][style*="none"]').length < cat.querySelectorAll('[data-faq]').length;
      cat.style.display = (q==='' || visible) ? '' : 'none';
    });
    empty.classList.toggle('show', !any && q!=='');
  }); }
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>